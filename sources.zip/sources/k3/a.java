package k3;

public abstract /* synthetic */ class a {
}
