package k1;

public abstract /* synthetic */ class m0 {
}
