package k1;

import android.net.Uri;
import androidx.media3.common.util.a;
import androidx.media3.common.util.b1;
import com.google.common.collect.e1;
import com.google.common.primitives.f;
import d1.h;
import d1.r;
import java.util.Map;
import k1.h;
import x1.n;
import y0.e0;

public final class l implements a0 {

    /* renamed from: a  reason: collision with root package name */
    private final Object f15097a = new Object();

    /* renamed from: b  reason: collision with root package name */
    private e0.f f15098b;

    /* renamed from: c  reason: collision with root package name */
    private x f15099c;

    /* renamed from: d  reason: collision with root package name */
    private h.a f15100d;

    /* renamed from: e  reason: collision with root package name */
    private String f15101e;

    /* renamed from: f  reason: collision with root package name */
    private n f15102f;

    private x b(e0.f fVar) {
        String str;
        h.a aVar = this.f15100d;
        if (aVar == null) {
            aVar = new r.b().c(this.f15101e);
        }
        Uri uri = fVar.f19674c;
        if (uri == null) {
            str = null;
        } else {
            str = uri.toString();
        }
        p0 p0Var = new p0(str, fVar.f19679h, aVar);
        e1 p10 = fVar.f19676e.entrySet().p();
        while (p10.hasNext()) {
            Map.Entry entry = (Map.Entry) p10.next();
            p0Var.e((String) entry.getKey(), (String) entry.getValue());
        }
        h.b f10 = new h.b().g(fVar.f19672a, o0.f15104d).d(fVar.f19677f).e(fVar.f19678g).f(f.n(fVar.f19681j));
        n nVar = this.f15102f;
        if (nVar != null) {
            f10.c(nVar);
        }
        h a10 = f10.a(p0Var);
        a10.F(0, fVar.d());
        return a10;
    }

    public x a(e0 e0Var) {
        x xVar;
        a.e(e0Var.f19617b);
        e0.f fVar = e0Var.f19617b.f19717c;
        if (fVar == null) {
            return x.f15136a;
        }
        synchronized (this.f15097a) {
            if (!b1.f(fVar, this.f15098b)) {
                this.f15098b = fVar;
                this.f15099c = b(fVar);
            }
            xVar = (x) a.e(this.f15099c);
        }
        return xVar;
    }
}
