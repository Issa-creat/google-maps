package k1;

import android.media.MediaDrmException;
import g1.b;
import h1.c4;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import k1.f0;

public final class c0 implements f0 {
    public Map a(byte[] bArr) {
        throw new IllegalStateException();
    }

    public f0.d b() {
        throw new IllegalStateException();
    }

    public b c(byte[] bArr) {
        throw new IllegalStateException();
    }

    public byte[] d() {
        throw new MediaDrmException("Attempting to open a session using a dummy ExoMediaDrm.");
    }

    public /* synthetic */ void e(byte[] bArr, c4 c4Var) {
        e0.a(this, bArr, c4Var);
    }

    public boolean f(byte[] bArr, String str) {
        throw new IllegalStateException();
    }

    public void g(byte[] bArr, byte[] bArr2) {
        throw new IllegalStateException();
    }

    public void h(byte[] bArr) {
    }

    public void i(f0.b bVar) {
    }

    public byte[] j(byte[] bArr, byte[] bArr2) {
        throw new IllegalStateException();
    }

    public void k(byte[] bArr) {
        throw new IllegalStateException();
    }

    public f0.a l(byte[] bArr, List list, int i10, HashMap hashMap) {
        throw new IllegalStateException();
    }

    public int m() {
        return 1;
    }

    public void release() {
    }
}
