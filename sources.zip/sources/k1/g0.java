package k1;

import androidx.media3.common.util.b1;
import g1.b;
import java.util.UUID;

public final class g0 implements b {

    /* renamed from: d  reason: collision with root package name */
    public static final boolean f15045d;

    /* renamed from: a  reason: collision with root package name */
    public final UUID f15046a;

    /* renamed from: b  reason: collision with root package name */
    public final byte[] f15047b;

    /* renamed from: c  reason: collision with root package name */
    public final boolean f15048c;

    static {
        boolean z10;
        if ("Amazon".equals(b1.f3697c)) {
            String str = b1.f3698d;
            if ("AFTM".equals(str) || "AFTB".equals(str)) {
                z10 = true;
                f15045d = z10;
            }
        }
        z10 = false;
        f15045d = z10;
    }

    public g0(UUID uuid, byte[] bArr, boolean z10) {
        this.f15046a = uuid;
        this.f15047b = bArr;
        this.f15048c = z10;
    }
}
