package k1;

public abstract /* synthetic */ class h0 {
}
