package k1;

import k1.v;
import k1.x;
import y0.y;

public abstract /* synthetic */ class w {
    public static x.b a(x xVar, v.a aVar, y yVar) {
        return x.b.f15137a;
    }

    public static void b(x xVar) {
    }

    public static void c(x xVar) {
    }
}
