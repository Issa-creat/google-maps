package k1;

import androidx.media3.common.util.j;
import k1.v;

public final /* synthetic */ class c implements j {

    /* renamed from: a  reason: collision with root package name */
    public final /* synthetic */ int f15005a;

    public /* synthetic */ c(int i10) {
        this.f15005a = i10;
    }

    public final void a(Object obj) {
        ((v.a) obj).k(this.f15005a);
    }
}
