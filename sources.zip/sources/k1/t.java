package k1;

import k1.v;

public final /* synthetic */ class t implements Runnable {

    /* renamed from: a  reason: collision with root package name */
    public final /* synthetic */ v.a f15126a;

    /* renamed from: w  reason: collision with root package name */
    public final /* synthetic */ v f15127w;

    public /* synthetic */ t(v.a aVar, v vVar) {
        this.f15126a = aVar;
        this.f15127w = vVar;
    }

    public final void run() {
        this.f15126a.o(this.f15127w);
    }
}
