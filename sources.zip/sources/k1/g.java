package k1;

import android.media.NotProvisionedException;
import android.os.Handler;
import android.os.HandlerThread;
import android.os.Looper;
import android.os.Message;
import android.os.SystemClock;
import android.util.Pair;
import androidx.media3.common.util.b1;
import androidx.media3.common.util.j;
import androidx.media3.common.util.k;
import androidx.media3.common.util.s;
import h1.c4;
import java.io.IOException;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import k1.f0;
import k1.n;
import k1.v;
import s1.b0;
import s1.y;
import x1.n;
import y0.l;

class g implements n {

    /* renamed from: a  reason: collision with root package name */
    public final List f15012a;

    /* renamed from: b  reason: collision with root package name */
    private final f0 f15013b;

    /* renamed from: c  reason: collision with root package name */
    private final a f15014c;

    /* renamed from: d  reason: collision with root package name */
    private final b f15015d;

    /* renamed from: e  reason: collision with root package name */
    private final int f15016e;

    /* renamed from: f  reason: collision with root package name */
    private final boolean f15017f;

    /* renamed from: g  reason: collision with root package name */
    private final boolean f15018g;

    /* renamed from: h  reason: collision with root package name */
    private final HashMap f15019h;

    /* renamed from: i  reason: collision with root package name */
    private final k f15020i;
    /* access modifiers changed from: private */

    /* renamed from: j  reason: collision with root package name */
    public final n f15021j;

    /* renamed from: k  reason: collision with root package name */
    private final c4 f15022k;
    /* access modifiers changed from: private */

    /* renamed from: l  reason: collision with root package name */
    public final r0 f15023l;
    /* access modifiers changed from: private */

    /* renamed from: m  reason: collision with root package name */
    public final UUID f15024m;

    /* renamed from: n  reason: collision with root package name */
    private final Looper f15025n;
    /* access modifiers changed from: private */

    /* renamed from: o  reason: collision with root package name */
    public final e f15026o;

    /* renamed from: p  reason: collision with root package name */
    private int f15027p;

    /* renamed from: q  reason: collision with root package name */
    private int f15028q;

    /* renamed from: r  reason: collision with root package name */
    private HandlerThread f15029r;

    /* renamed from: s  reason: collision with root package name */
    private c f15030s;

    /* renamed from: t  reason: collision with root package name */
    private g1.b f15031t;

    /* renamed from: u  reason: collision with root package name */
    private n.a f15032u;

    /* renamed from: v  reason: collision with root package name */
    private byte[] f15033v;

    /* renamed from: w  reason: collision with root package name */
    private byte[] f15034w;

    /* renamed from: x  reason: collision with root package name */
    private f0.a f15035x;

    /* renamed from: y  reason: collision with root package name */
    private f0.d f15036y;

    public interface a {
        void a(Exception exc, boolean z10);

        void b();

        void c(g gVar);
    }

    public interface b {
        void a(g gVar, int i10);

        void b(g gVar, int i10);
    }

    private class c extends Handler {

        /* renamed from: a  reason: collision with root package name */
        private boolean f15037a;

        public c(Looper looper) {
            super(looper);
        }

        private boolean a(Message message, s0 s0Var) {
            IOException iOException;
            s0 s0Var2 = s0Var;
            d dVar = (d) message.obj;
            if (!dVar.f15040b) {
                return false;
            }
            int i10 = dVar.f15043e + 1;
            dVar.f15043e = i10;
            if (i10 > g.this.f15021j.d(3)) {
                return false;
            }
            y yVar = new y(dVar.f15039a, s0Var2.f15122a, s0Var2.f15123w, s0Var2.f15124x, SystemClock.elapsedRealtime(), SystemClock.elapsedRealtime() - dVar.f15041c, s0Var2.f15125y);
            b0 b0Var = new b0(3);
            if (s0Var.getCause() instanceof IOException) {
                iOException = (IOException) s0Var.getCause();
            } else {
                iOException = new f(s0Var.getCause());
            }
            long b10 = g.this.f15021j.b(new n.c(yVar, b0Var, iOException, dVar.f15043e));
            if (b10 == -9223372036854775807L) {
                return false;
            }
            synchronized (this) {
                if (this.f15037a) {
                    return false;
                }
                sendMessageDelayed(Message.obtain(message), b10);
                return true;
            }
        }

        /* access modifiers changed from: package-private */
        public void b(int i10, Object obj, boolean z10) {
            obtainMessage(i10, new d(y.a(), z10, SystemClock.elapsedRealtime(), obj)).sendToTarget();
        }

        public synchronized void c() {
            removeCallbacksAndMessages((Object) null);
            this.f15037a = true;
        }

        /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r1v0, resolved type: k1.s0} */
        /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r1v11, resolved type: k1.s0} */
        /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r1v12, resolved type: k1.s0} */
        /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r1v13, resolved type: byte[]} */
        /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r1v14, resolved type: byte[]} */
        /* JADX WARNING: type inference failed for: r1v2, types: [java.lang.Throwable, java.lang.Exception] */
        /* JADX WARNING: Multi-variable type inference failed */
        /* JADX WARNING: Unknown variable types count: 1 */
        /* Code decompiled incorrectly, please refer to instructions dump. */
        public void handleMessage(android.os.Message r6) {
            /*
                r5 = this;
                java.lang.Object r0 = r6.obj
                k1.g$d r0 = (k1.g.d) r0
                int r1 = r6.what     // Catch:{ s0 -> 0x0045, Exception -> 0x003c }
                r2 = 1
                if (r1 == r2) goto L_0x0027
                r2 = 2
                if (r1 != r2) goto L_0x0021
                k1.g r1 = k1.g.this     // Catch:{ s0 -> 0x0045, Exception -> 0x003c }
                k1.r0 r1 = r1.f15023l     // Catch:{ s0 -> 0x0045, Exception -> 0x003c }
                k1.g r2 = k1.g.this     // Catch:{ s0 -> 0x0045, Exception -> 0x003c }
                java.util.UUID r2 = r2.f15024m     // Catch:{ s0 -> 0x0045, Exception -> 0x003c }
                java.lang.Object r3 = r0.f15042d     // Catch:{ s0 -> 0x0045, Exception -> 0x003c }
                k1.f0$a r3 = (k1.f0.a) r3     // Catch:{ s0 -> 0x0045, Exception -> 0x003c }
                byte[] r1 = r1.b(r2, r3)     // Catch:{ s0 -> 0x0045, Exception -> 0x003c }
                goto L_0x004d
            L_0x0021:
                java.lang.RuntimeException r1 = new java.lang.RuntimeException     // Catch:{ s0 -> 0x0045, Exception -> 0x003c }
                r1.<init>()     // Catch:{ s0 -> 0x0045, Exception -> 0x003c }
                throw r1     // Catch:{ s0 -> 0x0045, Exception -> 0x003c }
            L_0x0027:
                k1.g r1 = k1.g.this     // Catch:{ s0 -> 0x0045, Exception -> 0x003c }
                k1.r0 r1 = r1.f15023l     // Catch:{ s0 -> 0x0045, Exception -> 0x003c }
                k1.g r2 = k1.g.this     // Catch:{ s0 -> 0x0045, Exception -> 0x003c }
                java.util.UUID r2 = r2.f15024m     // Catch:{ s0 -> 0x0045, Exception -> 0x003c }
                java.lang.Object r3 = r0.f15042d     // Catch:{ s0 -> 0x0045, Exception -> 0x003c }
                k1.f0$d r3 = (k1.f0.d) r3     // Catch:{ s0 -> 0x0045, Exception -> 0x003c }
                byte[] r1 = r1.a(r2, r3)     // Catch:{ s0 -> 0x0045, Exception -> 0x003c }
                goto L_0x004d
            L_0x003c:
                r1 = move-exception
                java.lang.String r2 = "DefaultDrmSession"
                java.lang.String r3 = "Key/provisioning request produced an unexpected exception. Not retrying."
                androidx.media3.common.util.s.j(r2, r3, r1)
                goto L_0x004d
            L_0x0045:
                r1 = move-exception
                boolean r2 = r5.a(r6, r1)
                if (r2 == 0) goto L_0x004d
                return
            L_0x004d:
                k1.g r2 = k1.g.this
                x1.n r2 = r2.f15021j
                long r3 = r0.f15039a
                r2.c(r3)
                monitor-enter(r5)
                boolean r2 = r5.f15037a     // Catch:{ all -> 0x0074 }
                if (r2 != 0) goto L_0x0072
                k1.g r2 = k1.g.this     // Catch:{ all -> 0x0074 }
                k1.g$e r2 = r2.f15026o     // Catch:{ all -> 0x0074 }
                int r6 = r6.what     // Catch:{ all -> 0x0074 }
                java.lang.Object r0 = r0.f15042d     // Catch:{ all -> 0x0074 }
                android.util.Pair r0 = android.util.Pair.create(r0, r1)     // Catch:{ all -> 0x0074 }
                android.os.Message r6 = r2.obtainMessage(r6, r0)     // Catch:{ all -> 0x0074 }
                r6.sendToTarget()     // Catch:{ all -> 0x0074 }
            L_0x0072:
                monitor-exit(r5)     // Catch:{ all -> 0x0074 }
                return
            L_0x0074:
                r6 = move-exception
                monitor-exit(r5)     // Catch:{ all -> 0x0074 }
                throw r6
            */
            throw new UnsupportedOperationException("Method not decompiled: k1.g.c.handleMessage(android.os.Message):void");
        }
    }

    private static final class d {

        /* renamed from: a  reason: collision with root package name */
        public final long f15039a;

        /* renamed from: b  reason: collision with root package name */
        public final boolean f15040b;

        /* renamed from: c  reason: collision with root package name */
        public final long f15041c;

        /* renamed from: d  reason: collision with root package name */
        public final Object f15042d;

        /* renamed from: e  reason: collision with root package name */
        public int f15043e;

        public d(long j10, boolean z10, long j11, Object obj) {
            this.f15039a = j10;
            this.f15040b = z10;
            this.f15041c = j11;
            this.f15042d = obj;
        }
    }

    private class e extends Handler {
        public e(Looper looper) {
            super(looper);
        }

        public void handleMessage(Message message) {
            Pair pair = (Pair) message.obj;
            Object obj = pair.first;
            Object obj2 = pair.second;
            int i10 = message.what;
            if (i10 == 1) {
                g.this.E(obj, obj2);
            } else if (i10 == 2) {
                g.this.y(obj, obj2);
            }
        }
    }

    public static final class f extends IOException {
        public f(Throwable th2) {
            super(th2);
        }
    }

    public g(UUID uuid, f0 f0Var, a aVar, b bVar, List list, int i10, boolean z10, boolean z11, byte[] bArr, HashMap hashMap, r0 r0Var, Looper looper, x1.n nVar, c4 c4Var) {
        if (i10 == 1 || i10 == 3) {
            androidx.media3.common.util.a.e(bArr);
        }
        this.f15024m = uuid;
        this.f15014c = aVar;
        this.f15015d = bVar;
        this.f15013b = f0Var;
        this.f15016e = i10;
        this.f15017f = z10;
        this.f15018g = z11;
        if (bArr != null) {
            this.f15034w = bArr;
            this.f15012a = null;
        } else {
            this.f15012a = Collections.unmodifiableList((List) androidx.media3.common.util.a.e(list));
        }
        this.f15019h = hashMap;
        this.f15023l = r0Var;
        this.f15020i = new k();
        this.f15021j = nVar;
        this.f15022k = c4Var;
        this.f15027p = 2;
        this.f15025n = looper;
        this.f15026o = new e(looper);
    }

    private void A() {
        if (this.f15016e == 0 && this.f15027p == 4) {
            b1.l(this.f15033v);
            r(false);
        }
    }

    /* access modifiers changed from: private */
    public void E(Object obj, Object obj2) {
        if (obj != this.f15036y) {
            return;
        }
        if (this.f15027p == 2 || u()) {
            this.f15036y = null;
            if (obj2 instanceof Exception) {
                this.f15014c.a((Exception) obj2, false);
                return;
            }
            try {
                this.f15013b.k((byte[]) obj2);
                this.f15014c.b();
            } catch (Exception e10) {
                this.f15014c.a(e10, true);
            }
        }
    }

    private boolean F() {
        if (u()) {
            return true;
        }
        try {
            byte[] d10 = this.f15013b.d();
            this.f15033v = d10;
            this.f15013b.e(d10, this.f15022k);
            this.f15031t = this.f15013b.c(this.f15033v);
            this.f15027p = 3;
            q(new c(3));
            androidx.media3.common.util.a.e(this.f15033v);
            return true;
        } catch (NotProvisionedException unused) {
            this.f15014c.c(this);
            return false;
        } catch (Exception | NoSuchMethodError e10) {
            if (b0.b(e10)) {
                this.f15014c.c(this);
                return false;
            }
            x(e10, 1);
            return false;
        }
    }

    private void G(byte[] bArr, int i10, boolean z10) {
        try {
            this.f15035x = this.f15013b.l(bArr, this.f15012a, i10, this.f15019h);
            ((c) b1.l(this.f15030s)).b(2, androidx.media3.common.util.a.e(this.f15035x), z10);
        } catch (Exception | NoSuchMethodError e10) {
            z(e10, true);
        }
    }

    private boolean I() {
        try {
            this.f15013b.g(this.f15033v, this.f15034w);
            return true;
        } catch (Exception | NoSuchMethodError e10) {
            x(e10, 1);
            return false;
        }
    }

    private void J() {
        if (Thread.currentThread() != this.f15025n.getThread()) {
            s.j("DefaultDrmSession", "DefaultDrmSession accessed on the wrong thread.\nCurrent thread: " + Thread.currentThread().getName() + "\nExpected thread: " + this.f15025n.getThread().getName(), new IllegalStateException());
        }
    }

    private void q(j jVar) {
        for (v.a a10 : this.f15020i.N()) {
            jVar.a(a10);
        }
    }

    private void r(boolean z10) {
        if (!this.f15018g) {
            byte[] bArr = (byte[]) b1.l(this.f15033v);
            int i10 = this.f15016e;
            if (i10 == 0 || i10 == 1) {
                if (this.f15034w == null) {
                    G(bArr, 1, z10);
                } else if (this.f15027p == 4 || I()) {
                    long s10 = s();
                    if (this.f15016e == 0 && s10 <= 60) {
                        s.b("DefaultDrmSession", "Offline license has expired or will expire soon. Remaining seconds: " + s10);
                        G(bArr, 2, z10);
                    } else if (s10 <= 0) {
                        x(new q0(), 2);
                    } else {
                        this.f15027p = 4;
                        q(new d());
                    }
                }
            } else if (i10 != 2) {
                if (i10 == 3) {
                    androidx.media3.common.util.a.e(this.f15034w);
                    androidx.media3.common.util.a.e(this.f15033v);
                    G(this.f15034w, 3, z10);
                }
            } else if (this.f15034w == null || I()) {
                G(bArr, 2, z10);
            }
        }
    }

    private long s() {
        if (!l.f19918d.equals(this.f15024m)) {
            return Long.MAX_VALUE;
        }
        Pair pair = (Pair) androidx.media3.common.util.a.e(u0.b(this));
        return Math.min(((Long) pair.first).longValue(), ((Long) pair.second).longValue());
    }

    private boolean u() {
        int i10 = this.f15027p;
        if (i10 == 3 || i10 == 4) {
            return true;
        }
        return false;
    }

    private void x(Throwable th2, int i10) {
        this.f15032u = new n.a(th2, b0.a(th2, i10));
        s.e("DefaultDrmSession", "DRM session error", th2);
        if (th2 instanceof Exception) {
            q(new b(th2));
        } else if (!(th2 instanceof Error)) {
            throw new IllegalStateException("Unexpected Throwable subclass", th2);
        } else if (!b0.c(th2) && !b0.b(th2)) {
            throw ((Error) th2);
        }
        if (this.f15027p != 4) {
            this.f15027p = 1;
        }
    }

    /* access modifiers changed from: private */
    public void y(Object obj, Object obj2) {
        if (obj == this.f15035x && u()) {
            this.f15035x = null;
            if ((obj2 instanceof Exception) || (obj2 instanceof NoSuchMethodError)) {
                z((Throwable) obj2, false);
                return;
            }
            try {
                byte[] bArr = (byte[]) obj2;
                if (this.f15016e == 3) {
                    this.f15013b.j((byte[]) b1.l(this.f15034w), bArr);
                    q(new e());
                    return;
                }
                byte[] j10 = this.f15013b.j(this.f15033v, bArr);
                int i10 = this.f15016e;
                if (!((i10 != 2 && (i10 != 0 || this.f15034w == null)) || j10 == null || j10.length == 0)) {
                    this.f15034w = j10;
                }
                this.f15027p = 4;
                q(new f());
            } catch (Exception | NoSuchMethodError e10) {
                z(e10, true);
            }
        }
    }

    private void z(Throwable th2, boolean z10) {
        int i10;
        if ((th2 instanceof NotProvisionedException) || b0.b(th2)) {
            this.f15014c.c(this);
            return;
        }
        if (z10) {
            i10 = 1;
        } else {
            i10 = 2;
        }
        x(th2, i10);
    }

    /* access modifiers changed from: package-private */
    public void B(int i10) {
        if (i10 == 2) {
            A();
        }
    }

    /* access modifiers changed from: package-private */
    public void C() {
        if (F()) {
            r(true);
        }
    }

    /* access modifiers changed from: package-private */
    public void D(Exception exc, boolean z10) {
        int i10;
        if (z10) {
            i10 = 1;
        } else {
            i10 = 3;
        }
        x(exc, i10);
    }

    /* access modifiers changed from: package-private */
    public void H() {
        this.f15036y = this.f15013b.b();
        ((c) b1.l(this.f15030s)).b(1, androidx.media3.common.util.a.e(this.f15036y), true);
    }

    public final UUID a() {
        J();
        return this.f15024m;
    }

    public void b(v.a aVar) {
        J();
        int i10 = this.f15028q;
        if (i10 <= 0) {
            s.d("DefaultDrmSession", "release() called on a session that's already fully released.");
            return;
        }
        int i11 = i10 - 1;
        this.f15028q = i11;
        if (i11 == 0) {
            this.f15027p = 0;
            ((e) b1.l(this.f15026o)).removeCallbacksAndMessages((Object) null);
            ((c) b1.l(this.f15030s)).c();
            this.f15030s = null;
            ((HandlerThread) b1.l(this.f15029r)).quit();
            this.f15029r = null;
            this.f15031t = null;
            this.f15032u = null;
            this.f15035x = null;
            this.f15036y = null;
            byte[] bArr = this.f15033v;
            if (bArr != null) {
                this.f15013b.h(bArr);
                this.f15033v = null;
            }
        }
        if (aVar != null) {
            this.f15020i.g(aVar);
            if (this.f15020i.f(aVar) == 0) {
                aVar.m();
            }
        }
        this.f15015d.a(this, this.f15028q);
    }

    public void c(v.a aVar) {
        J();
        boolean z10 = false;
        if (this.f15028q < 0) {
            s.d("DefaultDrmSession", "Session reference count less than zero: " + this.f15028q);
            this.f15028q = 0;
        }
        if (aVar != null) {
            this.f15020i.e(aVar);
        }
        int i10 = this.f15028q + 1;
        this.f15028q = i10;
        if (i10 == 1) {
            if (this.f15027p == 2) {
                z10 = true;
            }
            androidx.media3.common.util.a.g(z10);
            HandlerThread handlerThread = new HandlerThread("ExoPlayer:DrmRequestHandler");
            this.f15029r = handlerThread;
            handlerThread.start();
            this.f15030s = new c(this.f15029r.getLooper());
            if (F()) {
                r(true);
            }
        } else if (aVar != null && u() && this.f15020i.f(aVar) == 1) {
            aVar.k(this.f15027p);
        }
        this.f15015d.b(this, this.f15028q);
    }

    public boolean d() {
        J();
        return this.f15017f;
    }

    public Map e() {
        J();
        byte[] bArr = this.f15033v;
        if (bArr == null) {
            return null;
        }
        return this.f15013b.a(bArr);
    }

    public boolean f(String str) {
        J();
        return this.f15013b.f((byte[]) androidx.media3.common.util.a.i(this.f15033v), str);
    }

    public final n.a g() {
        J();
        if (this.f15027p == 1) {
            return this.f15032u;
        }
        return null;
    }

    public final int getState() {
        J();
        return this.f15027p;
    }

    public final g1.b h() {
        J();
        return this.f15031t;
    }

    public boolean t(byte[] bArr) {
        J();
        return Arrays.equals(this.f15033v, bArr);
    }
}
