package k1;

import androidx.media3.common.util.j;
import k1.v;

public final /* synthetic */ class f implements j {
    public final void a(Object obj) {
        ((v.a) obj).h();
    }
}
