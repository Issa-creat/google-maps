package k1;

import k1.h;

public final /* synthetic */ class i implements Runnable {

    /* renamed from: a  reason: collision with root package name */
    public final /* synthetic */ h.f f15091a;

    public /* synthetic */ i(h.f fVar) {
        this.f15091a = fVar;
    }

    public final void run() {
        this.f15091a.e();
    }
}
