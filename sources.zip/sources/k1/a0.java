package k1;

import y0.e0;

public interface a0 {
    x a(e0 e0Var);
}
