package k1;

import java.util.UUID;
import k1.f0;

public interface r0 {
    byte[] a(UUID uuid, f0.d dVar);

    byte[] b(UUID uuid, f0.a aVar);
}
