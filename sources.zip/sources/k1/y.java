package k1;

import k1.x;

public final /* synthetic */ class y implements x.b {
    public final void release() {
        z.a();
    }
}
