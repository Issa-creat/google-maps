package k1;

public final class q0 extends Exception {
}
