package k1;

import g1.b;
import java.io.IOException;
import java.util.Map;
import java.util.UUID;
import k1.v;

public interface n {

    public static class a extends IOException {

        /* renamed from: a  reason: collision with root package name */
        public final int f15103a;

        public a(Throwable th2, int i10) {
            super(th2);
            this.f15103a = i10;
        }
    }

    UUID a();

    void b(v.a aVar);

    void c(v.a aVar);

    boolean d();

    Map e();

    boolean f(String str);

    a g();

    int getState();

    b h();
}
