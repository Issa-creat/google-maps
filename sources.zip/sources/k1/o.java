package k1;

import s1.f0;

public abstract /* synthetic */ class o {
    public static void a(v vVar, int i10, f0.b bVar) {
    }
}
