package k1;

import h1.c4;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

public interface f0 {

    public static final class a {

        /* renamed from: a  reason: collision with root package name */
        private final byte[] f15007a;

        /* renamed from: b  reason: collision with root package name */
        private final String f15008b;

        /* renamed from: c  reason: collision with root package name */
        private final int f15009c;

        public a(byte[] bArr, String str, int i10) {
            this.f15007a = bArr;
            this.f15008b = str;
            this.f15009c = i10;
        }

        public byte[] a() {
            return this.f15007a;
        }

        public String b() {
            return this.f15008b;
        }
    }

    public interface b {
        void a(f0 f0Var, byte[] bArr, int i10, int i11, byte[] bArr2);
    }

    public interface c {
        f0 a(UUID uuid);
    }

    public static final class d {

        /* renamed from: a  reason: collision with root package name */
        private final byte[] f15010a;

        /* renamed from: b  reason: collision with root package name */
        private final String f15011b;

        public d(byte[] bArr, String str) {
            this.f15010a = bArr;
            this.f15011b = str;
        }

        public byte[] a() {
            return this.f15010a;
        }

        public String b() {
            return this.f15011b;
        }
    }

    Map a(byte[] bArr);

    d b();

    g1.b c(byte[] bArr);

    byte[] d();

    void e(byte[] bArr, c4 c4Var);

    boolean f(byte[] bArr, String str);

    void g(byte[] bArr, byte[] bArr2);

    void h(byte[] bArr);

    void i(b bVar);

    byte[] j(byte[] bArr, byte[] bArr2);

    void k(byte[] bArr);

    a l(byte[] bArr, List list, int i10, HashMap hashMap);

    int m();

    void release();
}
