package k1;

import k1.v;

public final /* synthetic */ class p implements Runnable {

    /* renamed from: a  reason: collision with root package name */
    public final /* synthetic */ v.a f15108a;

    /* renamed from: w  reason: collision with root package name */
    public final /* synthetic */ v f15109w;

    /* renamed from: x  reason: collision with root package name */
    public final /* synthetic */ int f15110x;

    public /* synthetic */ p(v.a aVar, v vVar, int i10) {
        this.f15108a = aVar;
        this.f15109w = vVar;
        this.f15110x = i10;
    }

    public final void run() {
        this.f15108a.q(this.f15109w, this.f15110x);
    }
}
