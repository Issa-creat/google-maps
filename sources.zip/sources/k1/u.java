package k1;

import k1.v;

public final /* synthetic */ class u implements Runnable {

    /* renamed from: a  reason: collision with root package name */
    public final /* synthetic */ v.a f15129a;

    /* renamed from: w  reason: collision with root package name */
    public final /* synthetic */ v f15130w;

    public /* synthetic */ u(v.a aVar, v vVar) {
        this.f15129a = aVar;
        this.f15130w = vVar;
    }

    public final void run() {
        this.f15129a.n(this.f15130w);
    }
}
