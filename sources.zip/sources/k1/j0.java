package k1;

import android.media.MediaDrm;
import k1.f0;

public final /* synthetic */ class j0 implements MediaDrm.OnEventListener {

    /* renamed from: a  reason: collision with root package name */
    public final /* synthetic */ o0 f15094a;

    /* renamed from: b  reason: collision with root package name */
    public final /* synthetic */ f0.b f15095b;

    public /* synthetic */ j0(o0 o0Var, f0.b bVar) {
        this.f15094a = o0Var;
        this.f15095b = bVar;
    }

    public final void onEvent(MediaDrm mediaDrm, byte[] bArr, int i10, int i11, byte[] bArr2) {
        this.f15094a.A(this.f15095b, mediaDrm, bArr, i10, i11, bArr2);
    }
}
