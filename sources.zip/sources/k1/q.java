package k1;

import k1.v;

public final /* synthetic */ class q implements Runnable {

    /* renamed from: a  reason: collision with root package name */
    public final /* synthetic */ v.a f15115a;

    /* renamed from: w  reason: collision with root package name */
    public final /* synthetic */ v f15116w;

    public /* synthetic */ q(v.a aVar, v vVar) {
        this.f15115a = aVar;
        this.f15116w = vVar;
    }

    public final void run() {
        this.f15115a.s(this.f15116w);
    }
}
