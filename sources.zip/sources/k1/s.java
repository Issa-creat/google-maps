package k1;

import k1.v;

public final /* synthetic */ class s implements Runnable {

    /* renamed from: a  reason: collision with root package name */
    public final /* synthetic */ v.a f15120a;

    /* renamed from: w  reason: collision with root package name */
    public final /* synthetic */ v f15121w;

    public /* synthetic */ s(v.a aVar, v vVar) {
        this.f15120a = aVar;
        this.f15121w = vVar;
    }

    public final void run() {
        this.f15120a.p(this.f15121w);
    }
}
