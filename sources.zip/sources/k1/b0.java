package k1;

import android.media.DeniedByServerException;
import android.media.MediaDrm;
import android.media.NotProvisionedException;
import androidx.media3.common.util.b1;
import h1.u3;
import k1.h;

public abstract class b0 {

    private static final class a {
        public static boolean a(Throwable th2) {
            return th2 instanceof MediaDrm.MediaDrmStateException;
        }

        public static int b(Throwable th2) {
            return b1.g0(b1.h0(((MediaDrm.MediaDrmStateException) th2).getDiagnosticInfo()));
        }
    }

    private static final class b {
        public static boolean a(Throwable th2) {
            return u3.a(th2);
        }
    }

    public static int a(Throwable th2, int i10) {
        int i11 = b1.f3695a;
        if (i11 >= 21 && a.a(th2)) {
            return a.b(th2);
        }
        if (i11 >= 23 && b.a(th2)) {
            return 6006;
        }
        if ((th2 instanceof NotProvisionedException) || b(th2)) {
            return 6002;
        }
        if (th2 instanceof DeniedByServerException) {
            return 6007;
        }
        if (th2 instanceof t0) {
            return 6001;
        }
        if (th2 instanceof h.e) {
            return 6003;
        }
        if (th2 instanceof q0) {
            return 6008;
        }
        if (i10 == 1) {
            return 6006;
        }
        if (i10 == 2) {
            return 6004;
        }
        if (i10 == 3) {
            return 6002;
        }
        throw new IllegalArgumentException();
    }

    public static boolean b(Throwable th2) {
        if (b1.f3695a != 34 || !(th2 instanceof NoSuchMethodError) || th2.getMessage() == null || !th2.getMessage().contains("Landroid/media/NotProvisionedException;.<init>(")) {
            return false;
        }
        return true;
    }

    public static boolean c(Throwable th2) {
        if (b1.f3695a != 34 || !(th2 instanceof NoSuchMethodError) || th2.getMessage() == null || !th2.getMessage().contains("Landroid/media/ResourceBusyException;.<init>(")) {
            return false;
        }
        return true;
    }
}
