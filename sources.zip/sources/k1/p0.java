package k1;

import android.net.Uri;
import android.text.TextUtils;
import androidx.media3.common.util.a;
import androidx.media3.common.util.b1;
import com.google.common.collect.a0;
import d1.f0;
import d1.h;
import d1.n;
import d1.p;
import d1.z;
import he.b;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import k1.f0;
import y0.l;

public final class p0 implements r0 {

    /* renamed from: a  reason: collision with root package name */
    private final h.a f15111a;

    /* renamed from: b  reason: collision with root package name */
    private final String f15112b;

    /* renamed from: c  reason: collision with root package name */
    private final boolean f15113c;

    /* renamed from: d  reason: collision with root package name */
    private final Map f15114d;

    public p0(String str, h.a aVar) {
        this(str, false, aVar);
    }

    private static byte[] c(h.a aVar, String str, byte[] bArr, Map map) {
        n nVar;
        f0 f0Var = new f0(aVar.a());
        p a10 = new p.b().j(str).e(map).d(2).c(bArr).b(1).a();
        int i10 = 0;
        p pVar = a10;
        while (true) {
            try {
                nVar = new n(f0Var, pVar);
                byte[] d10 = b.d(nVar);
                b1.p(nVar);
                return d10;
            } catch (z e10) {
                String d11 = d(e10, i10);
                if (d11 != null) {
                    i10++;
                    pVar = pVar.a().j(d11).a();
                    b1.p(nVar);
                } else {
                    throw e10;
                }
            } catch (Exception e11) {
                throw new s0(a10, (Uri) a.e(f0Var.q()), f0Var.i(), f0Var.p(), e11);
            } catch (Throwable th2) {
                b1.p(nVar);
                throw th2;
            }
        }
    }

    private static String d(z zVar, int i10) {
        boolean z10;
        Map map;
        List list;
        int i11 = zVar.f12237y;
        if ((i11 == 307 || i11 == 308) && i10 < 5) {
            z10 = true;
        } else {
            z10 = false;
        }
        if (z10 && (map = zVar.A) != null && (list = (List) map.get("Location")) != null && !list.isEmpty()) {
            return (String) list.get(0);
        }
        return null;
    }

    public byte[] a(UUID uuid, f0.d dVar) {
        return c(this.f15111a, dVar.b() + "&signedRequest=" + b1.L(dVar.a()), (byte[]) null, Collections.emptyMap());
    }

    public byte[] b(UUID uuid, f0.a aVar) {
        String str;
        String b10 = aVar.b();
        if (this.f15113c || TextUtils.isEmpty(b10)) {
            b10 = this.f15112b;
        }
        if (!TextUtils.isEmpty(b10)) {
            HashMap hashMap = new HashMap();
            UUID uuid2 = l.f19919e;
            if (uuid2.equals(uuid)) {
                str = "text/xml";
            } else if (l.f19917c.equals(uuid)) {
                str = "application/json";
            } else {
                str = "application/octet-stream";
            }
            hashMap.put("Content-Type", str);
            if (uuid2.equals(uuid)) {
                hashMap.put("SOAPAction", "http://schemas.microsoft.com/DRM/2007/03/protocols/AcquireLicense");
            }
            synchronized (this.f15114d) {
                hashMap.putAll(this.f15114d);
            }
            return c(this.f15111a, b10, aVar.a(), hashMap);
        }
        throw new s0(new p.b().i(Uri.EMPTY).a(), Uri.EMPTY, a0.k(), 0, new IllegalStateException("No license URL"));
    }

    public void e(String str, String str2) {
        a.e(str);
        a.e(str2);
        synchronized (this.f15114d) {
            this.f15114d.put(str, str2);
        }
    }

    public p0(String str, boolean z10, h.a aVar) {
        a.a(!z10 || !TextUtils.isEmpty(str));
        this.f15111a = aVar;
        this.f15112b = str;
        this.f15113c = z10;
        this.f15114d = new HashMap();
    }
}
