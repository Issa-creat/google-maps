package k1;

import android.os.Looper;
import h1.c4;
import k1.n;
import k1.v;
import y0.y;

public interface x {

    /* renamed from: a  reason: collision with root package name */
    public static final x f15136a = new a();

    class a implements x {
        a() {
        }

        public /* synthetic */ b a(v.a aVar, y yVar) {
            return w.a(this, aVar, yVar);
        }

        public n b(v.a aVar, y yVar) {
            if (yVar.f20075r == null) {
                return null;
            }
            return new d0(new n.a(new t0(1), 6001));
        }

        public void c(Looper looper, c4 c4Var) {
        }

        public int d(y yVar) {
            if (yVar.f20075r != null) {
                return 1;
            }
            return 0;
        }

        public /* synthetic */ void k() {
            w.b(this);
        }

        public /* synthetic */ void release() {
            w.c(this);
        }
    }

    public interface b {

        /* renamed from: a  reason: collision with root package name */
        public static final b f15137a = new y();

        void release();
    }

    b a(v.a aVar, y yVar);

    n b(v.a aVar, y yVar);

    void c(Looper looper, c4 c4Var);

    int d(y yVar);

    void k();

    void release();
}
