package k1;

import androidx.media3.common.util.j;
import k1.v;

public final /* synthetic */ class b implements j {

    /* renamed from: a  reason: collision with root package name */
    public final /* synthetic */ Throwable f15004a;

    public /* synthetic */ b(Throwable th2) {
        this.f15004a = th2;
    }

    public final void a(Object obj) {
        ((v.a) obj).l((Exception) this.f15004a);
    }
}
