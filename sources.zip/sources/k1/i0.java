package k1;

import java.util.UUID;
import k1.f0;

public final /* synthetic */ class i0 implements f0.c {
    public final f0 a(UUID uuid) {
        return o0.B(uuid);
    }
}
