package k1;

import android.media.MediaDrm;
import android.media.UnsupportedSchemeException;
import android.media.metrics.LogSessionId;
import android.text.TextUtils;
import androidx.media3.common.util.b1;
import androidx.media3.common.util.s;
import ge.d;
import h1.c4;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.nio.charset.Charset;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.UUID;
import k1.f0;
import v2.o;
import y0.l;
import y0.r;

public final class o0 implements f0 {

    /* renamed from: d  reason: collision with root package name */
    public static final f0.c f15104d = new i0();

    /* renamed from: a  reason: collision with root package name */
    private final UUID f15105a;

    /* renamed from: b  reason: collision with root package name */
    private final MediaDrm f15106b;

    /* renamed from: c  reason: collision with root package name */
    private int f15107c = 1;

    private static class a {
        public static boolean a(MediaDrm mediaDrm, String str) {
            return mediaDrm.requiresSecureDecoder(str);
        }

        public static void b(MediaDrm mediaDrm, byte[] bArr, c4 c4Var) {
            LogSessionId a10 = c4Var.a();
            if (!a10.equals(LogSessionId.LOG_SESSION_ID_NONE)) {
                l0.a(androidx.media3.common.util.a.e(mediaDrm.getPlaybackComponent(bArr))).setLogSessionId(a10);
            }
        }
    }

    private o0(UUID uuid) {
        androidx.media3.common.util.a.e(uuid);
        androidx.media3.common.util.a.b(!l.f19916b.equals(uuid), "Use C.CLEARKEY_UUID instead");
        this.f15105a = uuid;
        MediaDrm mediaDrm = new MediaDrm(u(uuid));
        this.f15106b = mediaDrm;
        if (l.f19918d.equals(uuid) && C()) {
            w(mediaDrm);
        }
    }

    /* access modifiers changed from: private */
    public /* synthetic */ void A(f0.b bVar, MediaDrm mediaDrm, byte[] bArr, int i10, int i11, byte[] bArr2) {
        bVar.a(this, bArr, i10, i11, bArr2);
    }

    /* access modifiers changed from: private */
    public static /* synthetic */ f0 B(UUID uuid) {
        try {
            return D(uuid);
        } catch (t0 unused) {
            s.d("FrameworkMediaDrm", "Failed to instantiate a FrameworkMediaDrm for uuid: " + uuid + ".");
            return new c0();
        }
    }

    private static boolean C() {
        return "ASUS_Z00AD".equals(b1.f3698d);
    }

    public static o0 D(UUID uuid) {
        try {
            return new o0(uuid);
        } catch (UnsupportedSchemeException e10) {
            throw new t0(1, e10);
        } catch (Exception e11) {
            throw new t0(2, e11);
        }
    }

    private boolean F() {
        if (b1.f3695a >= 21 || !l.f19918d.equals(this.f15105a) || !"L3".equals(x("securityLevel"))) {
            return false;
        }
        return true;
    }

    private static byte[] p(byte[] bArr) {
        androidx.media3.common.util.f0 f0Var = new androidx.media3.common.util.f0(bArr);
        int u10 = f0Var.u();
        short w10 = f0Var.w();
        short w11 = f0Var.w();
        if (w10 == 1 && w11 == 1) {
            short w12 = f0Var.w();
            Charset charset = d.f40785e;
            String F = f0Var.F(w12, charset);
            if (F.contains("<LA_URL>")) {
                return bArr;
            }
            int indexOf = F.indexOf("</DATA>");
            if (indexOf == -1) {
                s.i("FrameworkMediaDrm", "Could not find the </DATA> tag. Skipping LA_URL workaround.");
            }
            String str = F.substring(0, indexOf) + "<LA_URL>https://x</LA_URL>" + F.substring(indexOf);
            int i10 = u10 + 52;
            ByteBuffer allocate = ByteBuffer.allocate(i10);
            allocate.order(ByteOrder.LITTLE_ENDIAN);
            allocate.putInt(i10);
            allocate.putShort((short) w10);
            allocate.putShort((short) w11);
            allocate.putShort((short) (str.length() * 2));
            allocate.put(str.getBytes(charset));
            return allocate.array();
        }
        s.g("FrameworkMediaDrm", "Unexpected record count or type. Skipping LA_URL workaround.");
        return bArr;
    }

    private String q(String str) {
        if ("<LA_URL>https://x</LA_URL>".equals(str)) {
            return "";
        }
        if (b1.f3695a >= 33 && "https://default.url".equals(str)) {
            String x10 = x("version");
            if (Objects.equals(x10, "1.2") || Objects.equals(x10, "aidl-1")) {
                return "";
            }
        }
        return str;
    }

    private static byte[] r(UUID uuid, byte[] bArr) {
        if (l.f19917c.equals(uuid)) {
            return a.a(bArr);
        }
        return bArr;
    }

    /* JADX WARNING: Code restructure failed: missing block: B:21:0x0056, code lost:
        if ("AFTT".equals(r0) == false) goto L_0x005f;
     */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    private static byte[] s(java.util.UUID r3, byte[] r4) {
        /*
            java.util.UUID r0 = y0.l.f19919e
            boolean r1 = r0.equals(r3)
            if (r1 == 0) goto L_0x0018
            byte[] r1 = v2.o.e(r4, r3)
            if (r1 != 0) goto L_0x000f
            goto L_0x0010
        L_0x000f:
            r4 = r1
        L_0x0010:
            byte[] r4 = p(r4)
            byte[] r4 = v2.o.a(r0, r4)
        L_0x0018:
            int r1 = androidx.media3.common.util.b1.f3695a
            r2 = 23
            if (r1 >= r2) goto L_0x0026
            java.util.UUID r1 = y0.l.f19918d
            boolean r1 = r1.equals(r3)
            if (r1 != 0) goto L_0x0058
        L_0x0026:
            boolean r0 = r0.equals(r3)
            if (r0 == 0) goto L_0x005f
            java.lang.String r0 = "Amazon"
            java.lang.String r1 = androidx.media3.common.util.b1.f3697c
            boolean r0 = r0.equals(r1)
            if (r0 == 0) goto L_0x005f
            java.lang.String r0 = androidx.media3.common.util.b1.f3698d
            java.lang.String r1 = "AFTB"
            boolean r1 = r1.equals(r0)
            if (r1 != 0) goto L_0x0058
            java.lang.String r1 = "AFTS"
            boolean r1 = r1.equals(r0)
            if (r1 != 0) goto L_0x0058
            java.lang.String r1 = "AFTM"
            boolean r1 = r1.equals(r0)
            if (r1 != 0) goto L_0x0058
            java.lang.String r1 = "AFTT"
            boolean r0 = r1.equals(r0)
            if (r0 == 0) goto L_0x005f
        L_0x0058:
            byte[] r3 = v2.o.e(r4, r3)
            if (r3 == 0) goto L_0x005f
            return r3
        L_0x005f:
            return r4
        */
        throw new UnsupportedOperationException("Method not decompiled: k1.o0.s(java.util.UUID, byte[]):byte[]");
    }

    private static String t(UUID uuid, String str) {
        if (b1.f3695a >= 26 || !l.f19917c.equals(uuid) || (!"video/mp4".equals(str) && !"audio/mp4".equals(str))) {
            return str;
        }
        return "cenc";
    }

    private static UUID u(UUID uuid) {
        if (b1.f3695a >= 27 || !l.f19917c.equals(uuid)) {
            return uuid;
        }
        return l.f19916b;
    }

    private static void w(MediaDrm mediaDrm) {
        mediaDrm.setPropertyString("securityLevel", "L3");
    }

    private static r.b y(UUID uuid, List list) {
        boolean z10;
        if (!l.f19918d.equals(uuid)) {
            return (r.b) list.get(0);
        }
        if (b1.f3695a >= 28 && list.size() > 1) {
            r.b bVar = (r.b) list.get(0);
            int i10 = 0;
            int i11 = 0;
            while (true) {
                if (i10 >= list.size()) {
                    z10 = true;
                    break;
                }
                r.b bVar2 = (r.b) list.get(i10);
                byte[] bArr = (byte[]) androidx.media3.common.util.a.e(bVar2.f20000z);
                if (!b1.f(bVar2.f19999y, bVar.f19999y) || !b1.f(bVar2.f19998x, bVar.f19998x) || !o.c(bArr)) {
                    z10 = false;
                } else {
                    i11 += bArr.length;
                    i10++;
                }
            }
            z10 = false;
            if (z10) {
                byte[] bArr2 = new byte[i11];
                int i12 = 0;
                for (int i13 = 0; i13 < list.size(); i13++) {
                    byte[] bArr3 = (byte[]) androidx.media3.common.util.a.e(((r.b) list.get(i13)).f20000z);
                    int length = bArr3.length;
                    System.arraycopy(bArr3, 0, bArr2, i12, length);
                    i12 += length;
                }
                return bVar.b(bArr2);
            }
        }
        for (int i14 = 0; i14 < list.size(); i14++) {
            r.b bVar3 = (r.b) list.get(i14);
            int g10 = o.g((byte[]) androidx.media3.common.util.a.e(bVar3.f20000z));
            int i15 = b1.f3695a;
            if (i15 < 23 && g10 == 0) {
                return bVar3;
            }
            if (i15 >= 23 && g10 == 1) {
                return bVar3;
            }
        }
        return (r.b) list.get(0);
    }

    private boolean z() {
        if (!this.f15105a.equals(l.f19918d)) {
            return this.f15105a.equals(l.f19917c);
        }
        String x10 = x("version");
        if (x10.startsWith("v5.") || x10.startsWith("14.") || x10.startsWith("15.") || x10.startsWith("16.0")) {
            return false;
        }
        return true;
    }

    public void E(String str, String str2) {
        this.f15106b.setPropertyString(str, str2);
    }

    public Map a(byte[] bArr) {
        return this.f15106b.queryKeyStatus(bArr);
    }

    public f0.d b() {
        MediaDrm.ProvisionRequest provisionRequest = this.f15106b.getProvisionRequest();
        return new f0.d(provisionRequest.getData(), provisionRequest.getDefaultUrl());
    }

    public byte[] d() {
        return this.f15106b.openSession();
    }

    public void e(byte[] bArr, c4 c4Var) {
        if (b1.f3695a >= 31) {
            try {
                a.b(this.f15106b, bArr, c4Var);
            } catch (UnsupportedOperationException unused) {
                s.i("FrameworkMediaDrm", "setLogSessionId failed.");
            }
        }
    }

    /* JADX WARNING: Removed duplicated region for block: B:17:0x002d  */
    /* JADX WARNING: Removed duplicated region for block: B:21:0x0034  */
    /* JADX WARNING: Removed duplicated region for block: B:26:0x0041 A[ORIG_RETURN, RETURN, SYNTHETIC] */
    /* JADX WARNING: Removed duplicated region for block: B:27:? A[RETURN, SYNTHETIC] */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public boolean f(byte[] r5, java.lang.String r6) {
        /*
            r4 = this;
            int r0 = androidx.media3.common.util.b1.f3695a
            r1 = 31
            r2 = 1
            if (r0 < r1) goto L_0x0014
            boolean r0 = r4.z()
            if (r0 == 0) goto L_0x0014
            android.media.MediaDrm r5 = r4.f15106b
            boolean r5 = k1.o0.a.a(r5, r6)
            goto L_0x0038
        L_0x0014:
            r0 = 0
            android.media.MediaCrypto r1 = new android.media.MediaCrypto     // Catch:{ MediaCryptoException -> 0x0031, all -> 0x002a }
            java.util.UUID r3 = r4.f15105a     // Catch:{ MediaCryptoException -> 0x0031, all -> 0x002a }
            r1.<init>(r3, r5)     // Catch:{ MediaCryptoException -> 0x0031, all -> 0x002a }
            boolean r5 = r1.requiresSecureDecoderComponent(r6)     // Catch:{ MediaCryptoException -> 0x0027, all -> 0x0024 }
            r1.release()
            goto L_0x0038
        L_0x0024:
            r5 = move-exception
            r0 = r1
            goto L_0x002b
        L_0x0027:
            r0 = r1
            goto L_0x0032
        L_0x002a:
            r5 = move-exception
        L_0x002b:
            if (r0 == 0) goto L_0x0030
            r0.release()
        L_0x0030:
            throw r5
        L_0x0031:
        L_0x0032:
            if (r0 == 0) goto L_0x0037
            r0.release()
        L_0x0037:
            r5 = 1
        L_0x0038:
            if (r5 == 0) goto L_0x0041
            boolean r5 = r4.F()
            if (r5 != 0) goto L_0x0041
            goto L_0x0042
        L_0x0041:
            r2 = 0
        L_0x0042:
            return r2
        */
        throw new UnsupportedOperationException("Method not decompiled: k1.o0.f(byte[], java.lang.String):boolean");
    }

    public void g(byte[] bArr, byte[] bArr2) {
        this.f15106b.restoreKeys(bArr, bArr2);
    }

    public void h(byte[] bArr) {
        this.f15106b.closeSession(bArr);
    }

    public void i(f0.b bVar) {
        j0 j0Var;
        MediaDrm mediaDrm = this.f15106b;
        if (bVar == null) {
            j0Var = null;
        } else {
            j0Var = new j0(this, bVar);
        }
        mediaDrm.setOnEventListener(j0Var);
    }

    public byte[] j(byte[] bArr, byte[] bArr2) {
        if (l.f19917c.equals(this.f15105a)) {
            bArr2 = a.b(bArr2);
        }
        return this.f15106b.provideKeyResponse(bArr, bArr2);
    }

    public void k(byte[] bArr) {
        this.f15106b.provideProvisionResponse(bArr);
    }

    public f0.a l(byte[] bArr, List list, int i10, HashMap hashMap) {
        r.b bVar;
        String str;
        byte[] bArr2;
        int i11;
        if (list != null) {
            bVar = y(this.f15105a, list);
            bArr2 = s(this.f15105a, (byte[]) androidx.media3.common.util.a.e(bVar.f20000z));
            str = t(this.f15105a, bVar.f19999y);
        } else {
            bVar = null;
            bArr2 = null;
            str = null;
        }
        MediaDrm.KeyRequest keyRequest = this.f15106b.getKeyRequest(bArr, bArr2, str, i10, hashMap);
        byte[] r10 = r(this.f15105a, keyRequest.getData());
        String q10 = q(keyRequest.getDefaultUrl());
        if (TextUtils.isEmpty(q10) && bVar != null && !TextUtils.isEmpty(bVar.f19998x)) {
            q10 = bVar.f19998x;
        }
        if (b1.f3695a >= 23) {
            i11 = keyRequest.getRequestType();
        } else {
            i11 = Integer.MIN_VALUE;
        }
        return new f0.a(r10, q10, i11);
    }

    public int m() {
        return 2;
    }

    public synchronized void release() {
        int i10 = this.f15107c - 1;
        this.f15107c = i10;
        if (i10 == 0) {
            this.f15106b.release();
        }
    }

    /* renamed from: v */
    public g0 c(byte[] bArr) {
        return new g0(u(this.f15105a), bArr, F());
    }

    public String x(String str) {
        return this.f15106b.getPropertyString(str);
    }
}
