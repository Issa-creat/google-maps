package k1;

import androidx.media3.common.util.a;
import g1.b;
import java.util.Map;
import java.util.UUID;
import k1.n;
import k1.v;
import y0.l;

public final class d0 implements n {

    /* renamed from: a  reason: collision with root package name */
    private final n.a f15006a;

    public d0(n.a aVar) {
        this.f15006a = (n.a) a.e(aVar);
    }

    public final UUID a() {
        return l.f19915a;
    }

    public void b(v.a aVar) {
    }

    public void c(v.a aVar) {
    }

    public boolean d() {
        return false;
    }

    public Map e() {
        return null;
    }

    public boolean f(String str) {
        return false;
    }

    public n.a g() {
        return this.f15006a;
    }

    public int getState() {
        return 1;
    }

    public b h() {
        return null;
    }
}
