package k1;

import k1.x;

public abstract /* synthetic */ class z {
    static {
        x.b bVar = x.b.f15137a;
    }

    public static /* synthetic */ void a() {
    }
}
