package k1;

import k1.v;

public final /* synthetic */ class k implements Runnable {

    /* renamed from: a  reason: collision with root package name */
    public final /* synthetic */ g f15096a;

    public /* synthetic */ k(g gVar) {
        this.f15096a = gVar;
    }

    public final void run() {
        this.f15096a.b((v.a) null);
    }
}
