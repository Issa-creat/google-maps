package k1;

public final class t0 extends Exception {

    /* renamed from: a  reason: collision with root package name */
    public final int f15128a;

    public t0(int i10) {
        this.f15128a = i10;
    }

    public t0(int i10, Exception exc) {
        super(exc);
        this.f15128a = i10;
    }
}
