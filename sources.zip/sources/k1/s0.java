package k1;

import android.net.Uri;
import d1.p;
import java.io.IOException;
import java.util.Map;

public final class s0 extends IOException {

    /* renamed from: a  reason: collision with root package name */
    public final p f15122a;

    /* renamed from: w  reason: collision with root package name */
    public final Uri f15123w;

    /* renamed from: x  reason: collision with root package name */
    public final Map f15124x;

    /* renamed from: y  reason: collision with root package name */
    public final long f15125y;

    public s0(p pVar, Uri uri, Map map, long j10, Throwable th2) {
        super(th2);
        this.f15122a = pVar;
        this.f15123w = uri;
        this.f15124x = map;
        this.f15125y = j10;
    }
}
