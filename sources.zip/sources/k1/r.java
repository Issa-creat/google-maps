package k1;

import k1.v;

public final /* synthetic */ class r implements Runnable {

    /* renamed from: a  reason: collision with root package name */
    public final /* synthetic */ v.a f15117a;

    /* renamed from: w  reason: collision with root package name */
    public final /* synthetic */ v f15118w;

    /* renamed from: x  reason: collision with root package name */
    public final /* synthetic */ Exception f15119x;

    public /* synthetic */ r(v.a aVar, v vVar, Exception exc) {
        this.f15117a = aVar;
        this.f15118w = vVar;
        this.f15119x = exc;
    }

    public final void run() {
        this.f15117a.r(this.f15118w, this.f15119x);
    }
}
