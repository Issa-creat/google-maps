package k1;

import android.os.Handler;
import androidx.media3.common.util.b1;
import java.util.Iterator;
import java.util.concurrent.CopyOnWriteArrayList;
import s1.f0;

public interface v {

    public static class a {

        /* renamed from: a  reason: collision with root package name */
        public final int f15131a;

        /* renamed from: b  reason: collision with root package name */
        public final f0.b f15132b;

        /* renamed from: c  reason: collision with root package name */
        private final CopyOnWriteArrayList f15133c;

        /* renamed from: k1.v$a$a  reason: collision with other inner class name */
        private static final class C0199a {

            /* renamed from: a  reason: collision with root package name */
            public Handler f15134a;

            /* renamed from: b  reason: collision with root package name */
            public v f15135b;

            public C0199a(Handler handler, v vVar) {
                this.f15134a = handler;
                this.f15135b = vVar;
            }
        }

        public a() {
            this(new CopyOnWriteArrayList(), 0, (f0.b) null);
        }

        /* access modifiers changed from: private */
        public /* synthetic */ void n(v vVar) {
            vVar.q0(this.f15131a, this.f15132b);
        }

        /* access modifiers changed from: private */
        public /* synthetic */ void o(v vVar) {
            vVar.T(this.f15131a, this.f15132b);
        }

        /* access modifiers changed from: private */
        public /* synthetic */ void p(v vVar) {
            vVar.E(this.f15131a, this.f15132b);
        }

        /* access modifiers changed from: private */
        public /* synthetic */ void q(v vVar, int i10) {
            vVar.J(this.f15131a, this.f15132b);
            vVar.h0(this.f15131a, this.f15132b, i10);
        }

        /* access modifiers changed from: private */
        public /* synthetic */ void r(v vVar, Exception exc) {
            vVar.b0(this.f15131a, this.f15132b, exc);
        }

        /* access modifiers changed from: private */
        public /* synthetic */ void s(v vVar) {
            vVar.K(this.f15131a, this.f15132b);
        }

        public void g(Handler handler, v vVar) {
            androidx.media3.common.util.a.e(handler);
            androidx.media3.common.util.a.e(vVar);
            this.f15133c.add(new C0199a(handler, vVar));
        }

        public void h() {
            Iterator it = this.f15133c.iterator();
            while (it.hasNext()) {
                C0199a aVar = (C0199a) it.next();
                b1.l1(aVar.f15134a, new u(this, aVar.f15135b));
            }
        }

        public void i() {
            Iterator it = this.f15133c.iterator();
            while (it.hasNext()) {
                C0199a aVar = (C0199a) it.next();
                b1.l1(aVar.f15134a, new t(this, aVar.f15135b));
            }
        }

        public void j() {
            Iterator it = this.f15133c.iterator();
            while (it.hasNext()) {
                C0199a aVar = (C0199a) it.next();
                b1.l1(aVar.f15134a, new s(this, aVar.f15135b));
            }
        }

        public void k(int i10) {
            Iterator it = this.f15133c.iterator();
            while (it.hasNext()) {
                C0199a aVar = (C0199a) it.next();
                b1.l1(aVar.f15134a, new p(this, aVar.f15135b, i10));
            }
        }

        public void l(Exception exc) {
            Iterator it = this.f15133c.iterator();
            while (it.hasNext()) {
                C0199a aVar = (C0199a) it.next();
                b1.l1(aVar.f15134a, new r(this, aVar.f15135b, exc));
            }
        }

        public void m() {
            Iterator it = this.f15133c.iterator();
            while (it.hasNext()) {
                C0199a aVar = (C0199a) it.next();
                b1.l1(aVar.f15134a, new q(this, aVar.f15135b));
            }
        }

        public void t(v vVar) {
            Iterator it = this.f15133c.iterator();
            while (it.hasNext()) {
                C0199a aVar = (C0199a) it.next();
                if (aVar.f15135b == vVar) {
                    this.f15133c.remove(aVar);
                }
            }
        }

        public a u(int i10, f0.b bVar) {
            return new a(this.f15133c, i10, bVar);
        }

        private a(CopyOnWriteArrayList copyOnWriteArrayList, int i10, f0.b bVar) {
            this.f15133c = copyOnWriteArrayList;
            this.f15131a = i10;
            this.f15132b = bVar;
        }
    }

    void E(int i10, f0.b bVar);

    void J(int i10, f0.b bVar);

    void K(int i10, f0.b bVar);

    void T(int i10, f0.b bVar);

    void b0(int i10, f0.b bVar, Exception exc);

    void h0(int i10, f0.b bVar, int i11);

    void q0(int i10, f0.b bVar);
}
