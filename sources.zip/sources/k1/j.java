package k1;

import k1.h;
import y0.y;

public final /* synthetic */ class j implements Runnable {

    /* renamed from: a  reason: collision with root package name */
    public final /* synthetic */ h.f f15092a;

    /* renamed from: w  reason: collision with root package name */
    public final /* synthetic */ y f15093w;

    public /* synthetic */ j(h.f fVar, y yVar) {
        this.f15092a = fVar;
        this.f15093w = yVar;
    }

    public final void run() {
        this.f15092a.d(this.f15093w);
    }
}
