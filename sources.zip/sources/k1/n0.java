package k1;

public abstract /* synthetic */ class n0 {
}
