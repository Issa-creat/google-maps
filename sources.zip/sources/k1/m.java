package k1;

import k1.v;

public abstract /* synthetic */ class m {
    public static void a(n nVar, n nVar2) {
        if (nVar != nVar2) {
            if (nVar2 != null) {
                nVar2.c((v.a) null);
            }
            if (nVar != null) {
                nVar.b((v.a) null);
            }
        }
    }
}
