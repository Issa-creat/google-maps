package k1;

import android.media.MediaDrm;

public abstract /* synthetic */ class l0 {
    public static /* bridge */ /* synthetic */ MediaDrm.PlaybackComponent a(Object obj) {
        return (MediaDrm.PlaybackComponent) obj;
    }
}
