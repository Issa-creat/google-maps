package k1;

import android.media.ResourceBusyException;
import android.os.Handler;
import android.os.Looper;
import android.os.Message;
import android.os.SystemClock;
import androidx.media3.common.util.b1;
import androidx.media3.common.util.s;
import com.google.common.collect.a1;
import com.google.common.collect.c0;
import com.google.common.collect.e1;
import h1.c4;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.UUID;
import k1.f0;
import k1.g;
import k1.n;
import k1.v;
import k1.x;
import x1.n;
import y0.l;
import y0.n0;
import y0.r;
import y0.y;

public class h implements x {

    /* renamed from: b  reason: collision with root package name */
    private final UUID f15049b;

    /* renamed from: c  reason: collision with root package name */
    private final f0.c f15050c;

    /* renamed from: d  reason: collision with root package name */
    private final r0 f15051d;

    /* renamed from: e  reason: collision with root package name */
    private final HashMap f15052e;

    /* renamed from: f  reason: collision with root package name */
    private final boolean f15053f;

    /* renamed from: g  reason: collision with root package name */
    private final int[] f15054g;

    /* renamed from: h  reason: collision with root package name */
    private final boolean f15055h;
    /* access modifiers changed from: private */

    /* renamed from: i  reason: collision with root package name */
    public final g f15056i;

    /* renamed from: j  reason: collision with root package name */
    private final n f15057j;

    /* renamed from: k  reason: collision with root package name */
    private final C0198h f15058k;
    /* access modifiers changed from: private */

    /* renamed from: l  reason: collision with root package name */
    public final long f15059l;
    /* access modifiers changed from: private */

    /* renamed from: m  reason: collision with root package name */
    public final List f15060m;
    /* access modifiers changed from: private */

    /* renamed from: n  reason: collision with root package name */
    public final Set f15061n;
    /* access modifiers changed from: private */

    /* renamed from: o  reason: collision with root package name */
    public final Set f15062o;
    /* access modifiers changed from: private */

    /* renamed from: p  reason: collision with root package name */
    public int f15063p;

    /* renamed from: q  reason: collision with root package name */
    private f0 f15064q;
    /* access modifiers changed from: private */

    /* renamed from: r  reason: collision with root package name */
    public g f15065r;
    /* access modifiers changed from: private */

    /* renamed from: s  reason: collision with root package name */
    public g f15066s;
    /* access modifiers changed from: private */

    /* renamed from: t  reason: collision with root package name */
    public Looper f15067t;
    /* access modifiers changed from: private */

    /* renamed from: u  reason: collision with root package name */
    public Handler f15068u;

    /* renamed from: v  reason: collision with root package name */
    private int f15069v;

    /* renamed from: w  reason: collision with root package name */
    private byte[] f15070w;

    /* renamed from: x  reason: collision with root package name */
    private c4 f15071x;

    /* renamed from: y  reason: collision with root package name */
    volatile d f15072y;

    public static final class b {

        /* renamed from: a  reason: collision with root package name */
        private final HashMap f15073a = new HashMap();

        /* renamed from: b  reason: collision with root package name */
        private UUID f15074b = l.f19918d;

        /* renamed from: c  reason: collision with root package name */
        private f0.c f15075c = o0.f15104d;

        /* renamed from: d  reason: collision with root package name */
        private boolean f15076d;

        /* renamed from: e  reason: collision with root package name */
        private int[] f15077e = new int[0];

        /* renamed from: f  reason: collision with root package name */
        private boolean f15078f = true;

        /* renamed from: g  reason: collision with root package name */
        private n f15079g = new x1.l();

        /* renamed from: h  reason: collision with root package name */
        private long f15080h = 300000;

        public h a(r0 r0Var) {
            return new h(this.f15074b, this.f15075c, r0Var, this.f15073a, this.f15076d, this.f15077e, this.f15078f, this.f15079g, this.f15080h);
        }

        public b b(Map map) {
            this.f15073a.clear();
            if (map != null) {
                this.f15073a.putAll(map);
            }
            return this;
        }

        public b c(n nVar) {
            this.f15079g = (n) androidx.media3.common.util.a.e(nVar);
            return this;
        }

        public b d(boolean z10) {
            this.f15076d = z10;
            return this;
        }

        public b e(boolean z10) {
            this.f15078f = z10;
            return this;
        }

        public b f(int... iArr) {
            for (int i10 : iArr) {
                boolean z10 = true;
                if (!(i10 == 2 || i10 == 1)) {
                    z10 = false;
                }
                androidx.media3.common.util.a.a(z10);
            }
            this.f15077e = (int[]) iArr.clone();
            return this;
        }

        public b g(UUID uuid, f0.c cVar) {
            this.f15074b = (UUID) androidx.media3.common.util.a.e(uuid);
            this.f15075c = (f0.c) androidx.media3.common.util.a.e(cVar);
            return this;
        }
    }

    private class c implements f0.b {
        private c() {
        }

        public void a(f0 f0Var, byte[] bArr, int i10, int i11, byte[] bArr2) {
            ((d) androidx.media3.common.util.a.e(h.this.f15072y)).obtainMessage(i10, bArr).sendToTarget();
        }
    }

    private class d extends Handler {
        public d(Looper looper) {
            super(looper);
        }

        public void handleMessage(Message message) {
            byte[] bArr = (byte[]) message.obj;
            if (bArr != null) {
                for (g gVar : h.this.f15060m) {
                    if (gVar.t(bArr)) {
                        gVar.B(message.what);
                        return;
                    }
                }
            }
        }
    }

    public static final class e extends Exception {
        private e(UUID uuid) {
            super("Media does not support uuid: " + uuid);
        }
    }

    private class f implements x.b {

        /* renamed from: b  reason: collision with root package name */
        private final v.a f15083b;

        /* renamed from: c  reason: collision with root package name */
        private n f15084c;

        /* renamed from: d  reason: collision with root package name */
        private boolean f15085d;

        public f(v.a aVar) {
            this.f15083b = aVar;
        }

        /* access modifiers changed from: private */
        public /* synthetic */ void d(y yVar) {
            if (h.this.f15063p != 0 && !this.f15085d) {
                h hVar = h.this;
                this.f15084c = hVar.t((Looper) androidx.media3.common.util.a.e(hVar.f15067t), this.f15083b, yVar, false);
                h.this.f15061n.add(this);
            }
        }

        /* access modifiers changed from: private */
        public /* synthetic */ void e() {
            if (!this.f15085d) {
                n nVar = this.f15084c;
                if (nVar != null) {
                    nVar.b(this.f15083b);
                }
                h.this.f15061n.remove(this);
                this.f15085d = true;
            }
        }

        public void c(y yVar) {
            ((Handler) androidx.media3.common.util.a.e(h.this.f15068u)).post(new j(this, yVar));
        }

        public void release() {
            b1.l1((Handler) androidx.media3.common.util.a.e(h.this.f15068u), new i(this));
        }
    }

    private class g implements g.a {

        /* renamed from: a  reason: collision with root package name */
        private final Set f15087a = new HashSet();

        /* renamed from: b  reason: collision with root package name */
        private g f15088b;

        public g() {
        }

        public void a(Exception exc, boolean z10) {
            this.f15088b = null;
            com.google.common.collect.y w10 = com.google.common.collect.y.w(this.f15087a);
            this.f15087a.clear();
            e1 p10 = w10.iterator();
            while (p10.hasNext()) {
                ((g) p10.next()).D(exc, z10);
            }
        }

        public void b() {
            this.f15088b = null;
            com.google.common.collect.y w10 = com.google.common.collect.y.w(this.f15087a);
            this.f15087a.clear();
            e1 p10 = w10.iterator();
            while (p10.hasNext()) {
                ((g) p10.next()).C();
            }
        }

        public void c(g gVar) {
            this.f15087a.add(gVar);
            if (this.f15088b == null) {
                this.f15088b = gVar;
                gVar.H();
            }
        }

        public void d(g gVar) {
            this.f15087a.remove(gVar);
            if (this.f15088b == gVar) {
                this.f15088b = null;
                if (!this.f15087a.isEmpty()) {
                    g gVar2 = (g) this.f15087a.iterator().next();
                    this.f15088b = gVar2;
                    gVar2.H();
                }
            }
        }
    }

    /* renamed from: k1.h$h  reason: collision with other inner class name */
    private class C0198h implements g.b {
        private C0198h() {
        }

        public void a(g gVar, int i10) {
            if (i10 == 1 && h.this.f15063p > 0 && h.this.f15059l != -9223372036854775807L) {
                h.this.f15062o.add(gVar);
                ((Handler) androidx.media3.common.util.a.e(h.this.f15068u)).postAtTime(new k(gVar), gVar, SystemClock.uptimeMillis() + h.this.f15059l);
            } else if (i10 == 0) {
                h.this.f15060m.remove(gVar);
                if (h.this.f15065r == gVar) {
                    g unused = h.this.f15065r = null;
                }
                if (h.this.f15066s == gVar) {
                    g unused2 = h.this.f15066s = null;
                }
                h.this.f15056i.d(gVar);
                if (h.this.f15059l != -9223372036854775807L) {
                    ((Handler) androidx.media3.common.util.a.e(h.this.f15068u)).removeCallbacksAndMessages(gVar);
                    h.this.f15062o.remove(gVar);
                }
            }
            h.this.C();
        }

        public void b(g gVar, int i10) {
            if (h.this.f15059l != -9223372036854775807L) {
                h.this.f15062o.remove(gVar);
                ((Handler) androidx.media3.common.util.a.e(h.this.f15068u)).removeCallbacksAndMessages(gVar);
            }
        }
    }

    private n A(int i10, boolean z10) {
        boolean z11;
        f0 f0Var = (f0) androidx.media3.common.util.a.e(this.f15064q);
        if (f0Var.m() != 2 || !g0.f15045d) {
            z11 = false;
        } else {
            z11 = true;
        }
        if (z11 || b1.Z0(this.f15054g, i10) == -1 || f0Var.m() == 1) {
            return null;
        }
        g gVar = this.f15065r;
        if (gVar == null) {
            g x10 = x(com.google.common.collect.y.C(), true, (v.a) null, z10);
            this.f15060m.add(x10);
            this.f15065r = x10;
        } else {
            gVar.c((v.a) null);
        }
        return this.f15065r;
    }

    private void B(Looper looper) {
        if (this.f15072y == null) {
            this.f15072y = new d(looper);
        }
    }

    /* access modifiers changed from: private */
    public void C() {
        if (this.f15064q != null && this.f15063p == 0 && this.f15060m.isEmpty() && this.f15061n.isEmpty()) {
            ((f0) androidx.media3.common.util.a.e(this.f15064q)).release();
            this.f15064q = null;
        }
    }

    private void D() {
        e1 p10 = c0.v(this.f15062o).p();
        while (p10.hasNext()) {
            ((n) p10.next()).b((v.a) null);
        }
    }

    private void E() {
        e1 p10 = c0.v(this.f15061n).p();
        while (p10.hasNext()) {
            ((f) p10.next()).release();
        }
    }

    private void G(n nVar, v.a aVar) {
        nVar.b(aVar);
        if (this.f15059l != -9223372036854775807L) {
            nVar.b((v.a) null);
        }
    }

    private void H(boolean z10) {
        if (z10 && this.f15067t == null) {
            s.j("DefaultDrmSessionMgr", "DefaultDrmSessionManager accessed before setPlayer(), possibly on the wrong thread.", new IllegalStateException());
        } else if (Thread.currentThread() != ((Looper) androidx.media3.common.util.a.e(this.f15067t)).getThread()) {
            s.j("DefaultDrmSessionMgr", "DefaultDrmSessionManager accessed on the wrong thread.\nCurrent thread: " + Thread.currentThread().getName() + "\nExpected thread: " + this.f15067t.getThread().getName(), new IllegalStateException());
        }
    }

    /* access modifiers changed from: private */
    public n t(Looper looper, v.a aVar, y yVar, boolean z10) {
        List list;
        B(looper);
        r rVar = yVar.f20075r;
        if (rVar == null) {
            return A(n0.k(yVar.f20071n), z10);
        }
        g gVar = null;
        if (this.f15070w == null) {
            list = y((r) androidx.media3.common.util.a.e(rVar), this.f15049b, false);
            if (list.isEmpty()) {
                e eVar = new e(this.f15049b);
                s.e("DefaultDrmSessionMgr", "DRM error", eVar);
                if (aVar != null) {
                    aVar.l(eVar);
                }
                return new d0(new n.a(eVar, 6003));
            }
        } else {
            list = null;
        }
        if (this.f15053f) {
            Iterator it = this.f15060m.iterator();
            while (true) {
                if (!it.hasNext()) {
                    break;
                }
                g gVar2 = (g) it.next();
                if (b1.f(gVar2.f15012a, list)) {
                    gVar = gVar2;
                    break;
                }
            }
        } else {
            gVar = this.f15066s;
        }
        if (gVar == null) {
            gVar = x(list, false, aVar, z10);
            if (!this.f15053f) {
                this.f15066s = gVar;
            }
            this.f15060m.add(gVar);
        } else {
            gVar.c(aVar);
        }
        return gVar;
    }

    private static boolean u(n nVar) {
        if (nVar.getState() != 1) {
            return false;
        }
        Throwable cause = ((n.a) androidx.media3.common.util.a.e(nVar.g())).getCause();
        if ((cause instanceof ResourceBusyException) || b0.c(cause)) {
            return true;
        }
        return false;
    }

    private boolean v(r rVar) {
        if (this.f15070w != null) {
            return true;
        }
        if (y(rVar, this.f15049b, true).isEmpty()) {
            if (rVar.f19995y != 1 || !rVar.e(0).d(l.f19916b)) {
                return false;
            }
            s.i("DefaultDrmSessionMgr", "DrmInitData only contains common PSSH SchemeData. Assuming support for: " + this.f15049b);
        }
        String str = rVar.f19994x;
        if (str == null || "cenc".equals(str)) {
            return true;
        }
        if ("cbcs".equals(str)) {
            if (b1.f3695a >= 25) {
                return true;
            }
            return false;
        } else if ("cbc1".equals(str) || "cens".equals(str)) {
            return false;
        } else {
            return true;
        }
    }

    private g w(List list, boolean z10, v.a aVar) {
        androidx.media3.common.util.a.e(this.f15064q);
        List list2 = list;
        g gVar = new g(this.f15049b, this.f15064q, this.f15056i, this.f15058k, list2, this.f15069v, this.f15055h | z10, z10, this.f15070w, this.f15052e, this.f15051d, (Looper) androidx.media3.common.util.a.e(this.f15067t), this.f15057j, (c4) androidx.media3.common.util.a.e(this.f15071x));
        gVar.c(aVar);
        if (this.f15059l != -9223372036854775807L) {
            gVar.c((v.a) null);
        }
        return gVar;
    }

    private g x(List list, boolean z10, v.a aVar, boolean z11) {
        g w10 = w(list, z10, aVar);
        if (u(w10) && !this.f15062o.isEmpty()) {
            D();
            G(w10, aVar);
            w10 = w(list, z10, aVar);
        }
        if (!u(w10) || !z11 || this.f15061n.isEmpty()) {
            return w10;
        }
        E();
        if (!this.f15062o.isEmpty()) {
            D();
        }
        G(w10, aVar);
        return w(list, z10, aVar);
    }

    private static List y(r rVar, UUID uuid, boolean z10) {
        boolean z11;
        ArrayList arrayList = new ArrayList(rVar.f19995y);
        for (int i10 = 0; i10 < rVar.f19995y; i10++) {
            r.b e10 = rVar.e(i10);
            if (e10.d(uuid) || (l.f19917c.equals(uuid) && e10.d(l.f19916b))) {
                z11 = true;
            } else {
                z11 = false;
            }
            if (z11 && (e10.f20000z != null || z10)) {
                arrayList.add(e10);
            }
        }
        return arrayList;
    }

    private synchronized void z(Looper looper) {
        boolean z10;
        Looper looper2 = this.f15067t;
        if (looper2 == null) {
            this.f15067t = looper;
            this.f15068u = new Handler(looper);
        } else {
            if (looper2 == looper) {
                z10 = true;
            } else {
                z10 = false;
            }
            androidx.media3.common.util.a.g(z10);
            androidx.media3.common.util.a.e(this.f15068u);
        }
    }

    public void F(int i10, byte[] bArr) {
        androidx.media3.common.util.a.g(this.f15060m.isEmpty());
        if (i10 == 1 || i10 == 3) {
            androidx.media3.common.util.a.e(bArr);
        }
        this.f15069v = i10;
        this.f15070w = bArr;
    }

    public x.b a(v.a aVar, y yVar) {
        boolean z10;
        if (this.f15063p > 0) {
            z10 = true;
        } else {
            z10 = false;
        }
        androidx.media3.common.util.a.g(z10);
        androidx.media3.common.util.a.i(this.f15067t);
        f fVar = new f(aVar);
        fVar.c(yVar);
        return fVar;
    }

    public n b(v.a aVar, y yVar) {
        boolean z10 = false;
        H(false);
        if (this.f15063p > 0) {
            z10 = true;
        }
        androidx.media3.common.util.a.g(z10);
        androidx.media3.common.util.a.i(this.f15067t);
        return t(this.f15067t, aVar, yVar, true);
    }

    public void c(Looper looper, c4 c4Var) {
        z(looper);
        this.f15071x = c4Var;
    }

    public int d(y yVar) {
        H(false);
        int m10 = ((f0) androidx.media3.common.util.a.e(this.f15064q)).m();
        r rVar = yVar.f20075r;
        if (rVar == null) {
            if (b1.Z0(this.f15054g, n0.k(yVar.f20071n)) != -1) {
                return m10;
            }
            return 0;
        } else if (v(rVar)) {
            return m10;
        } else {
            return 1;
        }
    }

    public final void k() {
        H(true);
        int i10 = this.f15063p;
        this.f15063p = i10 + 1;
        if (i10 == 0) {
            if (this.f15064q == null) {
                f0 a10 = this.f15050c.a(this.f15049b);
                this.f15064q = a10;
                a10.i(new c());
            } else if (this.f15059l != -9223372036854775807L) {
                for (int i11 = 0; i11 < this.f15060m.size(); i11++) {
                    ((g) this.f15060m.get(i11)).c((v.a) null);
                }
            }
        }
    }

    public final void release() {
        H(true);
        int i10 = this.f15063p - 1;
        this.f15063p = i10;
        if (i10 == 0) {
            if (this.f15059l != -9223372036854775807L) {
                ArrayList arrayList = new ArrayList(this.f15060m);
                for (int i11 = 0; i11 < arrayList.size(); i11++) {
                    ((g) arrayList.get(i11)).b((v.a) null);
                }
            }
            E();
            C();
        }
    }

    private h(UUID uuid, f0.c cVar, r0 r0Var, HashMap hashMap, boolean z10, int[] iArr, boolean z11, x1.n nVar, long j10) {
        androidx.media3.common.util.a.e(uuid);
        androidx.media3.common.util.a.b(!l.f19916b.equals(uuid), "Use C.CLEARKEY_UUID instead");
        this.f15049b = uuid;
        this.f15050c = cVar;
        this.f15051d = r0Var;
        this.f15052e = hashMap;
        this.f15053f = z10;
        this.f15054g = iArr;
        this.f15055h = z11;
        this.f15057j = nVar;
        this.f15056i = new g();
        this.f15058k = new C0198h();
        this.f15069v = 0;
        this.f15060m = new ArrayList();
        this.f15061n = a1.h();
        this.f15062o = a1.h();
        this.f15059l = j10;
    }
}
