package k1;

import h1.c4;

public abstract /* synthetic */ class e0 {
    public static void a(f0 f0Var, byte[] bArr, c4 c4Var) {
    }
}
