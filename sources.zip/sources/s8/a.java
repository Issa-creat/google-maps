package s8;

import ak.k;

public final class a {

    /* renamed from: a  reason: collision with root package name */
    public static final a f17716a = new a();

    private a() {
    }

    public static final Runnable a(Runnable runnable, String str) {
        return runnable;
    }

    public static final boolean b() {
        return false;
    }

    public static final void c(Object obj, Throwable th2) {
        k.f(th2, "th");
    }

    public static final Object d(String str) {
        return null;
    }

    public static final Object e(Object obj, String str) {
        return null;
    }

    public static final void f(Object obj) {
    }
}
