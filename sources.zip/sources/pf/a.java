package pf;

public interface a {
}
