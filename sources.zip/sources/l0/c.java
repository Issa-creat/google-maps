package l0;

public abstract class c {

    /* renamed from: a  reason: collision with root package name */
    public static int f15420a = 2131362098;

    /* renamed from: b  reason: collision with root package name */
    public static int f15421b = 2131362223;
}
