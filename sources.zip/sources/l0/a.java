package l0;

import ak.k;
import android.view.View;
import android.view.ViewGroup;
import androidx.core.view.g1;
import androidx.core.view.h1;

public abstract class a {

    /* renamed from: a  reason: collision with root package name */
    private static final int f15417a = c.f15421b;

    /* renamed from: b  reason: collision with root package name */
    private static final int f15418b = c.f15420a;

    public static final void a(View view) {
        k.f(view, "<this>");
        for (View c10 : h1.a(view)) {
            c(c10).a();
        }
    }

    public static final void b(ViewGroup viewGroup) {
        k.f(viewGroup, "<this>");
        for (View c10 : g1.a(viewGroup)) {
            c(c10).a();
        }
    }

    private static final b c(View view) {
        int i10 = f15417a;
        b bVar = (b) view.getTag(i10);
        if (bVar != null) {
            return bVar;
        }
        b bVar2 = new b();
        view.setTag(i10, bVar2);
        return bVar2;
    }

    public static final void d(View view, boolean z10) {
        k.f(view, "<this>");
        view.setTag(f15418b, Boolean.valueOf(z10));
    }
}
