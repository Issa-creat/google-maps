package l0;

import android.support.v4.media.a;
import java.util.ArrayList;

final class b {

    /* renamed from: a  reason: collision with root package name */
    private final ArrayList f15419a = new ArrayList();

    public final void a() {
        int k10 = p.k(this.f15419a);
        if (-1 < k10) {
            a.a(this.f15419a.get(k10));
            throw null;
        }
    }
}
