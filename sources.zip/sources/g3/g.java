package g3;

import android.text.TextUtils;
import androidx.media3.common.util.f0;
import androidx.media3.common.util.j;
import java.util.ArrayList;
import y0.o0;
import y2.h;
import y2.r;
import y2.s;

public final class g implements s {

    /* renamed from: a  reason: collision with root package name */
    private final f0 f13039a = new f0();

    /* renamed from: b  reason: collision with root package name */
    private final b f13040b = new b();

    private static int d(f0 f0Var) {
        int i10 = -1;
        int i11 = 0;
        while (i10 == -1) {
            i11 = f0Var.f();
            String s10 = f0Var.s();
            if (s10 == null) {
                i10 = 0;
            } else if ("STYLE".equals(s10)) {
                i10 = 2;
            } else if (s10.startsWith("NOTE")) {
                i10 = 1;
            } else {
                i10 = 3;
            }
        }
        f0Var.U(i11);
        return i10;
    }

    private static void e(f0 f0Var) {
        do {
        } while (!TextUtils.isEmpty(f0Var.s()));
    }

    public void a(byte[] bArr, int i10, int i11, s.b bVar, j jVar) {
        d m10;
        this.f13039a.S(bArr, i11 + i10);
        this.f13039a.U(i10);
        ArrayList arrayList = new ArrayList();
        try {
            h.e(this.f13039a);
            do {
            } while (!TextUtils.isEmpty(this.f13039a.s()));
            ArrayList arrayList2 = new ArrayList();
            while (true) {
                int d10 = d(this.f13039a);
                if (d10 == 0) {
                    h.c(new j(arrayList2), bVar, jVar);
                    return;
                } else if (d10 == 1) {
                    e(this.f13039a);
                } else if (d10 == 2) {
                    if (arrayList2.isEmpty()) {
                        this.f13039a.s();
                        arrayList.addAll(this.f13040b.d(this.f13039a));
                    } else {
                        throw new IllegalArgumentException("A style block was found after the first cue.");
                    }
                } else if (d10 == 3 && (m10 = e.m(this.f13039a, arrayList)) != null) {
                    arrayList2.add(m10);
                }
            }
        } catch (o0 e10) {
            throw new IllegalArgumentException(e10);
        }
    }

    public /* synthetic */ y2.j b(byte[] bArr, int i10, int i11) {
        return r.a(this, bArr, i10, i11);
    }

    public int c() {
        return 1;
    }

    public /* synthetic */ void reset() {
        r.b(this);
    }
}
