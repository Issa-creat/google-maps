package g3;

import androidx.media3.common.util.b1;
import androidx.media3.common.util.f0;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import y0.o0;

public abstract class h {

    /* renamed from: a  reason: collision with root package name */
    private static final Pattern f13041a = Pattern.compile("^NOTE([ \t].*)?$");

    public static Matcher a(f0 f0Var) {
        String s10;
        while (true) {
            String s11 = f0Var.s();
            if (s11 == null) {
                return null;
            }
            if (f13041a.matcher(s11).matches()) {
                do {
                    s10 = f0Var.s();
                    if (s10 == null) {
                        break;
                    }
                } while (s10.isEmpty());
            } else {
                Matcher matcher = e.f13015a.matcher(s11);
                if (matcher.matches()) {
                    return matcher;
                }
            }
        }
    }

    public static boolean b(f0 f0Var) {
        String s10 = f0Var.s();
        if (s10 == null || !s10.startsWith("WEBVTT")) {
            return false;
        }
        return true;
    }

    public static float c(String str) {
        if (str.endsWith("%")) {
            return Float.parseFloat(str.substring(0, str.length() - 1)) / 100.0f;
        }
        throw new NumberFormatException("Percentages must end with %");
    }

    public static long d(String str) {
        String[] D1 = b1.D1(str, "\\.");
        long j10 = 0;
        for (String parseLong : b1.C1(D1[0], ":")) {
            j10 = (j10 * 60) + Long.parseLong(parseLong);
        }
        long j11 = j10 * 1000;
        if (D1.length == 2) {
            j11 += Long.parseLong(D1[1]);
        }
        return j11 * 1000;
    }

    public static void e(f0 f0Var) {
        int f10 = f0Var.f();
        if (!b(f0Var)) {
            f0Var.U(f10);
            throw o0.a("Expected WEBVTT. Got " + f0Var.s(), (Throwable) null);
        }
    }
}
