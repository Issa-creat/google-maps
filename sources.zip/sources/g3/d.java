package g3;

import a1.a;

public final class d {

    /* renamed from: a  reason: collision with root package name */
    public final a f13012a;

    /* renamed from: b  reason: collision with root package name */
    public final long f13013b;

    /* renamed from: c  reason: collision with root package name */
    public final long f13014c;

    public d(a aVar, long j10, long j11) {
        this.f13012a = aVar;
        this.f13013b = j10;
        this.f13014c = j11;
    }
}
