package g3;

import androidx.media3.common.util.a;
import androidx.media3.common.util.b1;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;

final class j implements y2.j {

    /* renamed from: a  reason: collision with root package name */
    private final List f13042a;

    /* renamed from: w  reason: collision with root package name */
    private final long[] f13043w;

    /* renamed from: x  reason: collision with root package name */
    private final long[] f13044x;

    public j(List list) {
        this.f13042a = Collections.unmodifiableList(new ArrayList(list));
        this.f13043w = new long[(list.size() * 2)];
        for (int i10 = 0; i10 < list.size(); i10++) {
            d dVar = (d) list.get(i10);
            int i11 = i10 * 2;
            long[] jArr = this.f13043w;
            jArr[i11] = dVar.f13013b;
            jArr[i11 + 1] = dVar.f13014c;
        }
        long[] jArr2 = this.f13043w;
        long[] copyOf = Arrays.copyOf(jArr2, jArr2.length);
        this.f13044x = copyOf;
        Arrays.sort(copyOf);
    }

    public int a(long j10) {
        int g10 = b1.g(this.f13044x, j10, false, false);
        if (g10 < this.f13044x.length) {
            return g10;
        }
        return -1;
    }

    public long b(int i10) {
        boolean z10;
        boolean z11 = true;
        if (i10 >= 0) {
            z10 = true;
        } else {
            z10 = false;
        }
        a.a(z10);
        if (i10 >= this.f13044x.length) {
            z11 = false;
        }
        a.a(z11);
        return this.f13044x[i10];
    }

    public List c(long j10) {
        ArrayList arrayList = new ArrayList();
        ArrayList arrayList2 = new ArrayList();
        for (int i10 = 0; i10 < this.f13042a.size(); i10++) {
            long[] jArr = this.f13043w;
            int i11 = i10 * 2;
            if (jArr[i11] <= j10 && j10 < jArr[i11 + 1]) {
                d dVar = (d) this.f13042a.get(i10);
                a1.a aVar = dVar.f13012a;
                if (aVar.f25e == -3.4028235E38f) {
                    arrayList2.add(dVar);
                } else {
                    arrayList.add(aVar);
                }
            }
        }
        Collections.sort(arrayList2, new i());
        for (int i12 = 0; i12 < arrayList2.size(); i12++) {
            arrayList.add(((d) arrayList2.get(i12)).f13012a.a().h((float) (-1 - i12), 1).a());
        }
        return arrayList;
    }

    public int d() {
        return this.f13044x.length;
    }
}
