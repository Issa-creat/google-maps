package g3;

import java.util.Comparator;

public final /* synthetic */ class i implements Comparator {
    public final int compare(Object obj, Object obj2) {
        return Long.compare(((d) obj).f13013b, ((d) obj2).f13013b);
    }
}
