package g3;

import android.text.TextUtils;
import ge.b;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashSet;
import java.util.Set;

public final class c {

    /* renamed from: a  reason: collision with root package name */
    private String f12995a = "";

    /* renamed from: b  reason: collision with root package name */
    private String f12996b = "";

    /* renamed from: c  reason: collision with root package name */
    private Set f12997c = Collections.emptySet();

    /* renamed from: d  reason: collision with root package name */
    private String f12998d = "";

    /* renamed from: e  reason: collision with root package name */
    private String f12999e = null;

    /* renamed from: f  reason: collision with root package name */
    private int f13000f;

    /* renamed from: g  reason: collision with root package name */
    private boolean f13001g = false;

    /* renamed from: h  reason: collision with root package name */
    private int f13002h;

    /* renamed from: i  reason: collision with root package name */
    private boolean f13003i = false;

    /* renamed from: j  reason: collision with root package name */
    private int f13004j = -1;

    /* renamed from: k  reason: collision with root package name */
    private int f13005k = -1;

    /* renamed from: l  reason: collision with root package name */
    private int f13006l = -1;

    /* renamed from: m  reason: collision with root package name */
    private int f13007m = -1;

    /* renamed from: n  reason: collision with root package name */
    private int f13008n = -1;

    /* renamed from: o  reason: collision with root package name */
    private float f13009o;

    /* renamed from: p  reason: collision with root package name */
    private int f13010p = -1;

    /* renamed from: q  reason: collision with root package name */
    private boolean f13011q = false;

    private static int B(int i10, String str, String str2, int i11) {
        if (str.isEmpty() || i10 == -1) {
            return i10;
        }
        if (str.equals(str2)) {
            return i10 + i11;
        }
        return -1;
    }

    public c A(boolean z10) {
        this.f13005k = z10 ? 1 : 0;
        return this;
    }

    public int a() {
        if (this.f13003i) {
            return this.f13002h;
        }
        throw new IllegalStateException("Background color not defined.");
    }

    public boolean b() {
        return this.f13011q;
    }

    public int c() {
        if (this.f13001g) {
            return this.f13000f;
        }
        throw new IllegalStateException("Font color not defined");
    }

    public String d() {
        return this.f12999e;
    }

    public float e() {
        return this.f13009o;
    }

    public int f() {
        return this.f13008n;
    }

    public int g() {
        return this.f13010p;
    }

    public int h(String str, String str2, Set set, String str3) {
        if (this.f12995a.isEmpty() && this.f12996b.isEmpty() && this.f12997c.isEmpty() && this.f12998d.isEmpty()) {
            return TextUtils.isEmpty(str2) ? 1 : 0;
        }
        int B = B(B(B(0, this.f12995a, str, 1073741824), this.f12996b, str2, 2), this.f12998d, str3, 4);
        if (B == -1 || !set.containsAll(this.f12997c)) {
            return 0;
        }
        return B + (this.f12997c.size() * 4);
    }

    public int i() {
        int i10;
        int i11 = this.f13006l;
        if (i11 == -1 && this.f13007m == -1) {
            return -1;
        }
        int i12 = 0;
        if (i11 == 1) {
            i10 = 1;
        } else {
            i10 = 0;
        }
        if (this.f13007m == 1) {
            i12 = 2;
        }
        return i10 | i12;
    }

    public boolean j() {
        return this.f13003i;
    }

    public boolean k() {
        return this.f13001g;
    }

    public boolean l() {
        if (this.f13004j == 1) {
            return true;
        }
        return false;
    }

    public boolean m() {
        if (this.f13005k == 1) {
            return true;
        }
        return false;
    }

    public c n(int i10) {
        this.f13002h = i10;
        this.f13003i = true;
        return this;
    }

    public c o(boolean z10) {
        this.f13006l = z10 ? 1 : 0;
        return this;
    }

    public c p(boolean z10) {
        this.f13011q = z10;
        return this;
    }

    public c q(int i10) {
        this.f13000f = i10;
        this.f13001g = true;
        return this;
    }

    public c r(String str) {
        String str2;
        if (str == null) {
            str2 = null;
        } else {
            str2 = b.e(str);
        }
        this.f12999e = str2;
        return this;
    }

    public c s(float f10) {
        this.f13009o = f10;
        return this;
    }

    public c t(int i10) {
        this.f13008n = i10;
        return this;
    }

    public c u(boolean z10) {
        this.f13007m = z10 ? 1 : 0;
        return this;
    }

    public c v(int i10) {
        this.f13010p = i10;
        return this;
    }

    public void w(String[] strArr) {
        this.f12997c = new HashSet(Arrays.asList(strArr));
    }

    public void x(String str) {
        this.f12995a = str;
    }

    public void y(String str) {
        this.f12996b = str;
    }

    public void z(String str) {
        this.f12998d = str;
    }
}
