package g3;

import g3.e;
import java.util.Comparator;

public final /* synthetic */ class f implements Comparator {
    public final int compare(Object obj, Object obj2) {
        return Integer.compare(((e.b) obj).f13020a.f13023b, ((e.b) obj2).f13020a.f13023b);
    }
}
