package g3;

import a1.a;
import androidx.media3.common.util.b1;
import androidx.media3.common.util.f0;
import androidx.media3.common.util.j;
import java.util.ArrayList;
import java.util.Collections;
import y2.d;
import y2.r;
import y2.s;

public final class a implements s {

    /* renamed from: a  reason: collision with root package name */
    private final f0 f12990a = new f0();

    private static a1.a d(f0 f0Var, int i10) {
        boolean z10;
        CharSequence charSequence = null;
        a.b bVar = null;
        while (i10 > 0) {
            if (i10 >= 8) {
                z10 = true;
            } else {
                z10 = false;
            }
            androidx.media3.common.util.a.b(z10, "Incomplete vtt cue box header found.");
            int q10 = f0Var.q();
            int q11 = f0Var.q();
            int i11 = q10 - 8;
            String M = b1.M(f0Var.e(), f0Var.f(), i11);
            f0Var.V(i11);
            i10 = (i10 - 8) - i11;
            if (q11 == 1937011815) {
                bVar = e.o(M);
            } else if (q11 == 1885436268) {
                charSequence = e.q((String) null, M.trim(), Collections.emptyList());
            }
        }
        if (charSequence == null) {
            charSequence = "";
        }
        if (bVar != null) {
            return bVar.o(charSequence).a();
        }
        return e.l(charSequence);
    }

    public void a(byte[] bArr, int i10, int i11, s.b bVar, j jVar) {
        boolean z10;
        this.f12990a.S(bArr, i11 + i10);
        this.f12990a.U(i10);
        ArrayList arrayList = new ArrayList();
        while (this.f12990a.a() > 0) {
            if (this.f12990a.a() >= 8) {
                z10 = true;
            } else {
                z10 = false;
            }
            androidx.media3.common.util.a.b(z10, "Incomplete Mp4Webvtt Top Level box header found.");
            int q10 = this.f12990a.q();
            if (this.f12990a.q() == 1987343459) {
                arrayList.add(d(this.f12990a, q10 - 8));
            } else {
                this.f12990a.V(q10 - 8);
            }
        }
        jVar.a(new d(arrayList, -9223372036854775807L, -9223372036854775807L));
    }

    public /* synthetic */ y2.j b(byte[] bArr, int i10, int i11) {
        return r.a(this, bArr, i10, i11);
    }

    public int c() {
        return 2;
    }

    public /* synthetic */ void reset() {
        r.b(this);
    }
}
