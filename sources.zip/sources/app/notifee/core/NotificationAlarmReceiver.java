package app.notifee.core;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import m4.r1;

public class NotificationAlarmReceiver extends BroadcastReceiver {
    public void onReceive(Context context, Intent intent) {
        r1.f(intent.getExtras());
    }
}
