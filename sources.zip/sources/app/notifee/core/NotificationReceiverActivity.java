package app.notifee.core;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import sk.l;

public class NotificationReceiverActivity extends Activity {
    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        l.a(this, getIntent());
        finish();
    }

    public void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        l.a(this, intent);
        finish();
    }
}
