package app.notifee.core;

import android.content.Context;
import androidx.annotation.Keep;
import androidx.concurrent.futures.c;
import androidx.work.WorkerParameters;
import androidx.work.k;
import com.google.common.util.concurrent.o;
import m4.l2;
import m4.w;

public class Worker extends k {

    /* renamed from: a  reason: collision with root package name */
    public c.a f8109a;

    @Keep
    public Worker(Context context, WorkerParameters workerParameters) {
        super(context, workerParameters);
    }

    /* access modifiers changed from: private */
    public /* synthetic */ Object c(c.a aVar) {
        this.f8109a = aVar;
        String m10 = getInputData().m("workType");
        if (m10 == null) {
            Logger.d("Worker", "received task with no input key type.");
            aVar.b(k.a.c());
            return "Worker.startWork operation cancelled - no input.";
        } else if (m10.equals("app.notifee.core.BlockStateBroadcastReceiver.WORKER")) {
            Logger.d("Worker", "received task with type " + m10);
            BlockStateBroadcastReceiver.a(getInputData(), aVar);
            return "Worker.startWork operation created successfully.";
        } else if (!m10.equals("app.notifee.core.NotificationManager.TRIGGER")) {
            Logger.d("Worker", "unknown work type received: " + m10);
            aVar.b(k.a.c());
            return "Worker.startWork operation cancelled - unknown work type.";
        } else {
            l2.q(getInputData(), aVar);
            return "Worker.startWork operation created successfully.";
        }
    }

    public void onStopped() {
        c.a aVar = this.f8109a;
        if (aVar != null) {
            aVar.b(k.a.a());
        }
        this.f8109a = null;
    }

    public o startWork() {
        return c.a(new w(this));
    }
}
