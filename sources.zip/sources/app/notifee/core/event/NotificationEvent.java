package app.notifee.core.event;

import android.os.Bundle;
import app.notifee.core.KeepForSdk;
import app.notifee.core.model.NotificationModel;

@KeepForSdk
public class NotificationEvent {
    @KeepForSdk
    public static final int TYPE_ACTION_PRESS = 2;
    @KeepForSdk
    public static final int TYPE_DELIVERED = 3;
    @KeepForSdk
    public static final int TYPE_DISMISSED = 0;
    @KeepForSdk
    public static final int TYPE_FG_ALREADY_EXIST = 8;
    @KeepForSdk
    public static final int TYPE_PRESS = 1;
    @KeepForSdk
    public static final int TYPE_TRIGGER_NOTIFICATION_CREATED = 7;

    /* renamed from: a  reason: collision with root package name */
    public final int f8127a;

    /* renamed from: b  reason: collision with root package name */
    public final Bundle f8128b;

    /* renamed from: c  reason: collision with root package name */
    public final NotificationModel f8129c;

    public NotificationEvent(int i10, NotificationModel notificationModel) {
        this.f8127a = i10;
        this.f8129c = notificationModel;
        this.f8128b = null;
    }

    @KeepForSdk
    public Bundle getExtras() {
        return this.f8128b;
    }

    @KeepForSdk
    public NotificationModel getNotification() {
        return this.f8129c;
    }

    @KeepForSdk
    public int getType() {
        return this.f8127a;
    }

    public NotificationEvent(int i10, NotificationModel notificationModel, Bundle bundle) {
        this.f8127a = i10;
        this.f8129c = notificationModel;
        this.f8128b = bundle;
    }
}
