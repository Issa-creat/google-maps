package app.notifee.core.event;

import app.notifee.core.KeepForSdk;
import app.notifee.core.interfaces.MethodCallResult;
import app.notifee.core.model.NotificationModel;

@KeepForSdk
public class ForegroundServiceEvent {

    /* renamed from: a  reason: collision with root package name */
    public final NotificationModel f8120a;

    /* renamed from: b  reason: collision with root package name */
    public MethodCallResult f8121b;

    /* renamed from: c  reason: collision with root package name */
    public boolean f8122c = false;

    public ForegroundServiceEvent(NotificationModel notificationModel, MethodCallResult methodCallResult) {
        this.f8120a = notificationModel;
        this.f8121b = methodCallResult;
    }

    @KeepForSdk
    public NotificationModel getNotification() {
        return this.f8120a;
    }

    @KeepForSdk
    public void setCompletionResult() {
        if (!this.f8122c) {
            this.f8122c = true;
            this.f8121b.onComplete((Exception) null, null);
        }
    }
}
