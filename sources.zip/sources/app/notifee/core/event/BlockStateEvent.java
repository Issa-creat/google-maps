package app.notifee.core.event;

import android.os.Bundle;
import app.notifee.core.KeepForSdk;
import app.notifee.core.interfaces.MethodCallResult;

@KeepForSdk
public class BlockStateEvent {
    @KeepForSdk
    public static final int TYPE_APP_BLOCKED = 4;
    @KeepForSdk
    public static final int TYPE_CHANNEL_BLOCKED = 5;
    @KeepForSdk
    public static final int TYPE_CHANNEL_GROUP_BLOCKED = 6;

    /* renamed from: a  reason: collision with root package name */
    public int f8115a;

    /* renamed from: b  reason: collision with root package name */
    public boolean f8116b;

    /* renamed from: c  reason: collision with root package name */
    public Bundle f8117c;

    /* renamed from: d  reason: collision with root package name */
    public MethodCallResult f8118d;

    /* renamed from: e  reason: collision with root package name */
    public boolean f8119e = false;

    public BlockStateEvent(int i10, Bundle bundle, boolean z10, MethodCallResult methodCallResult) {
        this.f8115a = i10;
        this.f8118d = methodCallResult;
        this.f8116b = z10;
        this.f8117c = bundle;
    }

    @KeepForSdk
    public Bundle getChannelOrGroupBundle() {
        return this.f8117c;
    }

    @KeepForSdk
    public int getType() {
        return this.f8115a;
    }

    @KeepForSdk
    public boolean isBlocked() {
        return this.f8116b;
    }

    @KeepForSdk
    public void setCompletionResult() {
        if (!this.f8119e) {
            this.f8119e = true;
            this.f8118d.onComplete((Exception) null, null);
        }
    }
}
