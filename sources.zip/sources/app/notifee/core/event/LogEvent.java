package app.notifee.core.event;

import app.notifee.core.KeepForSdk;

@KeepForSdk
public class LogEvent {
    @KeepForSdk
    public static final String LEVEL_DEBUG = "debug";
    @KeepForSdk
    public static final String LEVEL_ERROR = "error";
    @KeepForSdk
    public static final String LEVEL_INFO = "info";
    @KeepForSdk
    public static final String LEVEL_VERBOSE = "verbose";
    @KeepForSdk
    public static final String LEVEL_WARN = "warn";

    /* renamed from: a  reason: collision with root package name */
    public final String f8123a;

    /* renamed from: b  reason: collision with root package name */
    public final String f8124b;

    /* renamed from: c  reason: collision with root package name */
    public final String f8125c;

    /* renamed from: d  reason: collision with root package name */
    public final Throwable f8126d;

    public LogEvent(String str, String str2, String str3) {
        this.f8123a = str2;
        this.f8124b = str;
        this.f8125c = str3;
        this.f8126d = null;
    }

    @KeepForSdk
    public String getLevel() {
        return this.f8124b;
    }

    @KeepForSdk
    public String getMessage() {
        return this.f8125c;
    }

    @KeepForSdk
    public String getTag() {
        return this.f8123a;
    }

    @KeepForSdk
    public Throwable getThrowable() {
        return this.f8126d;
    }

    public LogEvent(String str, String str2, String str3, Throwable th2) {
        this.f8123a = str2;
        this.f8124b = str;
        this.f8125c = str3;
        this.f8126d = th2;
    }
}
