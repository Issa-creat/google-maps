package app.notifee.core.database;

import android.content.Context;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import q3.t;
import q3.u;
import r3.b;
import sk.p;
import v3.g;

public abstract class NotifeeCoreDatabase extends u {

    /* renamed from: p  reason: collision with root package name */
    public static volatile NotifeeCoreDatabase f8110p;

    /* renamed from: q  reason: collision with root package name */
    public static final ExecutorService f8111q = Executors.newCachedThreadPool();

    /* renamed from: r  reason: collision with root package name */
    public static final b f8112r = new a(1, 2);

    public class a extends b {
        public a(int i10, int i11) {
            super(i10, i11);
        }

        public void a(g gVar) {
            gVar.K("ALTER TABLE work_data ADD COLUMN with_alarm_manager INTEGER NOT NULL DEFAULT 0");
        }
    }

    public static NotifeeCoreDatabase D(Context context) {
        if (f8110p == null) {
            synchronized (NotifeeCoreDatabase.class) {
                if (f8110p == null) {
                    f8110p = (NotifeeCoreDatabase) t.a(context.getApplicationContext(), NotifeeCoreDatabase.class, "notifee_core_database").b(f8112r).d();
                }
            }
        }
        return f8110p;
    }

    public abstract p E();
}
