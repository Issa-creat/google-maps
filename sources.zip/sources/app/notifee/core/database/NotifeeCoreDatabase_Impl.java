package app.notifee.core.database;

import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import q3.f;
import q3.o;
import q3.u;
import q3.w;
import s3.b;
import s3.e;
import sk.p;
import sk.q;
import v3.g;
import v3.h;

public final class NotifeeCoreDatabase_Impl extends NotifeeCoreDatabase {

    /* renamed from: s  reason: collision with root package name */
    public volatile p f8113s;

    public class a extends w.b {
        public a(int i10) {
            super(i10);
        }

        public void a(g gVar) {
            gVar.K("CREATE TABLE IF NOT EXISTS `work_data` (`id` TEXT NOT NULL, `notification` BLOB, `trigger` BLOB, `with_alarm_manager` INTEGER NOT NULL DEFAULT 0, PRIMARY KEY(`id`))");
            gVar.K("CREATE TABLE IF NOT EXISTS room_master_table (id INTEGER PRIMARY KEY,identity_hash TEXT)");
            gVar.K("INSERT OR REPLACE INTO room_master_table (id,identity_hash) VALUES(42, '24b2477514809255df232947ce7928c4')");
        }

        public void b(g gVar) {
            gVar.K("DROP TABLE IF EXISTS `work_data`");
            if (NotifeeCoreDatabase_Impl.this.f17034h != null) {
                int size = NotifeeCoreDatabase_Impl.this.f17034h.size();
                for (int i10 = 0; i10 < size; i10++) {
                    ((u.b) NotifeeCoreDatabase_Impl.this.f17034h.get(i10)).b(gVar);
                }
            }
        }

        public void c(g gVar) {
            if (NotifeeCoreDatabase_Impl.this.f17034h != null) {
                int size = NotifeeCoreDatabase_Impl.this.f17034h.size();
                for (int i10 = 0; i10 < size; i10++) {
                    ((u.b) NotifeeCoreDatabase_Impl.this.f17034h.get(i10)).a(gVar);
                }
            }
        }

        public void d(g gVar) {
            g unused = NotifeeCoreDatabase_Impl.this.f17027a = gVar;
            NotifeeCoreDatabase_Impl.this.u(gVar);
            if (NotifeeCoreDatabase_Impl.this.f17034h != null) {
                int size = NotifeeCoreDatabase_Impl.this.f17034h.size();
                for (int i10 = 0; i10 < size; i10++) {
                    ((u.b) NotifeeCoreDatabase_Impl.this.f17034h.get(i10)).c(gVar);
                }
            }
        }

        public void e(g gVar) {
        }

        public void f(g gVar) {
            b.a(gVar);
        }

        public w.c g(g gVar) {
            HashMap hashMap = new HashMap(4);
            hashMap.put("id", new e.a("id", "TEXT", true, 1, (String) null, 1));
            hashMap.put("notification", new e.a("notification", "BLOB", false, 0, (String) null, 1));
            hashMap.put("trigger", new e.a("trigger", "BLOB", false, 0, (String) null, 1));
            hashMap.put("with_alarm_manager", new e.a("with_alarm_manager", "INTEGER", true, 0, "0", 1));
            e eVar = new e("work_data", hashMap, new HashSet(0), new HashSet(0));
            e a10 = e.a(gVar, "work_data");
            if (eVar.equals(a10)) {
                return new w.c(true, (String) null);
            }
            return new w.c(false, "work_data(app.notifee.core.database.WorkDataEntity).\n Expected:\n" + eVar + "\n Found:\n" + a10);
        }
    }

    public p E() {
        p pVar;
        if (this.f8113s != null) {
            return this.f8113s;
        }
        synchronized (this) {
            if (this.f8113s == null) {
                this.f8113s = new q(this);
            }
            pVar = this.f8113s;
        }
        return pVar;
    }

    public o g() {
        return new o(this, new HashMap(0), new HashMap(0), "work_data");
    }

    public h h(f fVar) {
        return fVar.f16952c.a(h.b.a(fVar.f16950a).d(fVar.f16951b).c(new w(fVar, new a(2), "24b2477514809255df232947ce7928c4", "1ddaa4b892e61b0f7010597ddc582ed3")).b());
    }

    public List j(Map map) {
        return Arrays.asList(new r3.b[0]);
    }

    public Set o() {
        return new HashSet();
    }

    public Map p() {
        HashMap hashMap = new HashMap();
        hashMap.put(p.class, Collections.emptyList());
        return hashMap;
    }
}
