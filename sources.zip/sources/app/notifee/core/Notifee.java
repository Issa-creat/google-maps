package app.notifee.core;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.PowerManager;
import app.notifee.core.interfaces.EventListener;
import app.notifee.core.interfaces.MethodCallResult;
import app.notifee.core.model.NotificationModel;
import hd.j;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ExecutorService;
import m4.g;
import m4.h;
import m4.i;
import m4.k;
import m4.k1;
import m4.l;
import m4.l2;
import m4.m;
import m4.n;
import m4.o;
import m4.p;
import m4.q;
import m4.r;
import m4.s;
import m4.t;
import m4.u;
import m4.v;
import sk.a;
import sk.b;
import sk.c;
import sk.e;
import sk.f;

@KeepForSdk
public class Notifee {
    @KeepForSdk
    public static final int REQUEST_CODE_NOTIFICATION_PERMISSION = 11111;

    /* renamed from: b  reason: collision with root package name */
    public static Notifee f8105b = null;

    /* renamed from: c  reason: collision with root package name */
    public static boolean f8106c = false;

    /* renamed from: a  reason: collision with root package name */
    public MethodCallResult f8107a;

    public static /* synthetic */ void b(MethodCallResult methodCallResult, j jVar) {
        if (jVar.p()) {
            methodCallResult.onComplete((Exception) null, (Void) jVar.l());
        } else {
            methodCallResult.onComplete(jVar.k(), null);
        }
    }

    public static /* synthetic */ void c(MethodCallResult methodCallResult, j jVar) {
        if (jVar.p()) {
            methodCallResult.onComplete((Exception) null, (Void) jVar.l());
        } else {
            methodCallResult.onComplete(jVar.k(), null);
        }
    }

    public static /* synthetic */ void d(MethodCallResult methodCallResult, j jVar) {
        if (jVar.p()) {
            methodCallResult.onComplete((Exception) null, (Void) jVar.l());
        } else {
            methodCallResult.onComplete(jVar.k(), null);
        }
    }

    public static /* synthetic */ void e(MethodCallResult methodCallResult, j jVar) {
        if (jVar.p()) {
            methodCallResult.onComplete((Exception) null, (Void) jVar.l());
        } else {
            methodCallResult.onComplete(jVar.k(), null);
        }
    }

    public static /* synthetic */ void f(MethodCallResult methodCallResult, j jVar) {
        if (jVar.p()) {
            methodCallResult.onComplete((Exception) null, (Void) jVar.l());
        } else {
            methodCallResult.onComplete(jVar.k(), null);
        }
    }

    public static /* synthetic */ void g(MethodCallResult methodCallResult, j jVar) {
        if (jVar.p()) {
            methodCallResult.onComplete((Exception) null, (Void) jVar.l());
        } else {
            methodCallResult.onComplete(jVar.k(), null);
        }
    }

    @KeepForSdk
    public static Context getContext() {
        return e.f48818a;
    }

    @KeepForSdk
    public static Notifee getInstance() {
        if (!f8106c) {
            Logger.w("API", "getInstance() accessed before event listener is initialized");
            f8105b = new Notifee();
        }
        return f8105b;
    }

    public static /* synthetic */ void h(MethodCallResult methodCallResult, j jVar) {
        if (jVar.p()) {
            methodCallResult.onComplete((Exception) null, null);
            return;
        }
        Logger.e("API", "createTriggerNotification", jVar.k());
        methodCallResult.onComplete(jVar.k(), null);
    }

    public static /* synthetic */ void i(MethodCallResult methodCallResult, j jVar) {
        if (jVar.p()) {
            methodCallResult.onComplete((Exception) null, null);
            return;
        }
        Logger.e("API", "displayNotification", jVar.k());
        methodCallResult.onComplete(jVar.k(), null);
    }

    @KeepForSdk
    public static void initialize(EventListener eventListener) {
        synchronized (Notifee.class) {
            if (!f8106c) {
                if (f8105b == null) {
                    f8105b = new Notifee();
                }
                if (eventListener != null) {
                    EventSubscriber.register(eventListener);
                }
                f8106c = true;
            }
        }
    }

    public static /* synthetic */ void j(MethodCallResult methodCallResult, j jVar) {
        if (jVar.p()) {
            methodCallResult.onComplete((Exception) null, (Bundle) jVar.l());
        } else {
            methodCallResult.onComplete(jVar.k(), null);
        }
    }

    public static /* synthetic */ void k(MethodCallResult methodCallResult, j jVar) {
        if (jVar.p()) {
            methodCallResult.onComplete((Exception) null, (Bundle) jVar.l());
        } else {
            methodCallResult.onComplete(jVar.k(), null);
        }
    }

    public static /* synthetic */ void l(MethodCallResult methodCallResult, j jVar) {
        if (jVar.p()) {
            methodCallResult.onComplete((Exception) null, (List) jVar.l());
        } else {
            methodCallResult.onComplete(jVar.k(), null);
        }
    }

    public static /* synthetic */ void m(MethodCallResult methodCallResult, j jVar) {
        if (jVar.p()) {
            methodCallResult.onComplete((Exception) null, (List) jVar.l());
        } else {
            methodCallResult.onComplete(jVar.k(), null);
        }
    }

    public static /* synthetic */ void n(MethodCallResult methodCallResult, j jVar) {
        if (jVar.p()) {
            methodCallResult.onComplete((Exception) null, (List) jVar.l());
        } else {
            methodCallResult.onComplete(jVar.k(), null);
        }
    }

    public static /* synthetic */ void o(MethodCallResult methodCallResult, j jVar) {
        if (jVar.p()) {
            methodCallResult.onComplete((Exception) null, (Boolean) jVar.l());
        } else {
            methodCallResult.onComplete(jVar.k(), null);
        }
    }

    public static /* synthetic */ void p(MethodCallResult methodCallResult, j jVar) {
        if (jVar.p()) {
            methodCallResult.onComplete((Exception) null, (Boolean) jVar.l());
        } else {
            methodCallResult.onComplete(jVar.k(), null);
        }
    }

    @KeepForSdk
    public void cancelAllNotifications(int i10, MethodCallResult<Void> methodCallResult) {
        l2.e(i10).b(new v(methodCallResult));
    }

    @KeepForSdk
    public void cancelAllNotificationsWithIds(int i10, List<String> list, String str, MethodCallResult<Void> methodCallResult) {
        l2.f(i10, list, str).b(new u(methodCallResult));
    }

    @KeepForSdk
    public void createChannel(Bundle bundle, MethodCallResult<Void> methodCallResult) {
        k1.g(new c(bundle)).b(new r(methodCallResult));
    }

    @KeepForSdk
    public void createChannelGroup(Bundle bundle, MethodCallResult<Void> methodCallResult) {
        k1.f(new b(bundle)).b(new k(methodCallResult));
    }

    @KeepForSdk
    public void createChannelGroups(List<Bundle> list, MethodCallResult<Void> methodCallResult) {
        ArrayList arrayList = new ArrayList(list.size());
        for (Bundle bVar : list) {
            arrayList.add(new b(bVar));
        }
        k1.e(arrayList).b(new q(methodCallResult));
    }

    @KeepForSdk
    public void createChannels(List<Bundle> list, MethodCallResult<Void> methodCallResult) {
        ArrayList arrayList = new ArrayList(list.size());
        for (Bundle cVar : list) {
            arrayList.add(new c(cVar));
        }
        k1.j(arrayList).b(new n(methodCallResult));
    }

    @KeepForSdk
    public void createTriggerNotification(Bundle bundle, Bundle bundle2, MethodCallResult<Void> methodCallResult) {
        l2.i(new NotificationModel(bundle), bundle2).b(new o(methodCallResult));
    }

    @KeepForSdk
    public void deleteChannel(String str, MethodCallResult<Void> methodCallResult) {
        ExecutorService executorService = k1.f15775a;
        androidx.core.app.v.i(e.f48818a).g(str);
        methodCallResult.onComplete((Exception) null, null);
    }

    @KeepForSdk
    public void deleteChannelGroup(String str, MethodCallResult<Void> methodCallResult) {
        ExecutorService executorService = k1.f15775a;
        androidx.core.app.v.i(e.f48818a).h(str);
        methodCallResult.onComplete((Exception) null, null);
    }

    @KeepForSdk
    public void displayNotification(Bundle bundle, MethodCallResult<Void> methodCallResult) {
        l2.v(new NotificationModel(bundle), (Bundle) null).b(new g(methodCallResult));
    }

    @KeepForSdk
    public void getChannel(String str, MethodCallResult<Bundle> methodCallResult) {
        k1.d(str).b(new t(methodCallResult));
    }

    @KeepForSdk
    public void getChannelGroup(String str, MethodCallResult<Bundle> methodCallResult) {
        k1.i(str).b(new i(methodCallResult));
    }

    @KeepForSdk
    public void getChannelGroups(MethodCallResult<List<Bundle>> methodCallResult) {
        k1.c().b(new p(methodCallResult));
    }

    @KeepForSdk
    public void getChannels(MethodCallResult<List<Bundle>> methodCallResult) {
        k1.h().b(new l(methodCallResult));
    }

    @KeepForSdk
    public void getDisplayedNotifications(MethodCallResult<List<Bundle>> methodCallResult) {
        l2.d().b(new m(methodCallResult));
    }

    @KeepForSdk
    public void getInitialNotification(Activity activity, MethodCallResult<Bundle> methodCallResult) {
        sk.g gVar = (sk.g) f.f48819b.f48820a.q(sk.g.class);
        Bundle bundle = new Bundle();
        if (gVar != null) {
            bundle.putAll(gVar.f48822b);
            bundle.putBundle("notification", gVar.f48821a.toBundle());
            methodCallResult.onComplete((Exception) null, bundle);
            return;
        }
        if (activity != null) {
            try {
                Intent intent = activity.getIntent();
                if (!(intent == null || intent.getExtras() == null || !intent.hasExtra("notification"))) {
                    bundle.putBundle("notification", intent.getBundleExtra("notification"));
                    methodCallResult.onComplete((Exception) null, bundle);
                    return;
                }
            } catch (Exception e10) {
                Logger.e("API", "getInitialNotification", e10);
            }
        }
        methodCallResult.onComplete((Exception) null, null);
    }

    @KeepForSdk
    public String getMainComponent(String str) {
        sk.j jVar = (sk.j) f.f48819b.f48820a.q(sk.j.class);
        if (jVar == null) {
            return str;
        }
        return jVar.f48825a;
    }

    @KeepForSdk
    public void getNotificationSettings(MethodCallResult<Bundle> methodCallResult) {
        boolean z10;
        boolean a10 = androidx.core.app.v.i(e.f48818a).a();
        Bundle bundle = new Bundle();
        if (a10) {
            bundle.putInt("authorizationStatus", 1);
        } else {
            bundle.putInt("authorizationStatus", 0);
        }
        if (Build.VERSION.SDK_INT >= 31) {
            z10 = a.a().canScheduleExactAlarms();
        } else {
            z10 = true;
        }
        Bundle bundle2 = new Bundle();
        if (z10) {
            bundle2.putInt("alarm", 1);
        } else {
            bundle2.putInt("alarm", 0);
        }
        bundle.putBundle("android", bundle2);
        methodCallResult.onComplete((Exception) null, bundle);
    }

    @KeepForSdk
    public void getPowerManagerInfo(MethodCallResult<Bundle> methodCallResult) {
        String b10 = sk.i.b(sk.n.a(e.f48818a));
        String str = Build.MANUFACTURER;
        String str2 = Build.MODEL;
        String str3 = Build.VERSION.RELEASE;
        Bundle bundle = new Bundle();
        bundle.putString("manufacturer", str);
        bundle.putString("model", str2);
        bundle.putString("version", str3);
        bundle.putString("activity", b10);
        methodCallResult.onComplete((Exception) null, bundle);
    }

    @KeepForSdk
    public void getTriggerNotificationIds(MethodCallResult<List<String>> methodCallResult) {
        l2.r(methodCallResult);
    }

    @KeepForSdk
    public void getTriggerNotifications(MethodCallResult<List<Bundle>> methodCallResult) {
        l2.y(methodCallResult);
    }

    @KeepForSdk
    public void isBatteryOptimizationEnabled(MethodCallResult<Boolean> methodCallResult) {
        Boolean bool;
        Context context = e.f48818a;
        if (Build.VERSION.SDK_INT < 23) {
            bool = Boolean.FALSE;
        } else {
            bool = Boolean.valueOf(!((PowerManager) context.getSystemService("power")).isIgnoringBatteryOptimizations(context.getPackageName()));
        }
        methodCallResult.onComplete((Exception) null, bool);
    }

    @KeepForSdk
    public void isChannelBlocked(String str, MethodCallResult<Boolean> methodCallResult) {
        k1.m(str).b(new h(methodCallResult));
    }

    @KeepForSdk
    public void isChannelCreated(String str, MethodCallResult<Boolean> methodCallResult) {
        k1.p(str).b(new m4.j(methodCallResult));
    }

    @KeepForSdk
    public boolean onRequestPermissionsResult(int i10, String[] strArr, int[] iArr) {
        MethodCallResult methodCallResult;
        if (i10 != 11111 || (methodCallResult = this.f8107a) == null) {
            return false;
        }
        getNotificationSettings(methodCallResult);
        return true;
    }

    @KeepForSdk
    public void openAlarmPermissionSettings(Activity activity, MethodCallResult<Void> methodCallResult) {
        if (Build.VERSION.SDK_INT >= 31) {
            try {
                Intent intent = new Intent();
                intent.setFlags(268435456);
                intent.setAction("android.settings.REQUEST_SCHEDULE_EXACT_ALARM");
                String packageName = e.f48818a.getPackageName();
                intent.setData(Uri.parse("package:" + packageName));
                sk.i.c(activity, intent);
            } catch (Exception e10) {
                Logger.e("AlarmUtils", "An error occurred whilst trying to open alarm permission settings", e10);
            }
        }
        methodCallResult.onComplete((Exception) null, null);
    }

    @KeepForSdk
    public void openBatteryOptimizationSettings(Activity activity, MethodCallResult<Void> methodCallResult) {
        if (Build.VERSION.SDK_INT >= 23) {
            try {
                Intent intent = new Intent();
                intent.setAction("android.settings.IGNORE_BATTERY_OPTIMIZATION_SETTINGS");
                intent.setFlags(268435456);
                if (activity != null) {
                    if (!Boolean.valueOf(sk.i.d(e.f48818a, intent)).booleanValue()) {
                        Logger.d("PowerManagerUtils", "battery optimization settings is not available on device");
                    } else {
                        sk.i.c(activity, intent);
                    }
                }
            } catch (Exception e10) {
                Logger.e("PowerManagerUtils", "An error occurred whilst trying to open battery optimization settings", e10);
            }
        }
        methodCallResult.onComplete((Exception) null, null);
    }

    @KeepForSdk
    public void openNotificationSettings(String str, Activity activity, MethodCallResult<Void> methodCallResult) {
        Intent intent;
        if (getContext() == null || activity == null) {
            Logger.d("openNotificationSettings", "attempted to start activity but no current activity or context was available.");
            methodCallResult.onComplete((Exception) null, null);
            return;
        }
        if (Build.VERSION.SDK_INT >= 26) {
            if (str != null) {
                intent = new Intent("android.settings.CHANNEL_NOTIFICATION_SETTINGS");
                intent.putExtra("android.provider.extra.CHANNEL_ID", str);
            } else {
                intent = new Intent("android.settings.APP_NOTIFICATION_SETTINGS");
            }
            intent.putExtra("android.provider.extra.APP_PACKAGE", getContext().getPackageName());
        } else {
            intent = new Intent("android.settings.APPLICATION_SETTINGS");
        }
        intent.setFlags(268435456);
        activity.runOnUiThread(new s(intent));
        methodCallResult.onComplete((Exception) null, null);
    }

    @KeepForSdk
    public void openPowerManagerSettings(Activity activity, MethodCallResult<Void> methodCallResult) {
        Intent intent;
        synchronized (sk.n.class) {
            intent = sk.n.f48826a;
        }
        if (intent == null) {
            intent = sk.n.a(e.f48818a);
        }
        if (intent != null) {
            try {
                intent.setFlags(268435456);
                sk.i.c(activity, intent);
            } catch (Exception e10) {
                Logger.e("PowerManagerUtils", "Unable to start activity: " + sk.i.b(intent), e10);
            }
        } else {
            Logger.w("PowerManagerUtils", "Unable to find an activity to open the device's power manager");
        }
        methodCallResult.onComplete((Exception) null, null);
    }

    @KeepForSdk
    public void setRequestPermissionCallback(MethodCallResult<Bundle> methodCallResult) {
        this.f8107a = methodCallResult;
    }

    @KeepForSdk
    public void stopForegroundService(MethodCallResult<Void> methodCallResult) {
        String str = ForegroundService.f8104a;
        Intent intent = new Intent(e.f48818a, ForegroundService.class);
        intent.setAction("app.notifee.core.ForegroundService.STOP");
        try {
            e.f48818a.startService(intent);
        } catch (IllegalStateException unused) {
            e.f48818a.stopService(intent);
        } catch (Exception e10) {
            Logger.e("ForegroundService", "Unable to stop foreground service", e10);
        }
        methodCallResult.onComplete((Exception) null, null);
    }
}
