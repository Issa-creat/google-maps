package app.notifee.core.model;

import android.os.Bundle;
import app.notifee.core.KeepForSdk;
import java.util.Objects;

@KeepForSdk
public class NotificationModel {

    /* renamed from: a  reason: collision with root package name */
    public Bundle f8133a;

    public NotificationModel(Bundle bundle) {
        this.f8133a = bundle;
    }

    public NotificationAndroidModel a() {
        return NotificationAndroidModel.fromBundle(this.f8133a.getBundle("android"));
    }

    public Integer b() {
        return Integer.valueOf(c().hashCode());
    }

    public String c() {
        String string = this.f8133a.getString("id");
        Objects.requireNonNull(string);
        return string;
    }

    @KeepForSdk
    public Bundle toBundle() {
        return (Bundle) this.f8133a.clone();
    }
}
