package app.notifee.core.model;

import android.os.Bundle;
import androidx.annotation.Keep;
import androidx.core.app.q;
import androidx.core.app.w;
import androidx.core.text.b;
import hd.j;
import hd.m;
import java.util.ArrayList;
import java.util.Objects;
import java.util.concurrent.Executor;
import java.util.concurrent.TimeUnit;
import o4.a;
import o4.c;

@Keep
public class NotificationAndroidStyleModel {
    private static final String TAG = "NotificationAndroidStyle";
    private Bundle mNotificationAndroidStyleBundle;

    private NotificationAndroidStyleModel(Bundle bundle) {
        this.mNotificationAndroidStyleBundle = bundle;
    }

    public static NotificationAndroidStyleModel fromBundle(Bundle bundle) {
        return new NotificationAndroidStyleModel(bundle);
    }

    private j getBigPictureStyleTask(Executor executor) {
        return m.d(executor, new c(this));
    }

    private q.c getBigTextStyle() {
        q.c cVar = new q.c();
        if (this.mNotificationAndroidStyleBundle.containsKey("text")) {
            cVar = cVar.m(b.a(this.mNotificationAndroidStyleBundle.getString("text"), 0));
        }
        if (this.mNotificationAndroidStyleBundle.containsKey("title")) {
            cVar = cVar.n(b.a(this.mNotificationAndroidStyleBundle.getString("title"), 0));
        }
        if (this.mNotificationAndroidStyleBundle.containsKey("summary")) {
            return cVar.o(b.a(this.mNotificationAndroidStyleBundle.getString("summary"), 0));
        }
        return cVar;
    }

    private q.f getInboxStyle() {
        q.f fVar = new q.f();
        if (this.mNotificationAndroidStyleBundle.containsKey("title")) {
            fVar = fVar.n(b.a(this.mNotificationAndroidStyleBundle.getString("title"), 0));
        }
        if (this.mNotificationAndroidStyleBundle.containsKey("summary")) {
            fVar = fVar.o(b.a(this.mNotificationAndroidStyleBundle.getString("summary"), 0));
        }
        ArrayList<String> stringArrayList = this.mNotificationAndroidStyleBundle.getStringArrayList("lines");
        int i10 = 0;
        while (true) {
            Objects.requireNonNull(stringArrayList);
            if (i10 >= stringArrayList.size()) {
                return fVar;
            }
            fVar = fVar.m(b.a(stringArrayList.get(i10), 0));
            i10++;
        }
    }

    private j getMessagingStyleTask(Executor executor) {
        return m.d(executor, new o4.b(this, executor));
    }

    private static j getPerson(Executor executor, Bundle bundle) {
        return m.d(executor, new a(bundle));
    }

    /* access modifiers changed from: private */
    /* JADX WARNING: Removed duplicated region for block: B:11:0x0058  */
    /* JADX WARNING: Removed duplicated region for block: B:14:0x0065  */
    /* JADX WARNING: Removed duplicated region for block: B:17:0x0071  */
    /* JADX WARNING: Removed duplicated region for block: B:19:0x0074 A[SYNTHETIC, Splitter:B:19:0x0074] */
    /* JADX WARNING: Removed duplicated region for block: B:30:0x00bd  */
    /* JADX WARNING: Removed duplicated region for block: B:33:0x00d5  */
    /* JADX WARNING: Removed duplicated region for block: B:35:? A[RETURN, SYNTHETIC] */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public androidx.core.app.q.h lambda$getBigPictureStyleTask$1() {
        /*
            r9 = this;
            androidx.core.app.q$b r0 = new androidx.core.app.q$b
            r0.<init>()
            android.os.Bundle r1 = r9.mNotificationAndroidStyleBundle
            java.lang.String r2 = "picture"
            boolean r1 = r1.containsKey(r2)
            r3 = 10
            java.lang.String r5 = "NotificationAndroidStyle"
            r6 = 0
            if (r1 == 0) goto L_0x005b
            android.os.Bundle r1 = r9.mNotificationAndroidStyleBundle
            java.lang.String r1 = r1.getString(r2)
            java.util.Objects.requireNonNull(r1)
            hd.j r2 = sk.o.b(r1)     // Catch:{ TimeoutException -> 0x0040, Exception -> 0x002a }
            java.util.concurrent.TimeUnit r7 = java.util.concurrent.TimeUnit.SECONDS     // Catch:{ TimeoutException -> 0x0040, Exception -> 0x002a }
            java.lang.Object r2 = hd.m.b(r2, r3, r7)     // Catch:{ TimeoutException -> 0x0040, Exception -> 0x002a }
            android.graphics.Bitmap r2 = (android.graphics.Bitmap) r2     // Catch:{ TimeoutException -> 0x0040, Exception -> 0x002a }
            goto L_0x0056
        L_0x002a:
            r2 = move-exception
            java.lang.StringBuilder r7 = new java.lang.StringBuilder
            r7.<init>()
            java.lang.String r8 = "An error occurred whilst trying to retrieve a big picture style image: "
            r7.append(r8)
            r7.append(r1)
            java.lang.String r1 = r7.toString()
            app.notifee.core.Logger.e((java.lang.String) r5, (java.lang.String) r1, (java.lang.Exception) r2)
            goto L_0x0055
        L_0x0040:
            r2 = move-exception
            java.lang.StringBuilder r7 = new java.lang.StringBuilder
            r7.<init>()
            java.lang.String r8 = "Timeout occurred whilst trying to retrieve a big picture style image: "
            r7.append(r8)
            r7.append(r1)
            java.lang.String r1 = r7.toString()
            app.notifee.core.Logger.e((java.lang.String) r5, (java.lang.String) r1, (java.lang.Exception) r2)
        L_0x0055:
            r2 = r6
        L_0x0056:
            if (r2 == 0) goto L_0x005b
            r0.n(r2)
        L_0x005b:
            android.os.Bundle r1 = r9.mNotificationAndroidStyleBundle
            java.lang.String r2 = "largeIcon"
            boolean r1 = r1.containsKey(r2)
            if (r1 == 0) goto L_0x0071
            android.os.Bundle r1 = r9.mNotificationAndroidStyleBundle
            java.lang.String r1 = r1.getString(r2)
            if (r1 != 0) goto L_0x0072
            r0.m(r6)
            goto L_0x0072
        L_0x0071:
            r1 = r6
        L_0x0072:
            if (r1 == 0) goto L_0x00b2
            hd.j r2 = sk.o.b(r1)     // Catch:{ TimeoutException -> 0x0098, Exception -> 0x0082 }
            java.util.concurrent.TimeUnit r7 = java.util.concurrent.TimeUnit.SECONDS     // Catch:{ TimeoutException -> 0x0098, Exception -> 0x0082 }
            java.lang.Object r2 = hd.m.b(r2, r3, r7)     // Catch:{ TimeoutException -> 0x0098, Exception -> 0x0082 }
            android.graphics.Bitmap r2 = (android.graphics.Bitmap) r2     // Catch:{ TimeoutException -> 0x0098, Exception -> 0x0082 }
            r6 = r2
            goto L_0x00ad
        L_0x0082:
            r2 = move-exception
            java.lang.StringBuilder r3 = new java.lang.StringBuilder
            r3.<init>()
            java.lang.String r4 = "An error occurred whilst trying to retrieve a big picture style large icon: "
            r3.append(r4)
            r3.append(r1)
            java.lang.String r1 = r3.toString()
            app.notifee.core.Logger.e((java.lang.String) r5, (java.lang.String) r1, (java.lang.Exception) r2)
            goto L_0x00ad
        L_0x0098:
            r2 = move-exception
            java.lang.StringBuilder r3 = new java.lang.StringBuilder
            r3.<init>()
            java.lang.String r4 = "Timeout occurred whilst trying to retrieve a big picture style large icon: "
            r3.append(r4)
            r3.append(r1)
            java.lang.String r1 = r3.toString()
            app.notifee.core.Logger.e((java.lang.String) r5, (java.lang.String) r1, (java.lang.Exception) r2)
        L_0x00ad:
            if (r6 == 0) goto L_0x00b2
            r0.m(r6)
        L_0x00b2:
            android.os.Bundle r1 = r9.mNotificationAndroidStyleBundle
            java.lang.String r2 = "title"
            boolean r1 = r1.containsKey(r2)
            r3 = 0
            if (r1 == 0) goto L_0x00cb
            android.os.Bundle r1 = r9.mNotificationAndroidStyleBundle
            java.lang.String r1 = r1.getString(r2)
            android.text.Spanned r1 = androidx.core.text.b.a(r1, r3)
            androidx.core.app.q$b r0 = r0.o(r1)
        L_0x00cb:
            android.os.Bundle r1 = r9.mNotificationAndroidStyleBundle
            java.lang.String r2 = "summary"
            boolean r1 = r1.containsKey(r2)
            if (r1 == 0) goto L_0x00e3
            android.os.Bundle r1 = r9.mNotificationAndroidStyleBundle
            java.lang.String r1 = r1.getString(r2)
            android.text.Spanned r1 = androidx.core.text.b.a(r1, r3)
            androidx.core.app.q$b r0 = r0.p(r1)
        L_0x00e3:
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: app.notifee.core.model.NotificationAndroidStyleModel.lambda$getBigPictureStyleTask$1():androidx.core.app.q$h");
    }

    /* access modifiers changed from: private */
    public q.h lambda$getMessagingStyleTask$2(Executor executor) {
        w wVar;
        Bundle bundle = this.mNotificationAndroidStyleBundle.getBundle("person");
        Objects.requireNonNull(bundle);
        q.g gVar = new q.g((w) m.b(getPerson(executor, bundle), 20, TimeUnit.SECONDS));
        if (this.mNotificationAndroidStyleBundle.containsKey("title")) {
            gVar = gVar.t(b.a(this.mNotificationAndroidStyleBundle.getString("title"), 0));
        }
        if (this.mNotificationAndroidStyleBundle.containsKey("group")) {
            gVar = gVar.u(this.mNotificationAndroidStyleBundle.getBoolean("group"));
        }
        ArrayList parcelableArrayList = this.mNotificationAndroidStyleBundle.getParcelableArrayList("messages");
        int i10 = 0;
        while (true) {
            Objects.requireNonNull(parcelableArrayList);
            if (i10 >= parcelableArrayList.size()) {
                return gVar;
            }
            Bundle bundle2 = (Bundle) parcelableArrayList.get(i10);
            long d10 = sk.m.d(bundle2.get("timestamp"));
            if (bundle2.containsKey("person")) {
                Bundle bundle3 = bundle2.getBundle("person");
                Objects.requireNonNull(bundle3);
                wVar = (w) m.b(getPerson(executor, bundle3), 20, TimeUnit.SECONDS);
            } else {
                wVar = null;
            }
            gVar = gVar.n(b.a(bundle2.getString("text"), 0), d10, wVar);
            i10++;
        }
    }

    /* access modifiers changed from: private */
    /* JADX WARNING: Removed duplicated region for block: B:20:0x0089  */
    /* JADX WARNING: Removed duplicated region for block: B:23:0x0098  */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public static /* synthetic */ androidx.core.app.w lambda$getPerson$0(android.os.Bundle r7) {
        /*
            java.lang.String r0 = "NotificationAndroidStyle"
            androidx.core.app.w$b r1 = new androidx.core.app.w$b
            r1.<init>()
            java.lang.String r2 = "name"
            java.lang.String r2 = r7.getString(r2)
            r1.f(r2)
            java.lang.String r2 = "id"
            boolean r3 = r7.containsKey(r2)
            if (r3 == 0) goto L_0x001f
            java.lang.String r2 = r7.getString(r2)
            r1.e(r2)
        L_0x001f:
            java.lang.String r2 = "bot"
            boolean r3 = r7.containsKey(r2)
            if (r3 == 0) goto L_0x002e
            boolean r2 = r7.getBoolean(r2)
            r1.b(r2)
        L_0x002e:
            java.lang.String r2 = "important"
            boolean r3 = r7.containsKey(r2)
            if (r3 == 0) goto L_0x003d
            boolean r2 = r7.getBoolean(r2)
            r1.d(r2)
        L_0x003d:
            java.lang.String r2 = "icon"
            boolean r3 = r7.containsKey(r2)
            if (r3 == 0) goto L_0x0090
            java.lang.String r2 = r7.getString(r2)
            java.util.Objects.requireNonNull(r2)
            hd.j r3 = sk.o.b(r2)     // Catch:{ TimeoutException -> 0x0071, Exception -> 0x005b }
            java.util.concurrent.TimeUnit r4 = java.util.concurrent.TimeUnit.SECONDS     // Catch:{ TimeoutException -> 0x0071, Exception -> 0x005b }
            r5 = 10
            java.lang.Object r3 = hd.m.b(r3, r5, r4)     // Catch:{ TimeoutException -> 0x0071, Exception -> 0x005b }
            android.graphics.Bitmap r3 = (android.graphics.Bitmap) r3     // Catch:{ TimeoutException -> 0x0071, Exception -> 0x005b }
            goto L_0x0087
        L_0x005b:
            r3 = move-exception
            java.lang.StringBuilder r4 = new java.lang.StringBuilder
            r4.<init>()
            java.lang.String r5 = "An error occurred whilst trying to retrieve a person icon: "
            r4.append(r5)
            r4.append(r2)
            java.lang.String r2 = r4.toString()
            app.notifee.core.Logger.e((java.lang.String) r0, (java.lang.String) r2, (java.lang.Exception) r3)
            goto L_0x0086
        L_0x0071:
            r3 = move-exception
            java.lang.StringBuilder r4 = new java.lang.StringBuilder
            r4.<init>()
            java.lang.String r5 = "Timeout occurred whilst trying to retrieve a person icon: "
            r4.append(r5)
            r4.append(r2)
            java.lang.String r2 = r4.toString()
            app.notifee.core.Logger.e((java.lang.String) r0, (java.lang.String) r2, (java.lang.Exception) r3)
        L_0x0086:
            r3 = 0
        L_0x0087:
            if (r3 == 0) goto L_0x0090
            androidx.core.graphics.drawable.IconCompat r0 = androidx.core.graphics.drawable.IconCompat.d(r3)
            r1.c(r0)
        L_0x0090:
            java.lang.String r0 = "uri"
            boolean r2 = r7.containsKey(r0)
            if (r2 == 0) goto L_0x009f
            java.lang.String r7 = r7.getString(r0)
            r1.g(r7)
        L_0x009f:
            androidx.core.app.w r7 = r1.a()
            return r7
        */
        throw new UnsupportedOperationException("Method not decompiled: app.notifee.core.model.NotificationAndroidStyleModel.lambda$getPerson$0(android.os.Bundle):androidx.core.app.w");
    }

    public j getStyleTask(Executor executor) {
        int a10 = sk.m.a(this.mNotificationAndroidStyleBundle.get("type"));
        if (a10 == 0) {
            return getBigPictureStyleTask(executor);
        }
        if (a10 == 1) {
            return m.f(getBigTextStyle());
        }
        if (a10 == 2) {
            return m.f(getInboxStyle());
        }
        if (a10 != 3) {
            return null;
        }
        return getMessagingStyleTask(executor);
    }

    public Bundle toBundle() {
        return (Bundle) this.mNotificationAndroidStyleBundle.clone();
    }
}
