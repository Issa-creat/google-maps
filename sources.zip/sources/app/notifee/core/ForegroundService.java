package app.notifee.core;

import android.app.Notification;
import android.app.Service;
import android.content.Intent;
import android.os.Bundle;
import android.os.IBinder;
import androidx.core.app.v;
import app.notifee.core.event.ForegroundServiceEvent;
import app.notifee.core.event.NotificationEvent;
import app.notifee.core.model.NotificationModel;
import m4.d;
import sk.e;
import sk.f;

public class ForegroundService extends Service {

    /* renamed from: a  reason: collision with root package name */
    public static String f8104a;

    public IBinder onBind(Intent intent) {
        return null;
    }

    public int onStartCommand(Intent intent, int i10, int i11) {
        boolean z10;
        boolean z11 = false;
        if (intent == null || "app.notifee.core.ForegroundService.STOP".equals(intent.getAction())) {
            stopSelf();
            f8104a = null;
            return 0;
        }
        Bundle extras = intent.getExtras();
        if (extras == null) {
            return 2;
        }
        int i12 = extras.getInt("hashCode");
        Notification notification = (Notification) extras.getParcelable("notification");
        Bundle bundle = extras.getBundle("notificationBundle");
        if (notification != null) {
            z10 = true;
        } else {
            z10 = false;
        }
        if (bundle != null) {
            z11 = true;
        }
        if (!z11 || !z10) {
            return 2;
        }
        NotificationModel notificationModel = new NotificationModel(bundle);
        String str = f8104a;
        if (str == null) {
            f8104a = notificationModel.c();
            startForeground(i12, notification);
            f.a(new ForegroundServiceEvent(notificationModel, new d(this)));
            return 2;
        } else if (str.equals(notificationModel.c())) {
            v.i(e.f48818a).o(i12, notification);
            return 2;
        } else {
            f.a(new NotificationEvent(8, notificationModel));
            return 2;
        }
    }

    /* access modifiers changed from: private */
    public /* synthetic */ void a(Exception exc, Void voidR) {
        stopForeground(true);
        f8104a = null;
    }
}
