package app.notifee.core;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.util.Log;
import m4.r1;
import sk.e;

public class RebootBroadcastReceiver extends BroadcastReceiver {
    public void onReceive(Context context, Intent intent) {
        Log.i("RebootReceiver", "Received reboot event");
        if (e.f48818a == null) {
            e.a(context.getApplicationContext());
        }
        new r1().j();
    }
}
