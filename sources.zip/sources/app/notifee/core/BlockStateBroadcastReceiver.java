package app.notifee.core;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import androidx.concurrent.futures.c;
import androidx.work.d;
import androidx.work.f;
import androidx.work.k;
import androidx.work.n;
import androidx.work.w;
import java.util.concurrent.TimeUnit;
import m4.a;
import m4.b;
import sk.e;
import sk.m;

public class BlockStateBroadcastReceiver extends BroadcastReceiver {
    public static void a(d dVar, c.a aVar) {
        Logger.v("BlockState", "starting background work");
        boolean i10 = dVar.i("blocked", false);
        int k10 = dVar.k("type", 4);
        a aVar2 = new a(aVar, k10, i10);
        if (k10 == 4) {
            aVar2.a((Object) null);
            return;
        }
        b bVar = new b(aVar, aVar2);
        String m10 = dVar.m("channelOrGroupId");
        if (k10 == 5) {
            Notifee.getInstance().getChannel(m10, bVar);
        } else if (k10 == 6) {
            Notifee.getInstance().getChannelGroup(m10, bVar);
        } else {
            Logger.e("BlockState", "unknown block state work type");
            aVar.b(k.a.c());
        }
    }

    public void onReceive(Context context, Intent intent) {
        String action;
        if (Build.VERSION.SDK_INT >= 28 && (action = intent.getAction()) != null) {
            if (e.f48818a == null) {
                e.a(context.getApplicationContext());
            }
            d.a aVar = new d.a();
            aVar.g("workType", "app.notifee.core.BlockStateBroadcastReceiver.WORKER");
            char c10 = 65535;
            switch (action.hashCode()) {
                case 452039370:
                    if (action.equals("android.app.action.APP_BLOCK_STATE_CHANGED")) {
                        c10 = 0;
                        break;
                    }
                    break;
                case 806551504:
                    if (action.equals("android.app.action.NOTIFICATION_CHANNEL_GROUP_BLOCK_STATE_CHANGED")) {
                        c10 = 1;
                        break;
                    }
                    break;
                case 1171977904:
                    if (action.equals("android.app.action.NOTIFICATION_CHANNEL_BLOCK_STATE_CHANGED")) {
                        c10 = 2;
                        break;
                    }
                    break;
            }
            switch (c10) {
                case 0:
                    aVar.f("type", 4);
                    break;
                case 1:
                    aVar.f("type", 6);
                    String stringExtra = intent.getStringExtra("android.app.extra.NOTIFICATION_CHANNEL_GROUP_ID");
                    aVar.g("channelOrGroupId", stringExtra);
                    action = action + "." + stringExtra;
                    break;
                case 2:
                    aVar.f("type", 5);
                    String stringExtra2 = intent.getStringExtra("android.app.extra.NOTIFICATION_CHANNEL_ID");
                    aVar.g("channelOrGroupId", stringExtra2);
                    action = action + "." + stringExtra2;
                    break;
                default:
                    Logger.d("BlockState", "unknown intent action received, ignoring.");
                    return;
            }
            aVar.e("blocked", intent.getBooleanExtra("android.app.extra.BLOCKED_STATE", false));
            try {
                w.h(e.f48818a).f(action, f.REPLACE, (n) ((n.a) ((n.a) new n.a(Worker.class).k(1, TimeUnit.SECONDS)).l(aVar.a())).b());
            } catch (IllegalStateException e10) {
                Logger.e("BlockState", "Error while calling WorkManager.getInstance", (Exception) e10);
                if (e.f48818a == null) {
                    Logger.e("BlockState", "Application Context is null");
                }
            }
            Logger.v("BlockState", "scheduled new background work with id " + action);
        }
    }

    public static /* synthetic */ void a(c.a aVar, Exception exc, Void voidR) {
        if (exc != null) {
            Logger.e("BlockState", "background work failed with error: ", exc);
            aVar.b(k.a.a());
            return;
        }
        Logger.v("BlockState", "background work completed successfully");
        aVar.b(k.a.c());
    }

    public static /* synthetic */ void a(c.a aVar, m.a aVar2, Exception exc, Bundle bundle) {
        if (exc != null) {
            Logger.e("BlockState", "Failed getting channel or channel group bundle, received error: ", exc);
            aVar.b(k.a.c());
            return;
        }
        aVar2.a(bundle);
    }
}
