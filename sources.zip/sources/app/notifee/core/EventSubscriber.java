package app.notifee.core;

import android.content.Context;
import app.notifee.core.event.BlockStateEvent;
import app.notifee.core.event.ForegroundServiceEvent;
import app.notifee.core.event.LogEvent;
import app.notifee.core.event.NotificationEvent;
import app.notifee.core.interfaces.EventListener;
import java.util.HashSet;
import java.util.Set;
import org.greenrobot.eventbus.ThreadMode;
import sk.e;
import sk.f;
import wm.m;

@KeepForSdk
public class EventSubscriber {

    /* renamed from: b  reason: collision with root package name */
    public static final EventSubscriber f8102b = new EventSubscriber();

    /* renamed from: a  reason: collision with root package name */
    public final Set f8103a = new HashSet();

    private EventSubscriber() {
        f.c(this);
    }

    @KeepForSdk
    public static Context getContext() {
        return e.f48818a;
    }

    @KeepForSdk
    public static void register(EventListener eventListener) {
        f8102b.f8103a.add(eventListener);
    }

    @KeepForSdk
    public static void unregister(EventListener eventListener) {
        f8102b.f8103a.remove(eventListener);
    }

    @m(threadMode = ThreadMode.MAIN)
    public void onBlockStateEvent(BlockStateEvent blockStateEvent) {
        for (EventListener onBlockStateEvent : this.f8103a) {
            onBlockStateEvent.onBlockStateEvent(blockStateEvent);
        }
    }

    @m(threadMode = ThreadMode.MAIN)
    public void onForegroundServiceEvent(ForegroundServiceEvent foregroundServiceEvent) {
        for (EventListener onForegroundServiceEvent : this.f8103a) {
            onForegroundServiceEvent.onForegroundServiceEvent(foregroundServiceEvent);
        }
    }

    @m(threadMode = ThreadMode.MAIN)
    public void onLogEvent(LogEvent logEvent) {
        for (EventListener onLogEvent : this.f8103a) {
            onLogEvent.onLogEvent(logEvent);
        }
    }

    @m(threadMode = ThreadMode.MAIN)
    public void onNotificationEvent(NotificationEvent notificationEvent) {
        for (EventListener onNotificationEvent : this.f8103a) {
            onNotificationEvent.onNotificationEvent(notificationEvent);
        }
    }
}
