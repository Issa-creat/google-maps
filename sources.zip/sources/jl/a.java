package jl;

import hl.n;

public interface a {

    /* renamed from: a  reason: collision with root package name */
    public static final n f47343a = new n("0.4.0.127.0.15.1.1.13.0");

    /* renamed from: b  reason: collision with root package name */
    public static final n f47344b = new n("0.4.0.127.0.15.1.1.14.0");
}
