package qf;

public interface d {
    /* synthetic */ void a(Object obj, Object obj2);
}
