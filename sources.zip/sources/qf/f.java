package qf;

public interface f {
    /* synthetic */ void a(Object obj, Object obj2);
}
