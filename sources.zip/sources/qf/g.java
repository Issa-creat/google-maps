package qf;

public interface g {
    g c(String str);

    g d(boolean z10);
}
