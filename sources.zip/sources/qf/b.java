package qf;

public final class b extends RuntimeException {
    public b(String str) {
        super(str);
    }

    public b(String str, Exception exc) {
        super(str, exc);
    }
}
