package qf;

public interface e {
    e a(c cVar, Object obj);

    e b(c cVar, boolean z10);

    e e(c cVar, long j10);

    e f(c cVar, int i10);
}
