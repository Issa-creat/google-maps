package qf;

import java.lang.annotation.Annotation;
import java.util.Collections;
import java.util.HashMap;
import java.util.Map;

public final class c {

    /* renamed from: a  reason: collision with root package name */
    private final String f43104a;

    /* renamed from: b  reason: collision with root package name */
    private final Map f43105b;

    public static final class b {

        /* renamed from: a  reason: collision with root package name */
        private final String f43106a;

        /* renamed from: b  reason: collision with root package name */
        private Map f43107b = null;

        b(String str) {
            this.f43106a = str;
        }

        public c a() {
            Map map;
            String str = this.f43106a;
            if (this.f43107b == null) {
                map = Collections.emptyMap();
            } else {
                map = Collections.unmodifiableMap(new HashMap(this.f43107b));
            }
            return new c(str, map);
        }

        public b b(Annotation annotation) {
            if (this.f43107b == null) {
                this.f43107b = new HashMap();
            }
            this.f43107b.put(annotation.annotationType(), annotation);
            return this;
        }
    }

    public static b a(String str) {
        return new b(str);
    }

    public static c d(String str) {
        return new c(str, Collections.emptyMap());
    }

    public String b() {
        return this.f43104a;
    }

    public Annotation c(Class cls) {
        return (Annotation) this.f43105b.get(cls);
    }

    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (!(obj instanceof c)) {
            return false;
        }
        c cVar = (c) obj;
        if (!this.f43104a.equals(cVar.f43104a) || !this.f43105b.equals(cVar.f43105b)) {
            return false;
        }
        return true;
    }

    public int hashCode() {
        return (this.f43104a.hashCode() * 31) + this.f43105b.hashCode();
    }

    public String toString() {
        return "FieldDescriptor{name=" + this.f43104a + ", properties=" + this.f43105b.values() + "}";
    }

    private c(String str, Map map) {
        this.f43104a = str;
        this.f43105b = map;
    }
}
