package qf;

import java.io.Writer;

public interface a {
    void a(Object obj, Writer writer);

    String b(Object obj);
}
