package d8;

import d8.c;
import java.io.IOException;
import java.io.InputStream;
import java.util.List;
import p6.a;
import p6.k;
import p6.p;

public class d {

    /* renamed from: d  reason: collision with root package name */
    private static d f12354d;

    /* renamed from: a  reason: collision with root package name */
    private int f12355a;

    /* renamed from: b  reason: collision with root package name */
    private List f12356b;

    /* renamed from: c  reason: collision with root package name */
    private final a f12357c = new a();

    private d() {
        f();
    }

    public static c b(InputStream inputStream) {
        return d().a(inputStream);
    }

    public static c c(InputStream inputStream) {
        try {
            return b(inputStream);
        } catch (IOException e10) {
            throw p.a(e10);
        }
    }

    public static synchronized d d() {
        d dVar;
        synchronized (d.class) {
            if (f12354d == null) {
                f12354d = new d();
            }
            dVar = f12354d;
        }
        return dVar;
    }

    private static int e(int i10, InputStream inputStream, byte[] bArr) {
        boolean z10;
        k.g(inputStream);
        k.g(bArr);
        if (bArr.length >= i10) {
            z10 = true;
        } else {
            z10 = false;
        }
        k.b(Boolean.valueOf(z10));
        if (!inputStream.markSupported()) {
            return a.b(inputStream, bArr, 0, i10);
        }
        try {
            inputStream.mark(i10);
            return a.b(inputStream, bArr, 0, i10);
        } finally {
            inputStream.reset();
        }
    }

    private void f() {
        this.f12355a = this.f12357c.a();
        List<c.a> list = this.f12356b;
        if (list != null) {
            for (c.a a10 : list) {
                this.f12355a = Math.max(this.f12355a, a10.a());
            }
        }
    }

    public c a(InputStream inputStream) {
        k.g(inputStream);
        int i10 = this.f12355a;
        byte[] bArr = new byte[i10];
        int e10 = e(i10, inputStream, bArr);
        c b10 = this.f12357c.b(bArr, e10);
        if (b10 != null && b10 != c.f12351c) {
            return b10;
        }
        List<c.a> list = this.f12356b;
        if (list != null) {
            for (c.a b11 : list) {
                c b12 = b11.b(bArr, e10);
                if (b12 != null && b12 != c.f12351c) {
                    return b12;
                }
            }
        }
        return c.f12351c;
    }
}
