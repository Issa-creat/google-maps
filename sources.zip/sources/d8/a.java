package d8;

import d8.c;
import p6.i;
import p6.k;

public class a implements c.a {

    /* renamed from: c  reason: collision with root package name */
    private static final byte[] f12322c;

    /* renamed from: d  reason: collision with root package name */
    private static final int f12323d;

    /* renamed from: e  reason: collision with root package name */
    private static final byte[] f12324e;

    /* renamed from: f  reason: collision with root package name */
    private static final int f12325f;

    /* renamed from: g  reason: collision with root package name */
    private static final byte[] f12326g = e.a("GIF87a");

    /* renamed from: h  reason: collision with root package name */
    private static final byte[] f12327h = e.a("GIF89a");

    /* renamed from: i  reason: collision with root package name */
    private static final byte[] f12328i;

    /* renamed from: j  reason: collision with root package name */
    private static final int f12329j;

    /* renamed from: k  reason: collision with root package name */
    private static final byte[] f12330k;

    /* renamed from: l  reason: collision with root package name */
    private static final int f12331l;

    /* renamed from: m  reason: collision with root package name */
    private static final byte[] f12332m = e.a("ftyp");

    /* renamed from: n  reason: collision with root package name */
    private static final byte[][] f12333n = {e.a("heic"), e.a("heix"), e.a("hevc"), e.a("hevx"), e.a("mif1"), e.a("msf1")};

    /* renamed from: o  reason: collision with root package name */
    private static final byte[] f12334o;

    /* renamed from: p  reason: collision with root package name */
    private static final byte[] f12335p = {77, 77, 0, 42};

    /* renamed from: q  reason: collision with root package name */
    private static final int f12336q;

    /* renamed from: a  reason: collision with root package name */
    final int f12337a = i.a(21, 20, f12323d, f12325f, 6, f12329j, f12331l, 12);

    /* renamed from: b  reason: collision with root package name */
    private boolean f12338b = false;

    static {
        byte[] bArr = {-1, -40, -1};
        f12322c = bArr;
        f12323d = bArr.length;
        byte[] bArr2 = {-119, 80, 78, 71, 13, 10, 26, 10};
        f12324e = bArr2;
        f12325f = bArr2.length;
        byte[] a10 = e.a("BM");
        f12328i = a10;
        f12329j = a10.length;
        byte[] bArr3 = {0, 0, 1, 0};
        f12330k = bArr3;
        f12331l = bArr3.length;
        byte[] bArr4 = {73, 73, 42, 0};
        f12334o = bArr4;
        f12336q = bArr4.length;
    }

    private static c c(byte[] bArr, int i10) {
        k.b(Boolean.valueOf(y6.c.h(bArr, 0, i10)));
        if (y6.c.g(bArr, 0)) {
            return b.f12344f;
        }
        if (y6.c.f(bArr, 0)) {
            return b.f12345g;
        }
        if (!y6.c.c(bArr, 0, i10)) {
            return c.f12351c;
        }
        if (y6.c.b(bArr, 0)) {
            return b.f12348j;
        }
        if (y6.c.d(bArr, 0)) {
            return b.f12347i;
        }
        return b.f12346h;
    }

    private static boolean d(byte[] bArr, int i10) {
        byte[] bArr2 = f12328i;
        if (i10 < bArr2.length) {
            return false;
        }
        return e.c(bArr, bArr2);
    }

    private static boolean e(byte[] bArr, int i10) {
        if (i10 < f12336q || (!e.c(bArr, f12334o) && !e.c(bArr, f12335p))) {
            return false;
        }
        return true;
    }

    private static boolean f(byte[] bArr, int i10) {
        if (i10 < 6) {
            return false;
        }
        if (e.c(bArr, f12326g) || e.c(bArr, f12327h)) {
            return true;
        }
        return false;
    }

    private static boolean g(byte[] bArr, int i10) {
        if (i10 < 12 || bArr[3] < 8 || !e.b(bArr, f12332m, 4)) {
            return false;
        }
        for (byte[] b10 : f12333n) {
            if (e.b(bArr, b10, 8)) {
                return true;
            }
        }
        return false;
    }

    private static boolean h(byte[] bArr, int i10) {
        byte[] bArr2 = f12330k;
        if (i10 < bArr2.length) {
            return false;
        }
        return e.c(bArr, bArr2);
    }

    private static boolean i(byte[] bArr, int i10) {
        byte[] bArr2 = f12322c;
        if (i10 < bArr2.length || !e.c(bArr, bArr2)) {
            return false;
        }
        return true;
    }

    private static boolean j(byte[] bArr, int i10) {
        byte[] bArr2 = f12324e;
        if (i10 < bArr2.length || !e.c(bArr, bArr2)) {
            return false;
        }
        return true;
    }

    public int a() {
        return this.f12337a;
    }

    public final c b(byte[] bArr, int i10) {
        k.g(bArr);
        if (!this.f12338b && y6.c.h(bArr, 0, i10)) {
            return c(bArr, i10);
        }
        if (i(bArr, i10)) {
            return b.f12339a;
        }
        if (j(bArr, i10)) {
            return b.f12340b;
        }
        if (this.f12338b && y6.c.h(bArr, 0, i10)) {
            return c(bArr, i10);
        }
        if (f(bArr, i10)) {
            return b.f12341c;
        }
        if (d(bArr, i10)) {
            return b.f12342d;
        }
        if (h(bArr, i10)) {
            return b.f12343e;
        }
        if (g(bArr, i10)) {
            return b.f12349k;
        }
        if (e(bArr, i10)) {
            return b.f12350l;
        }
        return c.f12351c;
    }
}
