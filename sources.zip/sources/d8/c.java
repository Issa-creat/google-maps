package d8;

public class c {

    /* renamed from: c  reason: collision with root package name */
    public static final c f12351c = new c("UNKNOWN", (String) null);

    /* renamed from: a  reason: collision with root package name */
    private final String f12352a;

    /* renamed from: b  reason: collision with root package name */
    private final String f12353b;

    public interface a {
        int a();

        c b(byte[] bArr, int i10);
    }

    public c(String str, String str2) {
        this.f12353b = str;
        this.f12352a = str2;
    }

    public String a() {
        return this.f12353b;
    }

    public String toString() {
        return a();
    }
}
