package a0;

import android.os.Binder;
import android.os.IBinder;
import android.os.IInterface;

public interface a extends IInterface {

    /* renamed from: b  reason: collision with root package name */
    public static final String f9b = "androidx$core$app$unusedapprestrictions$IUnusedAppRestrictionsBackportCallback".replace('$', '.');

    /* renamed from: a0.a$a  reason: collision with other inner class name */
    public static abstract class C0002a extends Binder implements a {

        /* renamed from: a0.a$a$a  reason: collision with other inner class name */
        private static class C0003a implements a {

            /* renamed from: a  reason: collision with root package name */
            private IBinder f10a;

            C0003a(IBinder iBinder) {
                this.f10a = iBinder;
            }

            public IBinder asBinder() {
                return this.f10a;
            }
        }

        public static a J(IBinder iBinder) {
            if (iBinder == null) {
                return null;
            }
            IInterface queryLocalInterface = iBinder.queryLocalInterface(a.f9b);
            if (queryLocalInterface == null || !(queryLocalInterface instanceof a)) {
                return new C0003a(iBinder);
            }
            return (a) queryLocalInterface;
        }
    }
}
