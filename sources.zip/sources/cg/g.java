package cg;

import android.view.LayoutInflater;
import bg.l;
import javax.inject.Provider;
import kg.i;

public final class g implements Provider {

    /* renamed from: a  reason: collision with root package name */
    private final Provider f21299a;

    /* renamed from: b  reason: collision with root package name */
    private final Provider f21300b;

    /* renamed from: c  reason: collision with root package name */
    private final Provider f21301c;

    public g(Provider provider, Provider provider2, Provider provider3) {
        this.f21299a = provider;
        this.f21300b = provider2;
        this.f21301c = provider3;
    }

    public static g a(Provider provider, Provider provider2, Provider provider3) {
        return new g(provider, provider2, provider3);
    }

    public static f c(l lVar, LayoutInflater layoutInflater, i iVar) {
        return new f(lVar, layoutInflater, iVar);
    }

    /* renamed from: b */
    public f get() {
        return c((l) this.f21299a.get(), (LayoutInflater) this.f21300b.get(), (i) this.f21301c.get());
    }
}
