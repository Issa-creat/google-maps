package cg;

import android.view.LayoutInflater;
import bg.l;
import javax.inject.Provider;
import kg.i;

public final class b implements Provider {

    /* renamed from: a  reason: collision with root package name */
    private final Provider f21274a;

    /* renamed from: b  reason: collision with root package name */
    private final Provider f21275b;

    /* renamed from: c  reason: collision with root package name */
    private final Provider f21276c;

    public b(Provider provider, Provider provider2, Provider provider3) {
        this.f21274a = provider;
        this.f21275b = provider2;
        this.f21276c = provider3;
    }

    public static b a(Provider provider, Provider provider2, Provider provider3) {
        return new b(provider, provider2, provider3);
    }

    public static a c(l lVar, LayoutInflater layoutInflater, i iVar) {
        return new a(lVar, layoutInflater, iVar);
    }

    /* renamed from: b */
    public a get() {
        return c((l) this.f21274a.get(), (LayoutInflater) this.f21275b.get(), (i) this.f21276c.get());
    }
}
