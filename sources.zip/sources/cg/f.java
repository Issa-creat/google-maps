package cg;

import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewTreeObserver;
import android.widget.Button;
import android.widget.ImageView;
import bg.l;
import com.google.firebase.inappmessaging.display.internal.layout.FiamFrameLayout;
import com.google.firebase.inappmessaging.model.MessageType;
import java.util.Map;
import kg.h;
import kg.i;
import zf.g;

public class f extends c {

    /* renamed from: d  reason: collision with root package name */
    private FiamFrameLayout f21295d;

    /* renamed from: e  reason: collision with root package name */
    private ViewGroup f21296e;

    /* renamed from: f  reason: collision with root package name */
    private ImageView f21297f;

    /* renamed from: g  reason: collision with root package name */
    private Button f21298g;

    public f(l lVar, LayoutInflater layoutInflater, i iVar) {
        super(lVar, layoutInflater, iVar);
    }

    public View c() {
        return this.f21296e;
    }

    public ImageView e() {
        return this.f21297f;
    }

    public ViewGroup f() {
        return this.f21295d;
    }

    public ViewTreeObserver.OnGlobalLayoutListener g(Map map, View.OnClickListener onClickListener) {
        int i10;
        View inflate = this.f21279c.inflate(g.f44284c, (ViewGroup) null);
        this.f21295d = (FiamFrameLayout) inflate.findViewById(zf.f.f44274m);
        this.f21296e = (ViewGroup) inflate.findViewById(zf.f.f44273l);
        this.f21297f = (ImageView) inflate.findViewById(zf.f.f44275n);
        this.f21298g = (Button) inflate.findViewById(zf.f.f44272k);
        this.f21297f.setMaxHeight(this.f21278b.r());
        this.f21297f.setMaxWidth(this.f21278b.s());
        if (this.f21277a.c().equals(MessageType.IMAGE_ONLY)) {
            h hVar = (h) this.f21277a;
            ImageView imageView = this.f21297f;
            if (hVar.b() == null || TextUtils.isEmpty(hVar.b().b())) {
                i10 = 8;
            } else {
                i10 = 0;
            }
            imageView.setVisibility(i10);
            this.f21297f.setOnClickListener((View.OnClickListener) map.get(hVar.e()));
        }
        this.f21295d.setDismissListener(onClickListener);
        this.f21298g.setOnClickListener(onClickListener);
        return null;
    }
}
