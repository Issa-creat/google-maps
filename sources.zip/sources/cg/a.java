package cg;

import android.graphics.Color;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewTreeObserver;
import android.widget.ImageView;
import android.widget.TextView;
import bg.l;
import com.google.firebase.inappmessaging.display.internal.ResizableImageView;
import com.google.firebase.inappmessaging.display.internal.layout.FiamFrameLayout;
import com.google.firebase.inappmessaging.model.MessageType;
import java.util.Map;
import kg.c;
import kg.i;
import zf.f;
import zf.g;

public class a extends c {

    /* renamed from: d  reason: collision with root package name */
    private FiamFrameLayout f21268d;

    /* renamed from: e  reason: collision with root package name */
    private ViewGroup f21269e;

    /* renamed from: f  reason: collision with root package name */
    private TextView f21270f;

    /* renamed from: g  reason: collision with root package name */
    private ResizableImageView f21271g;

    /* renamed from: h  reason: collision with root package name */
    private TextView f21272h;

    /* renamed from: i  reason: collision with root package name */
    private View.OnClickListener f21273i;

    public a(l lVar, LayoutInflater layoutInflater, i iVar) {
        super(lVar, layoutInflater, iVar);
    }

    private void l(View.OnClickListener onClickListener) {
        this.f21269e.setOnClickListener(onClickListener);
    }

    private void m(l lVar) {
        int min = Math.min(lVar.u().intValue(), lVar.t().intValue());
        ViewGroup.LayoutParams layoutParams = this.f21268d.getLayoutParams();
        if (layoutParams == null) {
            layoutParams = new ViewGroup.LayoutParams(-1, -2);
        }
        layoutParams.width = min;
        this.f21268d.setLayoutParams(layoutParams);
        this.f21271g.setMaxHeight(lVar.r());
        this.f21271g.setMaxWidth(lVar.s());
    }

    private void n(c cVar) {
        int i10;
        if (!TextUtils.isEmpty(cVar.f())) {
            j(this.f21269e, cVar.f());
        }
        ResizableImageView resizableImageView = this.f21271g;
        if (cVar.b() == null || TextUtils.isEmpty(cVar.b().b())) {
            i10 = 8;
        } else {
            i10 = 0;
        }
        resizableImageView.setVisibility(i10);
        if (cVar.h() != null) {
            if (!TextUtils.isEmpty(cVar.h().c())) {
                this.f21272h.setText(cVar.h().c());
            }
            if (!TextUtils.isEmpty(cVar.h().b())) {
                this.f21272h.setTextColor(Color.parseColor(cVar.h().b()));
            }
        }
        if (cVar.g() != null) {
            if (!TextUtils.isEmpty(cVar.g().c())) {
                this.f21270f.setText(cVar.g().c());
            }
            if (!TextUtils.isEmpty(cVar.g().b())) {
                this.f21270f.setTextColor(Color.parseColor(cVar.g().b()));
            }
        }
    }

    private void o(View.OnClickListener onClickListener) {
        this.f21273i = onClickListener;
        this.f21268d.setDismissListener(onClickListener);
    }

    public boolean a() {
        return true;
    }

    public l b() {
        return this.f21278b;
    }

    public View c() {
        return this.f21269e;
    }

    public View.OnClickListener d() {
        return this.f21273i;
    }

    public ImageView e() {
        return this.f21271g;
    }

    public ViewGroup f() {
        return this.f21268d;
    }

    public ViewTreeObserver.OnGlobalLayoutListener g(Map map, View.OnClickListener onClickListener) {
        View inflate = this.f21279c.inflate(g.f44282a, (ViewGroup) null);
        this.f21268d = (FiamFrameLayout) inflate.findViewById(f.f44266e);
        this.f21269e = (ViewGroup) inflate.findViewById(f.f44264c);
        this.f21270f = (TextView) inflate.findViewById(f.f44263b);
        this.f21271g = (ResizableImageView) inflate.findViewById(f.f44265d);
        this.f21272h = (TextView) inflate.findViewById(f.f44267f);
        if (this.f21277a.c().equals(MessageType.BANNER)) {
            c cVar = (c) this.f21277a;
            n(cVar);
            m(this.f21278b);
            o(onClickListener);
            l((View.OnClickListener) map.get(cVar.e()));
        }
        return null;
    }
}
