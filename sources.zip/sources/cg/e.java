package cg;

import android.view.LayoutInflater;
import bg.l;
import javax.inject.Provider;
import kg.i;

public final class e implements Provider {

    /* renamed from: a  reason: collision with root package name */
    private final Provider f21292a;

    /* renamed from: b  reason: collision with root package name */
    private final Provider f21293b;

    /* renamed from: c  reason: collision with root package name */
    private final Provider f21294c;

    public e(Provider provider, Provider provider2, Provider provider3) {
        this.f21292a = provider;
        this.f21293b = provider2;
        this.f21294c = provider3;
    }

    public static e a(Provider provider, Provider provider2, Provider provider3) {
        return new e(provider, provider2, provider3);
    }

    public static d c(l lVar, LayoutInflater layoutInflater, i iVar) {
        return new d(lVar, layoutInflater, iVar);
    }

    /* renamed from: b */
    public d get() {
        return c((l) this.f21292a.get(), (LayoutInflater) this.f21293b.get(), (i) this.f21294c.get());
    }
}
