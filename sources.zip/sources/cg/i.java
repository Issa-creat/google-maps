package cg;

import android.view.LayoutInflater;
import bg.l;
import javax.inject.Provider;

public final class i implements Provider {

    /* renamed from: a  reason: collision with root package name */
    private final Provider f21313a;

    /* renamed from: b  reason: collision with root package name */
    private final Provider f21314b;

    /* renamed from: c  reason: collision with root package name */
    private final Provider f21315c;

    public i(Provider provider, Provider provider2, Provider provider3) {
        this.f21313a = provider;
        this.f21314b = provider2;
        this.f21315c = provider3;
    }

    public static i a(Provider provider, Provider provider2, Provider provider3) {
        return new i(provider, provider2, provider3);
    }

    public static h c(l lVar, LayoutInflater layoutInflater, kg.i iVar) {
        return new h(lVar, layoutInflater, iVar);
    }

    /* renamed from: b */
    public h get() {
        return c((l) this.f21313a.get(), (LayoutInflater) this.f21314b.get(), (kg.i) this.f21315c.get());
    }
}
