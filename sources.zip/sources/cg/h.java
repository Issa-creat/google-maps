package cg;

import android.graphics.Color;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewTreeObserver;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.ScrollView;
import android.widget.TextView;
import bg.l;
import com.google.firebase.inappmessaging.display.internal.layout.FiamRelativeLayout;
import com.google.firebase.inappmessaging.model.MessageType;
import java.util.Map;
import kg.i;
import kg.j;
import zf.f;
import zf.g;

public class h extends c {

    /* renamed from: d  reason: collision with root package name */
    private FiamRelativeLayout f21302d;

    /* renamed from: e  reason: collision with root package name */
    private ViewGroup f21303e;

    /* renamed from: f  reason: collision with root package name */
    private ScrollView f21304f;

    /* renamed from: g  reason: collision with root package name */
    private Button f21305g;

    /* renamed from: h  reason: collision with root package name */
    private View f21306h;
    /* access modifiers changed from: private */

    /* renamed from: i  reason: collision with root package name */
    public ImageView f21307i;

    /* renamed from: j  reason: collision with root package name */
    private TextView f21308j;

    /* renamed from: k  reason: collision with root package name */
    private TextView f21309k;

    /* renamed from: l  reason: collision with root package name */
    private j f21310l;

    /* renamed from: m  reason: collision with root package name */
    private ViewTreeObserver.OnGlobalLayoutListener f21311m = new a();

    public class a implements ViewTreeObserver.OnGlobalLayoutListener {
        public a() {
        }

        public void onGlobalLayout() {
            h.this.f21307i.getViewTreeObserver().removeGlobalOnLayoutListener(this);
        }
    }

    public h(l lVar, LayoutInflater layoutInflater, i iVar) {
        super(lVar, layoutInflater, iVar);
    }

    private void m(Map map) {
        kg.a e10 = this.f21310l.e();
        if (e10 == null || e10.c() == null || TextUtils.isEmpty(e10.c().c().c())) {
            this.f21305g.setVisibility(8);
            return;
        }
        c.k(this.f21305g, e10.c());
        h(this.f21305g, (View.OnClickListener) map.get(this.f21310l.e()));
        this.f21305g.setVisibility(0);
    }

    private void n(View.OnClickListener onClickListener) {
        this.f21306h.setOnClickListener(onClickListener);
        this.f21302d.setDismissListener(onClickListener);
    }

    private void o(l lVar) {
        this.f21307i.setMaxHeight(lVar.r());
        this.f21307i.setMaxWidth(lVar.s());
    }

    private void p(j jVar) {
        if (jVar.b() == null || TextUtils.isEmpty(jVar.b().b())) {
            this.f21307i.setVisibility(8);
        } else {
            this.f21307i.setVisibility(0);
        }
        if (jVar.h() != null) {
            if (!TextUtils.isEmpty(jVar.h().c())) {
                this.f21309k.setVisibility(0);
                this.f21309k.setText(jVar.h().c());
            } else {
                this.f21309k.setVisibility(8);
            }
            if (!TextUtils.isEmpty(jVar.h().b())) {
                this.f21309k.setTextColor(Color.parseColor(jVar.h().b()));
            }
        }
        if (jVar.g() == null || TextUtils.isEmpty(jVar.g().c())) {
            this.f21304f.setVisibility(8);
            this.f21308j.setVisibility(8);
            return;
        }
        this.f21304f.setVisibility(0);
        this.f21308j.setVisibility(0);
        this.f21308j.setTextColor(Color.parseColor(jVar.g().b()));
        this.f21308j.setText(jVar.g().c());
    }

    public l b() {
        return this.f21278b;
    }

    public View c() {
        return this.f21303e;
    }

    public ImageView e() {
        return this.f21307i;
    }

    public ViewGroup f() {
        return this.f21302d;
    }

    public ViewTreeObserver.OnGlobalLayoutListener g(Map map, View.OnClickListener onClickListener) {
        View inflate = this.f21279c.inflate(g.f44285d, (ViewGroup) null);
        this.f21304f = (ScrollView) inflate.findViewById(f.f44268g);
        this.f21305g = (Button) inflate.findViewById(f.f44269h);
        this.f21306h = inflate.findViewById(f.f44272k);
        this.f21307i = (ImageView) inflate.findViewById(f.f44275n);
        this.f21308j = (TextView) inflate.findViewById(f.f44276o);
        this.f21309k = (TextView) inflate.findViewById(f.f44277p);
        this.f21302d = (FiamRelativeLayout) inflate.findViewById(f.f44279r);
        this.f21303e = (ViewGroup) inflate.findViewById(f.f44278q);
        if (this.f21277a.c().equals(MessageType.MODAL)) {
            j jVar = (j) this.f21277a;
            this.f21310l = jVar;
            p(jVar);
            m(map);
            o(this.f21278b);
            n(onClickListener);
            j(this.f21303e, this.f21310l.f());
        }
        return this.f21311m;
    }
}
