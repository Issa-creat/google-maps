package cg;

import android.graphics.Color;
import android.graphics.drawable.Drawable;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewTreeObserver;
import android.widget.Button;
import android.widget.ImageView;
import androidx.core.graphics.drawable.a;
import bg.l;
import bg.m;
import java.util.Map;
import kg.d;
import kg.i;

public abstract class c {

    /* renamed from: a  reason: collision with root package name */
    protected final i f21277a;

    /* renamed from: b  reason: collision with root package name */
    final l f21278b;

    /* renamed from: c  reason: collision with root package name */
    final LayoutInflater f21279c;

    protected c(l lVar, LayoutInflater layoutInflater, i iVar) {
        this.f21278b = lVar;
        this.f21279c = layoutInflater;
        this.f21277a = iVar;
    }

    public static void i(Button button, String str) {
        try {
            Drawable r10 = a.r(button.getBackground());
            a.n(r10, Color.parseColor(str));
            button.setBackground(r10);
        } catch (IllegalArgumentException e10) {
            m.e("Error parsing background color: " + e10.toString());
        }
    }

    public static void k(Button button, d dVar) {
        String b10 = dVar.c().b();
        i(button, dVar.b());
        button.setText(dVar.c().c());
        button.setTextColor(Color.parseColor(b10));
    }

    public boolean a() {
        return false;
    }

    public l b() {
        return this.f21278b;
    }

    public abstract View c();

    public View.OnClickListener d() {
        return null;
    }

    public abstract ImageView e();

    public abstract ViewGroup f();

    public abstract ViewTreeObserver.OnGlobalLayoutListener g(Map map, View.OnClickListener onClickListener);

    /* access modifiers changed from: protected */
    public void h(Button button, View.OnClickListener onClickListener) {
        if (button != null) {
            button.setOnClickListener(onClickListener);
        }
    }

    /* access modifiers changed from: protected */
    public void j(View view, String str) {
        if (view != null && !TextUtils.isEmpty(str)) {
            try {
                view.setBackgroundColor(Color.parseColor(str));
            } catch (IllegalArgumentException e10) {
                m.e("Error parsing background color: " + e10.toString() + " color: " + str);
            }
        }
    }
}
