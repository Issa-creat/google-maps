package cg;

import android.graphics.Color;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewTreeObserver;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.ScrollView;
import android.widget.TextView;
import bg.l;
import com.google.firebase.inappmessaging.display.internal.layout.BaseModalLayout;
import com.google.firebase.inappmessaging.display.internal.layout.FiamCardView;
import com.google.firebase.inappmessaging.model.MessageType;
import java.util.Map;
import kg.f;
import kg.i;
import zf.g;

public class d extends c {

    /* renamed from: d  reason: collision with root package name */
    private FiamCardView f21280d;

    /* renamed from: e  reason: collision with root package name */
    private BaseModalLayout f21281e;

    /* renamed from: f  reason: collision with root package name */
    private ScrollView f21282f;

    /* renamed from: g  reason: collision with root package name */
    private Button f21283g;

    /* renamed from: h  reason: collision with root package name */
    private Button f21284h;
    /* access modifiers changed from: private */

    /* renamed from: i  reason: collision with root package name */
    public ImageView f21285i;

    /* renamed from: j  reason: collision with root package name */
    private TextView f21286j;

    /* renamed from: k  reason: collision with root package name */
    private TextView f21287k;

    /* renamed from: l  reason: collision with root package name */
    private f f21288l;

    /* renamed from: m  reason: collision with root package name */
    private View.OnClickListener f21289m;

    /* renamed from: n  reason: collision with root package name */
    private ViewTreeObserver.OnGlobalLayoutListener f21290n = new a();

    public class a implements ViewTreeObserver.OnGlobalLayoutListener {
        public a() {
        }

        public void onGlobalLayout() {
            d.this.f21285i.getViewTreeObserver().removeGlobalOnLayoutListener(this);
        }
    }

    public d(l lVar, LayoutInflater layoutInflater, i iVar) {
        super(lVar, layoutInflater, iVar);
    }

    private void m(Map map) {
        kg.a i10 = this.f21288l.i();
        kg.a j10 = this.f21288l.j();
        c.k(this.f21283g, i10.c());
        h(this.f21283g, (View.OnClickListener) map.get(i10));
        this.f21283g.setVisibility(0);
        if (j10 == null || j10.c() == null) {
            this.f21284h.setVisibility(8);
            return;
        }
        c.k(this.f21284h, j10.c());
        h(this.f21284h, (View.OnClickListener) map.get(j10));
        this.f21284h.setVisibility(0);
    }

    private void n(View.OnClickListener onClickListener) {
        this.f21289m = onClickListener;
        this.f21280d.setDismissListener(onClickListener);
    }

    private void o(f fVar) {
        if (fVar.h() == null && fVar.g() == null) {
            this.f21285i.setVisibility(8);
        } else {
            this.f21285i.setVisibility(0);
        }
    }

    private void p(l lVar) {
        this.f21285i.setMaxHeight(lVar.r());
        this.f21285i.setMaxWidth(lVar.s());
    }

    private void q(f fVar) {
        this.f21287k.setText(fVar.k().c());
        this.f21287k.setTextColor(Color.parseColor(fVar.k().b()));
        if (fVar.f() == null || fVar.f().c() == null) {
            this.f21282f.setVisibility(8);
            this.f21286j.setVisibility(8);
            return;
        }
        this.f21282f.setVisibility(0);
        this.f21286j.setVisibility(0);
        this.f21286j.setText(fVar.f().c());
        this.f21286j.setTextColor(Color.parseColor(fVar.f().b()));
    }

    public l b() {
        return this.f21278b;
    }

    public View c() {
        return this.f21281e;
    }

    public View.OnClickListener d() {
        return this.f21289m;
    }

    public ImageView e() {
        return this.f21285i;
    }

    public ViewGroup f() {
        return this.f21280d;
    }

    public ViewTreeObserver.OnGlobalLayoutListener g(Map map, View.OnClickListener onClickListener) {
        View inflate = this.f21279c.inflate(g.f44283b, (ViewGroup) null);
        this.f21282f = (ScrollView) inflate.findViewById(zf.f.f44268g);
        this.f21283g = (Button) inflate.findViewById(zf.f.f44280s);
        this.f21284h = (Button) inflate.findViewById(zf.f.f44281t);
        this.f21285i = (ImageView) inflate.findViewById(zf.f.f44275n);
        this.f21286j = (TextView) inflate.findViewById(zf.f.f44276o);
        this.f21287k = (TextView) inflate.findViewById(zf.f.f44277p);
        this.f21280d = (FiamCardView) inflate.findViewById(zf.f.f44271j);
        this.f21281e = (BaseModalLayout) inflate.findViewById(zf.f.f44270i);
        if (this.f21277a.c().equals(MessageType.CARD)) {
            f fVar = (f) this.f21277a;
            this.f21288l = fVar;
            q(fVar);
            o(this.f21288l);
            m(map);
            p(this.f21278b);
            n(onClickListener);
            j(this.f21281e, this.f21288l.e());
        }
        return this.f21290n;
    }
}
