package jm;

import hl.v;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.security.Key;
import java.security.PrivateKey;
import ml.b;

public class a implements Key, PrivateKey {
    private static final long serialVersionUID = 1;

    /* renamed from: a  reason: collision with root package name */
    private transient zl.a f47345a;

    /* renamed from: w  reason: collision with root package name */
    private transient v f47346w;

    public a(b bVar) {
        a(bVar);
    }

    private void a(b bVar) {
        this.f47346w = bVar.p();
        this.f47345a = (zl.a) em.a.b(bVar);
    }

    private void readObject(ObjectInputStream objectInputStream) {
        objectInputStream.defaultReadObject();
        a(b.q((byte[]) objectInputStream.readObject()));
    }

    private void writeObject(ObjectOutputStream objectOutputStream) {
        objectOutputStream.defaultWriteObject();
        objectOutputStream.writeObject(getEncoded());
    }

    public boolean equals(Object obj) {
        if (!(obj instanceof a)) {
            return false;
        }
        return rm.a.c(this.f47345a.a(), ((a) obj).f47345a.a());
    }

    public final String getAlgorithm() {
        return "NH";
    }

    public byte[] getEncoded() {
        try {
            return em.b.a(this.f47345a, this.f47346w).getEncoded();
        } catch (IOException unused) {
            return null;
        }
    }

    public String getFormat() {
        return "PKCS#8";
    }

    public int hashCode() {
        return rm.a.n(this.f47345a.a());
    }
}
