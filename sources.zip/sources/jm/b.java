package jm;

import em.c;
import em.d;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.security.Key;
import java.security.PublicKey;
import rm.a;

public class b implements Key, PublicKey {
    private static final long serialVersionUID = 1;

    /* renamed from: a  reason: collision with root package name */
    private transient zl.b f47347a;

    public b(nl.b bVar) {
        a(bVar);
    }

    private void a(nl.b bVar) {
        this.f47347a = (zl.b) c.a(bVar);
    }

    private void readObject(ObjectInputStream objectInputStream) {
        objectInputStream.defaultReadObject();
        a(nl.b.q((byte[]) objectInputStream.readObject()));
    }

    private void writeObject(ObjectOutputStream objectOutputStream) {
        objectOutputStream.defaultWriteObject();
        objectOutputStream.writeObject(getEncoded());
    }

    public boolean equals(Object obj) {
        if (obj == null || !(obj instanceof b)) {
            return false;
        }
        return a.a(this.f47347a.a(), ((b) obj).f47347a.a());
    }

    public final String getAlgorithm() {
        return "NH";
    }

    public byte[] getEncoded() {
        try {
            return d.a(this.f47347a).getEncoded();
        } catch (IOException unused) {
            return null;
        }
    }

    public String getFormat() {
        return "X.509";
    }

    public int hashCode() {
        return a.j(this.f47347a.a());
    }
}
