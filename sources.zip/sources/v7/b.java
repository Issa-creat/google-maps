package v7;

import android.graphics.Bitmap;
import android.graphics.Rect;
import g8.d;
import s7.c;
import t6.CloseableReference;

public class b implements c {

    /* renamed from: e  reason: collision with root package name */
    private static final Class f18630e = b.class;
    /* access modifiers changed from: private */

    /* renamed from: a  reason: collision with root package name */
    public final s7.b f18631a;

    /* renamed from: b  reason: collision with root package name */
    private e8.a f18632b;

    /* renamed from: c  reason: collision with root package name */
    private d f18633c;

    /* renamed from: d  reason: collision with root package name */
    private final d.b f18634d;

    class a implements d.b {
        a() {
        }

        public void a(int i10, Bitmap bitmap) {
        }

        public CloseableReference b(int i10) {
            return b.this.f18631a.c(i10);
        }
    }

    public b(s7.b bVar, e8.a aVar) {
        a aVar2 = new a();
        this.f18634d = aVar2;
        this.f18631a = bVar;
        this.f18632b = aVar;
        this.f18633c = new d(aVar, aVar2);
    }

    public boolean a(int i10, Bitmap bitmap) {
        try {
            this.f18633c.g(i10, bitmap);
            return true;
        } catch (IllegalStateException e10) {
            q6.a.i(f18630e, e10, "Rendering of frame unsuccessful. Frame number: %d", Integer.valueOf(i10));
            return false;
        }
    }

    public int c() {
        return this.f18632b.getHeight();
    }

    public void d(Rect rect) {
        e8.a f10 = this.f18632b.f(rect);
        if (f10 != this.f18632b) {
            this.f18632b = f10;
            this.f18633c = new d(f10, this.f18634d);
        }
    }

    public int e() {
        return this.f18632b.getWidth();
    }
}
