package v7;

import r7.d;

public class a implements d {

    /* renamed from: a  reason: collision with root package name */
    private final e8.a f18629a;

    public a(e8.a aVar) {
        this.f18629a = aVar;
    }

    public int a() {
        return this.f18629a.a();
    }

    public int b() {
        return this.f18629a.b();
    }

    public int h(int i10) {
        return this.f18629a.e(i10);
    }
}
