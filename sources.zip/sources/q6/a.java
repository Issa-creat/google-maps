package q6;

import java.util.Locale;

public abstract class a {

    /* renamed from: a  reason: collision with root package name */
    private static c f17114a = b.l();

    public static void A(Class cls, String str, Object obj, Object obj2, Object obj3, Object obj4) {
        if (f17114a.j(2)) {
            f17114a.g(o(cls), n(str, obj, obj2, obj3, obj4));
        }
    }

    public static void B(Class cls, String str, Object... objArr) {
        if (f17114a.j(2)) {
            f17114a.g(o(cls), n(str, objArr));
        }
    }

    public static void C(String str, String str2, Object... objArr) {
        if (f17114a.j(2)) {
            f17114a.g(str, n(str2, objArr));
        }
    }

    public static void D(Class cls, String str) {
        if (f17114a.j(5)) {
            f17114a.e(o(cls), str);
        }
    }

    public static void E(Class cls, String str, Throwable th2) {
        if (f17114a.j(5)) {
            f17114a.a(o(cls), str, th2);
        }
    }

    public static void F(Class cls, String str, Object... objArr) {
        if (f17114a.j(5)) {
            f17114a.e(o(cls), n(str, objArr));
        }
    }

    public static void G(Class cls, Throwable th2, String str, Object... objArr) {
        if (v(5)) {
            E(cls, n(str, objArr), th2);
        }
    }

    public static void H(String str, String str2) {
        if (f17114a.j(5)) {
            f17114a.e(str, str2);
        }
    }

    public static void I(String str, String str2, Throwable th2) {
        if (f17114a.j(5)) {
            f17114a.a(str, str2, th2);
        }
    }

    public static void J(String str, String str2, Object... objArr) {
        if (f17114a.j(5)) {
            f17114a.e(str, n(str2, objArr));
        }
    }

    public static void K(String str, Throwable th2, String str2, Object... objArr) {
        if (f17114a.j(5)) {
            f17114a.a(str, n(str2, objArr), th2);
        }
    }

    public static void L(Class cls, String str, Throwable th2) {
        if (f17114a.j(6)) {
            f17114a.d(o(cls), str, th2);
        }
    }

    public static void M(String str, String str2, Throwable th2) {
        if (f17114a.j(6)) {
            f17114a.d(str, str2, th2);
        }
    }

    public static void N(String str, String str2, Object... objArr) {
        if (f17114a.j(6)) {
            f17114a.h(str, n(str2, objArr));
        }
    }

    public static void a(Class cls, String str, Object obj) {
        if (f17114a.j(3)) {
            f17114a.i(o(cls), n(str, obj));
        }
    }

    public static void b(String str, String str2) {
        if (f17114a.j(3)) {
            f17114a.i(str, str2);
        }
    }

    public static void c(String str, String str2, Object obj) {
        if (f17114a.j(3)) {
            f17114a.i(str, n(str2, obj));
        }
    }

    public static void d(String str, String str2, Object obj, Object obj2) {
        if (f17114a.j(3)) {
            f17114a.i(str, n(str2, obj, obj2));
        }
    }

    public static void e(String str, String str2, Throwable th2) {
        if (f17114a.j(3)) {
            f17114a.c(str, str2, th2);
        }
    }

    public static void f(Class cls, String str) {
        if (f17114a.j(6)) {
            f17114a.f(o(cls), str);
        }
    }

    public static void g(Class cls, String str, Throwable th2) {
        if (f17114a.j(6)) {
            f17114a.b(o(cls), str, th2);
        }
    }

    public static void h(Class cls, String str, Object... objArr) {
        if (f17114a.j(6)) {
            f17114a.f(o(cls), n(str, objArr));
        }
    }

    public static void i(Class cls, Throwable th2, String str, Object... objArr) {
        if (f17114a.j(6)) {
            f17114a.b(o(cls), n(str, objArr), th2);
        }
    }

    public static void j(String str, String str2) {
        if (f17114a.j(6)) {
            f17114a.f(str, str2);
        }
    }

    public static void k(String str, String str2, Throwable th2) {
        if (f17114a.j(6)) {
            f17114a.b(str, str2, th2);
        }
    }

    public static void l(String str, String str2, Object... objArr) {
        if (f17114a.j(6)) {
            f17114a.f(str, n(str2, objArr));
        }
    }

    public static void m(String str, Throwable th2, String str2, Object... objArr) {
        if (f17114a.j(6)) {
            f17114a.b(str, n(str2, objArr), th2);
        }
    }

    private static String n(String str, Object... objArr) {
        return String.format((Locale) null, str, objArr);
    }

    private static String o(Class cls) {
        return cls.getSimpleName();
    }

    public static void p(String str, String str2) {
        if (f17114a.j(4)) {
            f17114a.k(str, str2);
        }
    }

    public static void q(String str, String str2, Object obj) {
        if (f17114a.j(4)) {
            f17114a.k(str, n(str2, obj));
        }
    }

    public static void r(String str, String str2, Object obj, Object obj2) {
        if (f17114a.j(4)) {
            f17114a.k(str, n(str2, obj, obj2));
        }
    }

    public static void s(String str, String str2, Object obj, Object obj2, Object obj3) {
        if (f17114a.j(4)) {
            f17114a.k(str, n(str2, obj, obj2, obj3));
        }
    }

    public static void t(String str, String str2, Object obj, Object obj2, Object obj3, Object obj4) {
        if (f17114a.j(4)) {
            f17114a.k(str, n(str2, obj, obj2, obj3, obj4));
        }
    }

    public static void u(String str, String str2, Object... objArr) {
        if (f17114a.j(4)) {
            f17114a.k(str, n(str2, objArr));
        }
    }

    public static boolean v(int i10) {
        return f17114a.j(i10);
    }

    public static void w(Class cls, String str) {
        if (f17114a.j(2)) {
            f17114a.g(o(cls), str);
        }
    }

    public static void x(Class cls, String str, Object obj) {
        if (f17114a.j(2)) {
            f17114a.g(o(cls), n(str, obj));
        }
    }

    public static void y(Class cls, String str, Object obj, Object obj2) {
        if (f17114a.j(2)) {
            f17114a.g(o(cls), n(str, obj, obj2));
        }
    }

    public static void z(Class cls, String str, Object obj, Object obj2, Object obj3) {
        if (v(2)) {
            w(cls, n(str, obj, obj2, obj3));
        }
    }
}
