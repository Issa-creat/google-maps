package q6;

public interface c {
    void a(String str, String str2, Throwable th2);

    void b(String str, String str2, Throwable th2);

    void c(String str, String str2, Throwable th2);

    void d(String str, String str2, Throwable th2);

    void e(String str, String str2);

    void f(String str, String str2);

    void g(String str, String str2);

    void h(String str, String str2);

    void i(String str, String str2);

    boolean j(int i10);

    void k(String str, String str2);
}
