package q6;

import android.util.Log;

public class b implements c {

    /* renamed from: c  reason: collision with root package name */
    public static final b f17115c = new b();

    /* renamed from: a  reason: collision with root package name */
    private String f17116a = "unknown";

    /* renamed from: b  reason: collision with root package name */
    private int f17117b = 5;

    private b() {
    }

    public static b l() {
        return f17115c;
    }

    private static String m(String str, Throwable th2) {
        return str + 10 + n(th2);
    }

    private static String n(Throwable th2) {
        if (th2 == null) {
            return "";
        }
        return Log.getStackTraceString(th2);
    }

    private String o(String str) {
        if (this.f17116a == null) {
            return str;
        }
        return this.f17116a + ":" + str;
    }

    private void p(int i10, String str, String str2) {
        Log.println(i10, o(str), str2);
    }

    private void q(int i10, String str, String str2, Throwable th2) {
        Log.println(i10, o(str), m(str2, th2));
    }

    public void a(String str, String str2, Throwable th2) {
        q(5, str, str2, th2);
    }

    public void b(String str, String str2, Throwable th2) {
        q(6, str, str2, th2);
    }

    public void c(String str, String str2, Throwable th2) {
        q(3, str, str2, th2);
    }

    public void d(String str, String str2, Throwable th2) {
        q(6, str, str2, th2);
    }

    public void e(String str, String str2) {
        p(5, str, str2);
    }

    public void f(String str, String str2) {
        p(6, str, str2);
    }

    public void g(String str, String str2) {
        p(2, str, str2);
    }

    public void h(String str, String str2) {
        p(6, str, str2);
    }

    public void i(String str, String str2) {
        p(3, str, str2);
    }

    public boolean j(int i10) {
        if (this.f17117b <= i10) {
            return true;
        }
        return false;
    }

    public void k(String str, String str2) {
        p(4, str, str2);
    }
}
