package oi;

import java.util.concurrent.Callable;
import ni.r;
import ri.b;
import ti.e;

public abstract class a {

    /* renamed from: a  reason: collision with root package name */
    private static volatile e f48190a;

    /* renamed from: b  reason: collision with root package name */
    private static volatile e f48191b;

    static Object a(e eVar, Object obj) {
        try {
            return eVar.apply(obj);
        } catch (Throwable th2) {
            throw b.a(th2);
        }
    }

    static r b(e eVar, Callable callable) {
        r rVar = (r) a(eVar, callable);
        if (rVar != null) {
            return rVar;
        }
        throw new NullPointerException("Scheduler Callable returned null");
    }

    static r c(Callable callable) {
        try {
            r rVar = (r) callable.call();
            if (rVar != null) {
                return rVar;
            }
            throw new NullPointerException("Scheduler Callable returned null");
        } catch (Throwable th2) {
            throw b.a(th2);
        }
    }

    public static r d(Callable callable) {
        if (callable != null) {
            e eVar = f48190a;
            if (eVar == null) {
                return c(callable);
            }
            return b(eVar, callable);
        }
        throw new NullPointerException("scheduler == null");
    }

    public static r e(r rVar) {
        if (rVar != null) {
            e eVar = f48191b;
            if (eVar == null) {
                return rVar;
            }
            return (r) a(eVar, rVar);
        }
        throw new NullPointerException("scheduler == null");
    }
}
