package dj;

import hj.k;
import java.util.concurrent.atomic.AtomicLong;
import java.util.concurrent.atomic.AtomicReferenceArray;
import wi.i;

public final class b implements i {
    static final int D = Integer.getInteger("jctools.spsc.max.lookahead.step", 4096).intValue();
    private static final Object E = new Object();
    final int A;
    AtomicReferenceArray B;
    final AtomicLong C = new AtomicLong();

    /* renamed from: a  reason: collision with root package name */
    final AtomicLong f45448a = new AtomicLong();

    /* renamed from: w  reason: collision with root package name */
    int f45449w;

    /* renamed from: x  reason: collision with root package name */
    long f45450x;

    /* renamed from: y  reason: collision with root package name */
    final int f45451y;

    /* renamed from: z  reason: collision with root package name */
    AtomicReferenceArray f45452z;

    public b(int i10) {
        int a10 = k.a(Math.max(8, i10));
        int i11 = a10 - 1;
        AtomicReferenceArray atomicReferenceArray = new AtomicReferenceArray(a10 + 1);
        this.f45452z = atomicReferenceArray;
        this.f45451y = i11;
        a(a10);
        this.B = atomicReferenceArray;
        this.A = i11;
        this.f45450x = (long) (i11 - 1);
        p(0);
    }

    private void a(int i10) {
        this.f45449w = Math.min(i10 / 4, D);
    }

    private static int b(int i10) {
        return i10;
    }

    private static int c(long j10, int i10) {
        return b(((int) j10) & i10);
    }

    private long d() {
        return this.C.get();
    }

    private long e() {
        return this.f45448a.get();
    }

    private long f() {
        return this.C.get();
    }

    private static Object g(AtomicReferenceArray atomicReferenceArray, int i10) {
        return atomicReferenceArray.get(i10);
    }

    private AtomicReferenceArray i(AtomicReferenceArray atomicReferenceArray, int i10) {
        int b10 = b(i10);
        AtomicReferenceArray atomicReferenceArray2 = (AtomicReferenceArray) g(atomicReferenceArray, b10);
        n(atomicReferenceArray, b10, (Object) null);
        return atomicReferenceArray2;
    }

    private long j() {
        return this.f45448a.get();
    }

    private Object k(AtomicReferenceArray atomicReferenceArray, long j10, int i10) {
        this.B = atomicReferenceArray;
        int c10 = c(j10, i10);
        Object g10 = g(atomicReferenceArray, c10);
        if (g10 != null) {
            n(atomicReferenceArray, c10, (Object) null);
            m(j10 + 1);
        }
        return g10;
    }

    private void l(AtomicReferenceArray atomicReferenceArray, long j10, int i10, Object obj, long j11) {
        AtomicReferenceArray atomicReferenceArray2 = new AtomicReferenceArray(atomicReferenceArray.length());
        this.f45452z = atomicReferenceArray2;
        this.f45450x = (j11 + j10) - 1;
        n(atomicReferenceArray2, i10, obj);
        o(atomicReferenceArray, atomicReferenceArray2);
        n(atomicReferenceArray, i10, E);
        p(j10 + 1);
    }

    private void m(long j10) {
        this.C.lazySet(j10);
    }

    private static void n(AtomicReferenceArray atomicReferenceArray, int i10, Object obj) {
        atomicReferenceArray.lazySet(i10, obj);
    }

    private void o(AtomicReferenceArray atomicReferenceArray, AtomicReferenceArray atomicReferenceArray2) {
        n(atomicReferenceArray, b(atomicReferenceArray.length() - 1), atomicReferenceArray2);
    }

    private void p(long j10) {
        this.f45448a.lazySet(j10);
    }

    private boolean q(AtomicReferenceArray atomicReferenceArray, Object obj, long j10, int i10) {
        n(atomicReferenceArray, i10, obj);
        p(j10 + 1);
        return true;
    }

    public void clear() {
        while (true) {
            if (poll() == null && isEmpty()) {
                return;
            }
        }
    }

    public boolean isEmpty() {
        if (j() == f()) {
            return true;
        }
        return false;
    }

    public boolean offer(Object obj) {
        if (obj != null) {
            AtomicReferenceArray atomicReferenceArray = this.f45452z;
            long e10 = e();
            int i10 = this.f45451y;
            int c10 = c(e10, i10);
            if (e10 < this.f45450x) {
                return q(atomicReferenceArray, obj, e10, c10);
            }
            long j10 = ((long) this.f45449w) + e10;
            if (g(atomicReferenceArray, c(j10, i10)) == null) {
                this.f45450x = j10 - 1;
                return q(atomicReferenceArray, obj, e10, c10);
            } else if (g(atomicReferenceArray, c(1 + e10, i10)) == null) {
                return q(atomicReferenceArray, obj, e10, c10);
            } else {
                l(atomicReferenceArray, e10, c10, obj, (long) i10);
                return true;
            }
        } else {
            throw new NullPointerException("Null is not a valid element");
        }
    }

    public Object poll() {
        boolean z10;
        AtomicReferenceArray atomicReferenceArray = this.B;
        long d10 = d();
        int i10 = this.A;
        int c10 = c(d10, i10);
        Object g10 = g(atomicReferenceArray, c10);
        if (g10 == E) {
            z10 = true;
        } else {
            z10 = false;
        }
        if (g10 != null && !z10) {
            n(atomicReferenceArray, c10, (Object) null);
            m(d10 + 1);
            return g10;
        } else if (z10) {
            return k(i(atomicReferenceArray, i10 + 1), d10, i10);
        } else {
            return null;
        }
    }
}
