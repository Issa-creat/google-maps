package dj;

import hj.k;
import java.util.concurrent.atomic.AtomicLong;
import java.util.concurrent.atomic.AtomicReferenceArray;
import wi.i;

public final class a extends AtomicReferenceArray implements i {
    private static final Integer A = Integer.getInteger("jctools.spsc.max.lookahead.step", 4096);
    private static final long serialVersionUID = -1296597691183856449L;

    /* renamed from: a  reason: collision with root package name */
    final int f45443a = (length() - 1);

    /* renamed from: w  reason: collision with root package name */
    final AtomicLong f45444w = new AtomicLong();

    /* renamed from: x  reason: collision with root package name */
    long f45445x;

    /* renamed from: y  reason: collision with root package name */
    final AtomicLong f45446y = new AtomicLong();

    /* renamed from: z  reason: collision with root package name */
    final int f45447z;

    public a(int i10) {
        super(k.a(i10));
        this.f45447z = Math.min(i10 / 4, A.intValue());
    }

    /* access modifiers changed from: package-private */
    public int a(long j10) {
        return this.f45443a & ((int) j10);
    }

    /* access modifiers changed from: package-private */
    public int b(long j10, int i10) {
        return ((int) j10) & i10;
    }

    /* access modifiers changed from: package-private */
    public Object c(int i10) {
        return get(i10);
    }

    public void clear() {
        while (true) {
            if (poll() == null && isEmpty()) {
                return;
            }
        }
    }

    /* access modifiers changed from: package-private */
    public void d(long j10) {
        this.f45446y.lazySet(j10);
    }

    /* access modifiers changed from: package-private */
    public void e(int i10, Object obj) {
        lazySet(i10, obj);
    }

    /* access modifiers changed from: package-private */
    public void f(long j10) {
        this.f45444w.lazySet(j10);
    }

    public boolean isEmpty() {
        if (this.f45444w.get() == this.f45446y.get()) {
            return true;
        }
        return false;
    }

    public boolean offer(Object obj) {
        if (obj != null) {
            int i10 = this.f45443a;
            long j10 = this.f45444w.get();
            int b10 = b(j10, i10);
            if (j10 >= this.f45445x) {
                long j11 = ((long) this.f45447z) + j10;
                if (c(b(j11, i10)) == null) {
                    this.f45445x = j11;
                } else if (c(b10) != null) {
                    return false;
                }
            }
            e(b10, obj);
            f(j10 + 1);
            return true;
        }
        throw new NullPointerException("Null is not a valid element");
    }

    public Object poll() {
        long j10 = this.f45446y.get();
        int a10 = a(j10);
        Object c10 = c(a10);
        if (c10 == null) {
            return null;
        }
        d(j10 + 1);
        e(a10, (Object) null);
        return c10;
    }
}
