package n2;

import android.os.Parcel;
import android.os.Parcelable;
import androidx.media3.common.util.b1;
import androidx.media3.common.util.f0;
import ge.d;
import java.util.Arrays;
import y0.k0;
import y0.l0;
import y0.m0;
import y0.n0;
import y0.y;

public final class a implements l0.b {
    public static final Parcelable.Creator<a> CREATOR = new C0227a();
    public final int A;
    public final int B;
    public final byte[] C;

    /* renamed from: a  reason: collision with root package name */
    public final int f16285a;

    /* renamed from: w  reason: collision with root package name */
    public final String f16286w;

    /* renamed from: x  reason: collision with root package name */
    public final String f16287x;

    /* renamed from: y  reason: collision with root package name */
    public final int f16288y;

    /* renamed from: z  reason: collision with root package name */
    public final int f16289z;

    /* renamed from: n2.a$a  reason: collision with other inner class name */
    class C0227a implements Parcelable.Creator {
        C0227a() {
        }

        /* renamed from: a */
        public a createFromParcel(Parcel parcel) {
            return new a(parcel);
        }

        /* renamed from: b */
        public a[] newArray(int i10) {
            return new a[i10];
        }
    }

    public a(int i10, String str, String str2, int i11, int i12, int i13, int i14, byte[] bArr) {
        this.f16285a = i10;
        this.f16286w = str;
        this.f16287x = str2;
        this.f16288y = i11;
        this.f16289z = i12;
        this.A = i13;
        this.B = i14;
        this.C = bArr;
    }

    public static a a(f0 f0Var) {
        int q10 = f0Var.q();
        String t10 = n0.t(f0Var.F(f0Var.q(), d.f40781a));
        String E = f0Var.E(f0Var.q());
        int q11 = f0Var.q();
        int q12 = f0Var.q();
        int q13 = f0Var.q();
        int q14 = f0Var.q();
        int q15 = f0Var.q();
        byte[] bArr = new byte[q15];
        f0Var.l(bArr, 0, q15);
        return new a(q10, t10, E, q11, q12, q13, q14, bArr);
    }

    public /* synthetic */ byte[] E() {
        return m0.a(this);
    }

    public int describeContents() {
        return 0;
    }

    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null || a.class != obj.getClass()) {
            return false;
        }
        a aVar = (a) obj;
        if (this.f16285a == aVar.f16285a && this.f16286w.equals(aVar.f16286w) && this.f16287x.equals(aVar.f16287x) && this.f16288y == aVar.f16288y && this.f16289z == aVar.f16289z && this.A == aVar.A && this.B == aVar.B && Arrays.equals(this.C, aVar.C)) {
            return true;
        }
        return false;
    }

    public int hashCode() {
        return ((((((((((((((527 + this.f16285a) * 31) + this.f16286w.hashCode()) * 31) + this.f16287x.hashCode()) * 31) + this.f16288y) * 31) + this.f16289z) * 31) + this.A) * 31) + this.B) * 31) + Arrays.hashCode(this.C);
    }

    public /* synthetic */ y r() {
        return m0.b(this);
    }

    public String toString() {
        return "Picture: mimeType=" + this.f16286w + ", description=" + this.f16287x;
    }

    public void v(k0.b bVar) {
        bVar.J(this.C, this.f16285a);
    }

    public void writeToParcel(Parcel parcel, int i10) {
        parcel.writeInt(this.f16285a);
        parcel.writeString(this.f16286w);
        parcel.writeString(this.f16287x);
        parcel.writeInt(this.f16288y);
        parcel.writeInt(this.f16289z);
        parcel.writeInt(this.A);
        parcel.writeInt(this.B);
        parcel.writeByteArray(this.C);
    }

    a(Parcel parcel) {
        this.f16285a = parcel.readInt();
        this.f16286w = (String) b1.l(parcel.readString());
        this.f16287x = (String) b1.l(parcel.readString());
        this.f16288y = parcel.readInt();
        this.f16289z = parcel.readInt();
        this.A = parcel.readInt();
        this.B = parcel.readInt();
        this.C = (byte[]) b1.l(parcel.createByteArray());
    }
}
