package n2;

import android.os.Parcel;
import android.os.Parcelable;
import androidx.media3.common.util.b1;
import y0.k0;
import y0.l0;
import y0.m0;
import y0.y;

public class b implements l0.b {
    public static final Parcelable.Creator<b> CREATOR = new a();

    /* renamed from: a  reason: collision with root package name */
    public final String f16290a;

    /* renamed from: w  reason: collision with root package name */
    public final String f16291w;

    class a implements Parcelable.Creator {
        a() {
        }

        /* renamed from: a */
        public b createFromParcel(Parcel parcel) {
            return new b(parcel);
        }

        /* renamed from: b */
        public b[] newArray(int i10) {
            return new b[i10];
        }
    }

    public b(String str, String str2) {
        this.f16290a = ge.b.g(str);
        this.f16291w = str2;
    }

    public /* synthetic */ byte[] E() {
        return m0.a(this);
    }

    public int describeContents() {
        return 0;
    }

    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null || getClass() != obj.getClass()) {
            return false;
        }
        b bVar = (b) obj;
        if (!this.f16290a.equals(bVar.f16290a) || !this.f16291w.equals(bVar.f16291w)) {
            return false;
        }
        return true;
    }

    public int hashCode() {
        return ((527 + this.f16290a.hashCode()) * 31) + this.f16291w.hashCode();
    }

    public /* synthetic */ y r() {
        return m0.b(this);
    }

    public String toString() {
        return "VC: " + this.f16290a + "=" + this.f16291w;
    }

    public void v(k0.b bVar) {
        String str = this.f16290a;
        str.hashCode();
        char c10 = 65535;
        switch (str.hashCode()) {
            case 62359119:
                if (str.equals("ALBUM")) {
                    c10 = 0;
                    break;
                }
                break;
            case 79833656:
                if (str.equals("TITLE")) {
                    c10 = 1;
                    break;
                }
                break;
            case 428414940:
                if (str.equals("DESCRIPTION")) {
                    c10 = 2;
                    break;
                }
                break;
            case 1746739798:
                if (str.equals("ALBUMARTIST")) {
                    c10 = 3;
                    break;
                }
                break;
            case 1939198791:
                if (str.equals("ARTIST")) {
                    c10 = 4;
                    break;
                }
                break;
        }
        switch (c10) {
            case 0:
                bVar.O(this.f16291w);
                return;
            case 1:
                bVar.o0(this.f16291w);
                return;
            case 2:
                bVar.V(this.f16291w);
                return;
            case 3:
                bVar.N(this.f16291w);
                return;
            case 4:
                bVar.P(this.f16291w);
                return;
            default:
                return;
        }
    }

    public void writeToParcel(Parcel parcel, int i10) {
        parcel.writeString(this.f16290a);
        parcel.writeString(this.f16291w);
    }

    protected b(Parcel parcel) {
        this.f16290a = (String) b1.l(parcel.readString());
        this.f16291w = (String) b1.l(parcel.readString());
    }
}
