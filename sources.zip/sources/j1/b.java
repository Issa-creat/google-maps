package j1;

import ge.j;

public final class b {

    /* renamed from: a  reason: collision with root package name */
    public final String f14616a;

    /* renamed from: b  reason: collision with root package name */
    public final String f14617b;

    /* renamed from: c  reason: collision with root package name */
    public final int f14618c;

    /* renamed from: d  reason: collision with root package name */
    public final int f14619d;

    public b(String str, String str2, int i10, int i11) {
        this.f14616a = str;
        this.f14617b = str2;
        this.f14618c = i10;
        this.f14619d = i11;
    }

    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (!(obj instanceof b)) {
            return false;
        }
        b bVar = (b) obj;
        if (this.f14618c != bVar.f14618c || this.f14619d != bVar.f14619d || !j.a(this.f14616a, bVar.f14616a) || !j.a(this.f14617b, bVar.f14617b)) {
            return false;
        }
        return true;
    }

    public int hashCode() {
        return j.b(this.f14616a, this.f14617b, Integer.valueOf(this.f14618c), Integer.valueOf(this.f14619d));
    }
}
