package j1;

import i1.f;

final class m implements f {

    /* renamed from: a  reason: collision with root package name */
    private final i f14705a;

    public m(i iVar) {
        this.f14705a = iVar;
    }

    public long a(long j10) {
        return 0;
    }

    public long b(long j10, long j11) {
        return j11;
    }

    public long c(long j10, long j11) {
        return 0;
    }

    public long d(long j10, long j11) {
        return -9223372036854775807L;
    }

    public i e(long j10) {
        return this.f14705a;
    }

    public long f(long j10, long j11) {
        return 0;
    }

    public boolean g() {
        return true;
    }

    public long h() {
        return 0;
    }

    public long i(long j10) {
        return 1;
    }

    public long j(long j10, long j11) {
        return 1;
    }
}
