package j1;

public final class o {

    /* renamed from: a  reason: collision with root package name */
    public final String f14709a;

    /* renamed from: b  reason: collision with root package name */
    public final String f14710b;

    public o(String str, String str2) {
        this.f14709a = str;
        this.f14710b = str2;
    }

    public String toString() {
        return this.f14709a + ", " + this.f14710b;
    }
}
