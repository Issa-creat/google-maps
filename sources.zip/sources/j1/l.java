package j1;

public final class l {

    /* renamed from: a  reason: collision with root package name */
    public final long f14700a;

    /* renamed from: b  reason: collision with root package name */
    public final long f14701b;

    /* renamed from: c  reason: collision with root package name */
    public final long f14702c;

    /* renamed from: d  reason: collision with root package name */
    public final float f14703d;

    /* renamed from: e  reason: collision with root package name */
    public final float f14704e;

    public l(long j10, long j11, long j12, float f10, float f11) {
        this.f14700a = j10;
        this.f14701b = j11;
        this.f14702c = j12;
        this.f14703d = f10;
        this.f14704e = f11;
    }
}
