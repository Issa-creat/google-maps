package j1;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

public final class n {

    /* renamed from: a  reason: collision with root package name */
    private final List f14706a;

    /* renamed from: b  reason: collision with root package name */
    private final List f14707b;

    /* renamed from: c  reason: collision with root package name */
    private final List f14708c;

    private n(List list, List list2, List list3) {
        this.f14706a = list;
        this.f14707b = list2;
        this.f14708c = list3;
    }

    public static n b(String str) {
        ArrayList arrayList = new ArrayList();
        ArrayList arrayList2 = new ArrayList();
        ArrayList arrayList3 = new ArrayList();
        c(str, arrayList, arrayList2, arrayList3);
        return new n(arrayList, arrayList2, arrayList3);
    }

    private static void c(String str, List list, List list2, List list3) {
        String str2;
        list.add("");
        int i10 = 0;
        while (i10 < str.length()) {
            int indexOf = str.indexOf("$", i10);
            char c10 = 65535;
            if (indexOf == -1) {
                list.set(list2.size(), ((String) list.get(list2.size())) + str.substring(i10));
                i10 = str.length();
            } else if (indexOf != i10) {
                list.set(list2.size(), ((String) list.get(list2.size())) + str.substring(i10, indexOf));
                i10 = indexOf;
            } else if (str.startsWith("$$", i10)) {
                list.set(list2.size(), ((String) list.get(list2.size())) + "$");
                i10 += 2;
            } else {
                list3.add("");
                int i11 = i10 + 1;
                int indexOf2 = str.indexOf("$", i11);
                String substring = str.substring(i11, indexOf2);
                if (substring.equals("RepresentationID")) {
                    list2.add(1);
                } else {
                    int indexOf3 = substring.indexOf("%0");
                    if (indexOf3 != -1) {
                        str2 = substring.substring(indexOf3);
                        if (!str2.endsWith("d") && !str2.endsWith("x") && !str2.endsWith("X")) {
                            str2 = str2 + "d";
                        }
                        substring = substring.substring(0, indexOf3);
                    } else {
                        str2 = "%01d";
                    }
                    substring.hashCode();
                    switch (substring.hashCode()) {
                        case -1950496919:
                            if (substring.equals("Number")) {
                                c10 = 0;
                                break;
                            }
                            break;
                        case 2606829:
                            if (substring.equals("Time")) {
                                c10 = 1;
                                break;
                            }
                            break;
                        case 38199441:
                            if (substring.equals("Bandwidth")) {
                                c10 = 2;
                                break;
                            }
                            break;
                    }
                    switch (c10) {
                        case 0:
                            list2.add(2);
                            break;
                        case 1:
                            list2.add(4);
                            break;
                        case 2:
                            list2.add(3);
                            break;
                        default:
                            throw new IllegalArgumentException("Invalid template: " + str);
                    }
                    list3.set(list2.size() - 1, str2);
                }
                list.add("");
                i10 = indexOf2 + 1;
            }
        }
    }

    public String a(String str, long j10, int i10, long j11) {
        StringBuilder sb2 = new StringBuilder();
        for (int i11 = 0; i11 < this.f14707b.size(); i11++) {
            sb2.append((String) this.f14706a.get(i11));
            if (((Integer) this.f14707b.get(i11)).intValue() == 1) {
                sb2.append(str);
            } else if (((Integer) this.f14707b.get(i11)).intValue() == 2) {
                sb2.append(String.format(Locale.US, (String) this.f14708c.get(i11), new Object[]{Long.valueOf(j10)}));
            } else if (((Integer) this.f14707b.get(i11)).intValue() == 3) {
                sb2.append(String.format(Locale.US, (String) this.f14708c.get(i11), new Object[]{Integer.valueOf(i10)}));
            } else if (((Integer) this.f14707b.get(i11)).intValue() == 4) {
                sb2.append(String.format(Locale.US, (String) this.f14708c.get(i11), new Object[]{Long.valueOf(j11)}));
            }
        }
        sb2.append((String) this.f14706a.get(this.f14707b.size()));
        return sb2.toString();
    }
}
