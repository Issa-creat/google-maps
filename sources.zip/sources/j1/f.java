package j1;

import m2.a;

public final class f {

    /* renamed from: a  reason: collision with root package name */
    public final a[] f14650a;

    /* renamed from: b  reason: collision with root package name */
    public final long[] f14651b;

    /* renamed from: c  reason: collision with root package name */
    public final String f14652c;

    /* renamed from: d  reason: collision with root package name */
    public final String f14653d;

    /* renamed from: e  reason: collision with root package name */
    public final long f14654e;

    public f(String str, String str2, long j10, long[] jArr, a[] aVarArr) {
        this.f14652c = str;
        this.f14653d = str2;
        this.f14654e = j10;
        this.f14651b = jArr;
        this.f14650a = aVarArr;
    }

    public String a() {
        return this.f14652c + "/" + this.f14653d;
    }
}
