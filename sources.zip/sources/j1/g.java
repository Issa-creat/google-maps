package j1;

import java.util.Collections;
import java.util.List;

public class g {

    /* renamed from: a  reason: collision with root package name */
    public final String f14655a;

    /* renamed from: b  reason: collision with root package name */
    public final long f14656b;

    /* renamed from: c  reason: collision with root package name */
    public final List f14657c;

    /* renamed from: d  reason: collision with root package name */
    public final List f14658d;

    /* renamed from: e  reason: collision with root package name */
    public final e f14659e;

    public g(String str, long j10, List list, List list2) {
        this(str, j10, list, list2, (e) null);
    }

    public int a(int i10) {
        int size = this.f14657c.size();
        for (int i11 = 0; i11 < size; i11++) {
            if (((a) this.f14657c.get(i11)).f14611b == i10) {
                return i11;
            }
        }
        return -1;
    }

    public g(String str, long j10, List list, List list2, e eVar) {
        this.f14655a = str;
        this.f14656b = j10;
        this.f14657c = Collections.unmodifiableList(list);
        this.f14658d = Collections.unmodifiableList(list2);
        this.f14659e = eVar;
    }
}
