package j1;

import android.net.Uri;
import android.text.TextUtils;
import android.util.Pair;
import android.util.Xml;
import androidx.media3.common.util.b1;
import androidx.media3.common.util.d1;
import androidx.media3.common.util.s;
import com.google.android.gms.ads.AdRequest;
import com.google.common.collect.g0;
import ge.b;
import j1.k;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import okhttp3.internal.http2.Http2;
import org.xml.sax.helpers.DefaultHandler;
import org.xmlpull.v1.XmlPullParser;
import org.xmlpull.v1.XmlPullParserException;
import org.xmlpull.v1.XmlPullParserFactory;
import org.xmlpull.v1.XmlSerializer;
import x1.q;
import xf.m;
import y0.d0;
import y0.l;
import y0.n0;
import y0.o0;
import y0.r;
import y0.y;

public class d extends DefaultHandler implements q.a {

    /* renamed from: b  reason: collision with root package name */
    private static final Pattern f14633b = Pattern.compile("(\\d+)(?:/(\\d+))?");

    /* renamed from: c  reason: collision with root package name */
    private static final Pattern f14634c = Pattern.compile("CC([1-4])=.*");

    /* renamed from: d  reason: collision with root package name */
    private static final Pattern f14635d = Pattern.compile("([1-9]|[1-5][0-9]|6[0-3])=.*");

    /* renamed from: e  reason: collision with root package name */
    private static final int[] f14636e = {-1, 1, 2, 3, 4, 5, 6, 8, 2, 3, 4, 7, 8, 24, 8, 12, 10, 12, 14, 12, 14};

    /* renamed from: a  reason: collision with root package name */
    private final XmlPullParserFactory f14637a;

    protected static final class a {

        /* renamed from: a  reason: collision with root package name */
        public final y f14638a;

        /* renamed from: b  reason: collision with root package name */
        public final com.google.common.collect.y f14639b;

        /* renamed from: c  reason: collision with root package name */
        public final k f14640c;

        /* renamed from: d  reason: collision with root package name */
        public final String f14641d;

        /* renamed from: e  reason: collision with root package name */
        public final ArrayList f14642e;

        /* renamed from: f  reason: collision with root package name */
        public final ArrayList f14643f;

        /* renamed from: g  reason: collision with root package name */
        public final long f14644g;

        /* renamed from: h  reason: collision with root package name */
        public final List f14645h;

        /* renamed from: i  reason: collision with root package name */
        public final List f14646i;

        public a(y yVar, List list, k kVar, String str, ArrayList arrayList, ArrayList arrayList2, List list2, List list3, long j10) {
            this.f14638a = yVar;
            this.f14639b = com.google.common.collect.y.w(list);
            this.f14640c = kVar;
            this.f14641d = str;
            this.f14642e = arrayList;
            this.f14643f = arrayList2;
            this.f14645h = list2;
            this.f14646i = list3;
            this.f14644g = j10;
        }
    }

    public d() {
        try {
            this.f14637a = XmlPullParserFactory.newInstance();
        } catch (XmlPullParserException e10) {
            throw new RuntimeException("Couldn't create XmlPullParserFactory instance", e10);
        }
    }

    protected static int D(List list) {
        String str;
        for (int i10 = 0; i10 < list.size(); i10++) {
            e eVar = (e) list.get(i10);
            if ("urn:scte:dash:cc:cea-608:2015".equals(eVar.f14647a) && (str = eVar.f14648b) != null) {
                Matcher matcher = f14634c.matcher(str);
                if (matcher.matches()) {
                    return Integer.parseInt(matcher.group(1));
                }
                s.i("MpdParser", "Unable to parse CEA-608 channel number from: " + eVar.f14648b);
            }
        }
        return -1;
    }

    protected static int E(List list) {
        String str;
        for (int i10 = 0; i10 < list.size(); i10++) {
            e eVar = (e) list.get(i10);
            if ("urn:scte:dash:cc:cea-708:2015".equals(eVar.f14647a) && (str = eVar.f14648b) != null) {
                Matcher matcher = f14635d.matcher(str);
                if (matcher.matches()) {
                    return Integer.parseInt(matcher.group(1));
                }
                s.i("MpdParser", "Unable to parse CEA-708 service block number from: " + eVar.f14648b);
            }
        }
        return -1;
    }

    protected static long H(XmlPullParser xmlPullParser, String str, long j10) {
        String attributeValue = xmlPullParser.getAttributeValue((String) null, str);
        if (attributeValue == null) {
            return j10;
        }
        return b1.j1(attributeValue);
    }

    protected static e I(XmlPullParser xmlPullParser, String str) {
        String r02 = r0(xmlPullParser, "schemeIdUri", "");
        String r03 = r0(xmlPullParser, "value", (String) null);
        String r04 = r0(xmlPullParser, "id", (String) null);
        do {
            xmlPullParser.next();
        } while (!d1.d(xmlPullParser, str));
        return new e(r02, r03, r04);
    }

    /* JADX WARNING: Can't fix incorrect switch cases order */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    protected static int J(org.xmlpull.v1.XmlPullParser r4) {
        /*
            r0 = 0
            java.lang.String r1 = "value"
            java.lang.String r4 = r4.getAttributeValue(r0, r1)
            r0 = -1
            if (r4 != 0) goto L_0x000b
            return r0
        L_0x000b:
            java.lang.String r4 = ge.b.e(r4)
            r4.hashCode()
            int r1 = r4.hashCode()
            r2 = 2
            r3 = 1
            switch(r1) {
                case 1596796: goto L_0x0049;
                case 2937391: goto L_0x003e;
                case 3094034: goto L_0x0033;
                case 3094035: goto L_0x0028;
                case 3133436: goto L_0x001d;
                default: goto L_0x001b;
            }
        L_0x001b:
            r4 = -1
            goto L_0x0053
        L_0x001d:
            java.lang.String r1 = "fa01"
            boolean r4 = r4.equals(r1)
            if (r4 != 0) goto L_0x0026
            goto L_0x001b
        L_0x0026:
            r4 = 4
            goto L_0x0053
        L_0x0028:
            java.lang.String r1 = "f801"
            boolean r4 = r4.equals(r1)
            if (r4 != 0) goto L_0x0031
            goto L_0x001b
        L_0x0031:
            r4 = 3
            goto L_0x0053
        L_0x0033:
            java.lang.String r1 = "f800"
            boolean r4 = r4.equals(r1)
            if (r4 != 0) goto L_0x003c
            goto L_0x001b
        L_0x003c:
            r4 = 2
            goto L_0x0053
        L_0x003e:
            java.lang.String r1 = "a000"
            boolean r4 = r4.equals(r1)
            if (r4 != 0) goto L_0x0047
            goto L_0x001b
        L_0x0047:
            r4 = 1
            goto L_0x0053
        L_0x0049:
            java.lang.String r1 = "4000"
            boolean r4 = r4.equals(r1)
            if (r4 != 0) goto L_0x0052
            goto L_0x001b
        L_0x0052:
            r4 = 0
        L_0x0053:
            switch(r4) {
                case 0: goto L_0x005f;
                case 1: goto L_0x005e;
                case 2: goto L_0x005c;
                case 3: goto L_0x005a;
                case 4: goto L_0x0057;
                default: goto L_0x0056;
            }
        L_0x0056:
            return r0
        L_0x0057:
            r4 = 8
            return r4
        L_0x005a:
            r4 = 6
            return r4
        L_0x005c:
            r4 = 5
            return r4
        L_0x005e:
            return r2
        L_0x005f:
            return r3
        */
        throw new UnsupportedOperationException("Method not decompiled: j1.d.J(org.xmlpull.v1.XmlPullParser):int");
    }

    protected static int K(XmlPullParser xmlPullParser) {
        int U = U(xmlPullParser, "value", -1);
        if (U <= 0 || U >= 33) {
            return -1;
        }
        return U;
    }

    protected static int L(XmlPullParser xmlPullParser) {
        int bitCount;
        String attributeValue = xmlPullParser.getAttributeValue((String) null, "value");
        if (attributeValue == null || (bitCount = Integer.bitCount(Integer.parseInt(attributeValue, 16))) == 0) {
            return -1;
        }
        return bitCount;
    }

    protected static long M(XmlPullParser xmlPullParser, String str, long j10) {
        String attributeValue = xmlPullParser.getAttributeValue((String) null, str);
        if (attributeValue == null) {
            return j10;
        }
        return b1.k1(attributeValue);
    }

    protected static String N(List list) {
        for (int i10 = 0; i10 < list.size(); i10++) {
            e eVar = (e) list.get(i10);
            String str = eVar.f14647a;
            if ("tag:dolby.com,2018:dash:EC3_ExtensionType:2018".equals(str) && "JOC".equals(eVar.f14648b)) {
                return "audio/eac3-joc";
            }
            if ("tag:dolby.com,2014:dash:DolbyDigitalPlusExtensionType:2014".equals(str) && "ec+3".equals(eVar.f14648b)) {
                return "audio/eac3-joc";
            }
        }
        return "audio/eac3";
    }

    protected static float R(XmlPullParser xmlPullParser, String str, float f10) {
        String attributeValue = xmlPullParser.getAttributeValue((String) null, str);
        if (attributeValue == null) {
            return f10;
        }
        return Float.parseFloat(attributeValue);
    }

    protected static float S(XmlPullParser xmlPullParser, float f10) {
        String attributeValue = xmlPullParser.getAttributeValue((String) null, "frameRate");
        if (attributeValue == null) {
            return f10;
        }
        Matcher matcher = f14633b.matcher(attributeValue);
        if (!matcher.matches()) {
            return f10;
        }
        int parseInt = Integer.parseInt(matcher.group(1));
        String group = matcher.group(2);
        if (!TextUtils.isEmpty(group)) {
            return ((float) parseInt) / ((float) Integer.parseInt(group));
        }
        return (float) parseInt;
    }

    protected static int U(XmlPullParser xmlPullParser, String str, int i10) {
        String attributeValue = xmlPullParser.getAttributeValue((String) null, str);
        if (attributeValue == null) {
            return i10;
        }
        return Integer.parseInt(attributeValue);
    }

    protected static long W(List list) {
        for (int i10 = 0; i10 < list.size(); i10++) {
            e eVar = (e) list.get(i10);
            if (b.a("http://dashif.org/guidelines/last-segment-number", eVar.f14647a)) {
                return Long.parseLong(eVar.f14648b);
            }
        }
        return -1;
    }

    protected static long X(XmlPullParser xmlPullParser, String str, long j10) {
        String attributeValue = xmlPullParser.getAttributeValue((String) null, str);
        if (attributeValue == null) {
            return j10;
        }
        return Long.parseLong(attributeValue);
    }

    protected static int Z(XmlPullParser xmlPullParser) {
        int U = U(xmlPullParser, "value", -1);
        if (U < 0) {
            return -1;
        }
        int[] iArr = f14636e;
        if (U < iArr.length) {
            return iArr[U];
        }
        return -1;
    }

    private long b(List list, long j10, long j11, int i10, long j12) {
        int i11;
        if (i10 >= 0) {
            i11 = i10 + 1;
        } else {
            i11 = (int) b1.o(j12 - j10, j11);
        }
        for (int i12 = 0; i12 < i11; i12++) {
            list.add(m(j10, j11));
            j10 += j11;
        }
        return j10;
    }

    private static int p(int i10, int i11) {
        boolean z10;
        if (i10 == -1) {
            return i11;
        }
        if (i11 == -1) {
            return i10;
        }
        if (i10 == i11) {
            z10 = true;
        } else {
            z10 = false;
        }
        androidx.media3.common.util.a.g(z10);
        return i10;
    }

    private static String q(String str, String str2) {
        if (str == null) {
            return str2;
        }
        if (str2 == null) {
            return str;
        }
        androidx.media3.common.util.a.g(str.equals(str2));
        return str;
    }

    private static void r(ArrayList arrayList) {
        String str;
        int i10 = 0;
        while (true) {
            if (i10 >= arrayList.size()) {
                str = null;
                break;
            }
            r.b bVar = (r.b) arrayList.get(i10);
            if (l.f19917c.equals(bVar.f19997w) && (str = bVar.f19998x) != null) {
                arrayList.remove(i10);
                break;
            }
            i10++;
        }
        if (str != null) {
            for (int i11 = 0; i11 < arrayList.size(); i11++) {
                r.b bVar2 = (r.b) arrayList.get(i11);
                if (l.f19916b.equals(bVar2.f19997w) && bVar2.f19998x == null) {
                    arrayList.set(i11, new r.b(l.f19917c, str, bVar2.f19999y, bVar2.f20000z));
                }
            }
        }
    }

    protected static String r0(XmlPullParser xmlPullParser, String str, String str2) {
        String attributeValue = xmlPullParser.getAttributeValue((String) null, str);
        if (attributeValue == null) {
            return str2;
        }
        return attributeValue;
    }

    private static void s(ArrayList arrayList) {
        for (int size = arrayList.size() - 1; size >= 0; size--) {
            r.b bVar = (r.b) arrayList.get(size);
            if (!bVar.c()) {
                int i10 = 0;
                while (true) {
                    if (i10 >= arrayList.size()) {
                        break;
                    } else if (((r.b) arrayList.get(i10)).a(bVar)) {
                        arrayList.remove(size);
                        break;
                    } else {
                        i10++;
                    }
                }
            }
        }
    }

    protected static String s0(XmlPullParser xmlPullParser, String str) {
        String str2 = "";
        do {
            xmlPullParser.next();
            if (xmlPullParser.getEventType() == 4) {
                str2 = xmlPullParser.getText();
            } else {
                w(xmlPullParser);
            }
        } while (!d1.d(xmlPullParser, str));
        return str2;
    }

    private static long t(long j10, long j11) {
        if (j11 != -9223372036854775807L) {
            j10 = j11;
        }
        if (j10 == Long.MAX_VALUE) {
            return -9223372036854775807L;
        }
        return j10;
    }

    private static String u(String str, String str2) {
        if (n0.o(str)) {
            return n0.c(str2);
        }
        if (n0.s(str)) {
            return n0.n(str2);
        }
        if (n0.r(str) || n0.p(str)) {
            return str;
        }
        if (!"application/mp4".equals(str)) {
            return null;
        }
        String g10 = n0.g(str2);
        if ("text/vtt".equals(g10)) {
            return "application/x-mp4-vtt";
        }
        return g10;
    }

    private boolean v(String[] strArr) {
        for (String startsWith : strArr) {
            if (startsWith.startsWith("urn:dvb:dash:profile:dvb-dash:")) {
                return true;
            }
        }
        return false;
    }

    public static void w(XmlPullParser xmlPullParser) {
        if (d1.e(xmlPullParser)) {
            int i10 = 1;
            while (i10 != 0) {
                xmlPullParser.next();
                if (d1.e(xmlPullParser)) {
                    i10++;
                } else if (d1.c(xmlPullParser)) {
                    i10--;
                }
            }
        }
    }

    /* access modifiers changed from: protected */
    /* JADX WARNING: Can't fix incorrect switch cases order */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public int A(org.xmlpull.v1.XmlPullParser r4) {
        /*
            r3 = this;
            java.lang.String r0 = "schemeIdUri"
            r1 = 0
            java.lang.String r0 = r0(r4, r0, r1)
            r0.hashCode()
            int r1 = r0.hashCode()
            r2 = -1
            switch(r1) {
                case -2128649360: goto L_0x0056;
                case -1352850286: goto L_0x004b;
                case -1138141449: goto L_0x0040;
                case -986633423: goto L_0x0035;
                case -79006963: goto L_0x002a;
                case 312179081: goto L_0x001f;
                case 2036691300: goto L_0x0014;
                default: goto L_0x0012;
            }
        L_0x0012:
            r0 = -1
            goto L_0x0060
        L_0x0014:
            java.lang.String r1 = "urn:dolby:dash:audio_channel_configuration:2011"
            boolean r0 = r0.equals(r1)
            if (r0 != 0) goto L_0x001d
            goto L_0x0012
        L_0x001d:
            r0 = 6
            goto L_0x0060
        L_0x001f:
            java.lang.String r1 = "tag:dts.com,2018:uhd:audio_channel_configuration"
            boolean r0 = r0.equals(r1)
            if (r0 != 0) goto L_0x0028
            goto L_0x0012
        L_0x0028:
            r0 = 5
            goto L_0x0060
        L_0x002a:
            java.lang.String r1 = "tag:dts.com,2014:dash:audio_channel_configuration:2012"
            boolean r0 = r0.equals(r1)
            if (r0 != 0) goto L_0x0033
            goto L_0x0012
        L_0x0033:
            r0 = 4
            goto L_0x0060
        L_0x0035:
            java.lang.String r1 = "urn:mpeg:mpegB:cicp:ChannelConfiguration"
            boolean r0 = r0.equals(r1)
            if (r0 != 0) goto L_0x003e
            goto L_0x0012
        L_0x003e:
            r0 = 3
            goto L_0x0060
        L_0x0040:
            java.lang.String r1 = "tag:dolby.com,2014:dash:audio_channel_configuration:2011"
            boolean r0 = r0.equals(r1)
            if (r0 != 0) goto L_0x0049
            goto L_0x0012
        L_0x0049:
            r0 = 2
            goto L_0x0060
        L_0x004b:
            java.lang.String r1 = "urn:mpeg:dash:23003:3:audio_channel_configuration:2011"
            boolean r0 = r0.equals(r1)
            if (r0 != 0) goto L_0x0054
            goto L_0x0012
        L_0x0054:
            r0 = 1
            goto L_0x0060
        L_0x0056:
            java.lang.String r1 = "urn:dts:dash:audio_channel_configuration:2012"
            boolean r0 = r0.equals(r1)
            if (r0 != 0) goto L_0x005f
            goto L_0x0012
        L_0x005f:
            r0 = 0
        L_0x0060:
            switch(r0) {
                case 0: goto L_0x007a;
                case 1: goto L_0x0073;
                case 2: goto L_0x006e;
                case 3: goto L_0x0069;
                case 4: goto L_0x007a;
                case 5: goto L_0x0064;
                case 6: goto L_0x006e;
                default: goto L_0x0063;
            }
        L_0x0063:
            goto L_0x007e
        L_0x0064:
            int r2 = L(r4)
            goto L_0x007e
        L_0x0069:
            int r2 = Z(r4)
            goto L_0x007e
        L_0x006e:
            int r2 = J(r4)
            goto L_0x007e
        L_0x0073:
            java.lang.String r0 = "value"
            int r2 = U(r4, r0, r2)
            goto L_0x007e
        L_0x007a:
            int r2 = K(r4)
        L_0x007e:
            r4.next()
            java.lang.String r0 = "AudioChannelConfiguration"
            boolean r0 = androidx.media3.common.util.d1.d(r4, r0)
            if (r0 == 0) goto L_0x007e
            return r2
        */
        throw new UnsupportedOperationException("Method not decompiled: j1.d.A(org.xmlpull.v1.XmlPullParser):int");
    }

    /* access modifiers changed from: protected */
    public long B(XmlPullParser xmlPullParser, long j10) {
        String attributeValue = xmlPullParser.getAttributeValue((String) null, "availabilityTimeOffset");
        if (attributeValue == null) {
            return j10;
        }
        if ("INF".equals(attributeValue)) {
            return Long.MAX_VALUE;
        }
        return (long) (Float.parseFloat(attributeValue) * 1000000.0f);
    }

    /* access modifiers changed from: protected */
    public List C(XmlPullParser xmlPullParser, List list, boolean z10) {
        int i10;
        int i11;
        String str;
        String attributeValue = xmlPullParser.getAttributeValue((String) null, "dvb:priority");
        if (attributeValue != null) {
            i10 = Integer.parseInt(attributeValue);
        } else if (z10) {
            i10 = 1;
        } else {
            i10 = Integer.MIN_VALUE;
        }
        String attributeValue2 = xmlPullParser.getAttributeValue((String) null, "dvb:weight");
        if (attributeValue2 != null) {
            i11 = Integer.parseInt(attributeValue2);
        } else {
            i11 = 1;
        }
        String attributeValue3 = xmlPullParser.getAttributeValue((String) null, "serviceLocation");
        String s02 = s0(xmlPullParser, "BaseURL");
        if (androidx.media3.common.util.n0.c(s02)) {
            if (attributeValue3 == null) {
                attributeValue3 = s02;
            }
            return g0.j(new b(s02, attributeValue3, i10, i11));
        }
        ArrayList arrayList = new ArrayList();
        for (int i12 = 0; i12 < list.size(); i12++) {
            b bVar = (b) list.get(i12);
            String e10 = androidx.media3.common.util.n0.e(bVar.f14616a, s02);
            if (attributeValue3 == null) {
                str = e10;
            } else {
                str = attributeValue3;
            }
            if (z10) {
                i10 = bVar.f14618c;
                i11 = bVar.f14619d;
                str = bVar.f14617b;
            }
            arrayList.add(new b(e10, str, i10, i11));
        }
        return arrayList;
    }

    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r5v0, resolved type: java.lang.String} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r5v1, resolved type: java.lang.String} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r5v2, resolved type: byte[]} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r5v7, resolved type: byte[]} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r5v8, resolved type: byte[]} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r5v9, resolved type: java.lang.String} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r5v10, resolved type: java.util.UUID} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r5v13, resolved type: java.lang.String} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r5v20, resolved type: byte[]} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r5v25, resolved type: java.lang.String} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r5v26, resolved type: byte[]} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r5v27, resolved type: byte[]} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r5v28, resolved type: byte[]} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r5v29, resolved type: byte[]} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r5v30, resolved type: byte[]} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r5v31, resolved type: java.lang.String} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r5v32, resolved type: java.lang.String} */
    /* access modifiers changed from: protected */
    /* JADX WARNING: Code restructure failed: missing block: B:29:0x0091, code lost:
        r0 = null;
        r5 = null;
     */
    /* JADX WARNING: Multi-variable type inference failed */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public android.util.Pair F(org.xmlpull.v1.XmlPullParser r12) {
        /*
            r11 = this;
            java.lang.String r0 = "schemeIdUri"
            r1 = 0
            java.lang.String r0 = r12.getAttributeValue(r1, r0)
            java.lang.String r2 = "MpdParser"
            r3 = 0
            if (r0 == 0) goto L_0x0097
            java.lang.String r0 = ge.b.e(r0)
            r0.hashCode()
            int r4 = r0.hashCode()
            r5 = -1
            switch(r4) {
                case -1980789791: goto L_0x003d;
                case 489446379: goto L_0x0032;
                case 755418770: goto L_0x0027;
                case 1812765994: goto L_0x001c;
                default: goto L_0x001b;
            }
        L_0x001b:
            goto L_0x0047
        L_0x001c:
            java.lang.String r4 = "urn:mpeg:dash:mp4protection:2011"
            boolean r0 = r0.equals(r4)
            if (r0 != 0) goto L_0x0025
            goto L_0x0047
        L_0x0025:
            r5 = 3
            goto L_0x0047
        L_0x0027:
            java.lang.String r4 = "urn:uuid:edef8ba9-79d6-4ace-a3c8-27dcd51d21ed"
            boolean r0 = r0.equals(r4)
            if (r0 != 0) goto L_0x0030
            goto L_0x0047
        L_0x0030:
            r5 = 2
            goto L_0x0047
        L_0x0032:
            java.lang.String r4 = "urn:uuid:9a04f079-9840-4286-ab92-e65be0885f95"
            boolean r0 = r0.equals(r4)
            if (r0 != 0) goto L_0x003b
            goto L_0x0047
        L_0x003b:
            r5 = 1
            goto L_0x0047
        L_0x003d:
            java.lang.String r4 = "urn:uuid:e2719d58-a985-b3c9-781a-b030af78d30e"
            boolean r0 = r0.equals(r4)
            if (r0 != 0) goto L_0x0046
            goto L_0x0047
        L_0x0046:
            r5 = 0
        L_0x0047:
            switch(r5) {
                case 0: goto L_0x0094;
                case 1: goto L_0x008f;
                case 2: goto L_0x008c;
                case 3: goto L_0x004b;
                default: goto L_0x004a;
            }
        L_0x004a:
            goto L_0x0097
        L_0x004b:
            java.lang.String r0 = "value"
            java.lang.String r0 = r12.getAttributeValue(r1, r0)
            java.lang.String r4 = "default_KID"
            java.lang.String r4 = androidx.media3.common.util.d1.b(r12, r4)
            boolean r5 = android.text.TextUtils.isEmpty(r4)
            if (r5 != 0) goto L_0x0085
            java.lang.String r5 = "00000000-0000-0000-0000-000000000000"
            boolean r5 = r5.equals(r4)
            if (r5 != 0) goto L_0x0085
            java.lang.String r5 = "\\s+"
            java.lang.String[] r4 = r4.split(r5)
            int r5 = r4.length
            java.util.UUID[] r5 = new java.util.UUID[r5]
            r6 = 0
        L_0x006f:
            int r7 = r4.length
            if (r6 >= r7) goto L_0x007d
            r7 = r4[r6]
            java.util.UUID r7 = java.util.UUID.fromString(r7)
            r5[r6] = r7
            int r6 = r6 + 1
            goto L_0x006f
        L_0x007d:
            java.util.UUID r4 = y0.l.f19916b
            byte[] r5 = v2.o.b(r4, r5, r1)
            r6 = r1
            goto L_0x009b
        L_0x0085:
            java.lang.String r4 = "Ignoring <ContentProtection> with schemeIdUri=\"urn:mpeg:dash:mp4protection:2011\" (ClearKey) due to missing required default_KID attribute."
            androidx.media3.common.util.s.i(r2, r4)
            r4 = r1
            goto L_0x0099
        L_0x008c:
            java.util.UUID r4 = y0.l.f19918d
            goto L_0x0091
        L_0x008f:
            java.util.UUID r4 = y0.l.f19919e
        L_0x0091:
            r0 = r1
            r5 = r0
            goto L_0x009a
        L_0x0094:
            java.util.UUID r4 = y0.l.f19917c
            goto L_0x0091
        L_0x0097:
            r0 = r1
            r4 = r0
        L_0x0099:
            r5 = r4
        L_0x009a:
            r6 = r5
        L_0x009b:
            r12.next()
            java.lang.String r7 = "clearkey:Laurl"
            boolean r7 = androidx.media3.common.util.d1.f(r12, r7)
            r8 = 4
            if (r7 != 0) goto L_0x00af
            java.lang.String r7 = "dashif:Laurl"
            boolean r7 = androidx.media3.common.util.d1.f(r12, r7)
            if (r7 == 0) goto L_0x00ba
        L_0x00af:
            int r7 = r12.next()
            if (r7 != r8) goto L_0x00ba
            java.lang.String r6 = r12.getText()
            goto L_0x011b
        L_0x00ba:
            java.lang.String r7 = "ms:laurl"
            boolean r7 = androidx.media3.common.util.d1.f(r12, r7)
            if (r7 == 0) goto L_0x00c9
            java.lang.String r6 = "licenseUrl"
            java.lang.String r6 = r12.getAttributeValue(r1, r6)
            goto L_0x011b
        L_0x00c9:
            if (r5 != 0) goto L_0x00f3
            java.lang.String r7 = "pssh"
            boolean r7 = androidx.media3.common.util.d1.g(r12, r7)
            if (r7 == 0) goto L_0x00f3
            int r7 = r12.next()
            if (r7 != r8) goto L_0x00f3
            java.lang.String r4 = r12.getText()
            byte[] r4 = android.util.Base64.decode(r4, r3)
            java.util.UUID r5 = v2.o.f(r4)
            if (r5 != 0) goto L_0x00ef
            java.lang.String r4 = "Skipping malformed cenc:pssh data"
            androidx.media3.common.util.s.i(r2, r4)
            r4 = r5
            r5 = r1
            goto L_0x011b
        L_0x00ef:
            r10 = r5
            r5 = r4
            r4 = r10
            goto L_0x011b
        L_0x00f3:
            if (r5 != 0) goto L_0x0118
            java.util.UUID r7 = y0.l.f19919e
            boolean r9 = r7.equals(r4)
            if (r9 == 0) goto L_0x0118
            java.lang.String r9 = "mspr:pro"
            boolean r9 = androidx.media3.common.util.d1.f(r12, r9)
            if (r9 == 0) goto L_0x0118
            int r9 = r12.next()
            if (r9 != r8) goto L_0x0118
            java.lang.String r5 = r12.getText()
            byte[] r5 = android.util.Base64.decode(r5, r3)
            byte[] r5 = v2.o.a(r7, r5)
            goto L_0x011b
        L_0x0118:
            w(r12)
        L_0x011b:
            java.lang.String r7 = "ContentProtection"
            boolean r7 = androidx.media3.common.util.d1.d(r12, r7)
            if (r7 == 0) goto L_0x009b
            if (r4 == 0) goto L_0x012c
            y0.r$b r1 = new y0.r$b
            java.lang.String r12 = "video/mp4"
            r1.<init>(r4, r6, r12, r5)
        L_0x012c:
            android.util.Pair r12 = android.util.Pair.create(r0, r1)
            return r12
        */
        throw new UnsupportedOperationException("Method not decompiled: j1.d.F(org.xmlpull.v1.XmlPullParser):android.util.Pair");
    }

    /* access modifiers changed from: protected */
    public int G(XmlPullParser xmlPullParser) {
        String attributeValue = xmlPullParser.getAttributeValue((String) null, "contentType");
        if (TextUtils.isEmpty(attributeValue)) {
            return -1;
        }
        if ("audio".equals(attributeValue)) {
            return 1;
        }
        if ("video".equals(attributeValue)) {
            return 2;
        }
        if ("text".equals(attributeValue)) {
            return 3;
        }
        if ("image".equals(attributeValue)) {
            return 4;
        }
        return -1;
    }

    /* access modifiers changed from: protected */
    public Pair O(XmlPullParser xmlPullParser, String str, String str2, long j10, long j11, ByteArrayOutputStream byteArrayOutputStream) {
        XmlPullParser xmlPullParser2 = xmlPullParser;
        long X = X(xmlPullParser2, "id", 0);
        long X2 = X(xmlPullParser2, "duration", -9223372036854775807L);
        long X3 = X(xmlPullParser2, "presentationTime", 0);
        long r12 = b1.r1(X2, 1000, j10);
        long r13 = b1.r1(X3 - j11, 1000000, j10);
        String r02 = r0(xmlPullParser2, "messageData", (String) null);
        byte[] P = P(xmlPullParser2, byteArrayOutputStream);
        Long valueOf = Long.valueOf(r13);
        if (r02 != null) {
            P = b1.C0(r02);
        }
        return Pair.create(valueOf, d(str, str2, X, r12, P));
    }

    /* access modifiers changed from: protected */
    public byte[] P(XmlPullParser xmlPullParser, ByteArrayOutputStream byteArrayOutputStream) {
        byteArrayOutputStream.reset();
        XmlSerializer newSerializer = Xml.newSerializer();
        newSerializer.setOutput(byteArrayOutputStream, ge.d.f40783c.name());
        xmlPullParser.nextToken();
        while (!d1.d(xmlPullParser, "Event")) {
            switch (xmlPullParser.getEventType()) {
                case 0:
                    newSerializer.startDocument((String) null, Boolean.FALSE);
                    break;
                case 1:
                    newSerializer.endDocument();
                    break;
                case 2:
                    newSerializer.startTag(xmlPullParser.getNamespace(), xmlPullParser.getName());
                    for (int i10 = 0; i10 < xmlPullParser.getAttributeCount(); i10++) {
                        newSerializer.attribute(xmlPullParser.getAttributeNamespace(i10), xmlPullParser.getAttributeName(i10), xmlPullParser.getAttributeValue(i10));
                    }
                    break;
                case 3:
                    newSerializer.endTag(xmlPullParser.getNamespace(), xmlPullParser.getName());
                    break;
                case 4:
                    newSerializer.text(xmlPullParser.getText());
                    break;
                case 5:
                    newSerializer.cdsect(xmlPullParser.getText());
                    break;
                case 6:
                    newSerializer.entityRef(xmlPullParser.getText());
                    break;
                case 7:
                    newSerializer.ignorableWhitespace(xmlPullParser.getText());
                    break;
                case 8:
                    newSerializer.processingInstruction(xmlPullParser.getText());
                    break;
                case 9:
                    newSerializer.comment(xmlPullParser.getText());
                    break;
                case 10:
                    newSerializer.docdecl(xmlPullParser.getText());
                    break;
            }
            xmlPullParser.nextToken();
        }
        newSerializer.flush();
        return byteArrayOutputStream.toByteArray();
    }

    /* access modifiers changed from: protected */
    public f Q(XmlPullParser xmlPullParser) {
        long j10;
        ByteArrayOutputStream byteArrayOutputStream;
        ArrayList arrayList;
        XmlPullParser xmlPullParser2 = xmlPullParser;
        String r02 = r0(xmlPullParser2, "schemeIdUri", "");
        String r03 = r0(xmlPullParser2, "value", "");
        long X = X(xmlPullParser2, "timescale", 1);
        long X2 = X(xmlPullParser2, "presentationTimeOffset", 0);
        ArrayList arrayList2 = new ArrayList();
        ByteArrayOutputStream byteArrayOutputStream2 = new ByteArrayOutputStream(AdRequest.MAX_CONTENT_URL_LENGTH);
        while (true) {
            xmlPullParser.next();
            if (d1.f(xmlPullParser2, "Event")) {
                byteArrayOutputStream = byteArrayOutputStream2;
                long j11 = X2;
                j10 = X2;
                arrayList = arrayList2;
                arrayList.add(O(xmlPullParser, r02, r03, X, j11, byteArrayOutputStream));
            } else {
                byteArrayOutputStream = byteArrayOutputStream2;
                j10 = X2;
                arrayList = arrayList2;
                w(xmlPullParser);
            }
            if (d1.d(xmlPullParser2, "EventStream")) {
                break;
            }
            arrayList2 = arrayList;
            byteArrayOutputStream2 = byteArrayOutputStream;
            X2 = j10;
        }
        long[] jArr = new long[arrayList.size()];
        m2.a[] aVarArr = new m2.a[arrayList.size()];
        for (int i10 = 0; i10 < arrayList.size(); i10++) {
            Pair pair = (Pair) arrayList.get(i10);
            jArr[i10] = ((Long) pair.first).longValue();
            aVarArr[i10] = (m2.a) pair.second;
        }
        return e(r02, r03, X, jArr, aVarArr);
    }

    /* access modifiers changed from: protected */
    public i T(XmlPullParser xmlPullParser) {
        return d0(xmlPullParser, "sourceURL", "range");
    }

    /* access modifiers changed from: protected */
    public d0 V(XmlPullParser xmlPullParser) {
        return new d0(xmlPullParser.getAttributeValue((String) null, "lang"), s0(xmlPullParser, "Label"));
    }

    /* access modifiers changed from: protected */
    /* JADX WARNING: Removed duplicated region for block: B:75:0x01bf  */
    /* JADX WARNING: Removed duplicated region for block: B:77:0x01df  */
    /* JADX WARNING: Removed duplicated region for block: B:79:0x01e6 A[LOOP:0: B:23:0x00a4->B:79:0x01e6, LOOP_END] */
    /* JADX WARNING: Removed duplicated region for block: B:81:0x01a2 A[SYNTHETIC] */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public j1.c Y(org.xmlpull.v1.XmlPullParser r47, android.net.Uri r48) {
        /*
            r46 = this;
            r14 = r46
            r12 = r47
            r0 = 0
            java.lang.String[] r1 = new java.lang.String[r0]
            java.lang.String r2 = "profiles"
            java.lang.String[] r1 = r14.b0(r12, r2, r1)
            boolean r13 = r14.v(r1)
            java.lang.String r1 = "availabilityStartTime"
            r9 = -9223372036854775807(0x8000000000000001, double:-4.9E-324)
            long r15 = H(r12, r1, r9)
            java.lang.String r1 = "mediaPresentationDuration"
            long r17 = M(r12, r1, r9)
            java.lang.String r1 = "minBufferTime"
            long r19 = M(r12, r1, r9)
            java.lang.String r1 = "type"
            r11 = 0
            java.lang.String r1 = r12.getAttributeValue(r11, r1)
            java.lang.String r2 = "dynamic"
            boolean r21 = r2.equals(r1)
            if (r21 == 0) goto L_0x0040
            java.lang.String r1 = "minimumUpdatePeriod"
            long r1 = M(r12, r1, r9)
            r22 = r1
            goto L_0x0042
        L_0x0040:
            r22 = r9
        L_0x0042:
            if (r21 == 0) goto L_0x004d
            java.lang.String r1 = "timeShiftBufferDepth"
            long r1 = M(r12, r1, r9)
            r24 = r1
            goto L_0x004f
        L_0x004d:
            r24 = r9
        L_0x004f:
            if (r21 == 0) goto L_0x005a
            java.lang.String r1 = "suggestedPresentationDelay"
            long r1 = M(r12, r1, r9)
            r26 = r1
            goto L_0x005c
        L_0x005a:
            r26 = r9
        L_0x005c:
            java.lang.String r1 = "publishTime"
            long r28 = H(r12, r1, r9)
            if (r21 == 0) goto L_0x0067
            r3 = 0
            goto L_0x0068
        L_0x0067:
            r3 = r9
        L_0x0068:
            j1.b r5 = new j1.b
            java.lang.String r6 = r48.toString()
            java.lang.String r7 = r48.toString()
            r8 = 1
            if (r13 == 0) goto L_0x0077
            r1 = 1
            goto L_0x007b
        L_0x0077:
            r30 = -2147483648(0xffffffff80000000, float:-0.0)
            r1 = -2147483648(0xffffffff80000000, float:-0.0)
        L_0x007b:
            r5.<init>(r6, r7, r1, r8)
            j1.b[] r1 = new j1.b[r8]
            r1[r0] = r5
            java.util.ArrayList r7 = com.google.common.collect.g0.j(r1)
            java.util.ArrayList r5 = new java.util.ArrayList
            r5.<init>()
            java.util.ArrayList r6 = new java.util.ArrayList
            r6.<init>()
            if (r21 == 0) goto L_0x0094
            r1 = r9
            goto L_0x0096
        L_0x0094:
            r1 = 0
        L_0x0096:
            r32 = r1
            r34 = r11
            r35 = r34
            r36 = r35
            r37 = r36
            r30 = 0
            r31 = 0
        L_0x00a4:
            r47.next()
            java.lang.String r0 = "BaseURL"
            boolean r0 = androidx.media3.common.util.d1.f(r12, r0)
            if (r0 == 0) goto L_0x00bf
            if (r30 != 0) goto L_0x00b7
            long r3 = r14.B(r12, r3)
            r30 = 1
        L_0x00b7:
            java.util.List r0 = r14.C(r12, r7, r13)
            r6.addAll(r0)
            goto L_0x00cd
        L_0x00bf:
            java.lang.String r0 = "ProgramInformation"
            boolean r0 = androidx.media3.common.util.d1.f(r12, r0)
            if (r0 == 0) goto L_0x00d9
            j1.h r0 = r46.c0(r47)
            r34 = r0
        L_0x00cd:
            r41 = r6
            r43 = r7
            r44 = r9
            r14 = r11
            r42 = 1
            r11 = r5
            goto L_0x019a
        L_0x00d9:
            java.lang.String r0 = "UTCTiming"
            boolean r0 = androidx.media3.common.util.d1.f(r12, r0)
            if (r0 == 0) goto L_0x00e8
            j1.o r0 = r46.w0(r47)
            r35 = r0
            goto L_0x00cd
        L_0x00e8:
            java.lang.String r0 = "Location"
            boolean r0 = androidx.media3.common.util.d1.f(r12, r0)
            if (r0 == 0) goto L_0x00ff
            java.lang.String r0 = r48.toString()
            java.lang.String r1 = r47.nextText()
            android.net.Uri r0 = androidx.media3.common.util.n0.f(r0, r1)
            r36 = r0
            goto L_0x00cd
        L_0x00ff:
            java.lang.String r0 = "ServiceDescription"
            boolean r0 = androidx.media3.common.util.d1.f(r12, r0)
            if (r0 == 0) goto L_0x010e
            j1.l r0 = r46.q0(r47)
            r37 = r0
            goto L_0x00cd
        L_0x010e:
            java.lang.String r0 = "Period"
            boolean r0 = androidx.media3.common.util.d1.f(r12, r0)
            if (r0 == 0) goto L_0x0189
            if (r31 != 0) goto L_0x0189
            boolean r0 = r6.isEmpty()
            if (r0 != 0) goto L_0x0120
            r2 = r6
            goto L_0x0121
        L_0x0120:
            r2 = r7
        L_0x0121:
            r0 = r46
            r1 = r47
            r38 = r3
            r3 = r32
            r40 = r5
            r41 = r6
            r5 = r38
            r43 = r7
            r42 = 1
            r7 = r15
            r44 = r9
            r9 = r24
            r14 = r11
            r11 = r13
            android.util.Pair r0 = r0.a0(r1, r2, r3, r5, r7, r9, r11)
            java.lang.Object r1 = r0.first
            j1.g r1 = (j1.g) r1
            long r2 = r1.f14656b
            int r4 = (r2 > r44 ? 1 : (r2 == r44 ? 0 : -1))
            if (r4 != 0) goto L_0x0168
            if (r21 == 0) goto L_0x014e
            r11 = r40
            r8 = 1
            goto L_0x0186
        L_0x014e:
            java.lang.StringBuilder r0 = new java.lang.StringBuilder
            r0.<init>()
            java.lang.String r1 = "Unable to determine start of period "
            r0.append(r1)
            int r1 = r40.size()
            r0.append(r1)
            java.lang.String r0 = r0.toString()
            y0.o0 r0 = y0.o0.c(r0, r14)
            throw r0
        L_0x0168:
            java.lang.Object r0 = r0.second
            java.lang.Long r0 = (java.lang.Long) r0
            long r2 = r0.longValue()
            int r0 = (r2 > r44 ? 1 : (r2 == r44 ? 0 : -1))
            if (r0 != 0) goto L_0x0179
            r11 = r40
            r9 = r44
            goto L_0x017f
        L_0x0179:
            long r4 = r1.f14656b
            long r9 = r4 + r2
            r11 = r40
        L_0x017f:
            r11.add(r1)
            r32 = r9
            r8 = r31
        L_0x0186:
            r31 = r8
            goto L_0x0198
        L_0x0189:
            r38 = r3
            r41 = r6
            r43 = r7
            r44 = r9
            r14 = r11
            r42 = 1
            r11 = r5
            w(r47)
        L_0x0198:
            r3 = r38
        L_0x019a:
            java.lang.String r0 = "MPD"
            boolean r0 = androidx.media3.common.util.d1.d(r12, r0)
            if (r0 == 0) goto L_0x01e6
            int r0 = (r17 > r44 ? 1 : (r17 == r44 ? 0 : -1))
            if (r0 != 0) goto L_0x01b7
            int r0 = (r32 > r44 ? 1 : (r32 == r44 ? 0 : -1))
            if (r0 == 0) goto L_0x01ad
            r3 = r32
            goto L_0x01b9
        L_0x01ad:
            if (r21 == 0) goto L_0x01b0
            goto L_0x01b7
        L_0x01b0:
            java.lang.String r0 = "Unable to determine duration of static manifest."
            y0.o0 r0 = y0.o0.c(r0, r14)
            throw r0
        L_0x01b7:
            r3 = r17
        L_0x01b9:
            boolean r0 = r11.isEmpty()
            if (r0 != 0) goto L_0x01df
            r0 = r46
            r1 = r15
            r5 = r19
            r7 = r21
            r8 = r22
            r38 = r11
            r10 = r24
            r12 = r26
            r14 = r28
            r16 = r34
            r17 = r35
            r18 = r37
            r19 = r36
            r20 = r38
            j1.c r0 = r0.g(r1, r3, r5, r7, r8, r10, r12, r14, r16, r17, r18, r19, r20)
            return r0
        L_0x01df:
            java.lang.String r0 = "No periods found."
            y0.o0 r0 = y0.o0.c(r0, r14)
            throw r0
        L_0x01e6:
            r5 = r11
            r11 = r14
            r6 = r41
            r7 = r43
            r9 = r44
            r8 = 1
            r14 = r46
            goto L_0x00a4
        */
        throw new UnsupportedOperationException("Method not decompiled: j1.d.Y(org.xmlpull.v1.XmlPullParser, android.net.Uri):j1.c");
    }

    /* access modifiers changed from: protected */
    public Pair a0(XmlPullParser xmlPullParser, List list, long j10, long j11, long j12, long j13, boolean z10) {
        long j14;
        long j15;
        ArrayList arrayList;
        Object obj;
        ArrayList arrayList2;
        ArrayList arrayList3;
        long j16;
        long j17;
        k l02;
        ArrayList arrayList4;
        d dVar = this;
        XmlPullParser xmlPullParser2 = xmlPullParser;
        Object obj2 = null;
        String attributeValue = xmlPullParser2.getAttributeValue((String) null, "id");
        long M = M(xmlPullParser2, "start", j10);
        long j18 = -9223372036854775807L;
        if (j12 != -9223372036854775807L) {
            j14 = j12 + M;
        } else {
            j14 = -9223372036854775807L;
        }
        long M2 = M(xmlPullParser2, "duration", -9223372036854775807L);
        ArrayList arrayList5 = new ArrayList();
        ArrayList arrayList6 = new ArrayList();
        ArrayList arrayList7 = new ArrayList();
        long j19 = j11;
        long j20 = -9223372036854775807L;
        k kVar = null;
        e eVar = null;
        boolean z11 = false;
        while (true) {
            xmlPullParser.next();
            if (d1.f(xmlPullParser2, "BaseURL")) {
                if (!z11) {
                    j19 = dVar.B(xmlPullParser2, j19);
                    z11 = true;
                }
                arrayList7.addAll(dVar.C(xmlPullParser2, list, z10));
                arrayList = arrayList6;
                arrayList2 = arrayList7;
                j15 = j18;
                obj = obj2;
                arrayList3 = arrayList5;
            } else {
                List list2 = list;
                boolean z12 = z10;
                if (d1.f(xmlPullParser2, "AdaptationSet")) {
                    if (!arrayList7.isEmpty()) {
                        arrayList4 = arrayList7;
                    } else {
                        arrayList4 = list2;
                    }
                    j16 = j19;
                    arrayList2 = arrayList7;
                    arrayList3 = arrayList5;
                    arrayList3.add(y(xmlPullParser, arrayList4, kVar, M2, j19, j20, j14, j13, z10));
                    xmlPullParser2 = xmlPullParser;
                    arrayList = arrayList6;
                } else {
                    j16 = j19;
                    ArrayList arrayList8 = arrayList6;
                    arrayList2 = arrayList7;
                    arrayList3 = arrayList5;
                    xmlPullParser2 = xmlPullParser;
                    if (d1.f(xmlPullParser2, "EventStream")) {
                        ArrayList arrayList9 = arrayList8;
                        arrayList9.add(Q(xmlPullParser));
                        arrayList = arrayList9;
                    } else {
                        ArrayList arrayList10 = arrayList8;
                        if (d1.f(xmlPullParser2, "SegmentBase")) {
                            arrayList = arrayList10;
                            kVar = j0(xmlPullParser2, (k.e) null);
                            obj = null;
                            j19 = j16;
                            j15 = -9223372036854775807L;
                        } else {
                            arrayList = arrayList10;
                            if (d1.f(xmlPullParser2, "SegmentList")) {
                                long B = B(xmlPullParser2, -9223372036854775807L);
                                obj = null;
                                l02 = k0(xmlPullParser, (k.b) null, j14, M2, j16, B, j13);
                                j20 = B;
                                j19 = j16;
                                j15 = -9223372036854775807L;
                            } else {
                                obj = null;
                                if (d1.f(xmlPullParser2, "SegmentTemplate")) {
                                    long B2 = B(xmlPullParser2, -9223372036854775807L);
                                    j15 = -9223372036854775807L;
                                    l02 = l0(xmlPullParser, (k.c) null, com.google.common.collect.y.C(), j14, M2, j16, B2, j13);
                                    j20 = B2;
                                    j19 = j16;
                                } else {
                                    j17 = -9223372036854775807L;
                                    if (d1.f(xmlPullParser2, "AssetIdentifier")) {
                                        eVar = I(xmlPullParser2, "AssetIdentifier");
                                    } else {
                                        w(xmlPullParser);
                                    }
                                    j19 = j16;
                                }
                            }
                            kVar = l02;
                        }
                    }
                }
                obj = null;
                j17 = -9223372036854775807L;
                j19 = j16;
            }
            if (d1.d(xmlPullParser2, "Period")) {
                return Pair.create(h(attributeValue, M, arrayList3, arrayList, eVar), Long.valueOf(M2));
            }
            arrayList5 = arrayList3;
            arrayList7 = arrayList2;
            obj2 = obj;
            arrayList6 = arrayList;
            j18 = j15;
            dVar = this;
        }
    }

    /* access modifiers changed from: protected */
    public String[] b0(XmlPullParser xmlPullParser, String str, String[] strArr) {
        String attributeValue = xmlPullParser.getAttributeValue((String) null, str);
        if (attributeValue == null) {
            return strArr;
        }
        return attributeValue.split(",");
    }

    /* access modifiers changed from: protected */
    public a c(long j10, int i10, List list, List list2, List list3, List list4) {
        return new a(j10, i10, list, list2, list3, list4);
    }

    /* access modifiers changed from: protected */
    public h c0(XmlPullParser xmlPullParser) {
        String str = null;
        String r02 = r0(xmlPullParser, "moreInformationURL", (String) null);
        String r03 = r0(xmlPullParser, "lang", (String) null);
        String str2 = null;
        String str3 = null;
        while (true) {
            xmlPullParser.next();
            if (d1.f(xmlPullParser, "Title")) {
                str = xmlPullParser.nextText();
            } else if (d1.f(xmlPullParser, "Source")) {
                str2 = xmlPullParser.nextText();
            } else if (d1.f(xmlPullParser, "Copyright")) {
                str3 = xmlPullParser.nextText();
            } else {
                w(xmlPullParser);
            }
            String str4 = str3;
            if (d1.d(xmlPullParser, "ProgramInformation")) {
                return new h(str, str2, str4, r02, r03);
            }
            str3 = str4;
        }
    }

    /* access modifiers changed from: protected */
    public m2.a d(String str, String str2, long j10, long j11, byte[] bArr) {
        return new m2.a(str, str2, j11, j10, bArr);
    }

    /* access modifiers changed from: protected */
    public i d0(XmlPullParser xmlPullParser, String str, String str2) {
        long j10;
        long j11;
        String attributeValue = xmlPullParser.getAttributeValue((String) null, str);
        String attributeValue2 = xmlPullParser.getAttributeValue((String) null, str2);
        if (attributeValue2 != null) {
            String[] split = attributeValue2.split("-");
            j11 = Long.parseLong(split[0]);
            if (split.length == 2) {
                j10 = (Long.parseLong(split[1]) - j11) + 1;
                return i(attributeValue, j11, j10);
            }
        } else {
            j11 = 0;
        }
        j10 = -1;
        return i(attributeValue, j11, j10);
    }

    /* access modifiers changed from: protected */
    public f e(String str, String str2, long j10, long[] jArr, m2.a[] aVarArr) {
        return new f(str, str2, j10, jArr, aVarArr);
    }

    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r31v0, resolved type: java.util.ArrayList} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r24v4, resolved type: j1.k$e} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r31v3, resolved type: java.util.ArrayList} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r31v4, resolved type: java.util.ArrayList} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r31v5, resolved type: java.util.ArrayList} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r31v6, resolved type: java.util.ArrayList} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r31v7, resolved type: java.util.ArrayList} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r31v8, resolved type: java.util.ArrayList} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r31v9, resolved type: java.util.ArrayList} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r31v10, resolved type: java.util.ArrayList} */
    /* JADX WARNING: type inference failed for: r31v1 */
    /* JADX WARNING: type inference failed for: r31v2 */
    /* access modifiers changed from: protected */
    /* JADX WARNING: Multi-variable type inference failed */
    /* JADX WARNING: Removed duplicated region for block: B:53:0x01ee A[LOOP:0: B:1:0x006a->B:53:0x01ee, LOOP_END] */
    /* JADX WARNING: Removed duplicated region for block: B:54:0x0198 A[EDGE_INSN: B:54:0x0198->B:45:0x0198 ?: BREAK  , SYNTHETIC] */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public j1.d.a e0(org.xmlpull.v1.XmlPullParser r36, java.util.List r37, java.lang.String r38, java.lang.String r39, int r40, int r41, float r42, int r43, int r44, java.lang.String r45, java.util.List r46, java.util.List r47, java.util.List r48, java.util.List r49, j1.k r50, long r51, long r53, long r55, long r57, long r59, boolean r61) {
        /*
            r35 = this;
            r15 = r35
            r14 = r36
            java.lang.String r0 = "id"
            r1 = 0
            java.lang.String r16 = r14.getAttributeValue(r1, r0)
            java.lang.String r0 = "bandwidth"
            r2 = -1
            int r17 = U(r14, r0, r2)
            java.lang.String r0 = "mimeType"
            r2 = r38
            java.lang.String r18 = r0(r14, r0, r2)
            java.lang.String r0 = "codecs"
            r2 = r39
            java.lang.String r19 = r0(r14, r0, r2)
            java.lang.String r0 = "width"
            r2 = r40
            int r20 = U(r14, r0, r2)
            java.lang.String r0 = "height"
            r2 = r41
            int r21 = U(r14, r0, r2)
            r0 = r42
            float r22 = S(r14, r0)
            java.lang.String r0 = "audioSamplingRate"
            r2 = r44
            int r23 = U(r14, r0, r2)
            java.util.ArrayList r13 = new java.util.ArrayList
            r13.<init>()
            java.util.ArrayList r11 = new java.util.ArrayList
            r11.<init>()
            java.util.ArrayList r12 = new java.util.ArrayList
            r0 = r48
            r12.<init>(r0)
            java.util.ArrayList r9 = new java.util.ArrayList
            r10 = r49
            r9.<init>(r10)
            java.util.ArrayList r7 = new java.util.ArrayList
            r7.<init>()
            r0 = 0
            r24 = r43
            r0 = r50
            r5 = r55
            r26 = r1
            r25 = 0
            r1 = r57
        L_0x006a:
            r36.next()
            java.lang.String r3 = "BaseURL"
            boolean r3 = androidx.media3.common.util.d1.f(r14, r3)
            if (r3 == 0) goto L_0x0090
            if (r25 != 0) goto L_0x007d
            long r5 = r15.B(r14, r5)
            r25 = 1
        L_0x007d:
            r8 = r37
            r3 = r61
            java.util.List r4 = r15.C(r14, r8, r3)
            r7.addAll(r4)
        L_0x0088:
            r31 = r7
            r15 = r13
            r7 = r24
            r24 = r0
            goto L_0x00a6
        L_0x0090:
            r8 = r37
            r3 = r61
            java.lang.String r4 = "AudioChannelConfiguration"
            boolean r4 = androidx.media3.common.util.d1.f(r14, r4)
            if (r4 == 0) goto L_0x00aa
            int r4 = r35.A(r36)
            r24 = r0
            r31 = r7
            r15 = r13
            r7 = r4
        L_0x00a6:
            r13 = r11
            r11 = r9
            goto L_0x0190
        L_0x00aa:
            java.lang.String r4 = "SegmentBase"
            boolean r4 = androidx.media3.common.util.d1.f(r14, r4)
            if (r4 == 0) goto L_0x00b9
            j1.k$e r0 = (j1.k.e) r0
            j1.k$e r0 = r15.j0(r14, r0)
            goto L_0x0088
        L_0x00b9:
            java.lang.String r4 = "SegmentList"
            boolean r4 = androidx.media3.common.util.d1.f(r14, r4)
            if (r4 == 0) goto L_0x00f5
            long r27 = r15.B(r14, r1)
            r2 = r0
            j1.k$b r2 = (j1.k.b) r2
            r0 = r35
            r1 = r36
            r3 = r51
            r29 = r5
            r5 = r53
            r31 = r7
            r7 = r29
            r32 = r9
            r9 = r27
            r33 = r11
            r34 = r12
            r11 = r59
            j1.k$b r0 = r0.k0(r1, r2, r3, r5, r7, r9, r11)
            r15 = r13
        L_0x00e5:
            r7 = r24
            r1 = r27
        L_0x00e9:
            r5 = r29
            r11 = r32
            r13 = r33
            r12 = r34
        L_0x00f1:
            r24 = r0
            goto L_0x0190
        L_0x00f5:
            r29 = r5
            r31 = r7
            r32 = r9
            r33 = r11
            r34 = r12
            java.lang.String r3 = "SegmentTemplate"
            boolean r3 = androidx.media3.common.util.d1.f(r14, r3)
            if (r3 == 0) goto L_0x0124
            long r27 = r15.B(r14, r1)
            r2 = r0
            j1.k$c r2 = (j1.k.c) r2
            r0 = r35
            r1 = r36
            r3 = r49
            r4 = r51
            r6 = r53
            r8 = r29
            r10 = r27
            r15 = r13
            r12 = r59
            j1.k$c r0 = r0.l0(r1, r2, r3, r4, r6, r8, r10, r12)
            goto L_0x00e5
        L_0x0124:
            r15 = r13
            java.lang.String r3 = "ContentProtection"
            boolean r3 = androidx.media3.common.util.d1.f(r14, r3)
            if (r3 == 0) goto L_0x0145
            android.util.Pair r3 = r35.F(r36)
            java.lang.Object r4 = r3.first
            if (r4 == 0) goto L_0x0139
            r26 = r4
            java.lang.String r26 = (java.lang.String) r26
        L_0x0139:
            java.lang.Object r3 = r3.second
            if (r3 == 0) goto L_0x0142
            y0.r$b r3 = (y0.r.b) r3
            r15.add(r3)
        L_0x0142:
            r7 = r24
            goto L_0x00e9
        L_0x0145:
            java.lang.String r3 = "InbandEventStream"
            boolean r4 = androidx.media3.common.util.d1.f(r14, r3)
            if (r4 == 0) goto L_0x015b
            j1.e r3 = I(r14, r3)
            r13 = r33
            r13.add(r3)
            r11 = r32
            r12 = r34
            goto L_0x018a
        L_0x015b:
            r13 = r33
            java.lang.String r3 = "EssentialProperty"
            boolean r4 = androidx.media3.common.util.d1.f(r14, r3)
            if (r4 == 0) goto L_0x0171
            j1.e r3 = I(r14, r3)
            r12 = r34
            r12.add(r3)
            r11 = r32
            goto L_0x018a
        L_0x0171:
            r12 = r34
            java.lang.String r3 = "SupplementalProperty"
            boolean r4 = androidx.media3.common.util.d1.f(r14, r3)
            if (r4 == 0) goto L_0x0185
            j1.e r3 = I(r14, r3)
            r11 = r32
            r11.add(r3)
            goto L_0x018a
        L_0x0185:
            r11 = r32
            w(r36)
        L_0x018a:
            r7 = r24
            r5 = r29
            goto L_0x00f1
        L_0x0190:
            java.lang.String r0 = "Representation"
            boolean r0 = androidx.media3.common.util.d1.d(r14, r0)
            if (r0 == 0) goto L_0x01ee
            r0 = r35
            r1 = r16
            r2 = r18
            r3 = r20
            r4 = r21
            r5 = r22
            r6 = r7
            r7 = r23
            r8 = r17
            r9 = r45
            r10 = r46
            r27 = r11
            r11 = r47
            r28 = r12
            r12 = r19
            r29 = r13
            r13 = r28
            r14 = r27
            y0.y r0 = r0.f(r1, r2, r3, r4, r5, r6, r7, r8, r9, r10, r11, r12, r13, r14)
            if (r24 == 0) goto L_0x01c2
            goto L_0x01c9
        L_0x01c2:
            j1.k$e r1 = new j1.k$e
            r1.<init>()
            r24 = r1
        L_0x01c9:
            j1.d$a r1 = new j1.d$a
            boolean r2 = r31.isEmpty()
            if (r2 != 0) goto L_0x01d2
            goto L_0x01d4
        L_0x01d2:
            r31 = r37
        L_0x01d4:
            r2 = -1
            r36 = r1
            r37 = r0
            r38 = r31
            r39 = r24
            r40 = r26
            r41 = r15
            r42 = r29
            r43 = r28
            r44 = r27
            r45 = r2
            r36.<init>(r37, r38, r39, r40, r41, r42, r43, r44, r45)
            return r1
        L_0x01ee:
            r10 = r49
            r9 = r11
            r11 = r13
            r13 = r15
            r0 = r24
            r15 = r35
            r24 = r7
            r7 = r31
            goto L_0x006a
        */
        throw new UnsupportedOperationException("Method not decompiled: j1.d.e0(org.xmlpull.v1.XmlPullParser, java.util.List, java.lang.String, java.lang.String, int, int, float, int, int, java.lang.String, java.util.List, java.util.List, java.util.List, java.util.List, j1.k, long, long, long, long, long, boolean):j1.d$a");
    }

    /* access modifiers changed from: protected */
    public y f(String str, String str2, int i10, int i11, float f10, int i12, int i13, int i14, String str3, List list, List list2, String str4, List list3, List list4) {
        int i15;
        int i16;
        String str5 = str2;
        int i17 = i10;
        int i18 = i11;
        List list5 = list;
        List list6 = list3;
        String str6 = str4;
        String u10 = u(str2, str6);
        if ("audio/eac3".equals(u10)) {
            u10 = N(list4);
            if ("audio/eac3-joc".equals(u10)) {
                str6 = "ec+3";
            }
        }
        int p02 = p0(list5);
        int i02 = i0(list5) | f0(list2) | h0(list6) | h0(list4);
        Pair t02 = t0(list6);
        String str7 = str;
        y.b e02 = new y.b().a0(str).Q(str2).o0(u10).O(str6).j0(i14).q0(p02).m0(i02).e0(str3);
        int i19 = -1;
        if (t02 != null) {
            i15 = ((Integer) t02.first).intValue();
        } else {
            i15 = -1;
        }
        y.b t03 = e02.t0(i15);
        if (t02 != null) {
            i16 = ((Integer) t02.second).intValue();
        } else {
            i16 = -1;
        }
        y.b u02 = t03.u0(i16);
        if (n0.s(u10)) {
            u02.v0(i10).Y(i18).X(f10);
        } else if (n0.o(u10)) {
            u02.N(i12).p0(i13);
        } else if (n0.r(u10)) {
            if ("application/cea-608".equals(u10)) {
                i19 = D(list2);
            } else if ("application/cea-708".equals(u10)) {
                i19 = E(list2);
            }
            u02.L(i19);
        } else if (n0.p(u10)) {
            u02.v0(i10).Y(i18);
        }
        return u02.K();
    }

    /* access modifiers changed from: protected */
    public int f0(List list) {
        int u02;
        int i10 = 0;
        for (int i11 = 0; i11 < list.size(); i11++) {
            e eVar = (e) list.get(i11);
            if (b.a("urn:mpeg:dash:role:2011", eVar.f14647a)) {
                u02 = g0(eVar.f14648b);
            } else if (b.a("urn:tva:metadata:cs:AudioPurposeCS:2007", eVar.f14647a)) {
                u02 = u0(eVar.f14648b);
            }
            i10 |= u02;
        }
        return i10;
    }

    /* access modifiers changed from: protected */
    public c g(long j10, long j11, long j12, boolean z10, long j13, long j14, long j15, long j16, h hVar, o oVar, l lVar, Uri uri, List list) {
        return new c(j10, j11, j12, z10, j13, j14, j15, j16, hVar, oVar, lVar, uri, list);
    }

    /* access modifiers changed from: protected */
    public int g0(String str) {
        if (str == null) {
            return 0;
        }
        char c10 = 65535;
        switch (str.hashCode()) {
            case -2060497896:
                if (str.equals("subtitle")) {
                    c10 = 0;
                    break;
                }
                break;
            case -1724546052:
                if (str.equals("description")) {
                    c10 = 1;
                    break;
                }
                break;
            case -1580883024:
                if (str.equals("enhanced-audio-intelligibility")) {
                    c10 = 2;
                    break;
                }
                break;
            case -1574842690:
                if (str.equals("forced_subtitle")) {
                    c10 = 3;
                    break;
                }
                break;
            case -1408024454:
                if (str.equals("alternate")) {
                    c10 = 4;
                    break;
                }
                break;
            case -1396432756:
                if (str.equals("forced-subtitle")) {
                    c10 = 5;
                    break;
                }
                break;
            case 99825:
                if (str.equals("dub")) {
                    c10 = 6;
                    break;
                }
                break;
            case 3343801:
                if (str.equals("main")) {
                    c10 = 7;
                    break;
                }
                break;
            case 3530173:
                if (str.equals("sign")) {
                    c10 = 8;
                    break;
                }
                break;
            case 552573414:
                if (str.equals("caption")) {
                    c10 = 9;
                    break;
                }
                break;
            case 899152809:
                if (str.equals("commentary")) {
                    c10 = 10;
                    break;
                }
                break;
            case 1629013393:
                if (str.equals("emergency")) {
                    c10 = 11;
                    break;
                }
                break;
            case 1855372047:
                if (str.equals("supplementary")) {
                    c10 = 12;
                    break;
                }
                break;
        }
        switch (c10) {
            case 0:
            case 3:
            case 5:
                return 128;
            case 1:
                return AdRequest.MAX_CONTENT_URL_LENGTH;
            case 2:
                return 2048;
            case 4:
                return 2;
            case 6:
                return 16;
            case 7:
                return 1;
            case 8:
                return 256;
            case 9:
                return 64;
            case 10:
                return 8;
            case 11:
                return 32;
            case m.OVERFLOW_POLICY_FIELD_NUMBER /*12*/:
                return 4;
            default:
                return 0;
        }
    }

    /* access modifiers changed from: protected */
    public g h(String str, long j10, List list, List list2, e eVar) {
        return new g(str, j10, list, list2, eVar);
    }

    /* access modifiers changed from: protected */
    public int h0(List list) {
        int i10 = 0;
        for (int i11 = 0; i11 < list.size(); i11++) {
            if (b.a("http://dashif.org/guidelines/trickmode", ((e) list.get(i11)).f14647a)) {
                i10 |= Http2.INITIAL_MAX_FRAME_SIZE;
            }
        }
        return i10;
    }

    /* access modifiers changed from: protected */
    public i i(String str, long j10, long j11) {
        return new i(str, j10, j11);
    }

    /* access modifiers changed from: protected */
    public int i0(List list) {
        int i10 = 0;
        for (int i11 = 0; i11 < list.size(); i11++) {
            e eVar = (e) list.get(i11);
            if (b.a("urn:mpeg:dash:role:2011", eVar.f14647a)) {
                i10 |= g0(eVar.f14648b);
            }
        }
        return i10;
    }

    /* access modifiers changed from: protected */
    public j j(a aVar, String str, List list, String str2, ArrayList arrayList, ArrayList arrayList2) {
        a aVar2 = aVar;
        String str3 = str;
        y.b a10 = aVar2.f14638a.a();
        if (str3 == null || !list.isEmpty()) {
            a10.d0(list);
        } else {
            a10.c0(str3);
        }
        String str4 = aVar2.f14641d;
        if (str4 == null) {
            str4 = str2;
        }
        ArrayList arrayList3 = aVar2.f14642e;
        arrayList3.addAll(arrayList);
        if (!arrayList3.isEmpty()) {
            r(arrayList3);
            s(arrayList3);
            a10.U(new r(str4, (List) arrayList3));
        }
        ArrayList arrayList4 = aVar2.f14643f;
        arrayList4.addAll(arrayList2);
        return j.o(aVar2.f14644g, a10.K(), aVar2.f14639b, aVar2.f14640c, arrayList4, aVar2.f14645h, aVar2.f14646i, (String) null);
    }

    /* access modifiers changed from: protected */
    public k.e j0(XmlPullParser xmlPullParser, k.e eVar) {
        long j10;
        long j11;
        long j12;
        long j13;
        long j14;
        XmlPullParser xmlPullParser2 = xmlPullParser;
        k.e eVar2 = eVar;
        if (eVar2 != null) {
            j10 = eVar2.f14684b;
        } else {
            j10 = 1;
        }
        long X = X(xmlPullParser2, "timescale", j10);
        long j15 = 0;
        if (eVar2 != null) {
            j11 = eVar2.f14685c;
        } else {
            j11 = 0;
        }
        long X2 = X(xmlPullParser2, "presentationTimeOffset", j11);
        if (eVar2 != null) {
            j12 = eVar2.f14698d;
        } else {
            j12 = 0;
        }
        if (eVar2 != null) {
            j15 = eVar2.f14699e;
        }
        i iVar = null;
        String attributeValue = xmlPullParser2.getAttributeValue((String) null, "indexRange");
        if (attributeValue != null) {
            String[] split = attributeValue.split("-");
            j14 = Long.parseLong(split[0]);
            j13 = (Long.parseLong(split[1]) - j14) + 1;
        } else {
            j13 = j15;
            j14 = j12;
        }
        if (eVar2 != null) {
            iVar = eVar2.f14683a;
        }
        do {
            xmlPullParser.next();
            if (d1.f(xmlPullParser2, "Initialization")) {
                iVar = T(xmlPullParser);
            } else {
                w(xmlPullParser);
            }
        } while (!d1.d(xmlPullParser2, "SegmentBase"));
        return n(iVar, X, X2, j14, j13);
    }

    /* access modifiers changed from: protected */
    public k.b k(i iVar, long j10, long j11, long j12, long j13, List list, long j14, List list2, long j15, long j16) {
        return new k.b(iVar, j10, j11, j12, j13, list, j14, list2, b1.c1(j15), b1.c1(j16));
    }

    /* access modifiers changed from: protected */
    public k.b k0(XmlPullParser xmlPullParser, k.b bVar, long j10, long j11, long j12, long j13, long j14) {
        long j15;
        long j16;
        long j17;
        XmlPullParser xmlPullParser2 = xmlPullParser;
        k.b bVar2 = bVar;
        long j18 = 1;
        if (bVar2 != null) {
            j15 = bVar2.f14684b;
        } else {
            j15 = 1;
        }
        long X = X(xmlPullParser2, "timescale", j15);
        if (bVar2 != null) {
            j16 = bVar2.f14685c;
        } else {
            j16 = 0;
        }
        long X2 = X(xmlPullParser2, "presentationTimeOffset", j16);
        if (bVar2 != null) {
            j17 = bVar2.f14687e;
        } else {
            j17 = -9223372036854775807L;
        }
        long X3 = X(xmlPullParser2, "duration", j17);
        if (bVar2 != null) {
            j18 = bVar2.f14686d;
        }
        long X4 = X(xmlPullParser2, "startNumber", j18);
        long t10 = t(j12, j13);
        List list = null;
        List list2 = null;
        i iVar = null;
        do {
            xmlPullParser.next();
            if (d1.f(xmlPullParser2, "Initialization")) {
                iVar = T(xmlPullParser);
            } else if (d1.f(xmlPullParser2, "SegmentTimeline")) {
                list = m0(xmlPullParser, X, j11);
            } else if (d1.f(xmlPullParser2, "SegmentURL")) {
                if (list2 == null) {
                    list2 = new ArrayList();
                }
                list2.add(n0(xmlPullParser));
            } else {
                w(xmlPullParser);
            }
        } while (!d1.d(xmlPullParser2, "SegmentList"));
        if (bVar2 != null) {
            if (iVar == null) {
                iVar = bVar2.f14683a;
            }
            if (list == null) {
                list = bVar2.f14688f;
            }
            if (list2 == null) {
                list2 = bVar2.f14692j;
            }
        }
        return k(iVar, X, X2, X4, X3, list, t10, list2, j14, j10);
    }

    /* access modifiers changed from: protected */
    public k.c l(i iVar, long j10, long j11, long j12, long j13, long j14, List list, long j15, n nVar, n nVar2, long j16, long j17) {
        return new k.c(iVar, j10, j11, j12, j13, j14, list, j15, nVar, nVar2, b1.c1(j16), b1.c1(j17));
    }

    /* access modifiers changed from: protected */
    public k.c l0(XmlPullParser xmlPullParser, k.c cVar, List list, long j10, long j11, long j12, long j13, long j14) {
        long j15;
        long j16;
        long j17;
        n nVar;
        n nVar2;
        XmlPullParser xmlPullParser2 = xmlPullParser;
        k.c cVar2 = cVar;
        long j18 = 1;
        if (cVar2 != null) {
            j15 = cVar2.f14684b;
        } else {
            j15 = 1;
        }
        long X = X(xmlPullParser2, "timescale", j15);
        if (cVar2 != null) {
            j16 = cVar2.f14685c;
        } else {
            j16 = 0;
        }
        long X2 = X(xmlPullParser2, "presentationTimeOffset", j16);
        if (cVar2 != null) {
            j17 = cVar2.f14687e;
        } else {
            j17 = -9223372036854775807L;
        }
        long X3 = X(xmlPullParser2, "duration", j17);
        if (cVar2 != null) {
            j18 = cVar2.f14686d;
        }
        long X4 = X(xmlPullParser2, "startNumber", j18);
        long W = W(list);
        long t10 = t(j12, j13);
        List list2 = null;
        if (cVar2 != null) {
            nVar = cVar2.f14694k;
        } else {
            nVar = null;
        }
        n v02 = v0(xmlPullParser2, "media", nVar);
        if (cVar2 != null) {
            nVar2 = cVar2.f14693j;
        } else {
            nVar2 = null;
        }
        n v03 = v0(xmlPullParser2, "initialization", nVar2);
        i iVar = null;
        while (true) {
            xmlPullParser.next();
            if (d1.f(xmlPullParser2, "Initialization")) {
                iVar = T(xmlPullParser);
            } else if (d1.f(xmlPullParser2, "SegmentTimeline")) {
                list2 = m0(xmlPullParser, X, j11);
            } else {
                w(xmlPullParser);
            }
            if (d1.d(xmlPullParser2, "SegmentTemplate")) {
                break;
            }
        }
        if (cVar2 != null) {
            if (iVar == null) {
                iVar = cVar2.f14683a;
            }
            if (list2 == null) {
                list2 = cVar2.f14688f;
            }
        }
        return l(iVar, X, X2, X4, W, X3, list2, t10, v03, v02, j14, j10);
    }

    /* access modifiers changed from: protected */
    public k.d m(long j10, long j11) {
        return new k.d(j10, j11);
    }

    /* access modifiers changed from: protected */
    public List m0(XmlPullParser xmlPullParser, long j10, long j11) {
        XmlPullParser xmlPullParser2 = xmlPullParser;
        ArrayList arrayList = new ArrayList();
        long j12 = 0;
        long j13 = -9223372036854775807L;
        boolean z10 = false;
        int i10 = 0;
        do {
            xmlPullParser.next();
            if (d1.f(xmlPullParser2, "S")) {
                long X = X(xmlPullParser2, "t", -9223372036854775807L);
                if (z10) {
                    j12 = b(arrayList, j12, j13, i10, X);
                }
                if (X == -9223372036854775807L) {
                    X = j12;
                }
                j13 = X(xmlPullParser2, "d", -9223372036854775807L);
                i10 = U(xmlPullParser2, "r", 0);
                j12 = X;
                z10 = true;
            } else {
                w(xmlPullParser);
            }
        } while (!d1.d(xmlPullParser2, "SegmentTimeline"));
        if (z10) {
            b(arrayList, j12, j13, i10, b1.r1(j11, j10, 1000));
        }
        return arrayList;
    }

    /* access modifiers changed from: protected */
    public k.e n(i iVar, long j10, long j11, long j12, long j13) {
        return new k.e(iVar, j10, j11, j12, j13);
    }

    /* access modifiers changed from: protected */
    public i n0(XmlPullParser xmlPullParser) {
        return d0(xmlPullParser, "media", "mediaRange");
    }

    /* access modifiers changed from: protected */
    public o o(String str, String str2) {
        return new o(str, str2);
    }

    /* access modifiers changed from: protected */
    public int o0(String str) {
        if (str == null) {
            return 0;
        }
        if (str.equals("forced_subtitle") || str.equals("forced-subtitle")) {
            return 2;
        }
        return 0;
    }

    /* access modifiers changed from: protected */
    public int p0(List list) {
        int i10 = 0;
        for (int i11 = 0; i11 < list.size(); i11++) {
            e eVar = (e) list.get(i11);
            if (b.a("urn:mpeg:dash:role:2011", eVar.f14647a)) {
                i10 |= o0(eVar.f14648b);
            }
        }
        return i10;
    }

    /* access modifiers changed from: protected */
    public l q0(XmlPullParser xmlPullParser) {
        XmlPullParser xmlPullParser2 = xmlPullParser;
        long j10 = -9223372036854775807L;
        long j11 = -9223372036854775807L;
        long j12 = -9223372036854775807L;
        float f10 = -3.4028235E38f;
        float f11 = -3.4028235E38f;
        while (true) {
            xmlPullParser.next();
            if (d1.f(xmlPullParser2, "Latency")) {
                j10 = X(xmlPullParser2, "target", -9223372036854775807L);
                j11 = X(xmlPullParser2, "min", -9223372036854775807L);
                j12 = X(xmlPullParser2, "max", -9223372036854775807L);
            } else if (d1.f(xmlPullParser2, "PlaybackRate")) {
                f10 = R(xmlPullParser2, "min", -3.4028235E38f);
                f11 = R(xmlPullParser2, "max", -3.4028235E38f);
            }
            long j13 = j10;
            long j14 = j11;
            long j15 = j12;
            float f12 = f10;
            float f13 = f11;
            if (d1.d(xmlPullParser2, "ServiceDescription")) {
                return new l(j13, j14, j15, f12, f13);
            }
            j10 = j13;
            j11 = j14;
            j12 = j15;
            f10 = f12;
            f11 = f13;
        }
    }

    /* access modifiers changed from: protected */
    public Pair t0(List list) {
        String str;
        for (int i10 = 0; i10 < list.size(); i10++) {
            e eVar = (e) list.get(i10);
            if ((b.a("http://dashif.org/thumbnail_tile", eVar.f14647a) || b.a("http://dashif.org/guidelines/thumbnail_tile", eVar.f14647a)) && (str = eVar.f14648b) != null) {
                String[] C1 = b1.C1(str, "x");
                if (C1.length != 2) {
                    continue;
                } else {
                    try {
                        return Pair.create(Integer.valueOf(Integer.parseInt(C1[0])), Integer.valueOf(Integer.parseInt(C1[1])));
                    } catch (NumberFormatException unused) {
                    }
                }
            }
        }
        return null;
    }

    /* access modifiers changed from: protected */
    public int u0(String str) {
        if (str == null) {
            return 0;
        }
        char c10 = 65535;
        switch (str.hashCode()) {
            case 49:
                if (str.equals("1")) {
                    c10 = 0;
                    break;
                }
                break;
            case 50:
                if (str.equals("2")) {
                    c10 = 1;
                    break;
                }
                break;
            case 51:
                if (str.equals("3")) {
                    c10 = 2;
                    break;
                }
                break;
            case 52:
                if (str.equals("4")) {
                    c10 = 3;
                    break;
                }
                break;
            case 54:
                if (str.equals("6")) {
                    c10 = 4;
                    break;
                }
                break;
        }
        switch (c10) {
            case 0:
                return AdRequest.MAX_CONTENT_URL_LENGTH;
            case 1:
                return 2048;
            case 2:
                return 4;
            case 3:
                return 8;
            case 4:
                return 1;
            default:
                return 0;
        }
    }

    /* access modifiers changed from: protected */
    public n v0(XmlPullParser xmlPullParser, String str, n nVar) {
        String attributeValue = xmlPullParser.getAttributeValue((String) null, str);
        if (attributeValue != null) {
            return n.b(attributeValue);
        }
        return nVar;
    }

    /* access modifiers changed from: protected */
    public o w0(XmlPullParser xmlPullParser) {
        return o(xmlPullParser.getAttributeValue((String) null, "schemeIdUri"), xmlPullParser.getAttributeValue((String) null, "value"));
    }

    /* renamed from: x */
    public c a(Uri uri, InputStream inputStream) {
        try {
            XmlPullParser newPullParser = this.f14637a.newPullParser();
            newPullParser.setInput(inputStream, (String) null);
            if (newPullParser.next() == 2 && "MPD".equals(newPullParser.getName())) {
                return Y(newPullParser, uri);
            }
            throw o0.c("inputStream does not contain a valid media presentation description", (Throwable) null);
        } catch (XmlPullParserException e10) {
            throw o0.c((String) null, e10);
        }
    }

    /* access modifiers changed from: protected */
    /* JADX WARNING: Removed duplicated region for block: B:72:0x0352 A[LOOP:0: B:1:0x007f->B:72:0x0352, LOOP_END] */
    /* JADX WARNING: Removed duplicated region for block: B:73:0x0311 A[EDGE_INSN: B:73:0x0311->B:66:0x0311 ?: BREAK  , SYNTHETIC] */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public j1.a y(org.xmlpull.v1.XmlPullParser r57, java.util.List r58, j1.k r59, long r60, long r62, long r64, long r66, long r68, boolean r70) {
        /*
            r56 = this;
            r15 = r56
            r14 = r57
            java.lang.String r0 = "id"
            r1 = -1
            long r27 = X(r14, r0, r1)
            int r0 = r56.G(r57)
            java.lang.String r1 = "mimeType"
            r13 = 0
            java.lang.String r29 = r14.getAttributeValue(r13, r1)
            java.lang.String r1 = "codecs"
            java.lang.String r30 = r14.getAttributeValue(r13, r1)
            java.lang.String r1 = "width"
            r2 = -1
            int r31 = U(r14, r1, r2)
            java.lang.String r1 = "height"
            int r32 = U(r14, r1, r2)
            r1 = -1082130432(0xffffffffbf800000, float:-1.0)
            float r33 = S(r14, r1)
            java.lang.String r1 = "audioSamplingRate"
            int r34 = U(r14, r1, r2)
            java.lang.String r12 = "lang"
            java.lang.String r1 = r14.getAttributeValue(r13, r12)
            java.lang.String r3 = "label"
            java.lang.String r35 = r14.getAttributeValue(r13, r3)
            java.util.ArrayList r11 = new java.util.ArrayList
            r11.<init>()
            java.util.ArrayList r10 = new java.util.ArrayList
            r10.<init>()
            java.util.ArrayList r9 = new java.util.ArrayList
            r9.<init>()
            java.util.ArrayList r8 = new java.util.ArrayList
            r8.<init>()
            java.util.ArrayList r7 = new java.util.ArrayList
            r7.<init>()
            java.util.ArrayList r6 = new java.util.ArrayList
            r6.<init>()
            java.util.ArrayList r5 = new java.util.ArrayList
            r5.<init>()
            java.util.ArrayList r4 = new java.util.ArrayList
            r4.<init>()
            java.util.ArrayList r3 = new java.util.ArrayList
            r3.<init>()
            r36 = 0
            r37 = r59
            r38 = r1
            r41 = r13
            r39 = -1
            r40 = 0
            r1 = r62
            r62 = r64
        L_0x007f:
            r57.next()
            java.lang.String r13 = "BaseURL"
            boolean r13 = androidx.media3.common.util.d1.f(r14, r13)
            if (r13 == 0) goto L_0x00bd
            if (r40 != 0) goto L_0x0092
            long r1 = r15.B(r14, r1)
            r40 = 1
        L_0x0092:
            r13 = r58
            r64 = r1
            r17 = r11
            r11 = r70
            java.util.List r1 = r15.C(r14, r13, r11)
            r3.addAll(r1)
            r1 = r64
            r15 = r4
            r46 = r5
            r47 = r6
            r48 = r7
            r49 = r8
            r51 = r10
            r53 = r12
            r4 = r17
        L_0x00b2:
            r55 = r38
            r54 = 0
            r16 = r62
            r38 = r3
            r3 = r9
            goto L_0x0309
        L_0x00bd:
            r13 = r58
            r18 = r1
            r17 = r11
            r11 = r70
            java.lang.String r1 = "ContentProtection"
            boolean r1 = androidx.media3.common.util.d1.f(r14, r1)
            if (r1 == 0) goto L_0x00f4
            android.util.Pair r1 = r56.F(r57)
            java.lang.Object r2 = r1.first
            if (r2 == 0) goto L_0x00d9
            r41 = r2
            java.lang.String r41 = (java.lang.String) r41
        L_0x00d9:
            java.lang.Object r1 = r1.second
            if (r1 == 0) goto L_0x00e2
            y0.r$b r1 = (y0.r.b) r1
            r10.add(r1)
        L_0x00e2:
            r15 = r4
            r46 = r5
            r47 = r6
            r48 = r7
            r49 = r8
            r51 = r10
            r53 = r12
            r4 = r17
            r1 = r18
            goto L_0x00b2
        L_0x00f4:
            java.lang.String r1 = "ContentComponent"
            boolean r1 = androidx.media3.common.util.d1.f(r14, r1)
            if (r1 == 0) goto L_0x012b
            r2 = 0
            java.lang.String r1 = r14.getAttributeValue(r2, r12)
            r15 = r38
            java.lang.String r1 = q(r15, r1)
            int r15 = r56.G(r57)
            int r0 = p(r0, r15)
            r55 = r1
            r54 = r2
            r38 = r3
            r15 = r4
            r46 = r5
            r47 = r6
            r48 = r7
            r49 = r8
            r3 = r9
            r51 = r10
            r53 = r12
            r4 = r17
            r1 = r18
        L_0x0127:
            r16 = r62
            goto L_0x0309
        L_0x012b:
            r15 = r38
            r2 = 0
            java.lang.String r1 = "Role"
            boolean r16 = androidx.media3.common.util.d1.f(r14, r1)
            if (r16 == 0) goto L_0x015b
            j1.e r1 = I(r14, r1)
            r7.add(r1)
        L_0x013d:
            r44 = r0
            r54 = r2
            r38 = r3
            r46 = r5
            r47 = r6
            r48 = r7
            r49 = r8
            r3 = r9
            r51 = r10
            r53 = r12
            r55 = r15
            r42 = r18
            r0 = r62
            r15 = r4
            r4 = r17
            goto L_0x0303
        L_0x015b:
            java.lang.String r1 = "AudioChannelConfiguration"
            boolean r1 = androidx.media3.common.util.d1.f(r14, r1)
            if (r1 == 0) goto L_0x0182
            int r1 = r56.A(r57)
            r39 = r1
            r54 = r2
            r38 = r3
            r46 = r5
            r47 = r6
            r48 = r7
            r49 = r8
            r3 = r9
            r51 = r10
            r53 = r12
            r55 = r15
            r1 = r18
            r15 = r4
            r4 = r17
            goto L_0x0127
        L_0x0182:
            java.lang.String r1 = "Accessibility"
            boolean r16 = androidx.media3.common.util.d1.f(r14, r1)
            if (r16 == 0) goto L_0x0192
            j1.e r1 = I(r14, r1)
            r8.add(r1)
            goto L_0x013d
        L_0x0192:
            java.lang.String r1 = "EssentialProperty"
            boolean r16 = androidx.media3.common.util.d1.f(r14, r1)
            if (r16 == 0) goto L_0x01a2
            j1.e r1 = I(r14, r1)
            r6.add(r1)
            goto L_0x013d
        L_0x01a2:
            java.lang.String r1 = "SupplementalProperty"
            boolean r16 = androidx.media3.common.util.d1.f(r14, r1)
            if (r16 == 0) goto L_0x01b2
            j1.e r1 = I(r14, r1)
            r5.add(r1)
            goto L_0x013d
        L_0x01b2:
            java.lang.String r1 = "Representation"
            boolean r1 = androidx.media3.common.util.d1.f(r14, r1)
            if (r1 == 0) goto L_0x0230
            boolean r1 = r3.isEmpty()
            if (r1 != 0) goto L_0x01c4
            r1 = r0
            r16 = r3
            goto L_0x01c7
        L_0x01c4:
            r1 = r0
            r16 = r13
        L_0x01c7:
            r0 = r56
            r44 = r1
            r42 = r18
            r1 = r57
            r18 = r2
            r2 = r16
            r38 = r3
            r3 = r29
            r45 = r4
            r4 = r30
            r46 = r5
            r5 = r31
            r47 = r6
            r6 = r32
            r48 = r7
            r7 = r33
            r49 = r8
            r8 = r39
            r50 = r9
            r9 = r34
            r51 = r10
            r10 = r15
            r52 = r17
            r11 = r48
            r53 = r12
            r12 = r49
            r54 = r18
            r13 = r47
            r14 = r46
            r55 = r15
            r15 = r37
            r16 = r66
            r18 = r60
            r20 = r42
            r22 = r62
            r24 = r68
            r26 = r70
            j1.d$a r0 = r0.e0(r1, r2, r3, r4, r5, r6, r7, r8, r9, r10, r11, r12, r13, r14, r15, r16, r18, r20, r22, r24, r26)
            y0.y r1 = r0.f14638a
            java.lang.String r1 = r1.f20071n
            int r1 = y0.n0.k(r1)
            r14 = r44
            int r1 = p(r14, r1)
            r15 = r45
            r15.add(r0)
            r14 = r57
            r16 = r62
            r0 = r1
            r1 = r42
            goto L_0x029c
        L_0x0230:
            r14 = r0
            r54 = r2
            r38 = r3
            r46 = r5
            r47 = r6
            r48 = r7
            r49 = r8
            r50 = r9
            r51 = r10
            r53 = r12
            r55 = r15
            r52 = r17
            r42 = r18
            r15 = r4
            java.lang.String r0 = "SegmentBase"
            r13 = r57
            boolean r0 = androidx.media3.common.util.d1.f(r13, r0)
            if (r0 == 0) goto L_0x026c
            r0 = r37
            j1.k$e r0 = (j1.k.e) r0
            r11 = r56
            j1.k$e r0 = r11.j0(r13, r0)
            r16 = r62
            r37 = r0
            r0 = r14
            r1 = r42
            r3 = r50
            r4 = r52
            r14 = r13
            goto L_0x0309
        L_0x026c:
            r11 = r56
            java.lang.String r0 = "SegmentList"
            boolean r0 = androidx.media3.common.util.d1.f(r13, r0)
            if (r0 == 0) goto L_0x02a2
            r0 = r62
            long r16 = r11.B(r13, r0)
            r2 = r37
            j1.k$b r2 = (j1.k.b) r2
            r0 = r56
            r1 = r57
            r3 = r66
            r5 = r60
            r7 = r42
            r9 = r16
            r44 = r14
            r14 = r11
            r11 = r68
            j1.k$b r0 = r0.k0(r1, r2, r3, r5, r7, r9, r11)
            r37 = r0
            r14 = r13
        L_0x0298:
            r1 = r42
            r0 = r44
        L_0x029c:
            r3 = r50
            r4 = r52
            goto L_0x0309
        L_0x02a2:
            r0 = r62
            r44 = r14
            r14 = r11
            java.lang.String r2 = "SegmentTemplate"
            boolean r2 = androidx.media3.common.util.d1.f(r13, r2)
            if (r2 == 0) goto L_0x02cf
            long r16 = r14.B(r13, r0)
            r2 = r37
            j1.k$c r2 = (j1.k.c) r2
            r0 = r56
            r1 = r57
            r3 = r46
            r4 = r66
            r6 = r60
            r8 = r42
            r10 = r16
            r14 = r13
            r12 = r68
            j1.k$c r0 = r0.l0(r1, r2, r3, r4, r6, r8, r10, r12)
            r37 = r0
            goto L_0x0298
        L_0x02cf:
            r14 = r13
            java.lang.String r2 = "InbandEventStream"
            boolean r3 = androidx.media3.common.util.d1.f(r14, r2)
            if (r3 == 0) goto L_0x02e4
            j1.e r2 = I(r14, r2)
            r3 = r50
            r3.add(r2)
            r4 = r52
            goto L_0x0303
        L_0x02e4:
            r3 = r50
            java.lang.String r2 = "Label"
            boolean r2 = androidx.media3.common.util.d1.f(r14, r2)
            if (r2 == 0) goto L_0x02f8
            y0.d0 r2 = r56.V(r57)
            r4 = r52
            r4.add(r2)
            goto L_0x0303
        L_0x02f8:
            r4 = r52
            boolean r2 = androidx.media3.common.util.d1.e(r57)
            if (r2 == 0) goto L_0x0303
            r56.z(r57)
        L_0x0303:
            r16 = r0
            r1 = r42
            r0 = r44
        L_0x0309:
            java.lang.String r5 = "AdaptationSet"
            boolean r5 = androidx.media3.common.util.d1.d(r14, r5)
            if (r5 == 0) goto L_0x0352
            java.util.ArrayList r1 = new java.util.ArrayList
            int r2 = r15.size()
            r1.<init>(r2)
            r2 = 0
        L_0x031b:
            int r5 = r15.size()
            if (r2 >= r5) goto L_0x033f
            java.lang.Object r5 = r15.get(r2)
            j1.d$a r5 = (j1.d.a) r5
            r57 = r56
            r58 = r5
            r59 = r35
            r60 = r4
            r61 = r41
            r62 = r51
            r63 = r3
            j1.j r5 = r57.j(r58, r59, r60, r61, r62, r63)
            r1.add(r5)
            int r2 = r2 + 1
            goto L_0x031b
        L_0x033f:
            r57 = r56
            r58 = r27
            r60 = r0
            r61 = r1
            r62 = r49
            r63 = r47
            r64 = r46
            j1.a r0 = r57.c(r58, r60, r61, r62, r63, r64)
            return r0
        L_0x0352:
            r9 = r3
            r11 = r4
            r4 = r15
            r62 = r16
            r3 = r38
            r5 = r46
            r6 = r47
            r7 = r48
            r8 = r49
            r10 = r51
            r12 = r53
            r13 = r54
            r38 = r55
            r15 = r56
            goto L_0x007f
        */
        throw new UnsupportedOperationException("Method not decompiled: j1.d.y(org.xmlpull.v1.XmlPullParser, java.util.List, j1.k, long, long, long, long, long, boolean):j1.a");
    }

    /* access modifiers changed from: protected */
    public void z(XmlPullParser xmlPullParser) {
        w(xmlPullParser);
    }
}
