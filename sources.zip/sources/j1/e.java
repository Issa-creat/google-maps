package j1;

import androidx.media3.common.util.b1;

public final class e {

    /* renamed from: a  reason: collision with root package name */
    public final String f14647a;

    /* renamed from: b  reason: collision with root package name */
    public final String f14648b;

    /* renamed from: c  reason: collision with root package name */
    public final String f14649c;

    public e(String str, String str2, String str3) {
        this.f14647a = str;
        this.f14648b = str2;
        this.f14649c = str3;
    }

    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null || e.class != obj.getClass()) {
            return false;
        }
        e eVar = (e) obj;
        if (!b1.f(this.f14647a, eVar.f14647a) || !b1.f(this.f14648b, eVar.f14648b) || !b1.f(this.f14649c, eVar.f14649c)) {
            return false;
        }
        return true;
    }

    public int hashCode() {
        int i10;
        int hashCode = this.f14647a.hashCode() * 31;
        String str = this.f14648b;
        int i11 = 0;
        if (str != null) {
            i10 = str.hashCode();
        } else {
            i10 = 0;
        }
        int i12 = (hashCode + i10) * 31;
        String str2 = this.f14649c;
        if (str2 != null) {
            i11 = str2.hashCode();
        }
        return i12 + i11;
    }
}
