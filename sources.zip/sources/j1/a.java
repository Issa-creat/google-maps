package j1;

import java.util.Collections;
import java.util.List;

public class a {

    /* renamed from: a  reason: collision with root package name */
    public final long f14610a;

    /* renamed from: b  reason: collision with root package name */
    public final int f14611b;

    /* renamed from: c  reason: collision with root package name */
    public final List f14612c;

    /* renamed from: d  reason: collision with root package name */
    public final List f14613d;

    /* renamed from: e  reason: collision with root package name */
    public final List f14614e;

    /* renamed from: f  reason: collision with root package name */
    public final List f14615f;

    public a(long j10, int i10, List list, List list2, List list3, List list4) {
        this.f14610a = j10;
        this.f14611b = i10;
        this.f14612c = Collections.unmodifiableList(list);
        this.f14613d = Collections.unmodifiableList(list2);
        this.f14614e = Collections.unmodifiableList(list3);
        this.f14615f = Collections.unmodifiableList(list4);
    }
}
