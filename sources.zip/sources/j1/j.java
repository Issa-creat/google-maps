package j1;

import android.net.Uri;
import i1.f;
import j1.k;
import java.util.Collections;
import java.util.List;
import y0.y;

public abstract class j {

    /* renamed from: a  reason: collision with root package name */
    public final long f14669a;

    /* renamed from: b  reason: collision with root package name */
    public final y f14670b;

    /* renamed from: c  reason: collision with root package name */
    public final com.google.common.collect.y f14671c;

    /* renamed from: d  reason: collision with root package name */
    public final long f14672d;

    /* renamed from: e  reason: collision with root package name */
    public final List f14673e;

    /* renamed from: f  reason: collision with root package name */
    public final List f14674f;

    /* renamed from: g  reason: collision with root package name */
    public final List f14675g;

    /* renamed from: h  reason: collision with root package name */
    private final i f14676h;

    public static class b extends j implements f {

        /* renamed from: i  reason: collision with root package name */
        final k.a f14677i;

        public b(long j10, y yVar, List list, k.a aVar, List list2, List list3, List list4) {
            super(j10, yVar, list, aVar, list2, list3, list4);
            this.f14677i = aVar;
        }

        public long a(long j10) {
            return this.f14677i.j(j10);
        }

        public long b(long j10, long j11) {
            return this.f14677i.h(j10, j11);
        }

        public long c(long j10, long j11) {
            return this.f14677i.d(j10, j11);
        }

        public long d(long j10, long j11) {
            return this.f14677i.f(j10, j11);
        }

        public i e(long j10) {
            return this.f14677i.k(this, j10);
        }

        public long f(long j10, long j11) {
            return this.f14677i.i(j10, j11);
        }

        public boolean g() {
            return this.f14677i.l();
        }

        public long h() {
            return this.f14677i.e();
        }

        public long i(long j10) {
            return this.f14677i.g(j10);
        }

        public long j(long j10, long j11) {
            return this.f14677i.c(j10, j11);
        }

        public String k() {
            return null;
        }

        public f l() {
            return this;
        }

        public i m() {
            return null;
        }
    }

    public static class c extends j {

        /* renamed from: i  reason: collision with root package name */
        public final Uri f14678i;

        /* renamed from: j  reason: collision with root package name */
        public final long f14679j;

        /* renamed from: k  reason: collision with root package name */
        private final String f14680k;

        /* renamed from: l  reason: collision with root package name */
        private final i f14681l;

        /* renamed from: m  reason: collision with root package name */
        private final m f14682m;

        /* JADX INFO: super call moved to the top of the method (can break code semantics) */
        public c(long j10, y yVar, List list, k.e eVar, List list2, List list3, List list4, String str, long j11) {
            super(j10, yVar, list, eVar, list2, list3, list4);
            m mVar;
            List list5 = list;
            this.f14678i = Uri.parse(((b) list.get(0)).f14616a);
            i c10 = eVar.c();
            this.f14681l = c10;
            this.f14680k = str;
            this.f14679j = j11;
            if (c10 != null) {
                mVar = null;
            } else {
                mVar = new m(new i((String) null, 0, j11));
            }
            this.f14682m = mVar;
        }

        public String k() {
            return this.f14680k;
        }

        public f l() {
            return this.f14682m;
        }

        public i m() {
            return this.f14681l;
        }
    }

    public static j o(long j10, y yVar, List list, k kVar, List list2, List list3, List list4, String str) {
        k kVar2 = kVar;
        if (kVar2 instanceof k.e) {
            return new c(j10, yVar, list, (k.e) kVar2, list2, list3, list4, str, -1);
        } else if (kVar2 instanceof k.a) {
            return new b(j10, yVar, list, (k.a) kVar2, list2, list3, list4);
        } else {
            throw new IllegalArgumentException("segmentBase must be of type SingleSegmentBase or MultiSegmentBase");
        }
    }

    public abstract String k();

    public abstract f l();

    public abstract i m();

    public i n() {
        return this.f14676h;
    }

    private j(long j10, y yVar, List list, k kVar, List list2, List list3, List list4) {
        List list5;
        androidx.media3.common.util.a.a(!list.isEmpty());
        this.f14669a = j10;
        this.f14670b = yVar;
        this.f14671c = com.google.common.collect.y.w(list);
        if (list2 == null) {
            list5 = Collections.emptyList();
        } else {
            list5 = Collections.unmodifiableList(list2);
        }
        this.f14673e = list5;
        this.f14674f = list3;
        this.f14675g = list4;
        this.f14676h = kVar.a(this);
        this.f14672d = kVar.b();
    }
}
