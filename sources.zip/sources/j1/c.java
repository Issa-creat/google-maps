package j1;

import android.net.Uri;
import androidx.media3.common.util.b1;
import androidx.media3.exoplayer.offline.d;
import java.util.ArrayList;
import java.util.Collections;
import java.util.LinkedList;
import java.util.List;
import y0.y0;

public class c implements d {

    /* renamed from: a  reason: collision with root package name */
    public final long f14620a;

    /* renamed from: b  reason: collision with root package name */
    public final long f14621b;

    /* renamed from: c  reason: collision with root package name */
    public final long f14622c;

    /* renamed from: d  reason: collision with root package name */
    public final boolean f14623d;

    /* renamed from: e  reason: collision with root package name */
    public final long f14624e;

    /* renamed from: f  reason: collision with root package name */
    public final long f14625f;

    /* renamed from: g  reason: collision with root package name */
    public final long f14626g;

    /* renamed from: h  reason: collision with root package name */
    public final long f14627h;

    /* renamed from: i  reason: collision with root package name */
    public final o f14628i;

    /* renamed from: j  reason: collision with root package name */
    public final l f14629j;

    /* renamed from: k  reason: collision with root package name */
    public final Uri f14630k;

    /* renamed from: l  reason: collision with root package name */
    public final h f14631l;

    /* renamed from: m  reason: collision with root package name */
    private final List f14632m;

    public c(long j10, long j11, long j12, boolean z10, long j13, long j14, long j15, long j16, h hVar, o oVar, l lVar, Uri uri, List list) {
        List list2;
        this.f14620a = j10;
        this.f14621b = j11;
        this.f14622c = j12;
        this.f14623d = z10;
        this.f14624e = j13;
        this.f14625f = j14;
        this.f14626g = j15;
        this.f14627h = j16;
        this.f14631l = hVar;
        this.f14628i = oVar;
        this.f14630k = uri;
        this.f14629j = lVar;
        if (list == null) {
            list2 = Collections.emptyList();
        } else {
            list2 = list;
        }
        this.f14632m = list2;
    }

    private static ArrayList c(List list, LinkedList linkedList) {
        y0 y0Var = (y0) linkedList.poll();
        int i10 = y0Var.f20112a;
        ArrayList arrayList = new ArrayList();
        do {
            int i11 = y0Var.f20113w;
            a aVar = (a) list.get(i11);
            List list2 = aVar.f14612c;
            ArrayList arrayList2 = new ArrayList();
            do {
                arrayList2.add((j) list2.get(y0Var.f20114x));
                y0Var = (y0) linkedList.poll();
                if (!(y0Var.f20112a == i10 && y0Var.f20113w == i11)) {
                    arrayList.add(new a(aVar.f14610a, aVar.f14611b, arrayList2, aVar.f14613d, aVar.f14614e, aVar.f14615f));
                }
                arrayList2.add((j) list2.get(y0Var.f20114x));
                y0Var = (y0) linkedList.poll();
                break;
            } while (y0Var.f20113w == i11);
            arrayList.add(new a(aVar.f14610a, aVar.f14611b, arrayList2, aVar.f14613d, aVar.f14614e, aVar.f14615f));
        } while (y0Var.f20112a == i10);
        linkedList.addFirst(y0Var);
        return arrayList;
    }

    /* renamed from: b */
    public final c a(List list) {
        long j10;
        LinkedList linkedList = new LinkedList(list);
        Collections.sort(linkedList);
        linkedList.add(new y0(-1, -1, -1));
        ArrayList arrayList = new ArrayList();
        long j11 = 0;
        int i10 = 0;
        while (true) {
            j10 = -9223372036854775807L;
            if (i10 >= e()) {
                break;
            }
            if (((y0) linkedList.peek()).f20112a != i10) {
                long f10 = f(i10);
                if (f10 != -9223372036854775807L) {
                    j11 += f10;
                }
            } else {
                g d10 = d(i10);
                arrayList.add(new g(d10.f14655a, d10.f14656b - j11, c(d10.f14657c, linkedList), d10.f14658d));
            }
            i10++;
        }
        long j12 = this.f14621b;
        if (j12 != -9223372036854775807L) {
            j10 = j12 - j11;
        }
        return new c(this.f14620a, j10, this.f14622c, this.f14623d, this.f14624e, this.f14625f, this.f14626g, this.f14627h, this.f14631l, this.f14628i, this.f14629j, this.f14630k, arrayList);
    }

    public final g d(int i10) {
        return (g) this.f14632m.get(i10);
    }

    public final int e() {
        return this.f14632m.size();
    }

    public final long f(int i10) {
        long j10;
        long j11;
        if (i10 == this.f14632m.size() - 1) {
            j11 = this.f14621b;
            if (j11 == -9223372036854775807L) {
                return -9223372036854775807L;
            }
            j10 = ((g) this.f14632m.get(i10)).f14656b;
        } else {
            j11 = ((g) this.f14632m.get(i10 + 1)).f14656b;
            j10 = ((g) this.f14632m.get(i10)).f14656b;
        }
        return j11 - j10;
    }

    public final long g(int i10) {
        return b1.c1(f(i10));
    }
}
