package j1;

import android.net.Uri;
import androidx.media3.common.util.n0;

public final class i {

    /* renamed from: a  reason: collision with root package name */
    public final long f14665a;

    /* renamed from: b  reason: collision with root package name */
    public final long f14666b;

    /* renamed from: c  reason: collision with root package name */
    private final String f14667c;

    /* renamed from: d  reason: collision with root package name */
    private int f14668d;

    public i(String str, long j10, long j11) {
        this.f14667c = str == null ? "" : str;
        this.f14665a = j10;
        this.f14666b = j11;
    }

    public i a(i iVar, String str) {
        String c10 = c(str);
        if (iVar != null && c10.equals(iVar.c(str))) {
            long j10 = this.f14666b;
            long j11 = -1;
            if (j10 != -1) {
                long j12 = this.f14665a;
                if (j12 + j10 == iVar.f14665a) {
                    long j13 = iVar.f14666b;
                    if (j13 != -1) {
                        j11 = j10 + j13;
                    }
                    return new i(c10, j12, j11);
                }
            }
            long j14 = iVar.f14666b;
            if (j14 != -1) {
                long j15 = iVar.f14665a;
                if (j15 + j14 == this.f14665a) {
                    if (j10 != -1) {
                        j11 = j14 + j10;
                    }
                    return new i(c10, j15, j11);
                }
            }
        }
        return null;
    }

    public Uri b(String str) {
        return n0.f(str, this.f14667c);
    }

    public String c(String str) {
        return n0.e(str, this.f14667c);
    }

    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null || i.class != obj.getClass()) {
            return false;
        }
        i iVar = (i) obj;
        if (this.f14665a == iVar.f14665a && this.f14666b == iVar.f14666b && this.f14667c.equals(iVar.f14667c)) {
            return true;
        }
        return false;
    }

    public int hashCode() {
        if (this.f14668d == 0) {
            this.f14668d = ((((527 + ((int) this.f14665a)) * 31) + ((int) this.f14666b)) * 31) + this.f14667c.hashCode();
        }
        return this.f14668d;
    }

    public String toString() {
        return "RangedUri(referenceUri=" + this.f14667c + ", start=" + this.f14665a + ", length=" + this.f14666b + ")";
    }
}
