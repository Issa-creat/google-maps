package j1;

import androidx.media3.common.util.b1;

public final class h {

    /* renamed from: a  reason: collision with root package name */
    public final String f14660a;

    /* renamed from: b  reason: collision with root package name */
    public final String f14661b;

    /* renamed from: c  reason: collision with root package name */
    public final String f14662c;

    /* renamed from: d  reason: collision with root package name */
    public final String f14663d;

    /* renamed from: e  reason: collision with root package name */
    public final String f14664e;

    public h(String str, String str2, String str3, String str4, String str5) {
        this.f14660a = str;
        this.f14661b = str2;
        this.f14662c = str3;
        this.f14663d = str4;
        this.f14664e = str5;
    }

    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (!(obj instanceof h)) {
            return false;
        }
        h hVar = (h) obj;
        if (!b1.f(this.f14660a, hVar.f14660a) || !b1.f(this.f14661b, hVar.f14661b) || !b1.f(this.f14662c, hVar.f14662c) || !b1.f(this.f14663d, hVar.f14663d) || !b1.f(this.f14664e, hVar.f14664e)) {
            return false;
        }
        return true;
    }

    public int hashCode() {
        int i10;
        int i11;
        int i12;
        int i13;
        String str = this.f14660a;
        int i14 = 0;
        if (str != null) {
            i10 = str.hashCode();
        } else {
            i10 = 0;
        }
        int i15 = (527 + i10) * 31;
        String str2 = this.f14661b;
        if (str2 != null) {
            i11 = str2.hashCode();
        } else {
            i11 = 0;
        }
        int i16 = (i15 + i11) * 31;
        String str3 = this.f14662c;
        if (str3 != null) {
            i12 = str3.hashCode();
        } else {
            i12 = 0;
        }
        int i17 = (i16 + i12) * 31;
        String str4 = this.f14663d;
        if (str4 != null) {
            i13 = str4.hashCode();
        } else {
            i13 = 0;
        }
        int i18 = (i17 + i13) * 31;
        String str5 = this.f14664e;
        if (str5 != null) {
            i14 = str5.hashCode();
        }
        return i18 + i14;
    }
}
