package hb;

import jb.j;

public abstract class o {

    /* renamed from: a  reason: collision with root package name */
    protected j f13928a;

    public o(j jVar) {
        this.f13928a = jVar;
    }
}
