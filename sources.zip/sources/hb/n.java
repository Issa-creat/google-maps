package hb;

import ab.h;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.drawable.Drawable;
import bb.d;
import com.github.mikephil.charting.charts.RadarChart;
import jb.e;
import jb.i;
import jb.j;
import wa.a;
import za.a0;
import za.y;

public class n extends k {

    /* renamed from: i  reason: collision with root package name */
    protected RadarChart f13923i;

    /* renamed from: j  reason: collision with root package name */
    protected Paint f13924j;

    /* renamed from: k  reason: collision with root package name */
    protected Paint f13925k;

    /* renamed from: l  reason: collision with root package name */
    protected Path f13926l = new Path();

    /* renamed from: m  reason: collision with root package name */
    protected Path f13927m = new Path();

    public n(RadarChart radarChart, a aVar, j jVar) {
        super(aVar, jVar);
        this.f13923i = radarChart;
        Paint paint = new Paint(1);
        this.f13876d = paint;
        paint.setStyle(Paint.Style.STROKE);
        this.f13876d.setStrokeWidth(2.0f);
        this.f13876d.setColor(Color.rgb(255, 187, 115));
        Paint paint2 = new Paint(1);
        this.f13924j = paint2;
        paint2.setStyle(Paint.Style.STROKE);
        this.f13925k = new Paint(1);
    }

    public void b(Canvas canvas) {
        y yVar = (y) this.f13923i.getData();
        int I0 = ((db.j) yVar.l()).I0();
        for (db.j jVar : yVar.g()) {
            if (jVar.isVisible()) {
                n(canvas, jVar, I0);
            }
        }
    }

    public void c(Canvas canvas) {
        q(canvas);
    }

    public void d(Canvas canvas, d[] dVarArr) {
        int i10;
        d[] dVarArr2 = dVarArr;
        float sliceAngle = this.f13923i.getSliceAngle();
        float factor = this.f13923i.getFactor();
        e centerOffsets = this.f13923i.getCenterOffsets();
        e c10 = e.c(0.0f, 0.0f);
        y yVar = (y) this.f13923i.getData();
        int length = dVarArr2.length;
        int i11 = 0;
        int i12 = 0;
        while (i12 < length) {
            d dVar = dVarArr2[i12];
            db.j jVar = (db.j) yVar.e(dVar.d());
            if (jVar != null && jVar.M0()) {
                a0 a0Var = (a0) jVar.P((int) dVar.h());
                if (h(a0Var, jVar)) {
                    i.t(centerOffsets, (a0Var.c() - this.f13923i.getYChartMin()) * factor * this.f13874b.e(), (dVar.h() * sliceAngle * this.f13874b.d()) + this.f13923i.getRotationAngle(), c10);
                    dVar.m(c10.f14944x, c10.f14945y);
                    j(canvas, c10.f14944x, c10.f14945y, jVar);
                    if (jVar.v() && !Float.isNaN(c10.f14944x) && !Float.isNaN(c10.f14945y)) {
                        int p10 = jVar.p();
                        if (p10 == 1122867) {
                            p10 = jVar.V(i11);
                        }
                        if (jVar.k() < 255) {
                            p10 = jb.a.a(p10, jVar.k());
                        }
                        float i13 = jVar.i();
                        float E = jVar.E();
                        int g10 = jVar.g();
                        int i14 = g10;
                        i10 = i12;
                        o(canvas, c10, i13, E, i14, p10, jVar.a());
                        i12 = i10 + 1;
                        i11 = 0;
                    }
                }
            }
            i10 = i12;
            i12 = i10 + 1;
            i11 = 0;
        }
        e.h(centerOffsets);
        e.h(c10);
    }

    public void e(Canvas canvas) {
        float f10;
        int i10;
        float f11;
        int i11;
        int i12;
        a0 a0Var;
        h hVar;
        db.j jVar;
        e eVar;
        float d10 = this.f13874b.d();
        float e10 = this.f13874b.e();
        float sliceAngle = this.f13923i.getSliceAngle();
        float factor = this.f13923i.getFactor();
        e centerOffsets = this.f13923i.getCenterOffsets();
        e c10 = e.c(0.0f, 0.0f);
        e c11 = e.c(0.0f, 0.0f);
        float e11 = i.e(5.0f);
        int i13 = 0;
        while (i13 < ((y) this.f13923i.getData()).f()) {
            db.j jVar2 = (db.j) ((y) this.f13923i.getData()).e(i13);
            if (!i(jVar2)) {
                i10 = i13;
                f10 = d10;
            } else {
                a(jVar2);
                h L = jVar2.L();
                e d11 = e.d(jVar2.J0());
                d11.f14944x = i.e(d11.f14944x);
                d11.f14945y = i.e(d11.f14945y);
                int i14 = 0;
                while (i14 < jVar2.I0()) {
                    a0 a0Var2 = (a0) jVar2.P(i14);
                    e eVar2 = d11;
                    float f12 = ((float) i14) * sliceAngle * d10;
                    i.t(centerOffsets, (a0Var2.c() - this.f13923i.getYChartMin()) * factor * e10, f12 + this.f13923i.getRotationAngle(), c10);
                    if (jVar2.B0()) {
                        String i15 = L.i(a0Var2);
                        float f13 = c10.f14944x;
                        a0Var = a0Var2;
                        float f14 = c10.f14945y - e11;
                        int f02 = jVar2.f0(i14);
                        i11 = i14;
                        f11 = d10;
                        eVar = eVar2;
                        hVar = L;
                        float f15 = f13;
                        jVar = jVar2;
                        float f16 = f14;
                        i12 = i13;
                        p(canvas, i15, f15, f16, f02);
                    } else {
                        a0Var = a0Var2;
                        i11 = i14;
                        jVar = jVar2;
                        i12 = i13;
                        f11 = d10;
                        eVar = eVar2;
                        hVar = L;
                    }
                    if (a0Var.b() != null && jVar.x()) {
                        Drawable b10 = a0Var.b();
                        i.t(centerOffsets, (a0Var.c() * factor * e10) + eVar.f14945y, f12 + this.f13923i.getRotationAngle(), c11);
                        float f17 = c11.f14945y + eVar.f14944x;
                        c11.f14945y = f17;
                        i.f(canvas, b10, (int) c11.f14944x, (int) f17, b10.getIntrinsicWidth(), b10.getIntrinsicHeight());
                    }
                    i14 = i11 + 1;
                    d11 = eVar;
                    jVar2 = jVar;
                    L = hVar;
                    i13 = i12;
                    d10 = f11;
                }
                i10 = i13;
                f10 = d10;
                e.h(d11);
            }
            i13 = i10 + 1;
            d10 = f10;
        }
        e.h(centerOffsets);
        e.h(c10);
        e.h(c11);
    }

    public void f() {
    }

    /* access modifiers changed from: protected */
    public void n(Canvas canvas, db.j jVar, int i10) {
        float d10 = this.f13874b.d();
        float e10 = this.f13874b.e();
        float sliceAngle = this.f13923i.getSliceAngle();
        float factor = this.f13923i.getFactor();
        e centerOffsets = this.f13923i.getCenterOffsets();
        e c10 = e.c(0.0f, 0.0f);
        Path path = this.f13926l;
        path.reset();
        boolean z10 = false;
        for (int i11 = 0; i11 < jVar.I0(); i11++) {
            this.f13875c.setColor(jVar.V(i11));
            i.t(centerOffsets, (((a0) jVar.P(i11)).c() - this.f13923i.getYChartMin()) * factor * e10, (((float) i11) * sliceAngle * d10) + this.f13923i.getRotationAngle(), c10);
            if (!Float.isNaN(c10.f14944x)) {
                if (!z10) {
                    path.moveTo(c10.f14944x, c10.f14945y);
                    z10 = true;
                } else {
                    path.lineTo(c10.f14944x, c10.f14945y);
                }
            }
        }
        if (jVar.I0() > i10) {
            path.lineTo(centerOffsets.f14944x, centerOffsets.f14945y);
        }
        path.close();
        if (jVar.R()) {
            Drawable I = jVar.I();
            if (I != null) {
                m(canvas, path, I);
            } else {
                l(canvas, path, jVar.e(), jVar.j());
            }
        }
        this.f13875c.setStrokeWidth(jVar.q());
        this.f13875c.setStyle(Paint.Style.STROKE);
        if (!jVar.R() || jVar.j() < 255) {
            canvas.drawPath(path, this.f13875c);
        }
        e.h(centerOffsets);
        e.h(c10);
    }

    public void o(Canvas canvas, e eVar, float f10, float f11, int i10, int i11, float f12) {
        canvas.save();
        float e10 = i.e(f11);
        float e11 = i.e(f10);
        if (i10 != 1122867) {
            Path path = this.f13927m;
            path.reset();
            path.addCircle(eVar.f14944x, eVar.f14945y, e10, Path.Direction.CW);
            if (e11 > 0.0f) {
                path.addCircle(eVar.f14944x, eVar.f14945y, e11, Path.Direction.CCW);
            }
            this.f13925k.setColor(i10);
            this.f13925k.setStyle(Paint.Style.FILL);
            canvas.drawPath(path, this.f13925k);
        }
        if (i11 != 1122867) {
            this.f13925k.setColor(i11);
            this.f13925k.setStyle(Paint.Style.STROKE);
            this.f13925k.setStrokeWidth(i.e(f12));
            canvas.drawCircle(eVar.f14944x, eVar.f14945y, e10, this.f13925k);
        }
        canvas.restore();
    }

    public void p(Canvas canvas, String str, float f10, float f11, int i10) {
        this.f13878f.setColor(i10);
        canvas.drawText(str, f10, f11, this.f13878f);
    }

    /* access modifiers changed from: protected */
    public void q(Canvas canvas) {
        float sliceAngle = this.f13923i.getSliceAngle();
        float factor = this.f13923i.getFactor();
        float rotationAngle = this.f13923i.getRotationAngle();
        e centerOffsets = this.f13923i.getCenterOffsets();
        this.f13924j.setStrokeWidth(this.f13923i.getWebLineWidth());
        this.f13924j.setColor(this.f13923i.getWebColor());
        this.f13924j.setAlpha(this.f13923i.getWebAlpha());
        int skipWebLineCount = this.f13923i.getSkipWebLineCount() + 1;
        int I0 = ((db.j) ((y) this.f13923i.getData()).l()).I0();
        e c10 = e.c(0.0f, 0.0f);
        for (int i10 = 0; i10 < I0; i10 += skipWebLineCount) {
            i.t(centerOffsets, this.f13923i.getYRange() * factor, (((float) i10) * sliceAngle) + rotationAngle, c10);
            canvas.drawLine(centerOffsets.f14944x, centerOffsets.f14945y, c10.f14944x, c10.f14945y, this.f13924j);
        }
        e.h(c10);
        this.f13924j.setStrokeWidth(this.f13923i.getWebLineWidthInner());
        this.f13924j.setColor(this.f13923i.getWebColorInner());
        this.f13924j.setAlpha(this.f13923i.getWebAlpha());
        int i11 = this.f13923i.getYAxis().f20233n;
        e c11 = e.c(0.0f, 0.0f);
        e c12 = e.c(0.0f, 0.0f);
        for (int i12 = 0; i12 < i11; i12++) {
            int i13 = 0;
            while (i13 < ((y) this.f13923i.getData()).h()) {
                float yChartMin = (this.f13923i.getYAxis().f20231l[i12] - this.f13923i.getYChartMin()) * factor;
                i.t(centerOffsets, yChartMin, (((float) i13) * sliceAngle) + rotationAngle, c11);
                i13++;
                i.t(centerOffsets, yChartMin, (((float) i13) * sliceAngle) + rotationAngle, c12);
                canvas.drawLine(c11.f14944x, c11.f14945y, c12.f14944x, c12.f14945y, this.f13924j);
            }
        }
        e.h(c11);
        e.h(c12);
    }
}
