package hb;

import ab.h;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.PathEffect;
import android.graphics.drawable.Drawable;
import bb.d;
import cb.g;
import db.f;
import hb.c;
import java.lang.ref.WeakReference;
import java.util.HashMap;
import java.util.List;
import jb.e;
import jb.i;
import za.q;
import za.r;
import za.s;

public class j extends k {

    /* renamed from: i  reason: collision with root package name */
    protected g f13890i;

    /* renamed from: j  reason: collision with root package name */
    protected Paint f13891j;

    /* renamed from: k  reason: collision with root package name */
    protected WeakReference f13892k;

    /* renamed from: l  reason: collision with root package name */
    protected Canvas f13893l;

    /* renamed from: m  reason: collision with root package name */
    protected Bitmap.Config f13894m = Bitmap.Config.ARGB_8888;

    /* renamed from: n  reason: collision with root package name */
    protected Path f13895n = new Path();

    /* renamed from: o  reason: collision with root package name */
    protected Path f13896o = new Path();

    /* renamed from: p  reason: collision with root package name */
    private float[] f13897p = new float[4];

    /* renamed from: q  reason: collision with root package name */
    protected Path f13898q = new Path();

    /* renamed from: r  reason: collision with root package name */
    private HashMap f13899r = new HashMap();

    /* renamed from: s  reason: collision with root package name */
    private float[] f13900s = new float[2];

    static /* synthetic */ class a {

        /* renamed from: a  reason: collision with root package name */
        static final /* synthetic */ int[] f13901a;

        /* JADX WARNING: Can't wrap try/catch for region: R(8:0|1|2|3|4|5|6|(3:7|8|10)) */
        /* JADX WARNING: Failed to process nested try/catch */
        /* JADX WARNING: Missing exception handler attribute for start block: B:3:0x0012 */
        /* JADX WARNING: Missing exception handler attribute for start block: B:5:0x001d */
        /* JADX WARNING: Missing exception handler attribute for start block: B:7:0x0028 */
        static {
            /*
                za.s$a[] r0 = za.s.a.values()
                int r0 = r0.length
                int[] r0 = new int[r0]
                f13901a = r0
                za.s$a r1 = za.s.a.LINEAR     // Catch:{ NoSuchFieldError -> 0x0012 }
                int r1 = r1.ordinal()     // Catch:{ NoSuchFieldError -> 0x0012 }
                r2 = 1
                r0[r1] = r2     // Catch:{ NoSuchFieldError -> 0x0012 }
            L_0x0012:
                int[] r0 = f13901a     // Catch:{ NoSuchFieldError -> 0x001d }
                za.s$a r1 = za.s.a.STEPPED     // Catch:{ NoSuchFieldError -> 0x001d }
                int r1 = r1.ordinal()     // Catch:{ NoSuchFieldError -> 0x001d }
                r2 = 2
                r0[r1] = r2     // Catch:{ NoSuchFieldError -> 0x001d }
            L_0x001d:
                int[] r0 = f13901a     // Catch:{ NoSuchFieldError -> 0x0028 }
                za.s$a r1 = za.s.a.CUBIC_BEZIER     // Catch:{ NoSuchFieldError -> 0x0028 }
                int r1 = r1.ordinal()     // Catch:{ NoSuchFieldError -> 0x0028 }
                r2 = 3
                r0[r1] = r2     // Catch:{ NoSuchFieldError -> 0x0028 }
            L_0x0028:
                int[] r0 = f13901a     // Catch:{ NoSuchFieldError -> 0x0033 }
                za.s$a r1 = za.s.a.HORIZONTAL_BEZIER     // Catch:{ NoSuchFieldError -> 0x0033 }
                int r1 = r1.ordinal()     // Catch:{ NoSuchFieldError -> 0x0033 }
                r2 = 4
                r0[r1] = r2     // Catch:{ NoSuchFieldError -> 0x0033 }
            L_0x0033:
                return
            */
            throw new UnsupportedOperationException("Method not decompiled: hb.j.a.<clinit>():void");
        }
    }

    public j(g gVar, wa.a aVar, jb.j jVar) {
        super(aVar, jVar);
        this.f13890i = gVar;
        Paint paint = new Paint(1);
        this.f13891j = paint;
        paint.setStyle(Paint.Style.FILL);
        this.f13891j.setColor(-1);
    }

    private void v(f fVar, int i10, int i11, Path path) {
        boolean z10;
        float a10 = fVar.m().a(fVar, this.f13890i);
        float e10 = this.f13874b.e();
        if (fVar.U() == s.a.STEPPED) {
            z10 = true;
        } else {
            z10 = false;
        }
        path.reset();
        q P = fVar.P(i10);
        path.moveTo(P.f(), a10);
        path.lineTo(P.f(), P.c() * e10);
        int i12 = i10 + 1;
        q qVar = null;
        while (i12 <= i11) {
            qVar = fVar.P(i12);
            if (z10) {
                path.lineTo(qVar.f(), P.c() * e10);
            }
            path.lineTo(qVar.f(), qVar.c() * e10);
            i12++;
            P = qVar;
        }
        if (qVar != null) {
            path.lineTo(qVar.f(), a10);
        }
        path.close();
    }

    public void b(Canvas canvas) {
        Bitmap bitmap;
        int n10 = (int) this.f13928a.n();
        int m10 = (int) this.f13928a.m();
        WeakReference weakReference = this.f13892k;
        if (weakReference == null) {
            bitmap = null;
        } else {
            bitmap = (Bitmap) weakReference.get();
        }
        if (!(bitmap != null && bitmap.getWidth() == n10 && bitmap.getHeight() == m10)) {
            if (n10 > 0 && m10 > 0) {
                bitmap = Bitmap.createBitmap(n10, m10, this.f13894m);
                this.f13892k = new WeakReference(bitmap);
                this.f13893l = new Canvas(bitmap);
            } else {
                return;
            }
        }
        bitmap.eraseColor(0);
        for (f fVar : this.f13890i.getLineData().g()) {
            if (fVar.isVisible()) {
                q(canvas, fVar);
            }
        }
        canvas.drawBitmap(bitmap, 0.0f, 0.0f, this.f13875c);
    }

    public void c(Canvas canvas) {
        n(canvas);
    }

    public void d(Canvas canvas, d[] dVarArr) {
        r lineData = this.f13890i.getLineData();
        for (d dVar : dVarArr) {
            f fVar = (f) lineData.e(dVar.d());
            if (fVar != null && fVar.M0()) {
                q t10 = fVar.t(dVar.h(), dVar.j());
                if (h(t10, fVar)) {
                    jb.d e10 = this.f13890i.e(fVar.G0()).e(t10.f(), t10.c() * this.f13874b.e());
                    dVar.m((float) e10.f14941x, (float) e10.f14942y);
                    j(canvas, (float) e10.f14941x, (float) e10.f14942y, fVar);
                }
            }
        }
    }

    public void e(Canvas canvas) {
        int i10;
        f fVar;
        q qVar;
        if (g(this.f13890i)) {
            List g10 = this.f13890i.getLineData().g();
            for (int i11 = 0; i11 < g10.size(); i11++) {
                f fVar2 = (f) g10.get(i11);
                if (i(fVar2) && fVar2.I0() >= 1) {
                    a(fVar2);
                    jb.g e10 = this.f13890i.e(fVar2.G0());
                    int Q = (int) (fVar2.Q() * 1.75f);
                    if (!fVar2.L0()) {
                        Q /= 2;
                    }
                    int i12 = Q;
                    this.f13855g.a(this.f13890i, fVar2);
                    float d10 = this.f13874b.d();
                    float e11 = this.f13874b.e();
                    c.a aVar = this.f13855g;
                    float[] c10 = e10.c(fVar2, d10, e11, aVar.f13856a, aVar.f13857b);
                    h L = fVar2.L();
                    e d11 = e.d(fVar2.J0());
                    d11.f14944x = i.e(d11.f14944x);
                    d11.f14945y = i.e(d11.f14945y);
                    int i13 = 0;
                    while (i13 < c10.length) {
                        float f10 = c10[i13];
                        float f11 = c10[i13 + 1];
                        if (!this.f13928a.C(f10)) {
                            break;
                        }
                        if (!this.f13928a.B(f10) || !this.f13928a.F(f11)) {
                            i10 = i12;
                            fVar = fVar2;
                        } else {
                            int i14 = i13 / 2;
                            q P = fVar2.P(this.f13855g.f13856a + i14);
                            if (fVar2.B0()) {
                                qVar = P;
                                i10 = i12;
                                float f12 = f11 - ((float) i12);
                                fVar = fVar2;
                                u(canvas, L.h(P), f10, f12, fVar2.f0(i14));
                            } else {
                                qVar = P;
                                i10 = i12;
                                fVar = fVar2;
                            }
                            if (qVar.b() != null && fVar.x()) {
                                Drawable b10 = qVar.b();
                                i.f(canvas, b10, (int) (f10 + d11.f14944x), (int) (f11 + d11.f14945y), b10.getIntrinsicWidth(), b10.getIntrinsicHeight());
                            }
                        }
                        i13 += 2;
                        fVar2 = fVar;
                        i12 = i10;
                    }
                    e.h(d11);
                }
            }
        }
    }

    public void f() {
    }

    /* access modifiers changed from: protected */
    public void n(Canvas canvas) {
        boolean z10;
        boolean z11;
        b bVar;
        Bitmap b10;
        this.f13875c.setStyle(Paint.Style.FILL);
        float e10 = this.f13874b.e();
        float[] fArr = this.f13900s;
        char c10 = 0;
        float f10 = 0.0f;
        fArr[0] = 0.0f;
        fArr[1] = 0.0f;
        List g10 = this.f13890i.getLineData().g();
        int i10 = 0;
        while (i10 < g10.size()) {
            f fVar = (f) g10.get(i10);
            if (fVar.isVisible() && fVar.L0() && fVar.I0() != 0) {
                this.f13891j.setColor(fVar.z());
                jb.g e11 = this.f13890i.e(fVar.G0());
                this.f13855g.a(this.f13890i, fVar);
                float Q = fVar.Q();
                float O0 = fVar.O0();
                if (!fVar.T0() || O0 >= Q || O0 <= f10) {
                    z10 = false;
                } else {
                    z10 = true;
                }
                if (!z10 || fVar.z() != 1122867) {
                    z11 = false;
                } else {
                    z11 = true;
                }
                if (this.f13899r.containsKey(fVar)) {
                    bVar = (b) this.f13899r.get(fVar);
                } else {
                    bVar = new b(this, (a) null);
                    this.f13899r.put(fVar, bVar);
                }
                if (bVar.c(fVar)) {
                    bVar.a(fVar, z10, z11);
                }
                c.a aVar = this.f13855g;
                int i11 = aVar.f13858c;
                int i12 = aVar.f13856a;
                int i13 = i11 + i12;
                while (i12 <= i13) {
                    q P = fVar.P(i12);
                    if (P == null) {
                        break;
                    }
                    this.f13900s[c10] = P.f();
                    this.f13900s[1] = P.c() * e10;
                    e11.k(this.f13900s);
                    if (!this.f13928a.C(this.f13900s[c10])) {
                        break;
                    }
                    if (!this.f13928a.B(this.f13900s[c10]) || !this.f13928a.F(this.f13900s[1]) || (b10 = bVar.b(i12)) == null) {
                        Canvas canvas2 = canvas;
                    } else {
                        float[] fArr2 = this.f13900s;
                        canvas.drawBitmap(b10, fArr2[c10] - Q, fArr2[1] - Q, (Paint) null);
                    }
                    i12++;
                    c10 = 0;
                }
            }
            Canvas canvas3 = canvas;
            i10++;
            c10 = 0;
            f10 = 0.0f;
        }
    }

    /* access modifiers changed from: protected */
    public void o(f fVar) {
        f fVar2 = fVar;
        float e10 = this.f13874b.e();
        jb.g e11 = this.f13890i.e(fVar.G0());
        this.f13855g.a(this.f13890i, fVar2);
        float F = fVar.F();
        this.f13895n.reset();
        c.a aVar = this.f13855g;
        if (aVar.f13858c >= 1) {
            int i10 = aVar.f13856a + 1;
            q P = fVar2.P(Math.max(i10 - 2, 0));
            q P2 = fVar2.P(Math.max(i10 - 1, 0));
            if (P2 != null) {
                this.f13895n.moveTo(P2.f(), P2.c() * e10);
                q qVar = P2;
                int i11 = this.f13855g.f13856a + 1;
                int i12 = -1;
                while (true) {
                    c.a aVar2 = this.f13855g;
                    if (i11 > aVar2.f13858c + aVar2.f13856a) {
                        break;
                    }
                    if (i12 != i11) {
                        P2 = fVar2.P(i11);
                    }
                    int i13 = i11 + 1;
                    if (i13 < fVar.I0()) {
                        i11 = i13;
                    }
                    q P3 = fVar2.P(i11);
                    this.f13895n.cubicTo(qVar.f() + ((P2.f() - P.f()) * F), (qVar.c() + ((P2.c() - P.c()) * F)) * e10, P2.f() - ((P3.f() - qVar.f()) * F), (P2.c() - ((P3.c() - qVar.c()) * F)) * e10, P2.f(), P2.c() * e10);
                    P = qVar;
                    qVar = P2;
                    P2 = P3;
                    int i14 = i11;
                    i11 = i13;
                    i12 = i14;
                }
            } else {
                return;
            }
        }
        if (fVar.R()) {
            this.f13896o.reset();
            this.f13896o.addPath(this.f13895n);
            p(this.f13893l, fVar, this.f13896o, e11, this.f13855g);
        }
        this.f13875c.setColor(fVar.K0());
        this.f13875c.setStyle(Paint.Style.STROKE);
        e11.i(this.f13895n);
        this.f13893l.drawPath(this.f13895n, this.f13875c);
        this.f13875c.setPathEffect((PathEffect) null);
    }

    /* access modifiers changed from: protected */
    public void p(Canvas canvas, f fVar, Path path, jb.g gVar, c.a aVar) {
        float a10 = fVar.m().a(fVar, this.f13890i);
        path.lineTo(fVar.P(aVar.f13856a + aVar.f13858c).f(), a10);
        path.lineTo(fVar.P(aVar.f13856a).f(), a10);
        path.close();
        gVar.i(path);
        Drawable I = fVar.I();
        if (I != null) {
            m(canvas, path, I);
        } else {
            l(canvas, path, fVar.e(), fVar.j());
        }
    }

    /* access modifiers changed from: protected */
    public void q(Canvas canvas, f fVar) {
        if (fVar.I0() >= 1) {
            this.f13875c.setStrokeWidth(fVar.q());
            this.f13875c.setPathEffect(fVar.H());
            int i10 = a.f13901a[fVar.U().ordinal()];
            if (i10 == 3) {
                o(fVar);
            } else if (i10 != 4) {
                s(canvas, fVar);
            } else {
                r(fVar);
            }
            this.f13875c.setPathEffect((PathEffect) null);
        }
    }

    /* access modifiers changed from: protected */
    public void r(f fVar) {
        float e10 = this.f13874b.e();
        jb.g e11 = this.f13890i.e(fVar.G0());
        this.f13855g.a(this.f13890i, fVar);
        this.f13895n.reset();
        c.a aVar = this.f13855g;
        if (aVar.f13858c >= 1) {
            q P = fVar.P(aVar.f13856a);
            this.f13895n.moveTo(P.f(), P.c() * e10);
            int i10 = this.f13855g.f13856a + 1;
            while (true) {
                c.a aVar2 = this.f13855g;
                if (i10 > aVar2.f13858c + aVar2.f13856a) {
                    break;
                }
                q P2 = fVar.P(i10);
                float f10 = P.f() + ((P2.f() - P.f()) / 2.0f);
                this.f13895n.cubicTo(f10, P.c() * e10, f10, P2.c() * e10, P2.f(), P2.c() * e10);
                i10++;
                P = P2;
            }
        }
        if (fVar.R()) {
            this.f13896o.reset();
            this.f13896o.addPath(this.f13895n);
            p(this.f13893l, fVar, this.f13896o, e11, this.f13855g);
        }
        this.f13875c.setColor(fVar.K0());
        this.f13875c.setStyle(Paint.Style.STROKE);
        e11.i(this.f13895n);
        this.f13893l.drawPath(this.f13895n, this.f13875c);
        this.f13875c.setPathEffect((PathEffect) null);
    }

    /* access modifiers changed from: protected */
    public void s(Canvas canvas, f fVar) {
        boolean z10;
        int i10;
        Canvas canvas2;
        int i11;
        f fVar2 = fVar;
        int I0 = fVar.I0();
        if (fVar.U() == s.a.STEPPED) {
            z10 = true;
        } else {
            z10 = false;
        }
        if (z10) {
            i10 = 4;
        } else {
            i10 = 2;
        }
        jb.g e10 = this.f13890i.e(fVar.G0());
        float e11 = this.f13874b.e();
        this.f13875c.setStyle(Paint.Style.STROKE);
        if (fVar.w()) {
            canvas2 = this.f13893l;
        } else {
            canvas2 = canvas;
        }
        this.f13855g.a(this.f13890i, fVar2);
        if (fVar.R() && I0 > 0) {
            t(canvas, fVar2, e10, this.f13855g);
        }
        if (fVar.k0().size() > 1) {
            int i12 = i10 * 2;
            if (this.f13897p.length <= i12) {
                this.f13897p = new float[(i10 * 4)];
            }
            int i13 = this.f13855g.f13856a;
            while (true) {
                c.a aVar = this.f13855g;
                if (i13 > aVar.f13858c + aVar.f13856a) {
                    break;
                }
                q P = fVar2.P(i13);
                if (P != null) {
                    this.f13897p[0] = P.f();
                    this.f13897p[1] = P.c() * e11;
                    if (i13 < this.f13855g.f13857b) {
                        q P2 = fVar2.P(i13 + 1);
                        if (P2 == null) {
                            break;
                        } else if (z10) {
                            this.f13897p[2] = P2.f();
                            float[] fArr = this.f13897p;
                            float f10 = fArr[1];
                            fArr[3] = f10;
                            fArr[4] = fArr[2];
                            fArr[5] = f10;
                            fArr[6] = P2.f();
                            this.f13897p[7] = P2.c() * e11;
                        } else {
                            this.f13897p[2] = P2.f();
                            this.f13897p[3] = P2.c() * e11;
                        }
                    } else {
                        float[] fArr2 = this.f13897p;
                        fArr2[2] = fArr2[0];
                        fArr2[3] = fArr2[1];
                    }
                    e10.k(this.f13897p);
                    if (!this.f13928a.C(this.f13897p[0])) {
                        break;
                    } else if (this.f13928a.B(this.f13897p[2]) && (this.f13928a.D(this.f13897p[1]) || this.f13928a.A(this.f13897p[3]))) {
                        this.f13875c.setColor(fVar2.V(i13));
                        canvas2.drawLines(this.f13897p, 0, i12, this.f13875c);
                    }
                }
                i13++;
            }
        } else {
            int i14 = I0 * i10;
            if (this.f13897p.length < Math.max(i14, i10) * 2) {
                this.f13897p = new float[(Math.max(i14, i10) * 4)];
            }
            if (fVar2.P(this.f13855g.f13856a) != null) {
                int i15 = this.f13855g.f13856a;
                int i16 = 0;
                while (true) {
                    c.a aVar2 = this.f13855g;
                    if (i15 > aVar2.f13858c + aVar2.f13856a) {
                        break;
                    }
                    if (i15 == 0) {
                        i11 = 0;
                    } else {
                        i11 = i15 - 1;
                    }
                    q P3 = fVar2.P(i11);
                    q P4 = fVar2.P(i15);
                    if (!(P3 == null || P4 == null)) {
                        int i17 = i16 + 1;
                        this.f13897p[i16] = P3.f();
                        int i18 = i17 + 1;
                        this.f13897p[i17] = P3.c() * e11;
                        if (z10) {
                            int i19 = i18 + 1;
                            this.f13897p[i18] = P4.f();
                            int i20 = i19 + 1;
                            this.f13897p[i19] = P3.c() * e11;
                            int i21 = i20 + 1;
                            this.f13897p[i20] = P4.f();
                            i18 = i21 + 1;
                            this.f13897p[i21] = P3.c() * e11;
                        }
                        int i22 = i18 + 1;
                        this.f13897p[i18] = P4.f();
                        this.f13897p[i22] = P4.c() * e11;
                        i16 = i22 + 1;
                    }
                    i15++;
                }
                if (i16 > 0) {
                    e10.k(this.f13897p);
                    this.f13875c.setColor(fVar.K0());
                    canvas2.drawLines(this.f13897p, 0, Math.max((this.f13855g.f13858c + 1) * i10, i10) * 2, this.f13875c);
                }
            }
        }
        this.f13875c.setPathEffect((PathEffect) null);
    }

    /* access modifiers changed from: protected */
    public void t(Canvas canvas, f fVar, jb.g gVar, c.a aVar) {
        int i10;
        int i11;
        Path path = this.f13898q;
        int i12 = aVar.f13856a;
        int i13 = aVar.f13858c + i12;
        int i14 = 0;
        do {
            i10 = (i14 * 128) + i12;
            i11 = i10 + 128;
            if (i11 > i13) {
                i11 = i13;
            }
            if (i10 <= i11) {
                v(fVar, i10, i11, path);
                gVar.i(path);
                Drawable I = fVar.I();
                if (I != null) {
                    m(canvas, path, I);
                } else {
                    l(canvas, path, fVar.e(), fVar.j());
                }
            }
            i14++;
        } while (i10 <= i11);
    }

    public void u(Canvas canvas, String str, float f10, float f11, int i10) {
        this.f13878f.setColor(i10);
        canvas.drawText(str, f10, f11, this.f13878f);
    }

    public void w() {
        Canvas canvas = this.f13893l;
        if (canvas != null) {
            canvas.setBitmap((Bitmap) null);
            this.f13893l = null;
        }
        WeakReference weakReference = this.f13892k;
        if (weakReference != null) {
            Bitmap bitmap = (Bitmap) weakReference.get();
            if (bitmap != null) {
                bitmap.recycle();
            }
            this.f13892k.clear();
            this.f13892k = null;
        }
    }

    private class b {

        /* renamed from: a  reason: collision with root package name */
        private Path f13902a;

        /* renamed from: b  reason: collision with root package name */
        private Bitmap[] f13903b;

        private b() {
            this.f13902a = new Path();
        }

        /* access modifiers changed from: protected */
        public void a(f fVar, boolean z10, boolean z11) {
            int d10 = fVar.d();
            float Q = fVar.Q();
            float O0 = fVar.O0();
            for (int i10 = 0; i10 < d10; i10++) {
                int i11 = (int) (((double) Q) * 2.1d);
                Bitmap createBitmap = Bitmap.createBitmap(i11, i11, Bitmap.Config.ARGB_4444);
                Canvas canvas = new Canvas(createBitmap);
                this.f13903b[i10] = createBitmap;
                j.this.f13875c.setColor(fVar.F0(i10));
                if (z11) {
                    this.f13902a.reset();
                    this.f13902a.addCircle(Q, Q, Q, Path.Direction.CW);
                    this.f13902a.addCircle(Q, Q, O0, Path.Direction.CCW);
                    canvas.drawPath(this.f13902a, j.this.f13875c);
                } else {
                    canvas.drawCircle(Q, Q, Q, j.this.f13875c);
                    if (z10) {
                        canvas.drawCircle(Q, Q, O0, j.this.f13891j);
                    }
                }
            }
        }

        /* access modifiers changed from: protected */
        public Bitmap b(int i10) {
            Bitmap[] bitmapArr = this.f13903b;
            return bitmapArr[i10 % bitmapArr.length];
        }

        /* access modifiers changed from: protected */
        public boolean c(f fVar) {
            int d10 = fVar.d();
            Bitmap[] bitmapArr = this.f13903b;
            if (bitmapArr == null) {
                this.f13903b = new Bitmap[d10];
                return true;
            } else if (bitmapArr.length == d10) {
                return false;
            } else {
                this.f13903b = new Bitmap[d10];
                return true;
            }
        }

        /* synthetic */ b(j jVar, a aVar) {
            this();
        }
    }
}
