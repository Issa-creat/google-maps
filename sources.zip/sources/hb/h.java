package hb;

import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.RectF;
import bb.d;
import cb.a;
import cb.e;
import jb.g;
import jb.i;
import jb.j;
import xa.b;
import xa.c;

public class h extends b {

    /* renamed from: n  reason: collision with root package name */
    private RectF f13879n = new RectF();

    public h(a aVar, wa.a aVar2, j jVar) {
        super(aVar, aVar2, jVar);
        this.f13878f.setTextAlign(Paint.Align.LEFT);
    }

    /* JADX WARNING: Removed duplicated region for block: B:142:0x03b6  */
    /* JADX WARNING: Removed duplicated region for block: B:143:0x03b9  */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public void e(android.graphics.Canvas r41) {
        /*
            r40 = this;
            r6 = r40
            cb.a r0 = r6.f13849h
            boolean r0 = r6.g(r0)
            if (r0 == 0) goto L_0x03cd
            cb.a r0 = r6.f13849h
            za.a r0 = r0.getBarData()
            java.util.List r7 = r0.g()
            r0 = 1084227584(0x40a00000, float:5.0)
            float r8 = jb.i.e(r0)
            cb.a r0 = r6.f13849h
            boolean r9 = r0.c()
            r11 = 0
        L_0x0021:
            cb.a r0 = r6.f13849h
            za.a r0 = r0.getBarData()
            int r0 = r0.f()
            if (r11 >= r0) goto L_0x03cd
            java.lang.Object r0 = r7.get(r11)
            r12 = r0
            db.a r12 = (db.a) r12
            boolean r0 = r6.i(r12)
            if (r0 != 0) goto L_0x0040
            r20 = r7
            r23 = r11
            goto L_0x03c7
        L_0x0040:
            cb.a r0 = r6.f13849h
            ya.i$a r1 = r12.G0()
            boolean r13 = r0.a(r1)
            r6.a(r12)
            android.graphics.Paint r0 = r6.f13878f
            java.lang.String r1 = "10"
            int r0 = jb.i.a(r0, r1)
            float r0 = (float) r0
            r14 = 1073741824(0x40000000, float:2.0)
            float r15 = r0 / r14
            ab.h r5 = r12.L()
            xa.b[] r0 = r6.f13851j
            r4 = r0[r11]
            wa.a r0 = r6.f13874b
            float r16 = r0.e()
            jb.e r0 = r12.J0()
            jb.e r3 = jb.e.d(r0)
            float r0 = r3.f14944x
            float r0 = jb.i.e(r0)
            r3.f14944x = r0
            float r0 = r3.f14945y
            float r0 = jb.i.e(r0)
            r3.f14945y = r0
            boolean r0 = r12.A0()
            r17 = 0
            if (r0 != 0) goto L_0x0197
            r2 = 0
        L_0x0089:
            float r0 = (float) r2
            float[] r1 = r4.f19465b
            int r1 = r1.length
            float r1 = (float) r1
            wa.a r10 = r6.f13874b
            float r10 = r10.d()
            float r1 = r1 * r10
            int r0 = (r0 > r1 ? 1 : (r0 == r1 ? 0 : -1))
            if (r0 >= 0) goto L_0x0190
            float[] r0 = r4.f19465b
            int r1 = r2 + 1
            r10 = r0[r1]
            int r16 = r2 + 3
            r0 = r0[r16]
            float r0 = r0 + r10
            float r16 = r0 / r14
            jb.j r0 = r6.f13928a
            boolean r0 = r0.D(r10)
            if (r0 != 0) goto L_0x00b1
            goto L_0x0190
        L_0x00b1:
            jb.j r0 = r6.f13928a
            float[] r10 = r4.f19465b
            r10 = r10[r2]
            boolean r0 = r0.E(r10)
            if (r0 != 0) goto L_0x00c8
        L_0x00bd:
            r25 = r2
            r14 = r4
            r20 = r7
            r23 = r11
            r7 = r3
            r11 = r5
            goto L_0x0183
        L_0x00c8:
            jb.j r0 = r6.f13928a
            float[] r10 = r4.f19465b
            r1 = r10[r1]
            boolean r0 = r0.A(r1)
            if (r0 != 0) goto L_0x00d5
            goto L_0x00bd
        L_0x00d5:
            int r0 = r2 / 4
            za.q r0 = r12.P(r0)
            r10 = r0
            za.c r10 = (za.c) r10
            float r18 = r10.c()
            java.lang.String r1 = r5.b(r10)
            android.graphics.Paint r0 = r6.f13878f
            int r0 = jb.i.d(r0, r1)
            float r0 = (float) r0
            if (r9 == 0) goto L_0x00f1
            r14 = r8
            goto L_0x00f4
        L_0x00f1:
            float r14 = r0 + r8
            float r14 = -r14
        L_0x00f4:
            r20 = r1
            if (r9 == 0) goto L_0x00fc
            float r1 = r0 + r8
            float r1 = -r1
            goto L_0x00fd
        L_0x00fc:
            r1 = r8
        L_0x00fd:
            if (r13 == 0) goto L_0x0103
            float r14 = -r14
            float r14 = r14 - r0
            float r1 = -r1
            float r1 = r1 - r0
        L_0x0103:
            r21 = r14
            r14 = r1
            boolean r0 = r12.B0()
            if (r0 == 0) goto L_0x013f
            float[] r0 = r4.f19465b
            int r1 = r2 + 2
            r0 = r0[r1]
            int r1 = (r18 > r17 ? 1 : (r18 == r17 ? 0 : -1))
            if (r1 < 0) goto L_0x0119
            r1 = r21
            goto L_0x011a
        L_0x0119:
            r1 = r14
        L_0x011a:
            float r22 = r0 + r1
            float r23 = r16 + r15
            int r0 = r2 / 2
            int r24 = r12.f0(r0)
            r0 = r40
            r1 = r41
            r25 = r2
            r2 = r20
            r20 = r7
            r7 = r3
            r3 = r22
            r22 = r14
            r14 = r4
            r4 = r23
            r23 = r11
            r11 = r5
            r5 = r24
            r0.k(r1, r2, r3, r4, r5)
            goto L_0x014a
        L_0x013f:
            r25 = r2
            r20 = r7
            r23 = r11
            r22 = r14
            r7 = r3
            r14 = r4
            r11 = r5
        L_0x014a:
            android.graphics.drawable.Drawable r0 = r10.b()
            if (r0 == 0) goto L_0x0183
            boolean r0 = r12.x()
            if (r0 == 0) goto L_0x0183
            android.graphics.drawable.Drawable r27 = r10.b()
            float[] r0 = r14.f19465b
            int r2 = r25 + 2
            r0 = r0[r2]
            int r1 = (r18 > r17 ? 1 : (r18 == r17 ? 0 : -1))
            if (r1 < 0) goto L_0x0165
            goto L_0x0167
        L_0x0165:
            r21 = r22
        L_0x0167:
            float r0 = r0 + r21
            float r1 = r7.f14944x
            float r0 = r0 + r1
            float r1 = r7.f14945y
            float r1 = r16 + r1
            int r0 = (int) r0
            int r1 = (int) r1
            int r30 = r27.getIntrinsicWidth()
            int r31 = r27.getIntrinsicHeight()
            r26 = r41
            r28 = r0
            r29 = r1
            jb.i.f(r26, r27, r28, r29, r30, r31)
        L_0x0183:
            int r2 = r25 + 4
            r3 = r7
            r5 = r11
            r4 = r14
            r7 = r20
            r11 = r23
            r14 = 1073741824(0x40000000, float:2.0)
            goto L_0x0089
        L_0x0190:
            r20 = r7
            r23 = r11
            r7 = r3
            goto L_0x03c4
        L_0x0197:
            r14 = r4
            r20 = r7
            r23 = r11
            r7 = r3
            r11 = r5
            cb.a r0 = r6.f13849h
            ya.i$a r1 = r12.G0()
            jb.g r10 = r0.e(r1)
            r5 = 0
            r18 = 0
        L_0x01ab:
            float r0 = (float) r5
            int r1 = r12.I0()
            float r1 = (float) r1
            wa.a r2 = r6.f13874b
            float r2 = r2.d()
            float r1 = r1 * r2
            int r0 = (r0 > r1 ? 1 : (r0 == r1 ? 0 : -1))
            if (r0 >= 0) goto L_0x03c4
            za.q r0 = r12.P(r5)
            r4 = r0
            za.c r4 = (za.c) r4
            int r21 = r12.f0(r5)
            float[] r3 = r4.n()
            if (r3 != 0) goto L_0x029c
            jb.j r0 = r6.f13928a
            float[] r1 = r14.f19465b
            int r22 = r18 + 1
            r1 = r1[r22]
            boolean r0 = r0.D(r1)
            if (r0 != 0) goto L_0x01de
            goto L_0x03c4
        L_0x01de:
            jb.j r0 = r6.f13928a
            float[] r1 = r14.f19465b
            r1 = r1[r18]
            boolean r0 = r0.E(r1)
            if (r0 != 0) goto L_0x01eb
            goto L_0x01ab
        L_0x01eb:
            jb.j r0 = r6.f13928a
            float[] r1 = r14.f19465b
            r1 = r1[r22]
            boolean r0 = r0.A(r1)
            if (r0 != 0) goto L_0x01f8
            goto L_0x01ab
        L_0x01f8:
            java.lang.String r2 = r11.b(r4)
            android.graphics.Paint r0 = r6.f13878f
            int r0 = jb.i.d(r0, r2)
            float r0 = (float) r0
            if (r9 == 0) goto L_0x0207
            r1 = r8
            goto L_0x020a
        L_0x0207:
            float r1 = r0 + r8
            float r1 = -r1
        L_0x020a:
            r24 = r3
            if (r9 == 0) goto L_0x0212
            float r3 = r0 + r8
            float r3 = -r3
            goto L_0x0213
        L_0x0212:
            r3 = r8
        L_0x0213:
            if (r13 == 0) goto L_0x0219
            float r1 = -r1
            float r1 = r1 - r0
            float r3 = -r3
            float r3 = r3 - r0
        L_0x0219:
            r25 = r1
            r26 = r3
            boolean r0 = r12.B0()
            if (r0 == 0) goto L_0x0252
            float[] r0 = r14.f19465b
            int r1 = r18 + 2
            r0 = r0[r1]
            float r1 = r4.c()
            int r1 = (r1 > r17 ? 1 : (r1 == r17 ? 0 : -1))
            if (r1 < 0) goto L_0x0234
            r1 = r25
            goto L_0x0236
        L_0x0234:
            r1 = r26
        L_0x0236:
            float r3 = r0 + r1
            float[] r0 = r14.f19465b
            r0 = r0[r22]
            float r27 = r0 + r15
            r0 = r40
            r1 = r41
            r28 = r15
            r15 = r24
            r24 = r4
            r4 = r27
            r27 = r5
            r5 = r21
            r0.k(r1, r2, r3, r4, r5)
            goto L_0x025a
        L_0x0252:
            r27 = r5
            r28 = r15
            r15 = r24
            r24 = r4
        L_0x025a:
            android.graphics.drawable.Drawable r0 = r24.b()
            if (r0 == 0) goto L_0x03b2
            boolean r0 = r12.x()
            if (r0 == 0) goto L_0x03b2
            android.graphics.drawable.Drawable r30 = r24.b()
            float[] r0 = r14.f19465b
            int r1 = r18 + 2
            r0 = r0[r1]
            float r1 = r24.c()
            int r1 = (r1 > r17 ? 1 : (r1 == r17 ? 0 : -1))
            if (r1 < 0) goto L_0x0279
            goto L_0x027b
        L_0x0279:
            r25 = r26
        L_0x027b:
            float r0 = r0 + r25
            float[] r1 = r14.f19465b
            r1 = r1[r22]
            float r2 = r7.f14944x
            float r0 = r0 + r2
            float r2 = r7.f14945y
            float r1 = r1 + r2
            int r0 = (int) r0
            int r1 = (int) r1
            int r33 = r30.getIntrinsicWidth()
            int r34 = r30.getIntrinsicHeight()
            r29 = r41
            r31 = r0
            r32 = r1
            jb.i.f(r29, r30, r31, r32, r33, r34)
            goto L_0x03b2
        L_0x029c:
            r24 = r4
            r27 = r5
            r28 = r15
            r15 = r3
            int r0 = r15.length
            int r5 = r0 * 2
            float[] r4 = new float[r5]
            float r0 = r24.k()
            float r0 = -r0
            r22 = r0
            r0 = 0
            r1 = 0
            r25 = 0
        L_0x02b3:
            if (r0 >= r5) goto L_0x02e0
            r2 = r15[r1]
            int r3 = (r2 > r17 ? 1 : (r2 == r17 ? 0 : -1))
            if (r3 != 0) goto L_0x02ca
            int r26 = (r25 > r17 ? 1 : (r25 == r17 ? 0 : -1))
            if (r26 == 0) goto L_0x02c3
            int r26 = (r22 > r17 ? 1 : (r22 == r17 ? 0 : -1))
            if (r26 != 0) goto L_0x02ca
        L_0x02c3:
            r39 = r22
            r22 = r2
            r2 = r39
            goto L_0x02d5
        L_0x02ca:
            if (r3 < 0) goto L_0x02d3
            float r25 = r25 + r2
            r2 = r22
            r22 = r25
            goto L_0x02d5
        L_0x02d3:
            float r2 = r22 - r2
        L_0x02d5:
            float r22 = r22 * r16
            r4[r0] = r22
            int r0 = r0 + 2
            int r1 = r1 + 1
            r22 = r2
            goto L_0x02b3
        L_0x02e0:
            r10.k(r4)
            r3 = 0
        L_0x02e4:
            if (r3 >= r5) goto L_0x03b2
            int r0 = r3 / 2
            r0 = r15[r0]
            r2 = r24
            java.lang.String r1 = r11.c(r0, r2)
            android.graphics.Paint r2 = r6.f13878f
            int r2 = jb.i.d(r2, r1)
            float r2 = (float) r2
            r26 = r1
            if (r9 == 0) goto L_0x02fd
            r1 = r8
            goto L_0x0300
        L_0x02fd:
            float r1 = r2 + r8
            float r1 = -r1
        L_0x0300:
            r29 = r5
            if (r9 == 0) goto L_0x0308
            float r5 = r2 + r8
            float r5 = -r5
            goto L_0x0309
        L_0x0308:
            r5 = r8
        L_0x0309:
            if (r13 == 0) goto L_0x030f
            float r1 = -r1
            float r1 = r1 - r2
            float r5 = -r5
            float r5 = r5 - r2
        L_0x030f:
            int r2 = (r0 > r17 ? 1 : (r0 == r17 ? 0 : -1))
            if (r2 != 0) goto L_0x031b
            int r2 = (r22 > r17 ? 1 : (r22 == r17 ? 0 : -1))
            if (r2 != 0) goto L_0x031b
            int r2 = (r25 > r17 ? 1 : (r25 == r17 ? 0 : -1))
            if (r2 > 0) goto L_0x031f
        L_0x031b:
            int r0 = (r0 > r17 ? 1 : (r0 == r17 ? 0 : -1))
            if (r0 >= 0) goto L_0x0321
        L_0x031f:
            r0 = 1
            goto L_0x0322
        L_0x0321:
            r0 = 0
        L_0x0322:
            r2 = r4[r3]
            if (r0 == 0) goto L_0x0327
            r1 = r5
        L_0x0327:
            float r5 = r2 + r1
            float[] r0 = r14.f19465b
            int r1 = r18 + 1
            r1 = r0[r1]
            int r2 = r18 + 3
            r0 = r0[r2]
            float r1 = r1 + r0
            r19 = 1073741824(0x40000000, float:2.0)
            float r2 = r1 / r19
            jb.j r0 = r6.f13928a
            boolean r0 = r0.D(r2)
            if (r0 != 0) goto L_0x0342
            goto L_0x03b4
        L_0x0342:
            jb.j r0 = r6.f13928a
            boolean r0 = r0.E(r5)
            if (r0 != 0) goto L_0x034f
        L_0x034a:
            r26 = r3
            r32 = r4
            goto L_0x03aa
        L_0x034f:
            jb.j r0 = r6.f13928a
            boolean r0 = r0.A(r2)
            if (r0 != 0) goto L_0x0358
            goto L_0x034a
        L_0x0358:
            boolean r0 = r12.B0()
            if (r0 == 0) goto L_0x0377
            float r30 = r2 + r28
            r0 = r40
            r1 = r41
            r31 = r2
            r2 = r26
            r26 = r3
            r3 = r5
            r32 = r4
            r4 = r30
            r30 = r5
            r5 = r21
            r0.k(r1, r2, r3, r4, r5)
            goto L_0x037f
        L_0x0377:
            r31 = r2
            r26 = r3
            r32 = r4
            r30 = r5
        L_0x037f:
            android.graphics.drawable.Drawable r0 = r24.b()
            if (r0 == 0) goto L_0x03aa
            boolean r0 = r12.x()
            if (r0 == 0) goto L_0x03aa
            android.graphics.drawable.Drawable r34 = r24.b()
            float r0 = r7.f14944x
            float r5 = r30 + r0
            int r0 = (int) r5
            float r1 = r7.f14945y
            float r2 = r31 + r1
            int r1 = (int) r2
            int r37 = r34.getIntrinsicWidth()
            int r38 = r34.getIntrinsicHeight()
            r33 = r41
            r35 = r0
            r36 = r1
            jb.i.f(r33, r34, r35, r36, r37, r38)
        L_0x03aa:
            int r3 = r26 + 2
            r5 = r29
            r4 = r32
            goto L_0x02e4
        L_0x03b2:
            r19 = 1073741824(0x40000000, float:2.0)
        L_0x03b4:
            if (r15 != 0) goto L_0x03b9
            int r18 = r18 + 4
            goto L_0x03be
        L_0x03b9:
            int r0 = r15.length
            int r0 = r0 * 4
            int r18 = r18 + r0
        L_0x03be:
            int r5 = r27 + 1
            r15 = r28
            goto L_0x01ab
        L_0x03c4:
            jb.e.h(r7)
        L_0x03c7:
            int r11 = r23 + 1
            r7 = r20
            goto L_0x0021
        L_0x03cd:
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: hb.h.e(android.graphics.Canvas):void");
    }

    public void f() {
        int i10;
        za.a barData = this.f13849h.getBarData();
        this.f13851j = new c[barData.f()];
        for (int i11 = 0; i11 < this.f13851j.length; i11++) {
            db.a aVar = (db.a) barData.e(i11);
            b[] bVarArr = this.f13851j;
            int I0 = aVar.I0() * 4;
            if (aVar.A0()) {
                i10 = aVar.l0();
            } else {
                i10 = 1;
            }
            bVarArr[i11] = new c(I0 * i10, barData.f(), aVar.A0());
        }
    }

    /* access modifiers changed from: protected */
    public boolean g(e eVar) {
        if (((float) eVar.getData().h()) < ((float) eVar.getMaxVisibleCount()) * this.f13928a.s()) {
            return true;
        }
        return false;
    }

    /* access modifiers changed from: protected */
    public void j(Canvas canvas, db.a aVar, int i10) {
        boolean z10;
        db.a aVar2 = aVar;
        int i11 = i10;
        g e10 = this.f13849h.e(aVar.G0());
        this.f13853l.setColor(aVar.r());
        this.f13853l.setStrokeWidth(i.e(aVar.A()));
        int i12 = 0;
        boolean z11 = true;
        if (aVar.A() > 0.0f) {
            z10 = true;
        } else {
            z10 = false;
        }
        float d10 = this.f13874b.d();
        float e11 = this.f13874b.e();
        if (this.f13849h.b()) {
            this.f13852k.setColor(aVar.c0());
            float t10 = this.f13849h.getBarData().t() / 2.0f;
            int min = Math.min((int) Math.ceil((double) (((float) aVar.I0()) * d10)), aVar.I0());
            for (int i13 = 0; i13 < min; i13++) {
                float f10 = ((za.c) aVar2.P(i13)).f();
                RectF rectF = this.f13879n;
                rectF.top = f10 - t10;
                rectF.bottom = f10 + t10;
                e10.p(rectF);
                if (!this.f13928a.D(this.f13879n.bottom)) {
                    Canvas canvas2 = canvas;
                } else if (!this.f13928a.A(this.f13879n.top)) {
                    break;
                } else {
                    this.f13879n.left = this.f13928a.h();
                    this.f13879n.right = this.f13928a.i();
                    canvas.drawRect(this.f13879n, this.f13852k);
                }
            }
        }
        Canvas canvas3 = canvas;
        b bVar = this.f13851j[i11];
        bVar.b(d10, e11);
        bVar.g(i11);
        bVar.h(this.f13849h.a(aVar.G0()));
        bVar.f(this.f13849h.getBarData().t());
        bVar.e(aVar2);
        e10.k(bVar.f19465b);
        if (aVar.k0().size() != 1) {
            z11 = false;
        }
        if (z11) {
            this.f13875c.setColor(aVar.K0());
        }
        while (i12 < bVar.c()) {
            int i14 = i12 + 3;
            if (this.f13928a.D(bVar.f19465b[i14])) {
                int i15 = i12 + 1;
                if (this.f13928a.A(bVar.f19465b[i15])) {
                    if (!z11) {
                        this.f13875c.setColor(aVar2.V(i12 / 4));
                    }
                    float[] fArr = bVar.f19465b;
                    int i16 = i12 + 2;
                    canvas.drawRect(fArr[i12], fArr[i15], fArr[i16], fArr[i14], this.f13875c);
                    if (z10) {
                        float[] fArr2 = bVar.f19465b;
                        canvas.drawRect(fArr2[i12], fArr2[i15], fArr2[i16], fArr2[i14], this.f13853l);
                    }
                }
                i12 += 4;
                Canvas canvas4 = canvas;
            } else {
                return;
            }
        }
    }

    public void k(Canvas canvas, String str, float f10, float f11, int i10) {
        this.f13878f.setColor(i10);
        canvas.drawText(str, f10, f11, this.f13878f);
    }

    /* access modifiers changed from: protected */
    public void l(float f10, float f11, float f12, float f13, g gVar) {
        this.f13850i.set(f11, f10 - f13, f12, f10 + f13);
        gVar.o(this.f13850i, this.f13874b.e());
    }

    /* access modifiers changed from: protected */
    public void m(d dVar, RectF rectF) {
        dVar.m(rectF.centerY(), rectF.right);
    }
}
