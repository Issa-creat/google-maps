package hb;

import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.PathEffect;
import android.graphics.RectF;
import java.util.List;
import jb.d;
import jb.g;
import jb.j;
import ya.g;
import ya.i;

public class t extends a {

    /* renamed from: h  reason: collision with root package name */
    protected i f13942h;

    /* renamed from: i  reason: collision with root package name */
    protected Paint f13943i;

    /* renamed from: j  reason: collision with root package name */
    protected Path f13944j = new Path();

    /* renamed from: k  reason: collision with root package name */
    protected RectF f13945k = new RectF();

    /* renamed from: l  reason: collision with root package name */
    protected float[] f13946l = new float[2];

    /* renamed from: m  reason: collision with root package name */
    protected Path f13947m = new Path();

    /* renamed from: n  reason: collision with root package name */
    protected RectF f13948n = new RectF();

    /* renamed from: o  reason: collision with root package name */
    protected Path f13949o = new Path();

    /* renamed from: p  reason: collision with root package name */
    protected float[] f13950p = new float[2];

    /* renamed from: q  reason: collision with root package name */
    protected RectF f13951q = new RectF();

    public t(j jVar, i iVar, g gVar) {
        super(jVar, gVar, iVar);
        this.f13942h = iVar;
        if (this.f13928a != null) {
            this.f13846e.setColor(-16777216);
            this.f13846e.setTextSize(jb.i.e(10.0f));
            Paint paint = new Paint(1);
            this.f13943i = paint;
            paint.setColor(-7829368);
            this.f13943i.setStrokeWidth(1.0f);
            this.f13943i.setStyle(Paint.Style.STROKE);
        }
    }

    /* access modifiers changed from: protected */
    public void d(Canvas canvas, float f10, float[] fArr, float f11) {
        int i10;
        if (this.f13942h.m0()) {
            i10 = this.f13942h.f20233n;
        } else {
            i10 = this.f13942h.f20233n - 1;
        }
        for (int i11 = !this.f13942h.l0(); i11 < i10; i11++) {
            canvas.drawText(this.f13942h.r(i11), f10, fArr[(i11 * 2) + 1] + f11, this.f13846e);
        }
    }

    /* access modifiers changed from: protected */
    public void e(Canvas canvas) {
        int save = canvas.save();
        this.f13948n.set(this.f13928a.p());
        this.f13948n.inset(0.0f, -this.f13942h.k0());
        canvas.clipRect(this.f13948n);
        d e10 = this.f13844c.e(0.0f, 0.0f);
        this.f13943i.setColor(this.f13942h.j0());
        this.f13943i.setStrokeWidth(this.f13942h.k0());
        Path path = this.f13947m;
        path.reset();
        path.moveTo(this.f13928a.h(), (float) e10.f14942y);
        path.lineTo(this.f13928a.i(), (float) e10.f14942y);
        canvas.drawPath(path, this.f13943i);
        canvas.restoreToCount(save);
    }

    public RectF f() {
        this.f13945k.set(this.f13928a.p());
        this.f13945k.inset(0.0f, -this.f13843b.v());
        return this.f13945k;
    }

    /* access modifiers changed from: protected */
    public float[] g() {
        int length = this.f13946l.length;
        int i10 = this.f13942h.f20233n;
        if (length != i10 * 2) {
            this.f13946l = new float[(i10 * 2)];
        }
        float[] fArr = this.f13946l;
        for (int i11 = 0; i11 < fArr.length; i11 += 2) {
            fArr[i11 + 1] = this.f13942h.f20231l[i11 / 2];
        }
        this.f13844c.k(fArr);
        return fArr;
    }

    /* access modifiers changed from: protected */
    public Path h(Path path, int i10, float[] fArr) {
        int i11 = i10 + 1;
        path.moveTo(this.f13928a.I(), fArr[i11]);
        path.lineTo(this.f13928a.i(), fArr[i11]);
        return path;
    }

    public void i(Canvas canvas) {
        float f10;
        float f11;
        float f12;
        if (this.f13942h.f() && this.f13942h.E()) {
            float[] g10 = g();
            this.f13846e.setTypeface(this.f13942h.c());
            this.f13846e.setTextSize(this.f13942h.b());
            this.f13846e.setColor(this.f13942h.a());
            float d10 = this.f13942h.d();
            float a10 = (((float) jb.i.a(this.f13846e, "A")) / 2.5f) + this.f13942h.e();
            i.a b02 = this.f13942h.b0();
            i.b c02 = this.f13942h.c0();
            if (b02 == i.a.LEFT) {
                if (c02 == i.b.OUTSIDE_CHART) {
                    this.f13846e.setTextAlign(Paint.Align.RIGHT);
                    f11 = this.f13928a.I();
                    f10 = f11 - d10;
                    d(canvas, f10, g10, a10);
                }
                this.f13846e.setTextAlign(Paint.Align.LEFT);
                f12 = this.f13928a.I();
            } else if (c02 == i.b.OUTSIDE_CHART) {
                this.f13846e.setTextAlign(Paint.Align.LEFT);
                f12 = this.f13928a.i();
            } else {
                this.f13846e.setTextAlign(Paint.Align.RIGHT);
                f11 = this.f13928a.i();
                f10 = f11 - d10;
                d(canvas, f10, g10, a10);
            }
            f10 = f12 + d10;
            d(canvas, f10, g10, a10);
        }
    }

    public void j(Canvas canvas) {
        if (this.f13942h.f() && this.f13942h.B()) {
            this.f13847f.setColor(this.f13942h.o());
            this.f13847f.setStrokeWidth(this.f13942h.q());
            if (this.f13942h.b0() == i.a.LEFT) {
                canvas.drawLine(this.f13928a.h(), this.f13928a.j(), this.f13928a.h(), this.f13928a.f(), this.f13847f);
                return;
            }
            canvas.drawLine(this.f13928a.i(), this.f13928a.j(), this.f13928a.i(), this.f13928a.f(), this.f13847f);
        }
    }

    public void k(Canvas canvas) {
        if (this.f13942h.f()) {
            if (this.f13942h.D()) {
                int save = canvas.save();
                canvas.clipRect(f());
                float[] g10 = g();
                this.f13845d.setColor(this.f13942h.t());
                this.f13845d.setStrokeWidth(this.f13942h.v());
                this.f13845d.setPathEffect(this.f13942h.u());
                Path path = this.f13944j;
                path.reset();
                for (int i10 = 0; i10 < g10.length; i10 += 2) {
                    canvas.drawPath(h(path, i10, g10), this.f13845d);
                    path.reset();
                }
                canvas.restoreToCount(save);
            }
            if (this.f13942h.n0()) {
                e(canvas);
            }
        }
    }

    public void l(Canvas canvas) {
        List x10 = this.f13942h.x();
        if (x10 != null && x10.size() > 0) {
            float[] fArr = this.f13950p;
            fArr[0] = 0.0f;
            fArr[1] = 0.0f;
            Path path = this.f13949o;
            path.reset();
            for (int i10 = 0; i10 < x10.size(); i10++) {
                ya.g gVar = (ya.g) x10.get(i10);
                if (gVar.f()) {
                    int save = canvas.save();
                    this.f13951q.set(this.f13928a.p());
                    this.f13951q.inset(0.0f, -gVar.r());
                    canvas.clipRect(this.f13951q);
                    this.f13848g.setStyle(Paint.Style.STROKE);
                    this.f13848g.setColor(gVar.q());
                    this.f13848g.setStrokeWidth(gVar.r());
                    this.f13848g.setPathEffect(gVar.m());
                    fArr[1] = gVar.p();
                    this.f13844c.k(fArr);
                    path.moveTo(this.f13928a.h(), fArr[1]);
                    path.lineTo(this.f13928a.i(), fArr[1]);
                    canvas.drawPath(path, this.f13848g);
                    path.reset();
                    String n10 = gVar.n();
                    if (n10 != null && !n10.equals("")) {
                        this.f13848g.setStyle(gVar.s());
                        this.f13848g.setPathEffect((PathEffect) null);
                        this.f13848g.setColor(gVar.a());
                        this.f13848g.setTypeface(gVar.c());
                        this.f13848g.setStrokeWidth(0.5f);
                        this.f13848g.setTextSize(gVar.b());
                        float a10 = (float) jb.i.a(this.f13848g, n10);
                        float e10 = jb.i.e(4.0f) + gVar.d();
                        float r10 = gVar.r() + a10 + gVar.e();
                        g.a o10 = gVar.o();
                        if (o10 == g.a.RIGHT_TOP) {
                            this.f13848g.setTextAlign(Paint.Align.RIGHT);
                            canvas.drawText(n10, this.f13928a.i() - e10, (fArr[1] - r10) + a10, this.f13848g);
                        } else if (o10 == g.a.RIGHT_BOTTOM) {
                            this.f13848g.setTextAlign(Paint.Align.RIGHT);
                            canvas.drawText(n10, this.f13928a.i() - e10, fArr[1] + r10, this.f13848g);
                        } else if (o10 == g.a.LEFT_TOP) {
                            this.f13848g.setTextAlign(Paint.Align.LEFT);
                            canvas.drawText(n10, this.f13928a.h() + e10, (fArr[1] - r10) + a10, this.f13848g);
                        } else {
                            this.f13848g.setTextAlign(Paint.Align.LEFT);
                            canvas.drawText(n10, this.f13928a.I() + e10, fArr[1] + r10, this.f13848g);
                        }
                    }
                    canvas.restoreToCount(save);
                }
            }
        }
    }
}
