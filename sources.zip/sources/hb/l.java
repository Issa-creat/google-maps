package hb;

import android.graphics.Canvas;
import android.graphics.Path;
import db.h;
import jb.j;
import wa.a;

public abstract class l extends c {

    /* renamed from: h  reason: collision with root package name */
    private Path f13905h = new Path();

    public l(a aVar, j jVar) {
        super(aVar, jVar);
    }

    /* access modifiers changed from: protected */
    public void j(Canvas canvas, float f10, float f11, h hVar) {
        this.f13876d.setColor(hVar.E0());
        this.f13876d.setStrokeWidth(hVar.C());
        this.f13876d.setPathEffect(hVar.g0());
        if (hVar.N0()) {
            this.f13905h.reset();
            this.f13905h.moveTo(f10, this.f13928a.j());
            this.f13905h.lineTo(f10, this.f13928a.f());
            canvas.drawPath(this.f13905h, this.f13876d);
        }
        if (hVar.Q0()) {
            this.f13905h.reset();
            this.f13905h.moveTo(this.f13928a.h(), f11);
            this.f13905h.lineTo(this.f13928a.i(), f11);
            canvas.drawPath(this.f13905h, this.f13876d);
        }
    }
}
