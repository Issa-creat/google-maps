package hb;

import android.graphics.Canvas;
import android.graphics.Path;
import com.github.mikephil.charting.charts.RadarChart;
import java.util.List;
import jb.e;
import jb.g;
import jb.j;
import ya.a;
import ya.i;
import za.y;

public class v extends t {

    /* renamed from: r  reason: collision with root package name */
    private RadarChart f13955r;

    /* renamed from: s  reason: collision with root package name */
    private Path f13956s = new Path();

    public v(j jVar, i iVar, RadarChart radarChart) {
        super(jVar, iVar, (g) null);
        this.f13955r = radarChart;
    }

    /* access modifiers changed from: protected */
    public void b(float f10, float f11) {
        double d10;
        double d11;
        boolean z10;
        float f12 = f10;
        float f13 = f11;
        int w10 = this.f13843b.w();
        double abs = (double) Math.abs(f13 - f12);
        if (w10 == 0 || abs <= 0.0d || Double.isInfinite(abs)) {
            a aVar = this.f13843b;
            aVar.f20231l = new float[0];
            aVar.f20232m = new float[0];
            aVar.f20233n = 0;
            return;
        }
        double A = (double) jb.i.A(abs / ((double) w10));
        if (this.f13843b.H() && A < ((double) this.f13843b.s())) {
            A = (double) this.f13843b.s();
        }
        double A2 = (double) jb.i.A(Math.pow(10.0d, (double) ((int) Math.log10(A))));
        if (((int) (A / A2)) > 5) {
            A = Math.floor(A2 * 10.0d);
        }
        boolean A3 = this.f13843b.A();
        if (this.f13843b.G()) {
            float f14 = ((float) abs) / ((float) (w10 - 1));
            a aVar2 = this.f13843b;
            aVar2.f20233n = w10;
            if (aVar2.f20231l.length < w10) {
                aVar2.f20231l = new float[w10];
            }
            for (int i10 = 0; i10 < w10; i10++) {
                this.f13843b.f20231l[i10] = f12;
                f12 += f14;
            }
        } else {
            int i11 = (A > 0.0d ? 1 : (A == 0.0d ? 0 : -1));
            if (i11 == 0) {
                d10 = 0.0d;
            } else {
                d10 = Math.ceil(((double) f12) / A) * A;
            }
            if (A3) {
                d10 -= A;
            }
            if (i11 == 0) {
                d11 = 0.0d;
            } else {
                d11 = jb.i.y(Math.floor(((double) f13) / A) * A);
            }
            if (i11 != 0) {
                z10 = A3;
                for (double d12 = d10; d12 <= d11; d12 += A) {
                    z10++;
                }
            } else {
                z10 = A3;
            }
            int i12 = ((int) z10) + 1;
            a aVar3 = this.f13843b;
            aVar3.f20233n = i12;
            if (aVar3.f20231l.length < i12) {
                aVar3.f20231l = new float[i12];
            }
            for (int i13 = 0; i13 < i12; i13++) {
                if (d10 == 0.0d) {
                    d10 = 0.0d;
                }
                this.f13843b.f20231l[i13] = (float) d10;
                d10 += A;
            }
            w10 = i12;
        }
        if (A < 1.0d) {
            this.f13843b.f20234o = (int) Math.ceil(-Math.log10(A));
        } else {
            this.f13843b.f20234o = 0;
        }
        if (A3) {
            a aVar4 = this.f13843b;
            if (aVar4.f20232m.length < w10) {
                aVar4.f20232m = new float[w10];
            }
            float[] fArr = aVar4.f20231l;
            float f15 = (fArr[1] - fArr[0]) / 2.0f;
            for (int i14 = 0; i14 < w10; i14++) {
                a aVar5 = this.f13843b;
                aVar5.f20232m[i14] = aVar5.f20231l[i14] + f15;
            }
        }
        a aVar6 = this.f13843b;
        float[] fArr2 = aVar6.f20231l;
        float f16 = fArr2[0];
        aVar6.H = f16;
        float f17 = fArr2[w10 - 1];
        aVar6.G = f17;
        aVar6.I = Math.abs(f17 - f16);
    }

    public void i(Canvas canvas) {
        int i10;
        if (this.f13942h.f() && this.f13942h.E()) {
            this.f13846e.setTypeface(this.f13942h.c());
            this.f13846e.setTextSize(this.f13942h.b());
            this.f13846e.setColor(this.f13942h.a());
            e centerOffsets = this.f13955r.getCenterOffsets();
            e c10 = e.c(0.0f, 0.0f);
            float factor = this.f13955r.getFactor();
            if (this.f13942h.m0()) {
                i10 = this.f13942h.f20233n;
            } else {
                i10 = this.f13942h.f20233n - 1;
            }
            for (int i11 = !this.f13942h.l0(); i11 < i10; i11++) {
                i iVar = this.f13942h;
                jb.i.t(centerOffsets, (iVar.f20231l[i11] - iVar.H) * factor, this.f13955r.getRotationAngle(), c10);
                canvas.drawText(this.f13942h.r(i11), c10.f14944x + 10.0f, c10.f14945y, this.f13846e);
            }
            e.h(centerOffsets);
            e.h(c10);
        }
    }

    public void l(Canvas canvas) {
        List x10 = this.f13942h.x();
        if (x10 != null) {
            float sliceAngle = this.f13955r.getSliceAngle();
            float factor = this.f13955r.getFactor();
            e centerOffsets = this.f13955r.getCenterOffsets();
            e c10 = e.c(0.0f, 0.0f);
            for (int i10 = 0; i10 < x10.size(); i10++) {
                ya.g gVar = (ya.g) x10.get(i10);
                if (gVar.f()) {
                    this.f13848g.setColor(gVar.q());
                    this.f13848g.setPathEffect(gVar.m());
                    this.f13848g.setStrokeWidth(gVar.r());
                    float p10 = (gVar.p() - this.f13955r.getYChartMin()) * factor;
                    Path path = this.f13956s;
                    path.reset();
                    for (int i11 = 0; i11 < ((db.j) ((y) this.f13955r.getData()).l()).I0(); i11++) {
                        jb.i.t(centerOffsets, p10, (((float) i11) * sliceAngle) + this.f13955r.getRotationAngle(), c10);
                        if (i11 == 0) {
                            path.moveTo(c10.f14944x, c10.f14945y);
                        } else {
                            path.lineTo(c10.f14944x, c10.f14945y);
                        }
                    }
                    path.close();
                    canvas.drawPath(path, this.f13848g);
                }
            }
            e.h(centerOffsets);
            e.h(c10);
        }
    }
}
