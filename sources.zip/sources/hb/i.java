package hb;

import android.graphics.Canvas;
import android.graphics.DashPathEffect;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.Typeface;
import db.d;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import jb.b;
import jb.j;
import ya.e;
import ya.f;
import za.n;
import za.x;

public class i extends o {

    /* renamed from: b  reason: collision with root package name */
    protected Paint f13880b;

    /* renamed from: c  reason: collision with root package name */
    protected Paint f13881c;

    /* renamed from: d  reason: collision with root package name */
    protected e f13882d;

    /* renamed from: e  reason: collision with root package name */
    protected List f13883e = new ArrayList(16);

    /* renamed from: f  reason: collision with root package name */
    protected Paint.FontMetrics f13884f = new Paint.FontMetrics();

    /* renamed from: g  reason: collision with root package name */
    private Path f13885g = new Path();

    static /* synthetic */ class a {

        /* renamed from: a  reason: collision with root package name */
        static final /* synthetic */ int[] f13886a;

        /* renamed from: b  reason: collision with root package name */
        static final /* synthetic */ int[] f13887b;

        /* renamed from: c  reason: collision with root package name */
        static final /* synthetic */ int[] f13888c;

        /* renamed from: d  reason: collision with root package name */
        static final /* synthetic */ int[] f13889d;

        /* JADX WARNING: Can't wrap try/catch for region: R(32:0|(2:1|2)|3|(2:5|6)|7|9|10|11|12|13|14|15|16|17|19|20|(2:21|22)|23|25|26|27|28|29|30|31|33|34|35|36|37|38|40) */
        /* JADX WARNING: Can't wrap try/catch for region: R(34:0|1|2|3|(2:5|6)|7|9|10|11|12|13|14|15|16|17|19|20|21|22|23|25|26|27|28|29|30|31|33|34|35|36|37|38|40) */
        /* JADX WARNING: Can't wrap try/catch for region: R(35:0|1|2|3|5|6|7|9|10|11|12|13|14|15|16|17|19|20|21|22|23|25|26|27|28|29|30|31|33|34|35|36|37|38|40) */
        /* JADX WARNING: Code restructure failed: missing block: B:41:?, code lost:
            return;
         */
        /* JADX WARNING: Failed to process nested try/catch */
        /* JADX WARNING: Missing exception handler attribute for start block: B:11:0x0028 */
        /* JADX WARNING: Missing exception handler attribute for start block: B:13:0x0033 */
        /* JADX WARNING: Missing exception handler attribute for start block: B:15:0x003e */
        /* JADX WARNING: Missing exception handler attribute for start block: B:21:0x005a */
        /* JADX WARNING: Missing exception handler attribute for start block: B:27:0x0075 */
        /* JADX WARNING: Missing exception handler attribute for start block: B:29:0x007f */
        /* JADX WARNING: Missing exception handler attribute for start block: B:35:0x009a */
        /* JADX WARNING: Missing exception handler attribute for start block: B:37:0x00a4 */
        static {
            /*
                ya.e$c[] r0 = ya.e.c.values()
                int r0 = r0.length
                int[] r0 = new int[r0]
                f13889d = r0
                r1 = 1
                ya.e$c r2 = ya.e.c.NONE     // Catch:{ NoSuchFieldError -> 0x0012 }
                int r2 = r2.ordinal()     // Catch:{ NoSuchFieldError -> 0x0012 }
                r0[r2] = r1     // Catch:{ NoSuchFieldError -> 0x0012 }
            L_0x0012:
                r0 = 2
                int[] r2 = f13889d     // Catch:{ NoSuchFieldError -> 0x001d }
                ya.e$c r3 = ya.e.c.EMPTY     // Catch:{ NoSuchFieldError -> 0x001d }
                int r3 = r3.ordinal()     // Catch:{ NoSuchFieldError -> 0x001d }
                r2[r3] = r0     // Catch:{ NoSuchFieldError -> 0x001d }
            L_0x001d:
                r2 = 3
                int[] r3 = f13889d     // Catch:{ NoSuchFieldError -> 0x0028 }
                ya.e$c r4 = ya.e.c.DEFAULT     // Catch:{ NoSuchFieldError -> 0x0028 }
                int r4 = r4.ordinal()     // Catch:{ NoSuchFieldError -> 0x0028 }
                r3[r4] = r2     // Catch:{ NoSuchFieldError -> 0x0028 }
            L_0x0028:
                int[] r3 = f13889d     // Catch:{ NoSuchFieldError -> 0x0033 }
                ya.e$c r4 = ya.e.c.CIRCLE     // Catch:{ NoSuchFieldError -> 0x0033 }
                int r4 = r4.ordinal()     // Catch:{ NoSuchFieldError -> 0x0033 }
                r5 = 4
                r3[r4] = r5     // Catch:{ NoSuchFieldError -> 0x0033 }
            L_0x0033:
                int[] r3 = f13889d     // Catch:{ NoSuchFieldError -> 0x003e }
                ya.e$c r4 = ya.e.c.SQUARE     // Catch:{ NoSuchFieldError -> 0x003e }
                int r4 = r4.ordinal()     // Catch:{ NoSuchFieldError -> 0x003e }
                r5 = 5
                r3[r4] = r5     // Catch:{ NoSuchFieldError -> 0x003e }
            L_0x003e:
                int[] r3 = f13889d     // Catch:{ NoSuchFieldError -> 0x0049 }
                ya.e$c r4 = ya.e.c.LINE     // Catch:{ NoSuchFieldError -> 0x0049 }
                int r4 = r4.ordinal()     // Catch:{ NoSuchFieldError -> 0x0049 }
                r5 = 6
                r3[r4] = r5     // Catch:{ NoSuchFieldError -> 0x0049 }
            L_0x0049:
                ya.e$e[] r3 = ya.e.C0303e.values()
                int r3 = r3.length
                int[] r3 = new int[r3]
                f13888c = r3
                ya.e$e r4 = ya.e.C0303e.HORIZONTAL     // Catch:{ NoSuchFieldError -> 0x005a }
                int r4 = r4.ordinal()     // Catch:{ NoSuchFieldError -> 0x005a }
                r3[r4] = r1     // Catch:{ NoSuchFieldError -> 0x005a }
            L_0x005a:
                int[] r3 = f13888c     // Catch:{ NoSuchFieldError -> 0x0064 }
                ya.e$e r4 = ya.e.C0303e.VERTICAL     // Catch:{ NoSuchFieldError -> 0x0064 }
                int r4 = r4.ordinal()     // Catch:{ NoSuchFieldError -> 0x0064 }
                r3[r4] = r0     // Catch:{ NoSuchFieldError -> 0x0064 }
            L_0x0064:
                ya.e$f[] r3 = ya.e.f.values()
                int r3 = r3.length
                int[] r3 = new int[r3]
                f13887b = r3
                ya.e$f r4 = ya.e.f.TOP     // Catch:{ NoSuchFieldError -> 0x0075 }
                int r4 = r4.ordinal()     // Catch:{ NoSuchFieldError -> 0x0075 }
                r3[r4] = r1     // Catch:{ NoSuchFieldError -> 0x0075 }
            L_0x0075:
                int[] r3 = f13887b     // Catch:{ NoSuchFieldError -> 0x007f }
                ya.e$f r4 = ya.e.f.BOTTOM     // Catch:{ NoSuchFieldError -> 0x007f }
                int r4 = r4.ordinal()     // Catch:{ NoSuchFieldError -> 0x007f }
                r3[r4] = r0     // Catch:{ NoSuchFieldError -> 0x007f }
            L_0x007f:
                int[] r3 = f13887b     // Catch:{ NoSuchFieldError -> 0x0089 }
                ya.e$f r4 = ya.e.f.CENTER     // Catch:{ NoSuchFieldError -> 0x0089 }
                int r4 = r4.ordinal()     // Catch:{ NoSuchFieldError -> 0x0089 }
                r3[r4] = r2     // Catch:{ NoSuchFieldError -> 0x0089 }
            L_0x0089:
                ya.e$d[] r3 = ya.e.d.values()
                int r3 = r3.length
                int[] r3 = new int[r3]
                f13886a = r3
                ya.e$d r4 = ya.e.d.LEFT     // Catch:{ NoSuchFieldError -> 0x009a }
                int r4 = r4.ordinal()     // Catch:{ NoSuchFieldError -> 0x009a }
                r3[r4] = r1     // Catch:{ NoSuchFieldError -> 0x009a }
            L_0x009a:
                int[] r1 = f13886a     // Catch:{ NoSuchFieldError -> 0x00a4 }
                ya.e$d r3 = ya.e.d.RIGHT     // Catch:{ NoSuchFieldError -> 0x00a4 }
                int r3 = r3.ordinal()     // Catch:{ NoSuchFieldError -> 0x00a4 }
                r1[r3] = r0     // Catch:{ NoSuchFieldError -> 0x00a4 }
            L_0x00a4:
                int[] r0 = f13886a     // Catch:{ NoSuchFieldError -> 0x00ae }
                ya.e$d r1 = ya.e.d.CENTER     // Catch:{ NoSuchFieldError -> 0x00ae }
                int r1 = r1.ordinal()     // Catch:{ NoSuchFieldError -> 0x00ae }
                r0[r1] = r2     // Catch:{ NoSuchFieldError -> 0x00ae }
            L_0x00ae:
                return
            */
            throw new UnsupportedOperationException("Method not decompiled: hb.i.a.<clinit>():void");
        }
    }

    public i(j jVar, e eVar) {
        super(jVar);
        this.f13882d = eVar;
        Paint paint = new Paint(1);
        this.f13880b = paint;
        paint.setTextSize(jb.i.e(9.0f));
        this.f13880b.setTextAlign(Paint.Align.LEFT);
        Paint paint2 = new Paint(1);
        this.f13881c = paint2;
        paint2.setStyle(Paint.Style.FILL);
    }

    public void a(n nVar) {
        n nVar2;
        String str;
        n nVar3 = nVar;
        if (!this.f13882d.H()) {
            this.f13883e.clear();
            int i10 = 0;
            while (i10 < nVar.f()) {
                db.e e10 = nVar3.e(i10);
                List k02 = e10.k0();
                int I0 = e10.I0();
                if (e10 instanceof db.a) {
                    db.a aVar = (db.a) e10;
                    if (aVar.A0()) {
                        String[] C0 = aVar.C0();
                        int i11 = 0;
                        while (i11 < k02.size() && i11 < aVar.l0()) {
                            List list = this.f13883e;
                            f fVar = r10;
                            f fVar2 = new f(C0[i11 % C0.length], e10.y(), e10.T(), e10.O(), e10.s(), ((Integer) k02.get(i11)).intValue());
                            list.add(fVar);
                            i11++;
                        }
                        if (aVar.B() != null) {
                            this.f13883e.add(new f(e10.B(), e.c.NONE, Float.NaN, Float.NaN, (DashPathEffect) null, 1122867));
                        }
                        nVar2 = nVar3;
                        i10++;
                        nVar3 = nVar2;
                    }
                }
                if (e10 instanceof db.i) {
                    db.i iVar = (db.i) e10;
                    int i12 = 0;
                    while (i12 < k02.size() && i12 < I0) {
                        List list2 = this.f13883e;
                        f fVar3 = r9;
                        f fVar4 = new f(((x) iVar.P(i12)).h(), e10.y(), e10.T(), e10.O(), e10.s(), ((Integer) k02.get(i12)).intValue());
                        list2.add(fVar3);
                        i12++;
                        n nVar4 = nVar;
                    }
                    if (iVar.B() != null) {
                        this.f13883e.add(new f(e10.B(), e.c.NONE, Float.NaN, Float.NaN, (DashPathEffect) null, 1122867));
                    }
                } else {
                    if (e10 instanceof d) {
                        d dVar = (d) e10;
                        if (dVar.R0() != 1122867) {
                            int R0 = dVar.R0();
                            int D0 = dVar.D0();
                            this.f13883e.add(new f((String) null, e10.y(), e10.T(), e10.O(), e10.s(), R0));
                            this.f13883e.add(new f(e10.B(), e10.y(), e10.T(), e10.O(), e10.s(), D0));
                        }
                    }
                    int i13 = 0;
                    while (i13 < k02.size() && i13 < I0) {
                        if (i13 >= k02.size() - 1 || i13 >= I0 - 1) {
                            str = nVar.e(i10).B();
                        } else {
                            str = null;
                            n nVar5 = nVar;
                        }
                        this.f13883e.add(new f(str, e10.y(), e10.T(), e10.O(), e10.s(), ((Integer) k02.get(i13)).intValue()));
                        i13++;
                    }
                }
                nVar2 = nVar;
                i10++;
                nVar3 = nVar2;
            }
            if (this.f13882d.r() != null) {
                Collections.addAll(this.f13883e, this.f13882d.r());
            }
            this.f13882d.L(this.f13883e);
        }
        Typeface c10 = this.f13882d.c();
        if (c10 != null) {
            this.f13880b.setTypeface(c10);
        }
        this.f13880b.setTextSize(this.f13882d.b());
        this.f13880b.setColor(this.f13882d.a());
        this.f13882d.l(this.f13880b, this.f13928a);
    }

    /* access modifiers changed from: protected */
    public void b(Canvas canvas, float f10, float f11, f fVar, e eVar) {
        float f12;
        float f13;
        int i10 = fVar.f20300f;
        if (i10 != 1122868 && i10 != 1122867 && i10 != 0) {
            int save = canvas.save();
            e.c cVar = fVar.f20296b;
            if (cVar == e.c.DEFAULT) {
                cVar = eVar.s();
            }
            this.f13881c.setColor(fVar.f20300f);
            if (Float.isNaN(fVar.f20297c)) {
                f12 = eVar.v();
            } else {
                f12 = fVar.f20297c;
            }
            float e10 = jb.i.e(f12);
            float f14 = e10 / 2.0f;
            int i11 = a.f13889d[cVar.ordinal()];
            if (i11 == 3 || i11 == 4) {
                this.f13881c.setStyle(Paint.Style.FILL);
                canvas.drawCircle(f10 + f14, f11, f14, this.f13881c);
            } else if (i11 == 5) {
                this.f13881c.setStyle(Paint.Style.FILL);
                canvas.drawRect(f10, f11 - f14, f10 + e10, f11 + f14, this.f13881c);
            } else if (i11 == 6) {
                if (Float.isNaN(fVar.f20298d)) {
                    f13 = eVar.u();
                } else {
                    f13 = fVar.f20298d;
                }
                float e11 = jb.i.e(f13);
                DashPathEffect dashPathEffect = fVar.f20299e;
                if (dashPathEffect == null) {
                    dashPathEffect = eVar.t();
                }
                this.f13881c.setStyle(Paint.Style.STROKE);
                this.f13881c.setStrokeWidth(e11);
                this.f13881c.setPathEffect(dashPathEffect);
                this.f13885g.reset();
                this.f13885g.moveTo(f10, f11);
                this.f13885g.lineTo(f10 + e10, f11);
                canvas.drawPath(this.f13885g, this.f13881c);
            }
            canvas.restoreToCount(save);
        }
    }

    /* access modifiers changed from: protected */
    public void c(Canvas canvas, float f10, float f11, String str) {
        canvas.drawText(str, f10, f11, this.f13880b);
    }

    public Paint d() {
        return this.f13880b;
    }

    public void e(Canvas canvas) {
        float f10;
        float f11;
        float f12;
        float f13;
        float f14;
        List list;
        List list2;
        int i10;
        float f15;
        float f16;
        float f17;
        float f18;
        float f19;
        float f20;
        float f21;
        float f22;
        float f23;
        float f24;
        e.b bVar;
        f fVar;
        float f25;
        float f26;
        float f27;
        float f28;
        double d10;
        Canvas canvas2 = canvas;
        if (this.f13882d.f()) {
            Typeface c10 = this.f13882d.c();
            if (c10 != null) {
                this.f13880b.setTypeface(c10);
            }
            this.f13880b.setTextSize(this.f13882d.b());
            this.f13880b.setColor(this.f13882d.a());
            float n10 = jb.i.n(this.f13880b, this.f13884f);
            float p10 = jb.i.p(this.f13880b, this.f13884f) + jb.i.e(this.f13882d.F());
            float a10 = n10 - (((float) jb.i.a(this.f13880b, "ABC")) / 2.0f);
            f[] q10 = this.f13882d.q();
            float e10 = jb.i.e(this.f13882d.w());
            float e11 = jb.i.e(this.f13882d.E());
            e.C0303e B = this.f13882d.B();
            e.d x10 = this.f13882d.x();
            e.f D = this.f13882d.D();
            e.b p11 = this.f13882d.p();
            float e12 = jb.i.e(this.f13882d.v());
            float e13 = jb.i.e(this.f13882d.C());
            float e14 = this.f13882d.e();
            float d11 = this.f13882d.d();
            int i11 = a.f13886a[x10.ordinal()];
            float f29 = e13;
            float f30 = e11;
            if (i11 == 1) {
                f11 = n10;
                f10 = p10;
                if (B != e.C0303e.VERTICAL) {
                    d11 += this.f13928a.h();
                }
                f12 = p11 == e.b.RIGHT_TO_LEFT ? d11 + this.f13882d.f20272x : d11;
            } else if (i11 == 2) {
                f11 = n10;
                f10 = p10;
                if (B == e.C0303e.VERTICAL) {
                    f27 = this.f13928a.n();
                } else {
                    f27 = this.f13928a.i();
                }
                f12 = f27 - d11;
                if (p11 == e.b.LEFT_TO_RIGHT) {
                    f12 -= this.f13882d.f20272x;
                }
            } else if (i11 != 3) {
                f11 = n10;
                f10 = p10;
                f12 = 0.0f;
            } else {
                e.C0303e eVar = e.C0303e.VERTICAL;
                if (B == eVar) {
                    f28 = this.f13928a.n() / 2.0f;
                } else {
                    f28 = this.f13928a.h() + (this.f13928a.k() / 2.0f);
                }
                e.b bVar2 = e.b.LEFT_TO_RIGHT;
                f10 = p10;
                f12 = f28 + (p11 == bVar2 ? d11 : -d11);
                if (B == eVar) {
                    double d12 = (double) f12;
                    if (p11 == bVar2) {
                        f11 = n10;
                        d10 = (((double) (-this.f13882d.f20272x)) / 2.0d) + ((double) d11);
                    } else {
                        f11 = n10;
                        d10 = (((double) this.f13882d.f20272x) / 2.0d) - ((double) d11);
                    }
                    f12 = (float) (d12 + d10);
                } else {
                    f11 = n10;
                }
            }
            int i12 = a.f13888c[B.ordinal()];
            if (i12 == 1) {
                Canvas canvas3 = canvas;
                float f31 = f12;
                float f32 = a10;
                float f33 = f29;
                e.b bVar3 = p11;
                List o10 = this.f13882d.o();
                List n11 = this.f13882d.n();
                List m10 = this.f13882d.m();
                int i13 = a.f13887b[D.ordinal()];
                if (i13 != 1) {
                    if (i13 == 2) {
                        e14 = (this.f13928a.m() - e14) - this.f13882d.f20273y;
                    } else if (i13 != 3) {
                        e14 = 0.0f;
                    } else {
                        e14 += (this.f13928a.m() - this.f13882d.f20273y) / 2.0f;
                    }
                }
                int length = q10.length;
                float f34 = f31;
                int i14 = 0;
                int i15 = 0;
                while (i14 < length) {
                    float f35 = f33;
                    f fVar2 = q10[i14];
                    float f36 = f34;
                    int i16 = length;
                    boolean z10 = fVar2.f20296b != e.c.NONE;
                    float e15 = Float.isNaN(fVar2.f20297c) ? e12 : jb.i.e(fVar2.f20297c);
                    if (i14 >= m10.size() || !((Boolean) m10.get(i14)).booleanValue()) {
                        f14 = f36;
                        f13 = e14;
                    } else {
                        f13 = e14 + f11 + f10;
                        f14 = f31;
                    }
                    if (f14 == f31 && x10 == e.d.CENTER && i15 < o10.size()) {
                        if (bVar3 == e.b.RIGHT_TO_LEFT) {
                            f19 = ((b) o10.get(i15)).f14938x;
                        } else {
                            f19 = -((b) o10.get(i15)).f14938x;
                        }
                        f14 += f19 / 2.0f;
                        i15++;
                    }
                    int i17 = i15;
                    boolean z11 = fVar2.f20295a == null;
                    if (z10) {
                        if (bVar3 == e.b.RIGHT_TO_LEFT) {
                            f14 -= e15;
                        }
                        float f37 = f14;
                        list2 = o10;
                        i10 = i14;
                        list = m10;
                        b(canvas, f37, f13 + f32, fVar2, this.f13882d);
                        f14 = bVar3 == e.b.LEFT_TO_RIGHT ? f37 + e15 : f37;
                    } else {
                        list = m10;
                        list2 = o10;
                        i10 = i14;
                    }
                    if (!z11) {
                        if (z10) {
                            f14 += bVar3 == e.b.RIGHT_TO_LEFT ? -e10 : e10;
                        }
                        e.b bVar4 = e.b.RIGHT_TO_LEFT;
                        if (bVar3 == bVar4) {
                            f14 -= ((b) n11.get(i10)).f14938x;
                        }
                        c(canvas3, f14, f13 + f11, fVar2.f20295a);
                        if (bVar3 == e.b.LEFT_TO_RIGHT) {
                            f14 += ((b) n11.get(i10)).f14938x;
                        }
                        if (bVar3 == bVar4) {
                            f16 = f30;
                            f18 = -f16;
                        } else {
                            f16 = f30;
                            f18 = f16;
                        }
                        f34 = f14 + f18;
                        f15 = f35;
                    } else {
                        f16 = f30;
                        if (bVar3 == e.b.RIGHT_TO_LEFT) {
                            f15 = f35;
                            f17 = -f15;
                        } else {
                            f15 = f35;
                            f17 = f15;
                        }
                        f34 = f14 + f17;
                    }
                    f30 = f16;
                    f33 = f15;
                    i14 = i10 + 1;
                    e14 = f13;
                    length = i16;
                    i15 = i17;
                    o10 = list2;
                    m10 = list;
                }
            } else if (i12 == 2) {
                int i18 = a.f13887b[D.ordinal()];
                if (i18 == 1) {
                    if (x10 == e.d.CENTER) {
                        f25 = 0.0f;
                    } else {
                        f25 = this.f13928a.j();
                    }
                    f20 = f25 + e14;
                } else if (i18 == 2) {
                    if (x10 == e.d.CENTER) {
                        f26 = this.f13928a.m();
                    } else {
                        f26 = this.f13928a.f();
                    }
                    f20 = f26 - (this.f13882d.f20273y + e14);
                } else if (i18 != 3) {
                    f20 = 0.0f;
                } else {
                    e eVar2 = this.f13882d;
                    f20 = ((this.f13928a.m() / 2.0f) - (eVar2.f20273y / 2.0f)) + eVar2.e();
                }
                float f38 = f20;
                boolean z12 = false;
                int i19 = 0;
                float f39 = 0.0f;
                while (i19 < q10.length) {
                    f fVar3 = q10[i19];
                    boolean z13 = fVar3.f20296b != e.c.NONE;
                    float e16 = Float.isNaN(fVar3.f20297c) ? e12 : jb.i.e(fVar3.f20297c);
                    if (z13) {
                        e.b bVar5 = e.b.LEFT_TO_RIGHT;
                        f23 = p11 == bVar5 ? f12 + f39 : f12 - (e16 - f39);
                        e.b bVar6 = bVar5;
                        float f40 = f38 + a10;
                        f22 = a10;
                        f24 = f29;
                        f fVar4 = fVar3;
                        f21 = f12;
                        bVar = p11;
                        b(canvas, f23, f40, fVar3, this.f13882d);
                        if (bVar == bVar6) {
                            f23 += e16;
                        }
                        fVar = fVar4;
                    } else {
                        f21 = f12;
                        f22 = a10;
                        f24 = f29;
                        bVar = p11;
                        fVar = fVar3;
                        f23 = f21;
                    }
                    String str = fVar.f20295a;
                    if (str != null) {
                        if (z13 && !z12) {
                            f23 += bVar == e.b.LEFT_TO_RIGHT ? e10 : -e10;
                        } else if (z12) {
                            f23 = f21;
                        }
                        if (bVar == e.b.RIGHT_TO_LEFT) {
                            f23 -= (float) jb.i.d(this.f13880b, str);
                        }
                        float f41 = f23;
                        if (!z12) {
                            c(canvas, f41, f38 + f11, fVar.f20295a);
                        } else {
                            f38 += f11 + f10;
                            c(canvas, f41, f38 + f11, fVar.f20295a);
                        }
                        f38 += f11 + f10;
                        f39 = 0.0f;
                    } else {
                        Canvas canvas4 = canvas;
                        f39 += e16 + f24;
                        z12 = true;
                    }
                    i19++;
                    p11 = bVar;
                    f29 = f24;
                    a10 = f22;
                    f12 = f21;
                }
            }
        }
    }
}
