package hb;

import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import bb.d;
import db.e;
import jb.i;
import jb.j;
import wa.a;

public abstract class g extends o {

    /* renamed from: b  reason: collision with root package name */
    protected a f13874b;

    /* renamed from: c  reason: collision with root package name */
    protected Paint f13875c;

    /* renamed from: d  reason: collision with root package name */
    protected Paint f13876d;

    /* renamed from: e  reason: collision with root package name */
    protected Paint f13877e = new Paint(4);

    /* renamed from: f  reason: collision with root package name */
    protected Paint f13878f;

    public g(a aVar, j jVar) {
        super(jVar);
        this.f13874b = aVar;
        Paint paint = new Paint(1);
        this.f13875c = paint;
        paint.setStyle(Paint.Style.FILL);
        Paint paint2 = new Paint(1);
        this.f13878f = paint2;
        paint2.setColor(Color.rgb(63, 63, 63));
        this.f13878f.setTextAlign(Paint.Align.CENTER);
        this.f13878f.setTextSize(i.e(9.0f));
        Paint paint3 = new Paint(1);
        this.f13876d = paint3;
        paint3.setStyle(Paint.Style.STROKE);
        this.f13876d.setStrokeWidth(2.0f);
        this.f13876d.setColor(Color.rgb(255, 187, 115));
    }

    /* access modifiers changed from: protected */
    public void a(e eVar) {
        this.f13878f.setTypeface(eVar.b0());
        this.f13878f.setTextSize(eVar.K());
    }

    public abstract void b(Canvas canvas);

    public abstract void c(Canvas canvas);

    public abstract void d(Canvas canvas, d[] dVarArr);

    public abstract void e(Canvas canvas);

    public abstract void f();

    /* access modifiers changed from: protected */
    public boolean g(cb.e eVar) {
        if (((float) eVar.getData().h()) < ((float) eVar.getMaxVisibleCount()) * this.f13928a.r()) {
            return true;
        }
        return false;
    }
}
