package hb;

import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.drawable.Drawable;
import cb.c;
import hb.c;
import java.util.List;
import jb.e;
import jb.g;
import jb.i;
import jb.j;
import wa.a;
import za.h;

public class d extends c {

    /* renamed from: h  reason: collision with root package name */
    protected c f13860h;

    /* renamed from: i  reason: collision with root package name */
    private float[] f13861i = new float[4];

    /* renamed from: j  reason: collision with root package name */
    private float[] f13862j = new float[2];

    /* renamed from: k  reason: collision with root package name */
    private float[] f13863k = new float[3];

    public d(c cVar, a aVar, j jVar) {
        super(aVar, jVar);
        this.f13860h = cVar;
        this.f13875c.setStyle(Paint.Style.FILL);
        this.f13876d.setStyle(Paint.Style.STROKE);
        this.f13876d.setStrokeWidth(i.e(1.5f));
    }

    public void b(Canvas canvas) {
        for (db.c cVar : this.f13860h.getBubbleData().g()) {
            if (cVar.isVisible()) {
                j(canvas, cVar);
            }
        }
    }

    public void c(Canvas canvas) {
    }

    public void d(Canvas canvas, bb.d[] dVarArr) {
        h bubbleData = this.f13860h.getBubbleData();
        float e10 = this.f13874b.e();
        for (bb.d dVar : dVarArr) {
            db.c cVar = (db.c) bubbleData.e(dVar.d());
            if (cVar != null && cVar.M0()) {
                za.j jVar = (za.j) cVar.t(dVar.h(), dVar.j());
                if (jVar.c() == dVar.j() && h(jVar, cVar)) {
                    g e11 = this.f13860h.e(cVar.G0());
                    float[] fArr = this.f13861i;
                    fArr[0] = 0.0f;
                    fArr[2] = 1.0f;
                    e11.k(fArr);
                    boolean c10 = cVar.c();
                    float[] fArr2 = this.f13861i;
                    float min = Math.min(Math.abs(this.f13928a.f() - this.f13928a.j()), Math.abs(fArr2[2] - fArr2[0]));
                    this.f13862j[0] = jVar.f();
                    this.f13862j[1] = jVar.c() * e10;
                    e11.k(this.f13862j);
                    float[] fArr3 = this.f13862j;
                    dVar.m(fArr3[0], fArr3[1]);
                    float l10 = l(jVar.h(), cVar.Y(), min, c10) / 2.0f;
                    if (this.f13928a.D(this.f13862j[1] + l10) && this.f13928a.A(this.f13862j[1] - l10) && this.f13928a.B(this.f13862j[0] + l10)) {
                        if (this.f13928a.C(this.f13862j[0] - l10)) {
                            int V = cVar.V((int) jVar.f());
                            Color.RGBToHSV(Color.red(V), Color.green(V), Color.blue(V), this.f13863k);
                            float[] fArr4 = this.f13863k;
                            fArr4[2] = fArr4[2] * 0.5f;
                            this.f13876d.setColor(Color.HSVToColor(Color.alpha(V), this.f13863k));
                            this.f13876d.setStrokeWidth(cVar.y0());
                            float[] fArr5 = this.f13862j;
                            canvas.drawCircle(fArr5[0], fArr5[1], l10, this.f13876d);
                        } else {
                            return;
                        }
                    }
                }
            }
            Canvas canvas2 = canvas;
        }
    }

    public void e(Canvas canvas) {
        float f10;
        int i10;
        float f11;
        za.j jVar;
        float f12;
        h bubbleData = this.f13860h.getBubbleData();
        if (bubbleData != null && g(this.f13860h)) {
            List g10 = bubbleData.g();
            float a10 = (float) i.a(this.f13878f, "1");
            for (int i11 = 0; i11 < g10.size(); i11++) {
                db.c cVar = (db.c) g10.get(i11);
                if (i(cVar) && cVar.I0() >= 1) {
                    a(cVar);
                    float max = Math.max(0.0f, Math.min(1.0f, this.f13874b.d()));
                    float e10 = this.f13874b.e();
                    this.f13855g.a(this.f13860h, cVar);
                    g e11 = this.f13860h.e(cVar.G0());
                    c.a aVar = this.f13855g;
                    float[] a11 = e11.a(cVar, e10, aVar.f13856a, aVar.f13857b);
                    if (max == 1.0f) {
                        f10 = e10;
                    } else {
                        f10 = max;
                    }
                    ab.h L = cVar.L();
                    e d10 = e.d(cVar.J0());
                    d10.f14944x = i.e(d10.f14944x);
                    d10.f14945y = i.e(d10.f14945y);
                    for (int i12 = 0; i12 < a11.length; i12 = i10 + 2) {
                        int i13 = i12 / 2;
                        int f02 = cVar.f0(this.f13855g.f13856a + i13);
                        int argb = Color.argb(Math.round(255.0f * f10), Color.red(f02), Color.green(f02), Color.blue(f02));
                        float f13 = a11[i12];
                        float f14 = a11[i12 + 1];
                        if (!this.f13928a.C(f13)) {
                            break;
                        }
                        if (!this.f13928a.B(f13) || !this.f13928a.F(f14)) {
                            i10 = i12;
                        } else {
                            za.j jVar2 = (za.j) cVar.P(i13 + this.f13855g.f13856a);
                            if (cVar.B0()) {
                                float f15 = f14 + (0.5f * a10);
                                jVar = jVar2;
                                f12 = f14;
                                float f16 = f13;
                                f11 = f13;
                                float f17 = f15;
                                i10 = i12;
                                k(canvas, L.d(jVar2), f16, f17, argb);
                            } else {
                                jVar = jVar2;
                                f12 = f14;
                                f11 = f13;
                                i10 = i12;
                            }
                            if (jVar.b() != null && cVar.x()) {
                                Drawable b10 = jVar.b();
                                i.f(canvas, b10, (int) (f11 + d10.f14944x), (int) (f12 + d10.f14945y), b10.getIntrinsicWidth(), b10.getIntrinsicHeight());
                            }
                        }
                    }
                    e.h(d10);
                }
            }
        }
    }

    public void f() {
    }

    /* access modifiers changed from: protected */
    public void j(Canvas canvas, db.c cVar) {
        if (cVar.I0() >= 1) {
            g e10 = this.f13860h.e(cVar.G0());
            float e11 = this.f13874b.e();
            this.f13855g.a(this.f13860h, cVar);
            float[] fArr = this.f13861i;
            fArr[0] = 0.0f;
            fArr[2] = 1.0f;
            e10.k(fArr);
            boolean c10 = cVar.c();
            float[] fArr2 = this.f13861i;
            float min = Math.min(Math.abs(this.f13928a.f() - this.f13928a.j()), Math.abs(fArr2[2] - fArr2[0]));
            int i10 = this.f13855g.f13856a;
            while (true) {
                c.a aVar = this.f13855g;
                if (i10 <= aVar.f13858c + aVar.f13856a) {
                    za.j jVar = (za.j) cVar.P(i10);
                    this.f13862j[0] = jVar.f();
                    this.f13862j[1] = jVar.c() * e11;
                    e10.k(this.f13862j);
                    float l10 = l(jVar.h(), cVar.Y(), min, c10) / 2.0f;
                    if (this.f13928a.D(this.f13862j[1] + l10) && this.f13928a.A(this.f13862j[1] - l10) && this.f13928a.B(this.f13862j[0] + l10)) {
                        if (this.f13928a.C(this.f13862j[0] - l10)) {
                            this.f13875c.setColor(cVar.V((int) jVar.f()));
                            float[] fArr3 = this.f13862j;
                            canvas.drawCircle(fArr3[0], fArr3[1], l10, this.f13875c);
                        } else {
                            return;
                        }
                    }
                    i10++;
                } else {
                    return;
                }
            }
        }
    }

    public void k(Canvas canvas, String str, float f10, float f11, int i10) {
        this.f13878f.setColor(i10);
        canvas.drawText(str, f10, f11, this.f13878f);
    }

    /* access modifiers changed from: protected */
    public float l(float f10, float f11, float f12, boolean z10) {
        if (z10) {
            if (f11 == 0.0f) {
                f10 = 1.0f;
            } else {
                f10 = (float) Math.sqrt((double) (f10 / f11));
            }
        }
        return f12 * f10;
    }
}
