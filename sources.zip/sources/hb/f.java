package hb;

import android.graphics.Canvas;
import bb.d;
import com.github.mikephil.charting.charts.Chart;
import com.github.mikephil.charting.charts.CombinedChart;
import java.lang.ref.WeakReference;
import java.util.ArrayList;
import java.util.List;
import jb.j;
import za.o;

public class f extends g {

    /* renamed from: g  reason: collision with root package name */
    protected List f13870g = new ArrayList(5);

    /* renamed from: h  reason: collision with root package name */
    protected WeakReference f13871h;

    /* renamed from: i  reason: collision with root package name */
    protected List f13872i = new ArrayList();

    static /* synthetic */ class a {

        /* renamed from: a  reason: collision with root package name */
        static final /* synthetic */ int[] f13873a;

        /* JADX WARNING: Can't wrap try/catch for region: R(12:0|1|2|3|4|5|6|7|8|9|10|12) */
        /* JADX WARNING: Code restructure failed: missing block: B:13:?, code lost:
            return;
         */
        /* JADX WARNING: Failed to process nested try/catch */
        /* JADX WARNING: Missing exception handler attribute for start block: B:3:0x0012 */
        /* JADX WARNING: Missing exception handler attribute for start block: B:5:0x001d */
        /* JADX WARNING: Missing exception handler attribute for start block: B:7:0x0028 */
        /* JADX WARNING: Missing exception handler attribute for start block: B:9:0x0033 */
        static {
            /*
                com.github.mikephil.charting.charts.CombinedChart$a[] r0 = com.github.mikephil.charting.charts.CombinedChart.a.values()
                int r0 = r0.length
                int[] r0 = new int[r0]
                f13873a = r0
                com.github.mikephil.charting.charts.CombinedChart$a r1 = com.github.mikephil.charting.charts.CombinedChart.a.BAR     // Catch:{ NoSuchFieldError -> 0x0012 }
                int r1 = r1.ordinal()     // Catch:{ NoSuchFieldError -> 0x0012 }
                r2 = 1
                r0[r1] = r2     // Catch:{ NoSuchFieldError -> 0x0012 }
            L_0x0012:
                int[] r0 = f13873a     // Catch:{ NoSuchFieldError -> 0x001d }
                com.github.mikephil.charting.charts.CombinedChart$a r1 = com.github.mikephil.charting.charts.CombinedChart.a.BUBBLE     // Catch:{ NoSuchFieldError -> 0x001d }
                int r1 = r1.ordinal()     // Catch:{ NoSuchFieldError -> 0x001d }
                r2 = 2
                r0[r1] = r2     // Catch:{ NoSuchFieldError -> 0x001d }
            L_0x001d:
                int[] r0 = f13873a     // Catch:{ NoSuchFieldError -> 0x0028 }
                com.github.mikephil.charting.charts.CombinedChart$a r1 = com.github.mikephil.charting.charts.CombinedChart.a.LINE     // Catch:{ NoSuchFieldError -> 0x0028 }
                int r1 = r1.ordinal()     // Catch:{ NoSuchFieldError -> 0x0028 }
                r2 = 3
                r0[r1] = r2     // Catch:{ NoSuchFieldError -> 0x0028 }
            L_0x0028:
                int[] r0 = f13873a     // Catch:{ NoSuchFieldError -> 0x0033 }
                com.github.mikephil.charting.charts.CombinedChart$a r1 = com.github.mikephil.charting.charts.CombinedChart.a.CANDLE     // Catch:{ NoSuchFieldError -> 0x0033 }
                int r1 = r1.ordinal()     // Catch:{ NoSuchFieldError -> 0x0033 }
                r2 = 4
                r0[r1] = r2     // Catch:{ NoSuchFieldError -> 0x0033 }
            L_0x0033:
                int[] r0 = f13873a     // Catch:{ NoSuchFieldError -> 0x003e }
                com.github.mikephil.charting.charts.CombinedChart$a r1 = com.github.mikephil.charting.charts.CombinedChart.a.SCATTER     // Catch:{ NoSuchFieldError -> 0x003e }
                int r1 = r1.ordinal()     // Catch:{ NoSuchFieldError -> 0x003e }
                r2 = 5
                r0[r1] = r2     // Catch:{ NoSuchFieldError -> 0x003e }
            L_0x003e:
                return
            */
            throw new UnsupportedOperationException("Method not decompiled: hb.f.a.<clinit>():void");
        }
    }

    public f(CombinedChart combinedChart, wa.a aVar, j jVar) {
        super(aVar, jVar);
        this.f13871h = new WeakReference(combinedChart);
        h();
    }

    public void b(Canvas canvas) {
        for (g b10 : this.f13870g) {
            b10.b(canvas);
        }
    }

    public void c(Canvas canvas) {
        for (g c10 : this.f13870g) {
            c10.c(canvas);
        }
    }

    public void d(Canvas canvas, d[] dVarArr) {
        Object obj;
        int i10;
        Chart chart = (Chart) this.f13871h.get();
        if (chart != null) {
            for (g gVar : this.f13870g) {
                if (gVar instanceof b) {
                    obj = ((b) gVar).f13849h.getBarData();
                } else if (gVar instanceof j) {
                    obj = ((j) gVar).f13890i.getLineData();
                } else if (gVar instanceof e) {
                    obj = ((e) gVar).f13864i.getCandleData();
                } else if (gVar instanceof p) {
                    obj = ((p) gVar).f13929i.getScatterData();
                } else if (gVar instanceof d) {
                    obj = ((d) gVar).f13860h.getBubbleData();
                } else {
                    obj = null;
                }
                if (obj == null) {
                    i10 = -1;
                } else {
                    i10 = ((o) chart.getData()).t().indexOf(obj);
                }
                this.f13872i.clear();
                for (d dVar : dVarArr) {
                    if (dVar.c() == i10 || dVar.c() == -1) {
                        this.f13872i.add(dVar);
                    }
                }
                List list = this.f13872i;
                gVar.d(canvas, (d[]) list.toArray(new d[list.size()]));
            }
        }
    }

    public void e(Canvas canvas) {
        for (g e10 : this.f13870g) {
            e10.e(canvas);
        }
    }

    public void f() {
        for (g f10 : this.f13870g) {
            f10.f();
        }
    }

    public void h() {
        this.f13870g.clear();
        CombinedChart combinedChart = (CombinedChart) this.f13871h.get();
        if (combinedChart != null) {
            for (CombinedChart.a ordinal : combinedChart.getDrawOrder()) {
                int i10 = a.f13873a[ordinal.ordinal()];
                if (i10 != 1) {
                    if (i10 != 2) {
                        if (i10 != 3) {
                            if (i10 != 4) {
                                if (i10 == 5 && combinedChart.getScatterData() != null) {
                                    this.f13870g.add(new p(combinedChart, this.f13874b, this.f13928a));
                                }
                            } else if (combinedChart.getCandleData() != null) {
                                this.f13870g.add(new e(combinedChart, this.f13874b, this.f13928a));
                            }
                        } else if (combinedChart.getLineData() != null) {
                            this.f13870g.add(new j(combinedChart, this.f13874b, this.f13928a));
                        }
                    } else if (combinedChart.getBubbleData() != null) {
                        this.f13870g.add(new d(combinedChart, this.f13874b, this.f13928a));
                    }
                } else if (combinedChart.getBarData() != null) {
                    this.f13870g.add(new b(combinedChart, this.f13874b, this.f13928a));
                }
            }
        }
    }
}
