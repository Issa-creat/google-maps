package hb;

import android.graphics.Paint;
import jb.d;
import jb.g;
import jb.i;
import jb.j;

public abstract class a extends o {

    /* renamed from: b  reason: collision with root package name */
    protected ya.a f13843b;

    /* renamed from: c  reason: collision with root package name */
    protected g f13844c;

    /* renamed from: d  reason: collision with root package name */
    protected Paint f13845d;

    /* renamed from: e  reason: collision with root package name */
    protected Paint f13846e;

    /* renamed from: f  reason: collision with root package name */
    protected Paint f13847f;

    /* renamed from: g  reason: collision with root package name */
    protected Paint f13848g;

    public a(j jVar, g gVar, ya.a aVar) {
        super(jVar);
        this.f13844c = gVar;
        this.f13843b = aVar;
        if (this.f13928a != null) {
            this.f13846e = new Paint(1);
            Paint paint = new Paint();
            this.f13845d = paint;
            paint.setColor(-7829368);
            this.f13845d.setStrokeWidth(1.0f);
            this.f13845d.setStyle(Paint.Style.STROKE);
            this.f13845d.setAlpha(90);
            Paint paint2 = new Paint();
            this.f13847f = paint2;
            paint2.setColor(-16777216);
            this.f13847f.setStrokeWidth(1.0f);
            this.f13847f.setStyle(Paint.Style.STROKE);
            Paint paint3 = new Paint(1);
            this.f13848g = paint3;
            paint3.setStyle(Paint.Style.STROKE);
        }
    }

    public void a(float f10, float f11, boolean z10) {
        float f12;
        double d10;
        j jVar = this.f13928a;
        if (jVar != null && jVar.k() > 10.0f && !this.f13928a.y()) {
            d g10 = this.f13844c.g(this.f13928a.h(), this.f13928a.j());
            d g11 = this.f13844c.g(this.f13928a.h(), this.f13928a.f());
            if (!z10) {
                f12 = (float) g11.f14942y;
                d10 = g10.f14942y;
            } else {
                f12 = (float) g10.f14942y;
                d10 = g11.f14942y;
            }
            d.c(g10);
            d.c(g11);
            f10 = f12;
            f11 = (float) d10;
        }
        b(f10, f11);
    }

    /* access modifiers changed from: protected */
    public void b(float f10, float f11) {
        double d10;
        double d11;
        float f12 = f10;
        float f13 = f11;
        int w10 = this.f13843b.w();
        double abs = (double) Math.abs(f13 - f12);
        if (w10 == 0 || abs <= 0.0d || Double.isInfinite(abs)) {
            ya.a aVar = this.f13843b;
            aVar.f20231l = new float[0];
            aVar.f20232m = new float[0];
            aVar.f20233n = 0;
            return;
        }
        double A = (double) i.A(abs / ((double) w10));
        if (this.f13843b.H() && A < ((double) this.f13843b.s())) {
            A = (double) this.f13843b.s();
        }
        double A2 = (double) i.A(Math.pow(10.0d, (double) ((int) Math.log10(A))));
        if (((int) (A / A2)) > 5) {
            A = Math.floor(A2 * 10.0d);
        }
        int A3 = this.f13843b.A();
        if (this.f13843b.G()) {
            A = (double) (((float) abs) / ((float) (w10 - 1)));
            ya.a aVar2 = this.f13843b;
            aVar2.f20233n = w10;
            if (aVar2.f20231l.length < w10) {
                aVar2.f20231l = new float[w10];
            }
            for (int i10 = 0; i10 < w10; i10++) {
                this.f13843b.f20231l[i10] = f12;
                f12 = (float) (((double) f12) + A);
            }
        } else {
            int i11 = (A > 0.0d ? 1 : (A == 0.0d ? 0 : -1));
            if (i11 == 0) {
                d10 = 0.0d;
            } else {
                d10 = Math.ceil(((double) f12) / A) * A;
            }
            if (this.f13843b.A()) {
                d10 -= A;
            }
            if (i11 == 0) {
                d11 = 0.0d;
            } else {
                d11 = i.y(Math.floor(((double) f13) / A) * A);
            }
            if (i11 != 0) {
                for (double d12 = d10; d12 <= d11; d12 += A) {
                    A3++;
                }
            }
            ya.a aVar3 = this.f13843b;
            aVar3.f20233n = A3;
            if (aVar3.f20231l.length < A3) {
                aVar3.f20231l = new float[A3];
            }
            for (int i12 = 0; i12 < A3; i12++) {
                if (d10 == 0.0d) {
                    d10 = 0.0d;
                }
                this.f13843b.f20231l[i12] = (float) d10;
                d10 += A;
            }
            w10 = A3;
        }
        if (A < 1.0d) {
            this.f13843b.f20234o = (int) Math.ceil(-Math.log10(A));
        } else {
            this.f13843b.f20234o = 0;
        }
        if (this.f13843b.A()) {
            ya.a aVar4 = this.f13843b;
            if (aVar4.f20232m.length < w10) {
                aVar4.f20232m = new float[w10];
            }
            float f14 = ((float) A) / 2.0f;
            for (int i13 = 0; i13 < w10; i13++) {
                ya.a aVar5 = this.f13843b;
                aVar5.f20232m[i13] = aVar5.f20231l[i13] + f14;
            }
        }
    }

    public Paint c() {
        return this.f13846e;
    }
}
