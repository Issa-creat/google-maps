package hb;

import cb.b;
import db.e;
import jb.j;
import za.p;
import za.q;

public abstract class c extends g {

    /* renamed from: g  reason: collision with root package name */
    protected a f13855g = new a();

    protected class a {

        /* renamed from: a  reason: collision with root package name */
        public int f13856a;

        /* renamed from: b  reason: collision with root package name */
        public int f13857b;

        /* renamed from: c  reason: collision with root package name */
        public int f13858c;

        protected a() {
        }

        public void a(b bVar, db.b bVar2) {
            int i10;
            float max = Math.max(0.0f, Math.min(1.0f, c.this.f13874b.d()));
            float lowestVisibleX = bVar.getLowestVisibleX();
            float highestVisibleX = bVar.getHighestVisibleX();
            q u10 = bVar2.u(lowestVisibleX, Float.NaN, p.a.DOWN);
            q u11 = bVar2.u(highestVisibleX, Float.NaN, p.a.UP);
            int i11 = 0;
            if (u10 == null) {
                i10 = 0;
            } else {
                i10 = bVar2.r0(u10);
            }
            this.f13856a = i10;
            if (u11 != null) {
                i11 = bVar2.r0(u11);
            }
            this.f13857b = i11;
            this.f13858c = (int) (((float) (i11 - this.f13856a)) * max);
        }
    }

    public c(wa.a aVar, j jVar) {
        super(aVar, jVar);
    }

    /* access modifiers changed from: protected */
    public boolean h(q qVar, db.b bVar) {
        if (qVar != null && ((float) bVar.r0(qVar)) < ((float) bVar.I0()) * this.f13874b.d()) {
            return true;
        }
        return false;
    }

    /* access modifiers changed from: protected */
    public boolean i(e eVar) {
        if (!eVar.isVisible() || (!eVar.B0() && !eVar.x())) {
            return false;
        }
        return true;
    }
}
