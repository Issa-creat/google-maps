package hb;

import android.graphics.Canvas;
import com.github.mikephil.charting.charts.RadarChart;
import jb.e;
import jb.g;
import jb.i;
import jb.j;
import ya.h;
import za.y;

public class s extends q {

    /* renamed from: p  reason: collision with root package name */
    private RadarChart f13941p;

    public s(j jVar, h hVar, RadarChart radarChart) {
        super(jVar, hVar, (g) null);
        this.f13941p = radarChart;
    }

    public void i(Canvas canvas) {
        if (this.f13931h.f() && this.f13931h.E()) {
            float b02 = this.f13931h.b0();
            e c10 = e.c(0.5f, 0.25f);
            this.f13846e.setTypeface(this.f13931h.c());
            this.f13846e.setTextSize(this.f13931h.b());
            this.f13846e.setColor(this.f13931h.a());
            float sliceAngle = this.f13941p.getSliceAngle();
            float factor = this.f13941p.getFactor();
            e centerOffsets = this.f13941p.getCenterOffsets();
            e c11 = e.c(0.0f, 0.0f);
            for (int i10 = 0; i10 < ((db.j) ((y) this.f13941p.getData()).l()).I0(); i10++) {
                float f10 = (float) i10;
                String a10 = this.f13931h.z().a(f10, this.f13931h);
                i.t(centerOffsets, (this.f13941p.getYRange() * factor) + (((float) this.f13931h.L) / 2.0f), ((f10 * sliceAngle) + this.f13941p.getRotationAngle()) % 360.0f, c11);
                f(canvas, a10, c11.f14944x, c11.f14945y - (((float) this.f13931h.M) / 2.0f), c10, b02);
            }
            e.h(centerOffsets);
            e.h(c11);
            e.h(c10);
        }
    }

    public void n(Canvas canvas) {
    }
}
