package hb;

import ab.h;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.drawable.Drawable;
import cb.d;
import hb.c;
import java.util.List;
import jb.g;
import jb.i;
import jb.j;
import wa.a;
import za.k;
import za.m;

public class e extends l {

    /* renamed from: i  reason: collision with root package name */
    protected d f13864i;

    /* renamed from: j  reason: collision with root package name */
    private float[] f13865j = new float[8];

    /* renamed from: k  reason: collision with root package name */
    private float[] f13866k = new float[4];

    /* renamed from: l  reason: collision with root package name */
    private float[] f13867l = new float[4];

    /* renamed from: m  reason: collision with root package name */
    private float[] f13868m = new float[4];

    /* renamed from: n  reason: collision with root package name */
    private float[] f13869n = new float[4];

    public e(d dVar, a aVar, j jVar) {
        super(aVar, jVar);
        this.f13864i = dVar;
    }

    public void b(Canvas canvas) {
        for (db.d dVar : this.f13864i.getCandleData().g()) {
            if (dVar.isVisible()) {
                k(canvas, dVar);
            }
        }
    }

    public void c(Canvas canvas) {
    }

    public void d(Canvas canvas, bb.d[] dVarArr) {
        k candleData = this.f13864i.getCandleData();
        for (bb.d dVar : dVarArr) {
            db.d dVar2 = (db.d) candleData.e(dVar.d());
            if (dVar2 != null && dVar2.M0()) {
                m mVar = (m) dVar2.t(dVar.h(), dVar.j());
                if (h(mVar, dVar2)) {
                    jb.d e10 = this.f13864i.e(dVar2.G0()).e(mVar.f(), ((mVar.j() * this.f13874b.e()) + (mVar.i() * this.f13874b.e())) / 2.0f);
                    dVar.m((float) e10.f14941x, (float) e10.f14942y);
                    j(canvas, (float) e10.f14941x, (float) e10.f14942y, dVar2);
                }
            }
        }
    }

    public void e(Canvas canvas) {
        db.d dVar;
        float f10;
        m mVar;
        if (g(this.f13864i)) {
            List g10 = this.f13864i.getCandleData().g();
            for (int i10 = 0; i10 < g10.size(); i10++) {
                db.d dVar2 = (db.d) g10.get(i10);
                if (i(dVar2) && dVar2.I0() >= 1) {
                    a(dVar2);
                    g e10 = this.f13864i.e(dVar2.G0());
                    this.f13855g.a(this.f13864i, dVar2);
                    float d10 = this.f13874b.d();
                    float e11 = this.f13874b.e();
                    c.a aVar = this.f13855g;
                    float[] b10 = e10.b(dVar2, d10, e11, aVar.f13856a, aVar.f13857b);
                    float e12 = i.e(5.0f);
                    h L = dVar2.L();
                    jb.e d11 = jb.e.d(dVar2.J0());
                    d11.f14944x = i.e(d11.f14944x);
                    d11.f14945y = i.e(d11.f14945y);
                    int i11 = 0;
                    while (i11 < b10.length) {
                        float f11 = b10[i11];
                        float f12 = b10[i11 + 1];
                        if (!this.f13928a.C(f11)) {
                            break;
                        }
                        if (!this.f13928a.B(f11) || !this.f13928a.F(f12)) {
                            dVar = dVar2;
                        } else {
                            int i12 = i11 / 2;
                            m mVar2 = (m) dVar2.P(this.f13855g.f13856a + i12);
                            if (dVar2.B0()) {
                                mVar = mVar2;
                                f10 = f12;
                                float f13 = f12 - e12;
                                dVar = dVar2;
                                l(canvas, L.e(mVar2), f11, f13, dVar2.f0(i12));
                            } else {
                                mVar = mVar2;
                                f10 = f12;
                                dVar = dVar2;
                            }
                            if (mVar.b() != null && dVar.x()) {
                                Drawable b11 = mVar.b();
                                i.f(canvas, b11, (int) (f11 + d11.f14944x), (int) (f10 + d11.f14945y), b11.getIntrinsicWidth(), b11.getIntrinsicHeight());
                            }
                        }
                        i11 += 2;
                        dVar2 = dVar;
                    }
                    jb.e.h(d11);
                }
            }
        }
    }

    public void f() {
    }

    /* access modifiers changed from: protected */
    public void k(Canvas canvas, db.d dVar) {
        int i10;
        int i11;
        int i12;
        int i13;
        int i14;
        db.d dVar2 = dVar;
        g e10 = this.f13864i.e(dVar.G0());
        float e11 = this.f13874b.e();
        float N = dVar.N();
        boolean H0 = dVar.H0();
        this.f13855g.a(this.f13864i, dVar2);
        this.f13875c.setStrokeWidth(dVar.o());
        int i15 = this.f13855g.f13856a;
        while (true) {
            c.a aVar = this.f13855g;
            if (i15 <= aVar.f13858c + aVar.f13856a) {
                m mVar = (m) dVar2.P(i15);
                if (mVar == null) {
                    Canvas canvas2 = canvas;
                } else {
                    float f10 = mVar.f();
                    float k10 = mVar.k();
                    float h10 = mVar.h();
                    float i16 = mVar.i();
                    float j10 = mVar.j();
                    if (H0) {
                        float[] fArr = this.f13865j;
                        fArr[0] = f10;
                        fArr[2] = f10;
                        fArr[4] = f10;
                        fArr[6] = f10;
                        int i17 = (k10 > h10 ? 1 : (k10 == h10 ? 0 : -1));
                        if (i17 > 0) {
                            fArr[1] = i16 * e11;
                            fArr[3] = k10 * e11;
                            fArr[5] = j10 * e11;
                            fArr[7] = h10 * e11;
                        } else if (k10 < h10) {
                            fArr[1] = i16 * e11;
                            fArr[3] = h10 * e11;
                            fArr[5] = j10 * e11;
                            fArr[7] = k10 * e11;
                        } else {
                            fArr[1] = i16 * e11;
                            float f11 = k10 * e11;
                            fArr[3] = f11;
                            fArr[5] = j10 * e11;
                            fArr[7] = f11;
                        }
                        e10.k(fArr);
                        if (!dVar.i0()) {
                            Paint paint = this.f13875c;
                            if (dVar.w0() == 1122867) {
                                i11 = dVar2.V(i15);
                            } else {
                                i11 = dVar.w0();
                            }
                            paint.setColor(i11);
                        } else if (i17 > 0) {
                            Paint paint2 = this.f13875c;
                            if (dVar.R0() == 1122867) {
                                i14 = dVar2.V(i15);
                            } else {
                                i14 = dVar.R0();
                            }
                            paint2.setColor(i14);
                        } else if (k10 < h10) {
                            Paint paint3 = this.f13875c;
                            if (dVar.D0() == 1122867) {
                                i13 = dVar2.V(i15);
                            } else {
                                i13 = dVar.D0();
                            }
                            paint3.setColor(i13);
                        } else {
                            Paint paint4 = this.f13875c;
                            if (dVar.b() == 1122867) {
                                i12 = dVar2.V(i15);
                            } else {
                                i12 = dVar.b();
                            }
                            paint4.setColor(i12);
                        }
                        this.f13875c.setStyle(Paint.Style.STROKE);
                        canvas.drawLines(this.f13865j, this.f13875c);
                        float[] fArr2 = this.f13866k;
                        fArr2[0] = (f10 - 0.5f) + N;
                        fArr2[1] = h10 * e11;
                        fArr2[2] = (f10 + 0.5f) - N;
                        fArr2[3] = k10 * e11;
                        e10.k(fArr2);
                        if (i17 > 0) {
                            if (dVar.R0() == 1122867) {
                                this.f13875c.setColor(dVar2.V(i15));
                            } else {
                                this.f13875c.setColor(dVar.R0());
                            }
                            this.f13875c.setStyle(dVar.J());
                            float[] fArr3 = this.f13866k;
                            canvas.drawRect(fArr3[0], fArr3[3], fArr3[2], fArr3[1], this.f13875c);
                        } else if (k10 < h10) {
                            if (dVar.D0() == 1122867) {
                                this.f13875c.setColor(dVar2.V(i15));
                            } else {
                                this.f13875c.setColor(dVar.D0());
                            }
                            this.f13875c.setStyle(dVar.a0());
                            float[] fArr4 = this.f13866k;
                            canvas.drawRect(fArr4[0], fArr4[1], fArr4[2], fArr4[3], this.f13875c);
                        } else {
                            if (dVar.b() == 1122867) {
                                this.f13875c.setColor(dVar2.V(i15));
                            } else {
                                this.f13875c.setColor(dVar.b());
                            }
                            float[] fArr5 = this.f13866k;
                            canvas.drawLine(fArr5[0], fArr5[1], fArr5[2], fArr5[3], this.f13875c);
                        }
                    } else {
                        Canvas canvas3 = canvas;
                        float[] fArr6 = this.f13867l;
                        fArr6[0] = f10;
                        fArr6[1] = i16 * e11;
                        fArr6[2] = f10;
                        fArr6[3] = j10 * e11;
                        float[] fArr7 = this.f13868m;
                        fArr7[0] = (f10 - 0.5f) + N;
                        float f12 = k10 * e11;
                        fArr7[1] = f12;
                        fArr7[2] = f10;
                        fArr7[3] = f12;
                        float[] fArr8 = this.f13869n;
                        fArr8[0] = (0.5f + f10) - N;
                        float f13 = h10 * e11;
                        fArr8[1] = f13;
                        fArr8[2] = f10;
                        fArr8[3] = f13;
                        e10.k(fArr6);
                        e10.k(this.f13868m);
                        e10.k(this.f13869n);
                        if (k10 > h10) {
                            if (dVar.R0() == 1122867) {
                                i10 = dVar2.V(i15);
                            } else {
                                i10 = dVar.R0();
                            }
                        } else if (k10 < h10) {
                            if (dVar.D0() == 1122867) {
                                i10 = dVar2.V(i15);
                            } else {
                                i10 = dVar.D0();
                            }
                        } else if (dVar.b() == 1122867) {
                            i10 = dVar2.V(i15);
                        } else {
                            i10 = dVar.b();
                        }
                        this.f13875c.setColor(i10);
                        float[] fArr9 = this.f13867l;
                        Canvas canvas4 = canvas;
                        canvas4.drawLine(fArr9[0], fArr9[1], fArr9[2], fArr9[3], this.f13875c);
                        float[] fArr10 = this.f13868m;
                        canvas4.drawLine(fArr10[0], fArr10[1], fArr10[2], fArr10[3], this.f13875c);
                        float[] fArr11 = this.f13869n;
                        canvas4.drawLine(fArr11[0], fArr11[1], fArr11[2], fArr11[3], this.f13875c);
                    }
                }
                i15++;
            } else {
                return;
            }
        }
    }

    public void l(Canvas canvas, String str, float f10, float f11, int i10) {
        this.f13878f.setColor(i10);
        canvas.drawText(str, f10, f11, this.f13878f);
    }
}
