package hb;

import ab.h;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.RectF;
import android.graphics.drawable.Drawable;
import bb.d;
import cb.a;
import java.util.List;
import jb.e;
import jb.g;
import jb.i;
import jb.j;
import za.c;

public class b extends c {

    /* renamed from: h  reason: collision with root package name */
    protected a f13849h;

    /* renamed from: i  reason: collision with root package name */
    protected RectF f13850i = new RectF();

    /* renamed from: j  reason: collision with root package name */
    protected xa.b[] f13851j;

    /* renamed from: k  reason: collision with root package name */
    protected Paint f13852k;

    /* renamed from: l  reason: collision with root package name */
    protected Paint f13853l;

    /* renamed from: m  reason: collision with root package name */
    private RectF f13854m = new RectF();

    public b(a aVar, wa.a aVar2, j jVar) {
        super(aVar2, jVar);
        this.f13849h = aVar;
        Paint paint = new Paint(1);
        this.f13876d = paint;
        paint.setStyle(Paint.Style.FILL);
        this.f13876d.setColor(Color.rgb(0, 0, 0));
        this.f13876d.setAlpha(120);
        Paint paint2 = new Paint(1);
        this.f13852k = paint2;
        paint2.setStyle(Paint.Style.FILL);
        Paint paint3 = new Paint(1);
        this.f13853l = paint3;
        paint3.setStyle(Paint.Style.STROKE);
    }

    public void b(Canvas canvas) {
        za.a barData = this.f13849h.getBarData();
        for (int i10 = 0; i10 < barData.f(); i10++) {
            db.a aVar = (db.a) barData.e(i10);
            if (aVar.isVisible()) {
                j(canvas, aVar, i10);
            }
        }
    }

    public void c(Canvas canvas) {
    }

    public void d(Canvas canvas, d[] dVarArr) {
        boolean z10;
        float f10;
        float f11;
        za.a barData = this.f13849h.getBarData();
        for (d dVar : dVarArr) {
            db.a aVar = (db.a) barData.e(dVar.d());
            if (aVar != null && aVar.M0()) {
                c cVar = (c) aVar.t(dVar.h(), dVar.j());
                if (h(cVar, aVar)) {
                    g e10 = this.f13849h.e(aVar.G0());
                    this.f13876d.setColor(aVar.E0());
                    this.f13876d.setAlpha(aVar.s0());
                    if (dVar.g() < 0 || !cVar.o()) {
                        z10 = false;
                    } else {
                        z10 = true;
                    }
                    if (!z10) {
                        f11 = cVar.c();
                        f10 = 0.0f;
                    } else if (this.f13849h.d()) {
                        float l10 = cVar.l();
                        f10 = -cVar.k();
                        f11 = l10;
                    } else {
                        bb.j jVar = cVar.m()[dVar.g()];
                        f11 = jVar.f8528a;
                        f10 = jVar.f8529b;
                    }
                    l(cVar.f(), f11, f10, barData.t() / 2.0f, e10);
                    m(dVar, this.f13850i);
                    canvas.drawRect(this.f13850i, this.f13876d);
                }
            }
        }
    }

    public void e(Canvas canvas) {
        boolean z10;
        float f10;
        float f11;
        List list;
        boolean z11;
        e eVar;
        int i10;
        float f12;
        boolean z12;
        g gVar;
        float[] fArr;
        float f13;
        int i11;
        int i12;
        c cVar;
        float[] fArr2;
        float f14;
        float f15;
        float f16;
        c cVar2;
        List list2;
        int i13;
        h hVar;
        e eVar2;
        float f17;
        c cVar3;
        if (g(this.f13849h)) {
            List g10 = this.f13849h.getBarData().g();
            float e10 = i.e(4.5f);
            boolean c10 = this.f13849h.c();
            int i14 = 0;
            while (i14 < this.f13849h.getBarData().f()) {
                db.a aVar = (db.a) g10.get(i14);
                if (!i(aVar)) {
                    list = g10;
                    f11 = f10;
                    z11 = z10;
                } else {
                    a(aVar);
                    boolean a10 = this.f13849h.a(aVar.G0());
                    float a11 = (float) i.a(this.f13878f, "8");
                    float f18 = z10 ? -f10 : a11 + f10;
                    float f19 = z10 ? a11 + f10 : -f10;
                    if (a10) {
                        f18 = (-f18) - a11;
                        f19 = (-f19) - a11;
                    }
                    float f20 = f18;
                    float f21 = f19;
                    xa.b bVar = this.f13851j[i14];
                    float e11 = this.f13874b.e();
                    h L = aVar.L();
                    e d10 = e.d(aVar.J0());
                    d10.f14944x = i.e(d10.f14944x);
                    d10.f14945y = i.e(d10.f14945y);
                    if (!aVar.A0()) {
                        int i15 = 0;
                        while (((float) i15) < ((float) bVar.f19465b.length) * this.f13874b.d()) {
                            float[] fArr3 = bVar.f19465b;
                            float f22 = (fArr3[i15] + fArr3[i15 + 2]) / 2.0f;
                            if (!this.f13928a.C(f22)) {
                                break;
                            }
                            int i16 = i15 + 1;
                            if (!this.f13928a.F(bVar.f19465b[i16]) || !this.f13928a.B(f22)) {
                                i13 = i15;
                                hVar = L;
                                list2 = g10;
                                eVar2 = d10;
                            } else {
                                int i17 = i15 / 4;
                                c cVar4 = (c) aVar.P(i17);
                                float c11 = cVar4.c();
                                if (aVar.B0()) {
                                    String b10 = L.b(cVar4);
                                    int i18 = (c11 > 0.0f ? 1 : (c11 == 0.0f ? 0 : -1));
                                    float[] fArr4 = bVar.f19465b;
                                    cVar3 = cVar4;
                                    f17 = f22;
                                    String str = b10;
                                    i13 = i15;
                                    list2 = g10;
                                    eVar2 = d10;
                                    float f23 = i18 >= 0 ? fArr4[i16] + f20 : fArr4[i15 + 3] + f21;
                                    hVar = L;
                                    k(canvas, str, f17, f23, aVar.f0(i17));
                                } else {
                                    cVar3 = cVar4;
                                    f17 = f22;
                                    i13 = i15;
                                    hVar = L;
                                    list2 = g10;
                                    eVar2 = d10;
                                }
                                if (cVar3.b() != null && aVar.x()) {
                                    Drawable b11 = cVar3.b();
                                    i.f(canvas, b11, (int) (f17 + eVar2.f14944x), (int) ((c11 >= 0.0f ? bVar.f19465b[i16] + f20 : bVar.f19465b[i13 + 3] + f21) + eVar2.f14945y), b11.getIntrinsicWidth(), b11.getIntrinsicHeight());
                                }
                            }
                            i15 = i13 + 4;
                            d10 = eVar2;
                            L = hVar;
                            g10 = list2;
                        }
                        list = g10;
                        eVar = d10;
                    } else {
                        h hVar2 = L;
                        list = g10;
                        eVar = d10;
                        g e12 = this.f13849h.e(aVar.G0());
                        int i19 = 0;
                        int i20 = 0;
                        while (((float) i19) < ((float) aVar.I0()) * this.f13874b.d()) {
                            c cVar5 = (c) aVar.P(i19);
                            float[] n10 = cVar5.n();
                            float[] fArr5 = bVar.f19465b;
                            float f24 = (fArr5[i20] + fArr5[i20 + 2]) / 2.0f;
                            int f02 = aVar.f0(i19);
                            if (n10 != null) {
                                c cVar6 = cVar5;
                                i10 = i19;
                                f12 = f10;
                                z12 = z10;
                                fArr = n10;
                                gVar = e12;
                                float f25 = f24;
                                int length = fArr.length * 2;
                                float[] fArr6 = new float[length];
                                float f26 = -cVar6.k();
                                int i21 = 0;
                                int i22 = 0;
                                float f27 = 0.0f;
                                while (i21 < length) {
                                    float f28 = fArr[i22];
                                    int i23 = (f28 > 0.0f ? 1 : (f28 == 0.0f ? 0 : -1));
                                    if (i23 == 0 && (f27 == 0.0f || f26 == 0.0f)) {
                                        float f29 = f26;
                                        f26 = f28;
                                        f15 = f29;
                                    } else if (i23 >= 0) {
                                        f27 += f28;
                                        f15 = f26;
                                        f26 = f27;
                                    } else {
                                        f15 = f26 - f28;
                                    }
                                    fArr6[i21 + 1] = f26 * e11;
                                    i21 += 2;
                                    i22++;
                                    f26 = f15;
                                }
                                gVar.k(fArr6);
                                int i24 = 0;
                                while (i24 < length) {
                                    float f30 = fArr[i24 / 2];
                                    float f31 = fArr6[i24 + 1] + (((f30 > 0.0f ? 1 : (f30 == 0.0f ? 0 : -1)) == 0 && (f26 > 0.0f ? 1 : (f26 == 0.0f ? 0 : -1)) == 0 && (f27 > 0.0f ? 1 : (f27 == 0.0f ? 0 : -1)) > 0) || (f30 > 0.0f ? 1 : (f30 == 0.0f ? 0 : -1)) < 0 ? f21 : f20);
                                    int i25 = i24;
                                    if (!this.f13928a.C(f25)) {
                                        break;
                                    }
                                    if (!this.f13928a.F(f31) || !this.f13928a.B(f25)) {
                                        i11 = length;
                                        f13 = f25;
                                        i12 = i25;
                                        cVar = cVar6;
                                        fArr2 = fArr6;
                                    } else {
                                        if (aVar.B0()) {
                                            c cVar7 = cVar6;
                                            f14 = f31;
                                            i12 = i25;
                                            cVar = cVar7;
                                            fArr2 = fArr6;
                                            i11 = length;
                                            f13 = f25;
                                            k(canvas, hVar2.c(f30, cVar7), f25, f14, f02);
                                        } else {
                                            f14 = f31;
                                            i11 = length;
                                            f13 = f25;
                                            i12 = i25;
                                            cVar = cVar6;
                                            fArr2 = fArr6;
                                        }
                                        if (cVar.b() != null && aVar.x()) {
                                            Drawable b12 = cVar.b();
                                            i.f(canvas, b12, (int) (f13 + eVar.f14944x), (int) (f14 + eVar.f14945y), b12.getIntrinsicWidth(), b12.getIntrinsicHeight());
                                        }
                                    }
                                    i24 = i12 + 2;
                                    fArr6 = fArr2;
                                    cVar6 = cVar;
                                    length = i11;
                                    f25 = f13;
                                }
                            } else if (!this.f13928a.C(f24)) {
                                break;
                            } else {
                                float[] fArr7 = n10;
                                int i26 = i20 + 1;
                                if (!this.f13928a.F(bVar.f19465b[i26]) || !this.f13928a.B(f24)) {
                                    e12 = e12;
                                    z10 = z10;
                                    f10 = f10;
                                    i19 = i19;
                                } else {
                                    if (aVar.B0()) {
                                        f16 = f24;
                                        f12 = f10;
                                        fArr = fArr7;
                                        cVar2 = cVar5;
                                        i10 = i19;
                                        z12 = z10;
                                        gVar = e12;
                                        k(canvas, hVar2.b(cVar5), f16, bVar.f19465b[i26] + (cVar5.c() >= 0.0f ? f20 : f21), f02);
                                    } else {
                                        f16 = f24;
                                        i10 = i19;
                                        f12 = f10;
                                        z12 = z10;
                                        fArr = fArr7;
                                        cVar2 = cVar5;
                                        gVar = e12;
                                    }
                                    if (cVar2.b() != null && aVar.x()) {
                                        Drawable b13 = cVar2.b();
                                        i.f(canvas, b13, (int) (eVar.f14944x + f16), (int) (bVar.f19465b[i26] + (cVar2.c() >= 0.0f ? f20 : f21) + eVar.f14945y), b13.getIntrinsicWidth(), b13.getIntrinsicHeight());
                                    }
                                }
                            }
                            if (fArr == null) {
                                i20 += 4;
                            } else {
                                i20 += fArr.length * 4;
                            }
                            i19 = i10 + 1;
                            e12 = gVar;
                            z10 = z12;
                            f10 = f12;
                        }
                    }
                    f11 = f10;
                    z11 = z10;
                    e.h(eVar);
                }
                i14++;
                c10 = z11;
                g10 = list;
                e10 = f11;
            }
        }
    }

    public void f() {
        int i10;
        za.a barData = this.f13849h.getBarData();
        this.f13851j = new xa.b[barData.f()];
        for (int i11 = 0; i11 < this.f13851j.length; i11++) {
            db.a aVar = (db.a) barData.e(i11);
            xa.b[] bVarArr = this.f13851j;
            int I0 = aVar.I0() * 4;
            if (aVar.A0()) {
                i10 = aVar.l0();
            } else {
                i10 = 1;
            }
            bVarArr[i11] = new xa.b(I0 * i10, barData.f(), aVar.A0());
        }
    }

    /* access modifiers changed from: protected */
    public void j(Canvas canvas, db.a aVar, int i10) {
        boolean z10;
        db.a aVar2 = aVar;
        int i11 = i10;
        g e10 = this.f13849h.e(aVar.G0());
        this.f13853l.setColor(aVar.r());
        this.f13853l.setStrokeWidth(i.e(aVar.A()));
        int i12 = 0;
        boolean z11 = true;
        if (aVar.A() > 0.0f) {
            z10 = true;
        } else {
            z10 = false;
        }
        float d10 = this.f13874b.d();
        float e11 = this.f13874b.e();
        if (this.f13849h.b()) {
            this.f13852k.setColor(aVar.c0());
            float t10 = this.f13849h.getBarData().t() / 2.0f;
            int min = Math.min((int) Math.ceil((double) (((float) aVar.I0()) * d10)), aVar.I0());
            for (int i13 = 0; i13 < min; i13++) {
                float f10 = ((c) aVar2.P(i13)).f();
                RectF rectF = this.f13854m;
                rectF.left = f10 - t10;
                rectF.right = f10 + t10;
                e10.p(rectF);
                if (!this.f13928a.B(this.f13854m.right)) {
                    Canvas canvas2 = canvas;
                } else if (!this.f13928a.C(this.f13854m.left)) {
                    break;
                } else {
                    this.f13854m.top = this.f13928a.j();
                    this.f13854m.bottom = this.f13928a.f();
                    canvas.drawRect(this.f13854m, this.f13852k);
                }
            }
        }
        Canvas canvas3 = canvas;
        xa.b bVar = this.f13851j[i11];
        bVar.b(d10, e11);
        bVar.g(i11);
        bVar.h(this.f13849h.a(aVar.G0()));
        bVar.f(this.f13849h.getBarData().t());
        bVar.e(aVar2);
        e10.k(bVar.f19465b);
        if (aVar.k0().size() != 1) {
            z11 = false;
        }
        if (z11) {
            this.f13875c.setColor(aVar.K0());
        }
        while (i12 < bVar.c()) {
            int i14 = i12 + 2;
            if (this.f13928a.B(bVar.f19465b[i14])) {
                if (this.f13928a.C(bVar.f19465b[i12])) {
                    if (!z11) {
                        this.f13875c.setColor(aVar2.V(i12 / 4));
                    }
                    aVar.G();
                    if (aVar.t0() == null) {
                        float[] fArr = bVar.f19465b;
                        int i15 = i12 + 1;
                        int i16 = i12 + 3;
                        canvas.drawRect(fArr[i12], fArr[i15], fArr[i14], fArr[i16], this.f13875c);
                        if (z10) {
                            float[] fArr2 = bVar.f19465b;
                            canvas.drawRect(fArr2[i12], fArr2[i15], fArr2[i14], fArr2[i16], this.f13853l);
                        }
                    } else {
                        float[] fArr3 = bVar.f19465b;
                        float f11 = fArr3[i12];
                        float f12 = fArr3[i12 + 3];
                        float f13 = fArr3[i12 + 1];
                        aVar2.P0(i12 / 4);
                        throw null;
                    }
                } else {
                    return;
                }
            }
            i12 += 4;
            Canvas canvas4 = canvas;
        }
    }

    public void k(Canvas canvas, String str, float f10, float f11, int i10) {
        this.f13878f.setColor(i10);
        canvas.drawText(str, f10, f11, this.f13878f);
    }

    /* access modifiers changed from: protected */
    public void l(float f10, float f11, float f12, float f13, g gVar) {
        this.f13850i.set(f10 - f13, f11, f10 + f13, f12);
        gVar.n(this.f13850i, this.f13874b.e());
    }

    /* access modifiers changed from: protected */
    public void m(d dVar, RectF rectF) {
        dVar.m(rectF.centerX(), rectF.top);
    }
}
