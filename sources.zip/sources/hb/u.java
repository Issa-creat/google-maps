package hb;

import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.PathEffect;
import android.graphics.RectF;
import java.util.List;
import jb.d;
import jb.g;
import jb.j;
import ya.g;
import ya.i;

public class u extends t {

    /* renamed from: r  reason: collision with root package name */
    protected Path f13952r = new Path();

    /* renamed from: s  reason: collision with root package name */
    protected Path f13953s = new Path();

    /* renamed from: t  reason: collision with root package name */
    protected float[] f13954t = new float[4];

    public u(j jVar, i iVar, g gVar) {
        super(jVar, iVar, gVar);
        this.f13848g.setTextAlign(Paint.Align.LEFT);
    }

    public void a(float f10, float f11, boolean z10) {
        float f12;
        double d10;
        if (this.f13928a.g() > 10.0f && !this.f13928a.x()) {
            d g10 = this.f13844c.g(this.f13928a.h(), this.f13928a.j());
            d g11 = this.f13844c.g(this.f13928a.i(), this.f13928a.j());
            if (!z10) {
                f12 = (float) g10.f14941x;
                d10 = g11.f14941x;
            } else {
                f12 = (float) g11.f14941x;
                d10 = g10.f14941x;
            }
            d.c(g10);
            d.c(g11);
            f10 = f12;
            f11 = (float) d10;
        }
        b(f10, f11);
    }

    /* access modifiers changed from: protected */
    public void d(Canvas canvas, float f10, float[] fArr, float f11) {
        int i10;
        this.f13846e.setTypeface(this.f13942h.c());
        this.f13846e.setTextSize(this.f13942h.b());
        this.f13846e.setColor(this.f13942h.a());
        if (this.f13942h.m0()) {
            i10 = this.f13942h.f20233n;
        } else {
            i10 = this.f13942h.f20233n - 1;
        }
        for (int i11 = !this.f13942h.l0(); i11 < i10; i11++) {
            canvas.drawText(this.f13942h.r(i11), fArr[i11 * 2], f10 - f11, this.f13846e);
        }
    }

    /* access modifiers changed from: protected */
    public void e(Canvas canvas) {
        int save = canvas.save();
        this.f13948n.set(this.f13928a.p());
        this.f13948n.inset(-this.f13942h.k0(), 0.0f);
        canvas.clipRect(this.f13951q);
        d e10 = this.f13844c.e(0.0f, 0.0f);
        this.f13943i.setColor(this.f13942h.j0());
        this.f13943i.setStrokeWidth(this.f13942h.k0());
        Path path = this.f13952r;
        path.reset();
        path.moveTo(((float) e10.f14941x) - 1.0f, this.f13928a.j());
        path.lineTo(((float) e10.f14941x) - 1.0f, this.f13928a.f());
        canvas.drawPath(path, this.f13943i);
        canvas.restoreToCount(save);
    }

    public RectF f() {
        this.f13945k.set(this.f13928a.p());
        this.f13945k.inset(-this.f13843b.v(), 0.0f);
        return this.f13945k;
    }

    /* access modifiers changed from: protected */
    public float[] g() {
        int length = this.f13946l.length;
        int i10 = this.f13942h.f20233n;
        if (length != i10 * 2) {
            this.f13946l = new float[(i10 * 2)];
        }
        float[] fArr = this.f13946l;
        for (int i11 = 0; i11 < fArr.length; i11 += 2) {
            fArr[i11] = this.f13942h.f20231l[i11 / 2];
        }
        this.f13844c.k(fArr);
        return fArr;
    }

    /* access modifiers changed from: protected */
    public Path h(Path path, int i10, float[] fArr) {
        path.moveTo(fArr[i10], this.f13928a.j());
        path.lineTo(fArr[i10], this.f13928a.f());
        return path;
    }

    public void i(Canvas canvas) {
        float f10;
        float f11;
        float f12;
        if (this.f13942h.f() && this.f13942h.E()) {
            float[] g10 = g();
            this.f13846e.setTypeface(this.f13942h.c());
            this.f13846e.setTextSize(this.f13942h.b());
            this.f13846e.setColor(this.f13942h.a());
            this.f13846e.setTextAlign(Paint.Align.CENTER);
            float e10 = jb.i.e(2.5f);
            float a10 = (float) jb.i.a(this.f13846e, "Q");
            i.a b02 = this.f13942h.b0();
            i.b c02 = this.f13942h.c0();
            if (b02 == i.a.LEFT) {
                if (c02 == i.b.OUTSIDE_CHART) {
                    f12 = this.f13928a.j();
                } else {
                    f12 = this.f13928a.j();
                }
                f10 = f12 - e10;
            } else {
                if (c02 == i.b.OUTSIDE_CHART) {
                    f11 = this.f13928a.f();
                } else {
                    f11 = this.f13928a.f();
                }
                f10 = f11 + a10 + e10;
            }
            d(canvas, f10, g10, this.f13942h.e());
        }
    }

    public void j(Canvas canvas) {
        if (this.f13942h.f() && this.f13942h.B()) {
            this.f13847f.setColor(this.f13942h.o());
            this.f13847f.setStrokeWidth(this.f13942h.q());
            if (this.f13942h.b0() == i.a.LEFT) {
                canvas.drawLine(this.f13928a.h(), this.f13928a.j(), this.f13928a.i(), this.f13928a.j(), this.f13847f);
                return;
            }
            canvas.drawLine(this.f13928a.h(), this.f13928a.f(), this.f13928a.i(), this.f13928a.f(), this.f13847f);
        }
    }

    public void l(Canvas canvas) {
        Canvas canvas2 = canvas;
        List x10 = this.f13942h.x();
        if (x10 != null && x10.size() > 0) {
            float[] fArr = this.f13954t;
            float f10 = 0.0f;
            fArr[0] = 0.0f;
            char c10 = 1;
            fArr[1] = 0.0f;
            fArr[2] = 0.0f;
            fArr[3] = 0.0f;
            Path path = this.f13953s;
            path.reset();
            int i10 = 0;
            while (i10 < x10.size()) {
                ya.g gVar = (ya.g) x10.get(i10);
                if (gVar.f()) {
                    int save = canvas.save();
                    this.f13951q.set(this.f13928a.p());
                    this.f13951q.inset(-gVar.r(), f10);
                    canvas2.clipRect(this.f13951q);
                    fArr[0] = gVar.p();
                    fArr[2] = gVar.p();
                    this.f13844c.k(fArr);
                    fArr[c10] = this.f13928a.j();
                    fArr[3] = this.f13928a.f();
                    path.moveTo(fArr[0], fArr[c10]);
                    path.lineTo(fArr[2], fArr[3]);
                    this.f13848g.setStyle(Paint.Style.STROKE);
                    this.f13848g.setColor(gVar.q());
                    this.f13848g.setPathEffect(gVar.m());
                    this.f13848g.setStrokeWidth(gVar.r());
                    canvas2.drawPath(path, this.f13848g);
                    path.reset();
                    String n10 = gVar.n();
                    if (n10 != null && !n10.equals("")) {
                        this.f13848g.setStyle(gVar.s());
                        this.f13848g.setPathEffect((PathEffect) null);
                        this.f13848g.setColor(gVar.a());
                        this.f13848g.setTypeface(gVar.c());
                        this.f13848g.setStrokeWidth(0.5f);
                        this.f13848g.setTextSize(gVar.b());
                        float r10 = gVar.r() + gVar.d();
                        float e10 = jb.i.e(2.0f) + gVar.e();
                        g.a o10 = gVar.o();
                        if (o10 == g.a.RIGHT_TOP) {
                            this.f13848g.setTextAlign(Paint.Align.LEFT);
                            canvas2.drawText(n10, fArr[0] + r10, this.f13928a.j() + e10 + ((float) jb.i.a(this.f13848g, n10)), this.f13848g);
                        } else if (o10 == g.a.RIGHT_BOTTOM) {
                            this.f13848g.setTextAlign(Paint.Align.LEFT);
                            canvas2.drawText(n10, fArr[0] + r10, this.f13928a.f() - e10, this.f13848g);
                        } else if (o10 == g.a.LEFT_TOP) {
                            this.f13848g.setTextAlign(Paint.Align.RIGHT);
                            canvas2.drawText(n10, fArr[0] - r10, this.f13928a.j() + e10 + ((float) jb.i.a(this.f13848g, n10)), this.f13848g);
                        } else {
                            this.f13848g.setTextAlign(Paint.Align.RIGHT);
                            canvas2.drawText(n10, fArr[0] - r10, this.f13928a.f() - e10, this.f13848g);
                        }
                    }
                    canvas2.restoreToCount(save);
                }
                i10++;
                f10 = 0.0f;
                c10 = 1;
            }
        }
    }
}
