package hb;

import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RectF;
import android.text.Layout;
import android.text.StaticLayout;
import android.text.TextPaint;
import bb.d;
import com.github.mikephil.charting.charts.PieChart;
import java.lang.ref.WeakReference;
import jb.e;
import jb.i;
import jb.j;
import wa.a;
import za.v;
import za.x;

public class m extends g {

    /* renamed from: g  reason: collision with root package name */
    protected PieChart f13906g;

    /* renamed from: h  reason: collision with root package name */
    protected Paint f13907h;

    /* renamed from: i  reason: collision with root package name */
    protected Paint f13908i;

    /* renamed from: j  reason: collision with root package name */
    protected Paint f13909j;

    /* renamed from: k  reason: collision with root package name */
    private TextPaint f13910k;

    /* renamed from: l  reason: collision with root package name */
    private Paint f13911l;

    /* renamed from: m  reason: collision with root package name */
    private StaticLayout f13912m;

    /* renamed from: n  reason: collision with root package name */
    private CharSequence f13913n;

    /* renamed from: o  reason: collision with root package name */
    private RectF f13914o = new RectF();

    /* renamed from: p  reason: collision with root package name */
    private RectF[] f13915p = {new RectF(), new RectF(), new RectF()};

    /* renamed from: q  reason: collision with root package name */
    protected WeakReference f13916q;

    /* renamed from: r  reason: collision with root package name */
    protected Canvas f13917r;

    /* renamed from: s  reason: collision with root package name */
    private Path f13918s = new Path();

    /* renamed from: t  reason: collision with root package name */
    private RectF f13919t = new RectF();

    /* renamed from: u  reason: collision with root package name */
    private Path f13920u = new Path();

    /* renamed from: v  reason: collision with root package name */
    protected Path f13921v = new Path();

    /* renamed from: w  reason: collision with root package name */
    protected RectF f13922w = new RectF();

    public m(PieChart pieChart, a aVar, j jVar) {
        super(aVar, jVar);
        this.f13906g = pieChart;
        Paint paint = new Paint(1);
        this.f13907h = paint;
        paint.setColor(-1);
        this.f13907h.setStyle(Paint.Style.FILL);
        Paint paint2 = new Paint(1);
        this.f13908i = paint2;
        paint2.setColor(-1);
        this.f13908i.setStyle(Paint.Style.FILL);
        this.f13908i.setAlpha(105);
        TextPaint textPaint = new TextPaint(1);
        this.f13910k = textPaint;
        textPaint.setColor(-16777216);
        this.f13910k.setTextSize(i.e(12.0f));
        this.f13878f.setTextSize(i.e(13.0f));
        this.f13878f.setColor(-1);
        this.f13878f.setTextAlign(Paint.Align.CENTER);
        Paint paint3 = new Paint(1);
        this.f13911l = paint3;
        paint3.setColor(-1);
        this.f13911l.setTextAlign(Paint.Align.CENTER);
        this.f13911l.setTextSize(i.e(13.0f));
        Paint paint4 = new Paint(1);
        this.f13909j = paint4;
        paint4.setStyle(Paint.Style.STROKE);
    }

    public void b(Canvas canvas) {
        Bitmap bitmap;
        int n10 = (int) this.f13928a.n();
        int m10 = (int) this.f13928a.m();
        WeakReference weakReference = this.f13916q;
        if (weakReference == null) {
            bitmap = null;
        } else {
            bitmap = (Bitmap) weakReference.get();
        }
        if (!(bitmap != null && bitmap.getWidth() == n10 && bitmap.getHeight() == m10)) {
            if (n10 > 0 && m10 > 0) {
                bitmap = Bitmap.createBitmap(n10, m10, Bitmap.Config.ARGB_4444);
                this.f13916q = new WeakReference(bitmap);
                this.f13917r = new Canvas(bitmap);
            } else {
                return;
            }
        }
        bitmap.eraseColor(0);
        for (db.i iVar : ((v) this.f13906g.getData()).g()) {
            if (iVar.isVisible() && iVar.I0() > 0) {
                j(canvas, iVar);
            }
        }
    }

    public void c(Canvas canvas) {
        l(canvas);
        canvas.drawBitmap((Bitmap) this.f13916q.get(), 0.0f, 0.0f, (Paint) null);
        i(canvas);
    }

    public void d(Canvas canvas, d[] dVarArr) {
        boolean z10;
        float f10;
        boolean z11;
        float[] fArr;
        float f11;
        e eVar;
        float f12;
        int i10;
        RectF rectF;
        float f13;
        db.i u10;
        float f14;
        int i11;
        float f15;
        boolean z12;
        float f16;
        float f17;
        float f18;
        int i12;
        float f19;
        float[] fArr2;
        float f20;
        float f21;
        float f22;
        d[] dVarArr2 = dVarArr;
        if (!this.f13906g.N() || this.f13906g.P()) {
            z10 = false;
        } else {
            z10 = true;
        }
        if (!z10 || !this.f13906g.O()) {
            float d10 = this.f13874b.d();
            float e10 = this.f13874b.e();
            float rotationAngle = this.f13906g.getRotationAngle();
            float[] drawAngles = this.f13906g.getDrawAngles();
            float[] absoluteAngles = this.f13906g.getAbsoluteAngles();
            e centerCircleBox = this.f13906g.getCenterCircleBox();
            float radius = this.f13906g.getRadius();
            if (z10) {
                f10 = (this.f13906g.getHoleRadius() / 100.0f) * radius;
            } else {
                f10 = 0.0f;
            }
            RectF rectF2 = this.f13922w;
            rectF2.set(0.0f, 0.0f, 0.0f, 0.0f);
            int i13 = 0;
            while (i13 < dVarArr2.length) {
                int h10 = (int) dVarArr2[i13].h();
                if (h10 < drawAngles.length && (u10 = ((v) this.f13906g.getData()).e(dVarArr2[i13].d())) != null && u10.M0()) {
                    int I0 = u10.I0();
                    int i14 = 0;
                    for (int i15 = 0; i15 < I0; i15++) {
                        if (Math.abs(((x) u10.P(i15)).c()) > i.f14970e) {
                            i14++;
                        }
                    }
                    if (h10 == 0) {
                        i11 = 1;
                        f14 = 0.0f;
                    } else {
                        f14 = absoluteAngles[h10 - 1] * d10;
                        i11 = 1;
                    }
                    if (i14 <= i11) {
                        f15 = 0.0f;
                    } else {
                        f15 = u10.h();
                    }
                    float f23 = drawAngles[h10];
                    float v02 = u10.v0();
                    int i16 = i13;
                    float f24 = radius + v02;
                    float f25 = f10;
                    rectF2.set(this.f13906g.getCircleBox());
                    float f26 = -v02;
                    rectF2.inset(f26, f26);
                    if (f15 <= 0.0f || f23 > 180.0f) {
                        z12 = false;
                    } else {
                        z12 = true;
                    }
                    this.f13875c.setColor(u10.V(h10));
                    if (i14 == 1) {
                        f16 = 0.0f;
                    } else {
                        f16 = f15 / (radius * 0.017453292f);
                    }
                    if (i14 == 1) {
                        f17 = 0.0f;
                    } else {
                        f17 = f15 / (f24 * 0.017453292f);
                    }
                    float f27 = rotationAngle + (((f16 / 2.0f) + f14) * e10);
                    float f28 = (f23 - f16) * e10;
                    if (f28 < 0.0f) {
                        f18 = 0.0f;
                    } else {
                        f18 = f28;
                    }
                    float f29 = (((f17 / 2.0f) + f14) * e10) + rotationAngle;
                    float f30 = (f23 - f17) * e10;
                    if (f30 < 0.0f) {
                        f30 = 0.0f;
                    }
                    this.f13918s.reset();
                    int i17 = (f18 > 360.0f ? 1 : (f18 == 360.0f ? 0 : -1));
                    if (i17 < 0 || f18 % 360.0f > i.f14970e) {
                        fArr2 = drawAngles;
                        f19 = f14;
                        double d11 = (double) (f29 * 0.017453292f);
                        i12 = i14;
                        z11 = z10;
                        this.f13918s.moveTo(centerCircleBox.f14944x + (((float) Math.cos(d11)) * f24), centerCircleBox.f14945y + (f24 * ((float) Math.sin(d11))));
                        this.f13918s.arcTo(rectF2, f29, f30);
                    } else {
                        this.f13918s.addCircle(centerCircleBox.f14944x, centerCircleBox.f14945y, f24, Path.Direction.CW);
                        fArr2 = drawAngles;
                        f19 = f14;
                        i12 = i14;
                        z11 = z10;
                    }
                    if (z12) {
                        double d12 = (double) (f27 * 0.017453292f);
                        float cos = (((float) Math.cos(d12)) * radius) + centerCircleBox.f14944x;
                        i10 = i16;
                        rectF = rectF2;
                        f12 = f25;
                        float f31 = cos;
                        float sin = centerCircleBox.f14945y + (((float) Math.sin(d12)) * radius);
                        eVar = centerCircleBox;
                        fArr = fArr2;
                        f20 = h(centerCircleBox, radius, f23 * e10, f31, sin, f27, f18);
                    } else {
                        rectF = rectF2;
                        eVar = centerCircleBox;
                        i10 = i16;
                        f12 = f25;
                        fArr = fArr2;
                        f20 = 0.0f;
                    }
                    RectF rectF3 = this.f13919t;
                    float f32 = eVar.f14944x;
                    float f33 = eVar.f14945y;
                    rectF3.set(f32 - f12, f33 - f12, f32 + f12, f33 + f12);
                    if (!z11 || (f12 <= 0.0f && !z12)) {
                        f13 = d10;
                        f11 = e10;
                        if (f18 % 360.0f > i.f14970e) {
                            if (z12) {
                                double d13 = (double) ((f27 + (f18 / 2.0f)) * 0.017453292f);
                                this.f13918s.lineTo(eVar.f14944x + (((float) Math.cos(d13)) * f20), eVar.f14945y + (f20 * ((float) Math.sin(d13))));
                            } else {
                                this.f13918s.lineTo(eVar.f14944x, eVar.f14945y);
                            }
                        }
                    } else {
                        if (z12) {
                            if (f20 < 0.0f) {
                                f20 = -f20;
                            }
                            f21 = Math.max(f12, f20);
                        } else {
                            f21 = f12;
                        }
                        if (i12 == 1 || f21 == 0.0f) {
                            f22 = 0.0f;
                        } else {
                            f22 = f15 / (f21 * 0.017453292f);
                        }
                        float f34 = ((f19 + (f22 / 2.0f)) * e10) + rotationAngle;
                        float f35 = (f23 - f22) * e10;
                        if (f35 < 0.0f) {
                            f35 = 0.0f;
                        }
                        float f36 = f34 + f35;
                        if (i17 < 0 || f18 % 360.0f > i.f14970e) {
                            double d14 = (double) (f36 * 0.017453292f);
                            f13 = d10;
                            f11 = e10;
                            this.f13918s.lineTo(eVar.f14944x + (((float) Math.cos(d14)) * f21), eVar.f14945y + (f21 * ((float) Math.sin(d14))));
                            this.f13918s.arcTo(this.f13919t, f36, -f35);
                        } else {
                            this.f13918s.addCircle(eVar.f14944x, eVar.f14945y, f21, Path.Direction.CCW);
                            f13 = d10;
                            f11 = e10;
                        }
                    }
                    this.f13918s.close();
                    this.f13917r.drawPath(this.f13918s, this.f13875c);
                } else {
                    i10 = i13;
                    rectF = rectF2;
                    f12 = f10;
                    fArr = drawAngles;
                    z11 = z10;
                    f13 = d10;
                    f11 = e10;
                    eVar = centerCircleBox;
                }
                i13 = i10 + 1;
                d10 = f13;
                rectF2 = rectF;
                f10 = f12;
                centerCircleBox = eVar;
                e10 = f11;
                drawAngles = fArr;
                z10 = z11;
                dVarArr2 = dVarArr;
            }
            e.h(centerCircleBox);
        }
    }

    /* JADX WARNING: Removed duplicated region for block: B:119:0x03b3  */
    /* JADX WARNING: Removed duplicated region for block: B:120:0x03db  */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public void e(android.graphics.Canvas r54) {
        /*
            r53 = this;
            r6 = r53
            r7 = r54
            com.github.mikephil.charting.charts.PieChart r0 = r6.f13906g
            jb.e r8 = r0.getCenterCircleBox()
            com.github.mikephil.charting.charts.PieChart r0 = r6.f13906g
            float r9 = r0.getRadius()
            com.github.mikephil.charting.charts.PieChart r0 = r6.f13906g
            float r0 = r0.getRotationAngle()
            com.github.mikephil.charting.charts.PieChart r1 = r6.f13906g
            float[] r10 = r1.getDrawAngles()
            com.github.mikephil.charting.charts.PieChart r1 = r6.f13906g
            float[] r11 = r1.getAbsoluteAngles()
            wa.a r1 = r6.f13874b
            float r12 = r1.d()
            wa.a r1 = r6.f13874b
            float r13 = r1.e()
            com.github.mikephil.charting.charts.PieChart r1 = r6.f13906g
            float r1 = r1.getHoleRadius()
            float r1 = r1 * r9
            r14 = 1120403456(0x42c80000, float:100.0)
            float r1 = r1 / r14
            float r1 = r9 - r1
            r15 = 1073741824(0x40000000, float:2.0)
            float r1 = r1 / r15
            com.github.mikephil.charting.charts.PieChart r2 = r6.f13906g
            float r2 = r2.getHoleRadius()
            float r16 = r2 / r14
            r2 = 1092616192(0x41200000, float:10.0)
            float r2 = r9 / r2
            r3 = 1080452710(0x40666666, float:3.6)
            float r2 = r2 * r3
            com.github.mikephil.charting.charts.PieChart r3 = r6.f13906g
            boolean r3 = r3.N()
            if (r3 == 0) goto L_0x007d
            float r2 = r9 * r16
            float r2 = r9 - r2
            float r2 = r2 / r15
            com.github.mikephil.charting.charts.PieChart r3 = r6.f13906g
            boolean r3 = r3.P()
            if (r3 != 0) goto L_0x007d
            com.github.mikephil.charting.charts.PieChart r3 = r6.f13906g
            boolean r3 = r3.O()
            if (r3 == 0) goto L_0x007d
            double r3 = (double) r0
            r0 = 1135869952(0x43b40000, float:360.0)
            float r1 = r1 * r0
            double r0 = (double) r1
            r17 = 4618760256179416344(0x401921fb54442d18, double:6.283185307179586)
            double r14 = (double) r9
            double r14 = r14 * r17
            double r0 = r0 / r14
            double r3 = r3 + r0
            float r0 = (float) r3
        L_0x007d:
            r14 = r0
            float r15 = r9 - r2
            com.github.mikephil.charting.charts.PieChart r0 = r6.f13906g
            za.n r0 = r0.getData()
            r17 = r0
            za.v r17 = (za.v) r17
            java.util.List r5 = r17.g()
            float r18 = r17.v()
            com.github.mikephil.charting.charts.PieChart r0 = r6.f13906g
            boolean r21 = r0.M()
            r54.save()
            r0 = 1084227584(0x40a00000, float:5.0)
            float r22 = jb.i.e(r0)
            r23 = 0
            r0 = 0
            r4 = 0
        L_0x00a5:
            int r1 = r5.size()
            if (r4 >= r1) goto L_0x042f
            java.lang.Object r1 = r5.get(r4)
            r3 = r1
            db.i r3 = (db.i) r3
            boolean r24 = r3.B0()
            if (r24 != 0) goto L_0x00d2
            if (r21 != 0) goto L_0x00d2
            r26 = r4
            r33 = r5
            r29 = r9
            r34 = r10
            r36 = r11
            r37 = r12
            r38 = r13
            r40 = r14
            r10 = 1073741824(0x40000000, float:2.0)
            r19 = 1120403456(0x42c80000, float:100.0)
            r9 = r7
            r13 = r8
            goto L_0x041b
        L_0x00d2:
            za.w$a r2 = r3.Z()
            za.w$a r1 = r3.h0()
            r6.a(r3)
            r25 = r0
            android.graphics.Paint r0 = r6.f13878f
            r26 = r4
            java.lang.String r4 = "Q"
            int r0 = jb.i.a(r0, r4)
            float r0 = (float) r0
            r4 = 1082130432(0x40800000, float:4.0)
            float r4 = jb.i.e(r4)
            float r27 = r0 + r4
            ab.h r4 = r3.L()
            int r0 = r3.I0()
            r28 = r5
            android.graphics.Paint r5 = r6.f13909j
            int r7 = r3.S()
            r5.setColor(r7)
            android.graphics.Paint r5 = r6.f13909j
            float r7 = r3.W()
            float r7 = jb.i.e(r7)
            r5.setStrokeWidth(r7)
            float r7 = r6.r(r3)
            jb.e r5 = r3.J0()
            jb.e r5 = jb.e.d(r5)
            r29 = r8
            float r8 = r5.f14944x
            float r8 = jb.i.e(r8)
            r5.f14944x = r8
            float r8 = r5.f14945y
            float r8 = jb.i.e(r8)
            r5.f14945y = r8
            r8 = 0
        L_0x0131:
            if (r8 >= r0) goto L_0x03ff
            za.q r30 = r3.P(r8)
            r31 = r5
            r5 = r30
            za.x r5 = (za.x) r5
            if (r25 != 0) goto L_0x0142
            r30 = 0
            goto L_0x0148
        L_0x0142:
            int r30 = r25 + -1
            r30 = r11[r30]
            float r30 = r30 * r12
        L_0x0148:
            r32 = r10[r25]
            r33 = 1016003125(0x3c8efa35, float:0.017453292)
            float r34 = r15 * r33
            float r34 = r7 / r34
            r20 = 1073741824(0x40000000, float:2.0)
            float r34 = r34 / r20
            float r32 = r32 - r34
            float r32 = r32 / r20
            float r30 = r30 + r32
            float r30 = r30 * r13
            r32 = r0
            float r0 = r14 + r30
            r30 = r7
            com.github.mikephil.charting.charts.PieChart r7 = r6.f13906g
            boolean r7 = r7.Q()
            if (r7 == 0) goto L_0x0176
            float r7 = r5.c()
            float r7 = r7 / r18
            r19 = 1120403456(0x42c80000, float:100.0)
            float r7 = r7 * r19
            goto L_0x017a
        L_0x0176:
            float r7 = r5.c()
        L_0x017a:
            java.lang.String r7 = r4.g(r7, r5)
            r34 = r10
            java.lang.String r10 = r5.h()
            r35 = r4
            float r4 = r0 * r33
            r33 = r5
            double r4 = (double) r4
            r36 = r11
            r37 = r12
            double r11 = java.lang.Math.cos(r4)
            float r11 = (float) r11
            r38 = r13
            double r12 = java.lang.Math.sin(r4)
            float r12 = (float) r12
            if (r21 == 0) goto L_0x01a3
            za.w$a r13 = za.w.a.OUTSIDE_SLICE
            if (r2 != r13) goto L_0x01a3
            r13 = 1
            goto L_0x01a4
        L_0x01a3:
            r13 = 0
        L_0x01a4:
            r40 = r14
            if (r24 == 0) goto L_0x01ae
            za.w$a r14 = za.w.a.OUTSIDE_SLICE
            if (r1 != r14) goto L_0x01ae
            r14 = 1
            goto L_0x01af
        L_0x01ae:
            r14 = 0
        L_0x01af:
            r41 = r10
            if (r21 == 0) goto L_0x01b9
            za.w$a r10 = za.w.a.INSIDE_SLICE
            if (r2 != r10) goto L_0x01b9
            r10 = 1
            goto L_0x01ba
        L_0x01b9:
            r10 = 0
        L_0x01ba:
            r42 = r2
            if (r24 == 0) goto L_0x01c5
            za.w$a r2 = za.w.a.INSIDE_SLICE
            if (r1 != r2) goto L_0x01c5
            r39 = 1
            goto L_0x01c7
        L_0x01c5:
            r39 = 0
        L_0x01c7:
            if (r13 != 0) goto L_0x01e7
            if (r14 == 0) goto L_0x01cc
            goto L_0x01e7
        L_0x01cc:
            r45 = r1
            r44 = r12
            r50 = r29
            r51 = r31
            r48 = r35
            r14 = r41
            r19 = 1120403456(0x42c80000, float:100.0)
            r12 = r3
            r29 = r9
            r9 = r54
            r52 = r33
            r33 = r28
            r28 = r52
            goto L_0x033b
        L_0x01e7:
            float r2 = r3.X()
            float r43 = r3.m0()
            float r44 = r3.z0()
            r19 = 1120403456(0x42c80000, float:100.0)
            float r44 = r44 / r19
            r45 = r1
            com.github.mikephil.charting.charts.PieChart r1 = r6.f13906g
            boolean r1 = r1.N()
            if (r1 == 0) goto L_0x020a
            float r1 = r9 * r16
            float r46 = r9 - r1
            float r46 = r46 * r44
            float r46 = r46 + r1
            goto L_0x020c
        L_0x020a:
            float r46 = r9 * r44
        L_0x020c:
            boolean r1 = r3.j0()
            if (r1 == 0) goto L_0x0220
            float r43 = r43 * r15
            double r4 = java.lang.Math.sin(r4)
            double r4 = java.lang.Math.abs(r4)
            float r1 = (float) r4
            float r43 = r43 * r1
            goto L_0x0222
        L_0x0220:
            float r43 = r43 * r15
        L_0x0222:
            float r1 = r46 * r11
            r5 = r29
            float r4 = r5.f14944x
            float r1 = r1 + r4
            float r46 = r46 * r12
            r29 = r9
            float r9 = r5.f14945y
            float r44 = r46 + r9
            r46 = 1065353216(0x3f800000, float:1.0)
            float r2 = r2 + r46
            float r2 = r2 * r15
            float r46 = r2 * r11
            float r46 = r46 + r4
            float r2 = r2 * r12
            float r9 = r9 + r2
            r47 = r5
            double r4 = (double) r0
            r48 = 4645040803167600640(0x4076800000000000, double:360.0)
            double r4 = r4 % r48
            r48 = 4636033603912859648(0x4056800000000000, double:90.0)
            int r0 = (r4 > r48 ? 1 : (r4 == r48 ? 0 : -1))
            if (r0 < 0) goto L_0x0272
            r48 = 4643457506423603200(0x4070e00000000000, double:270.0)
            int r0 = (r4 > r48 ? 1 : (r4 == r48 ? 0 : -1))
            if (r0 > 0) goto L_0x0272
            float r0 = r46 - r43
            android.graphics.Paint r2 = r6.f13878f
            android.graphics.Paint$Align r4 = android.graphics.Paint.Align.RIGHT
            r2.setTextAlign(r4)
            if (r13 == 0) goto L_0x026c
            android.graphics.Paint r2 = r6.f13911l
            android.graphics.Paint$Align r4 = android.graphics.Paint.Align.RIGHT
            r2.setTextAlign(r4)
        L_0x026c:
            float r2 = r0 - r22
            r43 = r0
            r5 = r2
            goto L_0x0287
        L_0x0272:
            float r43 = r46 + r43
            android.graphics.Paint r0 = r6.f13878f
            android.graphics.Paint$Align r2 = android.graphics.Paint.Align.LEFT
            r0.setTextAlign(r2)
            if (r13 == 0) goto L_0x0284
            android.graphics.Paint r0 = r6.f13911l
            android.graphics.Paint$Align r2 = android.graphics.Paint.Align.LEFT
            r0.setTextAlign(r2)
        L_0x0284:
            float r0 = r43 + r22
            r5 = r0
        L_0x0287:
            int r0 = r3.S()
            r2 = 1122867(0x112233, float:1.573472E-39)
            if (r0 == r2) goto L_0x02cb
            boolean r0 = r3.q0()
            if (r0 == 0) goto L_0x029f
            android.graphics.Paint r0 = r6.f13909j
            int r2 = r3.V(r8)
            r0.setColor(r2)
        L_0x029f:
            android.graphics.Paint r4 = r6.f13909j
            r0 = r54
            r2 = r44
            r44 = r12
            r12 = r3
            r3 = r46
            r48 = r35
            r35 = r4
            r4 = r9
            r51 = r31
            r50 = r47
            r31 = r5
            r52 = r33
            r33 = r28
            r28 = r52
            r5 = r35
            r0.drawLine(r1, r2, r3, r4, r5)
            android.graphics.Paint r5 = r6.f13909j
            r1 = r46
            r2 = r9
            r3 = r43
            r0.drawLine(r1, r2, r3, r4, r5)
            goto L_0x02dc
        L_0x02cb:
            r44 = r12
            r51 = r31
            r48 = r35
            r50 = r47
            r12 = r3
            r31 = r5
            r52 = r33
            r33 = r28
            r28 = r52
        L_0x02dc:
            if (r13 == 0) goto L_0x0308
            if (r14 == 0) goto L_0x0308
            int r5 = r12.f0(r8)
            r0 = r53
            r1 = r54
            r2 = r7
            r3 = r31
            r4 = r9
            r0.m(r1, r2, r3, r4, r5)
            int r0 = r17.h()
            if (r8 >= r0) goto L_0x0303
            if (r41 == 0) goto L_0x0303
            float r9 = r9 + r27
            r5 = r54
            r3 = r31
            r4 = r41
            r6.k(r5, r4, r3, r9)
            goto L_0x0339
        L_0x0303:
            r9 = r54
            r14 = r41
            goto L_0x033b
        L_0x0308:
            r5 = r54
            r3 = r31
            r4 = r41
            if (r13 == 0) goto L_0x0321
            int r0 = r17.h()
            if (r8 >= r0) goto L_0x0339
            if (r4 == 0) goto L_0x0339
            r0 = 1073741824(0x40000000, float:2.0)
            float r1 = r27 / r0
            float r9 = r9 + r1
            r6.k(r5, r4, r3, r9)
            goto L_0x0339
        L_0x0321:
            r0 = 1073741824(0x40000000, float:2.0)
            if (r14 == 0) goto L_0x0339
            float r1 = r27 / r0
            float r9 = r9 + r1
            int r13 = r12.f0(r8)
            r0 = r53
            r1 = r54
            r2 = r7
            r14 = r4
            r4 = r9
            r9 = r5
            r5 = r13
            r0.m(r1, r2, r3, r4, r5)
            goto L_0x033b
        L_0x0339:
            r14 = r4
            r9 = r5
        L_0x033b:
            if (r10 != 0) goto L_0x0346
            if (r39 == 0) goto L_0x0340
            goto L_0x0346
        L_0x0340:
            r13 = r50
        L_0x0342:
            r10 = 1073741824(0x40000000, float:2.0)
            goto L_0x03a7
        L_0x0346:
            float r0 = r15 * r11
            r13 = r50
            float r1 = r13.f14944x
            float r5 = r0 + r1
            float r0 = r15 * r44
            float r1 = r13.f14945y
            float r31 = r0 + r1
            android.graphics.Paint r0 = r6.f13878f
            android.graphics.Paint$Align r1 = android.graphics.Paint.Align.CENTER
            r0.setTextAlign(r1)
            if (r10 == 0) goto L_0x037e
            if (r39 == 0) goto L_0x037e
            int r10 = r12.f0(r8)
            r0 = r53
            r1 = r54
            r2 = r7
            r3 = r5
            r4 = r31
            r7 = r5
            r5 = r10
            r0.m(r1, r2, r3, r4, r5)
            int r0 = r17.h()
            if (r8 >= r0) goto L_0x0342
            if (r14 == 0) goto L_0x0342
            float r0 = r31 + r27
            r6.k(r9, r14, r7, r0)
            goto L_0x0342
        L_0x037e:
            r3 = r5
            if (r10 == 0) goto L_0x0393
            int r0 = r17.h()
            if (r8 >= r0) goto L_0x0342
            if (r14 == 0) goto L_0x0342
            r10 = 1073741824(0x40000000, float:2.0)
            float r0 = r27 / r10
            float r0 = r31 + r0
            r6.k(r9, r14, r3, r0)
            goto L_0x03a7
        L_0x0393:
            r10 = 1073741824(0x40000000, float:2.0)
            if (r39 == 0) goto L_0x03a7
            float r0 = r27 / r10
            float r4 = r31 + r0
            int r5 = r12.f0(r8)
            r0 = r53
            r1 = r54
            r2 = r7
            r0.m(r1, r2, r3, r4, r5)
        L_0x03a7:
            android.graphics.drawable.Drawable r0 = r28.b()
            if (r0 == 0) goto L_0x03db
            boolean r0 = r12.x()
            if (r0 == 0) goto L_0x03db
            android.graphics.drawable.Drawable r1 = r28.b()
            r7 = r51
            float r0 = r7.f14945y
            float r2 = r15 + r0
            float r2 = r2 * r11
            float r3 = r13.f14944x
            float r2 = r2 + r3
            float r0 = r0 + r15
            float r0 = r0 * r44
            float r3 = r13.f14945y
            float r0 = r0 + r3
            float r3 = r7.f14944x
            float r0 = r0 + r3
            int r2 = (int) r2
            int r3 = (int) r0
            int r4 = r1.getIntrinsicWidth()
            int r5 = r1.getIntrinsicHeight()
            r0 = r54
            jb.i.f(r0, r1, r2, r3, r4, r5)
            goto L_0x03dd
        L_0x03db:
            r7 = r51
        L_0x03dd:
            int r25 = r25 + 1
            int r8 = r8 + 1
            r5 = r7
            r3 = r12
            r9 = r29
            r7 = r30
            r0 = r32
            r28 = r33
            r10 = r34
            r11 = r36
            r12 = r37
            r14 = r40
            r2 = r42
            r1 = r45
            r4 = r48
            r29 = r13
            r13 = r38
            goto L_0x0131
        L_0x03ff:
            r7 = r5
            r34 = r10
            r36 = r11
            r37 = r12
            r38 = r13
            r40 = r14
            r33 = r28
            r13 = r29
            r10 = 1073741824(0x40000000, float:2.0)
            r19 = 1120403456(0x42c80000, float:100.0)
            r29 = r9
            r9 = r54
            jb.e.h(r7)
            r0 = r25
        L_0x041b:
            int r4 = r26 + 1
            r7 = r9
            r8 = r13
            r9 = r29
            r5 = r33
            r10 = r34
            r11 = r36
            r12 = r37
            r13 = r38
            r14 = r40
            goto L_0x00a5
        L_0x042f:
            r9 = r7
            r13 = r8
            jb.e.h(r13)
            r54.restore()
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: hb.m.e(android.graphics.Canvas):void");
    }

    public void f() {
    }

    /* access modifiers changed from: protected */
    public float h(e eVar, float f10, float f11, float f12, float f13, float f14, float f15) {
        e eVar2 = eVar;
        double d10 = (double) ((f14 + f15) * 0.017453292f);
        float cos = eVar2.f14944x + (((float) Math.cos(d10)) * f10);
        float sin = eVar2.f14945y + (((float) Math.sin(d10)) * f10);
        double d11 = (double) ((f14 + (f15 / 2.0f)) * 0.017453292f);
        return (float) (((double) (f10 - ((float) ((Math.sqrt(Math.pow((double) (cos - f12), 2.0d) + Math.pow((double) (sin - f13), 2.0d)) / 2.0d) * Math.tan(((180.0d - ((double) f11)) / 2.0d) * 0.017453292519943295d))))) - Math.sqrt(Math.pow((double) ((eVar2.f14944x + (((float) Math.cos(d11)) * f10)) - ((cos + f12) / 2.0f)), 2.0d) + Math.pow((double) ((eVar2.f14945y + (((float) Math.sin(d11)) * f10)) - ((sin + f13) / 2.0f)), 2.0d)));
    }

    /* access modifiers changed from: protected */
    public void i(Canvas canvas) {
        float f10;
        e eVar;
        Canvas canvas2 = canvas;
        CharSequence centerText = this.f13906g.getCenterText();
        if (this.f13906g.L() && centerText != null) {
            e centerCircleBox = this.f13906g.getCenterCircleBox();
            e centerTextOffset = this.f13906g.getCenterTextOffset();
            float f11 = centerCircleBox.f14944x + centerTextOffset.f14944x;
            float f12 = centerCircleBox.f14945y + centerTextOffset.f14945y;
            if (!this.f13906g.N() || this.f13906g.P()) {
                f10 = this.f13906g.getRadius();
            } else {
                f10 = this.f13906g.getRadius() * (this.f13906g.getHoleRadius() / 100.0f);
            }
            RectF[] rectFArr = this.f13915p;
            RectF rectF = rectFArr[0];
            rectF.left = f11 - f10;
            rectF.top = f12 - f10;
            rectF.right = f11 + f10;
            rectF.bottom = f12 + f10;
            RectF rectF2 = rectFArr[1];
            rectF2.set(rectF);
            float centerTextRadiusPercent = this.f13906g.getCenterTextRadiusPercent() / 100.0f;
            if (((double) centerTextRadiusPercent) > 0.0d) {
                rectF2.inset((rectF2.width() - (rectF2.width() * centerTextRadiusPercent)) / 2.0f, (rectF2.height() - (rectF2.height() * centerTextRadiusPercent)) / 2.0f);
            }
            if (!centerText.equals(this.f13913n) || !rectF2.equals(this.f13914o)) {
                this.f13914o.set(rectF2);
                this.f13913n = centerText;
                eVar = centerTextOffset;
                StaticLayout staticLayout = r3;
                StaticLayout staticLayout2 = new StaticLayout(centerText, 0, centerText.length(), this.f13910k, (int) Math.max(Math.ceil((double) this.f13914o.width()), 1.0d), Layout.Alignment.ALIGN_CENTER, 1.0f, 0.0f, false);
                this.f13912m = staticLayout;
            } else {
                eVar = centerTextOffset;
            }
            canvas.save();
            Path path = this.f13921v;
            path.reset();
            path.addOval(rectF, Path.Direction.CW);
            canvas2.clipPath(path);
            canvas2.translate(rectF2.left, rectF2.top + ((rectF2.height() - ((float) this.f13912m.getHeight())) / 2.0f));
            this.f13912m.draw(canvas2);
            canvas.restore();
            e.h(centerCircleBox);
            e.h(eVar);
        }
    }

    /* access modifiers changed from: protected */
    public void j(Canvas canvas, db.i iVar) {
        boolean z10;
        float f10;
        boolean z11;
        float f11;
        RectF rectF;
        float f12;
        float[] fArr;
        int i10;
        int i11;
        float f13;
        float f14;
        e eVar;
        int i12;
        float f15;
        RectF rectF2;
        boolean z12;
        float f16;
        int i13;
        RectF rectF3;
        float f17;
        float f18;
        float f19;
        float f20;
        RectF rectF4;
        int i14;
        RectF rectF5;
        RectF rectF6;
        float f21;
        e eVar2;
        int i15;
        float f22;
        m mVar = this;
        db.i iVar2 = iVar;
        float rotationAngle = mVar.f13906g.getRotationAngle();
        float d10 = mVar.f13874b.d();
        float e10 = mVar.f13874b.e();
        RectF circleBox = mVar.f13906g.getCircleBox();
        int I0 = iVar.I0();
        float[] drawAngles = mVar.f13906g.getDrawAngles();
        e centerCircleBox = mVar.f13906g.getCenterCircleBox();
        float radius = mVar.f13906g.getRadius();
        if (!mVar.f13906g.N() || mVar.f13906g.P()) {
            z10 = false;
        } else {
            z10 = true;
        }
        if (z10) {
            f10 = (mVar.f13906g.getHoleRadius() / 100.0f) * radius;
        } else {
            f10 = 0.0f;
        }
        float holeRadius = (radius - ((mVar.f13906g.getHoleRadius() * radius) / 100.0f)) / 2.0f;
        RectF rectF7 = new RectF();
        if (!z10 || !mVar.f13906g.O()) {
            z11 = false;
        } else {
            z11 = true;
        }
        int i16 = 0;
        for (int i17 = 0; i17 < I0; i17++) {
            if (Math.abs(((x) iVar2.P(i17)).c()) > i.f14970e) {
                i16++;
            }
        }
        if (i16 <= 1) {
            f11 = 0.0f;
        } else {
            f11 = mVar.r(iVar2);
        }
        int i18 = 0;
        float f23 = 0.0f;
        while (i18 < I0) {
            float f24 = drawAngles[i18];
            float abs = Math.abs(iVar2.P(i18).c());
            float f25 = i.f14970e;
            if (abs > f25 && (!mVar.f13906g.R(i18) || z11)) {
                if (f11 <= 0.0f || f24 > 180.0f) {
                    z12 = false;
                } else {
                    z12 = true;
                }
                mVar.f13875c.setColor(iVar2.V(i18));
                if (i16 == 1) {
                    f16 = 0.0f;
                } else {
                    f16 = f11 / (radius * 0.017453292f);
                }
                float f26 = rotationAngle + ((f23 + (f16 / 2.0f)) * e10);
                float f27 = (f24 - f16) * e10;
                if (f27 < 0.0f) {
                    f27 = 0.0f;
                }
                mVar.f13918s.reset();
                if (z11) {
                    float f28 = radius - holeRadius;
                    i11 = i18;
                    i13 = i16;
                    double d11 = (double) (f26 * 0.017453292f);
                    i10 = I0;
                    fArr = drawAngles;
                    float cos = centerCircleBox.f14944x + (((float) Math.cos(d11)) * f28);
                    float sin = centerCircleBox.f14945y + (f28 * ((float) Math.sin(d11)));
                    rectF7.set(cos - holeRadius, sin - holeRadius, cos + holeRadius, sin + holeRadius);
                } else {
                    i11 = i18;
                    i13 = i16;
                    i10 = I0;
                    fArr = drawAngles;
                }
                double d12 = (double) (f26 * 0.017453292f);
                f13 = rotationAngle;
                f12 = d10;
                float cos2 = centerCircleBox.f14944x + (((float) Math.cos(d12)) * radius);
                float sin2 = centerCircleBox.f14945y + (((float) Math.sin(d12)) * radius);
                int i19 = (f27 > 360.0f ? 1 : (f27 == 360.0f ? 0 : -1));
                if (i19 < 0 || f27 % 360.0f > f25) {
                    if (z11) {
                        mVar.f13918s.arcTo(rectF7, f26 + 180.0f, -180.0f);
                    }
                    mVar.f13918s.arcTo(circleBox, f26, f27);
                } else {
                    mVar.f13918s.addCircle(centerCircleBox.f14944x, centerCircleBox.f14945y, radius, Path.Direction.CW);
                }
                RectF rectF8 = mVar.f13919t;
                float f29 = centerCircleBox.f14944x;
                float f30 = centerCircleBox.f14945y;
                float f31 = f27;
                rectF8.set(f29 - f10, f30 - f10, f29 + f10, f30 + f10);
                if (!z10) {
                    f19 = f10;
                    f20 = radius;
                    eVar = centerCircleBox;
                    rectF4 = circleBox;
                    i14 = i13;
                    f17 = f31;
                    rectF5 = rectF7;
                    f18 = 360.0f;
                } else if (f10 > 0.0f || z12) {
                    if (z12) {
                        f21 = f31;
                        rectF = circleBox;
                        i12 = i13;
                        rectF6 = rectF7;
                        f15 = f10;
                        i15 = 1;
                        f14 = radius;
                        float f32 = f26;
                        eVar2 = centerCircleBox;
                        float h10 = h(centerCircleBox, radius, f24 * e10, cos2, sin2, f32, f21);
                        if (h10 < 0.0f) {
                            h10 = -h10;
                        }
                        f10 = Math.max(f15, h10);
                    } else {
                        rectF6 = rectF7;
                        f15 = f10;
                        f14 = radius;
                        eVar2 = centerCircleBox;
                        rectF = circleBox;
                        i12 = i13;
                        f21 = f31;
                        i15 = 1;
                    }
                    if (i12 == i15 || f10 == 0.0f) {
                        f22 = 0.0f;
                    } else {
                        f22 = f11 / (f10 * 0.017453292f);
                    }
                    float f33 = f13 + ((f23 + (f22 / 2.0f)) * e10);
                    float f34 = (f24 - f22) * e10;
                    if (f34 < 0.0f) {
                        f34 = 0.0f;
                    }
                    float f35 = f33 + f34;
                    if (i19 < 0 || f21 % 360.0f > f25) {
                        mVar = this;
                        if (z11) {
                            float f36 = f14 - holeRadius;
                            double d13 = (double) (f35 * 0.017453292f);
                            float cos3 = eVar2.f14944x + (((float) Math.cos(d13)) * f36);
                            float sin3 = eVar2.f14945y + (f36 * ((float) Math.sin(d13)));
                            rectF3 = rectF6;
                            rectF3.set(cos3 - holeRadius, sin3 - holeRadius, cos3 + holeRadius, sin3 + holeRadius);
                            mVar.f13918s.arcTo(rectF3, f35, 180.0f);
                        } else {
                            rectF3 = rectF6;
                            double d14 = (double) (f35 * 0.017453292f);
                            mVar.f13918s.lineTo(eVar2.f14944x + (((float) Math.cos(d14)) * f10), eVar2.f14945y + (f10 * ((float) Math.sin(d14))));
                        }
                        mVar.f13918s.arcTo(mVar.f13919t, f35, -f34);
                    } else {
                        mVar = this;
                        mVar.f13918s.addCircle(eVar2.f14944x, eVar2.f14945y, f10, Path.Direction.CCW);
                        rectF3 = rectF6;
                    }
                    eVar = eVar2;
                    rectF2 = rectF3;
                    mVar.f13918s.close();
                    mVar.f13917r.drawPath(mVar.f13918s, mVar.f13875c);
                    f23 += f24 * f12;
                } else {
                    f19 = f10;
                    f20 = radius;
                    eVar = centerCircleBox;
                    rectF4 = circleBox;
                    i14 = i13;
                    f17 = f31;
                    f18 = 360.0f;
                    rectF5 = rectF7;
                }
                if (f17 % f18 > f25) {
                    if (z12) {
                        float f37 = f26 + (f17 / 2.0f);
                        float f38 = f26;
                        rectF2 = rectF3;
                        float h11 = h(eVar, f14, f24 * e10, cos2, sin2, f38, f17);
                        double d15 = (double) (f37 * 0.017453292f);
                        mVar.f13918s.lineTo(eVar.f14944x + (((float) Math.cos(d15)) * h11), eVar.f14945y + (h11 * ((float) Math.sin(d15))));
                    } else {
                        rectF2 = rectF3;
                        mVar.f13918s.lineTo(eVar.f14944x, eVar.f14945y);
                    }
                    mVar.f13918s.close();
                    mVar.f13917r.drawPath(mVar.f13918s, mVar.f13875c);
                    f23 += f24 * f12;
                }
                rectF2 = rectF3;
                mVar.f13918s.close();
                mVar.f13917r.drawPath(mVar.f13918s, mVar.f13875c);
                f23 += f24 * f12;
            } else {
                f23 += f24 * d10;
                i11 = i18;
                rectF2 = rectF7;
                f14 = radius;
                f13 = rotationAngle;
                f12 = d10;
                rectF = circleBox;
                i10 = I0;
                fArr = drawAngles;
                i12 = i16;
                f15 = f10;
                eVar = centerCircleBox;
            }
            i18 = i11 + 1;
            rectF7 = rectF2;
            f10 = f15;
            i16 = i12;
            centerCircleBox = eVar;
            radius = f14;
            rotationAngle = f13;
            I0 = i10;
            drawAngles = fArr;
            d10 = f12;
            circleBox = rectF;
            iVar2 = iVar;
        }
        e.h(centerCircleBox);
    }

    /* access modifiers changed from: protected */
    public void k(Canvas canvas, String str, float f10, float f11) {
        canvas.drawText(str, f10, f11, this.f13911l);
    }

    /* access modifiers changed from: protected */
    public void l(Canvas canvas) {
        if (this.f13906g.N() && this.f13917r != null) {
            float radius = this.f13906g.getRadius();
            float holeRadius = (this.f13906g.getHoleRadius() / 100.0f) * radius;
            e centerCircleBox = this.f13906g.getCenterCircleBox();
            if (Color.alpha(this.f13907h.getColor()) > 0) {
                this.f13917r.drawCircle(centerCircleBox.f14944x, centerCircleBox.f14945y, holeRadius, this.f13907h);
            }
            if (Color.alpha(this.f13908i.getColor()) > 0 && this.f13906g.getTransparentCircleRadius() > this.f13906g.getHoleRadius()) {
                int alpha = this.f13908i.getAlpha();
                float transparentCircleRadius = radius * (this.f13906g.getTransparentCircleRadius() / 100.0f);
                this.f13908i.setAlpha((int) (((float) alpha) * this.f13874b.d() * this.f13874b.e()));
                this.f13920u.reset();
                this.f13920u.addCircle(centerCircleBox.f14944x, centerCircleBox.f14945y, transparentCircleRadius, Path.Direction.CW);
                this.f13920u.addCircle(centerCircleBox.f14944x, centerCircleBox.f14945y, holeRadius, Path.Direction.CCW);
                this.f13917r.drawPath(this.f13920u, this.f13908i);
                this.f13908i.setAlpha(alpha);
            }
            e.h(centerCircleBox);
        }
    }

    public void m(Canvas canvas, String str, float f10, float f11, int i10) {
        this.f13878f.setColor(i10);
        canvas.drawText(str, f10, f11, this.f13878f);
    }

    public TextPaint n() {
        return this.f13910k;
    }

    public Paint o() {
        return this.f13911l;
    }

    public Paint p() {
        return this.f13907h;
    }

    public Paint q() {
        return this.f13908i;
    }

    /* access modifiers changed from: protected */
    public float r(db.i iVar) {
        if (!iVar.M()) {
            return iVar.h();
        }
        if (iVar.h() / this.f13928a.t() > (iVar.D() / ((v) this.f13906g.getData()).v()) * 2.0f) {
            return 0.0f;
        }
        return iVar.h();
    }

    public void s() {
        Canvas canvas = this.f13917r;
        if (canvas != null) {
            canvas.setBitmap((Bitmap) null);
            this.f13917r = null;
        }
        WeakReference weakReference = this.f13916q;
        if (weakReference != null) {
            Bitmap bitmap = (Bitmap) weakReference.get();
            if (bitmap != null) {
                bitmap.recycle();
            }
            this.f13916q.clear();
            this.f13916q = null;
        }
    }
}
