package hb;

import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.drawable.Drawable;
import jb.i;
import jb.j;
import wa.a;

public abstract class k extends l {
    public k(a aVar, j jVar) {
        super(aVar, jVar);
    }

    private boolean k() {
        if (i.u() >= 18) {
            return true;
        }
        return false;
    }

    /* access modifiers changed from: protected */
    public void l(Canvas canvas, Path path, int i10, int i11) {
        int i12 = (i10 & 16777215) | (i11 << 24);
        if (k()) {
            int save = canvas.save();
            canvas.clipPath(path);
            canvas.drawColor(i12);
            canvas.restoreToCount(save);
            return;
        }
        Paint.Style style = this.f13875c.getStyle();
        int color = this.f13875c.getColor();
        this.f13875c.setStyle(Paint.Style.FILL);
        this.f13875c.setColor(i12);
        canvas.drawPath(path, this.f13875c);
        this.f13875c.setColor(color);
        this.f13875c.setStyle(style);
    }

    /* access modifiers changed from: protected */
    public void m(Canvas canvas, Path path, Drawable drawable) {
        if (k()) {
            int save = canvas.save();
            canvas.clipPath(path);
            drawable.setBounds((int) this.f13928a.h(), (int) this.f13928a.j(), (int) this.f13928a.i(), (int) this.f13928a.f());
            drawable.draw(canvas);
            canvas.restoreToCount(save);
            return;
        }
        throw new RuntimeException("Fill-drawables not (yet) supported below API level 18, this code was run on API level " + i.u() + ".");
    }
}
