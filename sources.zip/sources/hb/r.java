package hb;

import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.PathEffect;
import android.graphics.RectF;
import com.github.mikephil.charting.charts.BarChart;
import java.util.List;
import jb.b;
import jb.d;
import jb.e;
import jb.g;
import jb.i;
import jb.j;
import ya.g;
import ya.h;

public class r extends q {

    /* renamed from: p  reason: collision with root package name */
    protected BarChart f13939p;

    /* renamed from: q  reason: collision with root package name */
    protected Path f13940q = new Path();

    public r(j jVar, h hVar, g gVar, BarChart barChart) {
        super(jVar, hVar, gVar);
        this.f13939p = barChart;
    }

    public void a(float f10, float f11, boolean z10) {
        float f12;
        double d10;
        if (this.f13928a.k() > 10.0f && !this.f13928a.y()) {
            d g10 = this.f13844c.g(this.f13928a.h(), this.f13928a.f());
            d g11 = this.f13844c.g(this.f13928a.h(), this.f13928a.j());
            if (z10) {
                f12 = (float) g11.f14942y;
                d10 = g10.f14942y;
            } else {
                f12 = (float) g10.f14942y;
                d10 = g11.f14942y;
            }
            d.c(g10);
            d.c(g11);
            f10 = f12;
            f11 = (float) d10;
        }
        b(f10, f11);
    }

    /* access modifiers changed from: protected */
    public void d() {
        this.f13846e.setTypeface(this.f13931h.c());
        this.f13846e.setTextSize(this.f13931h.b());
        b b10 = i.b(this.f13846e, this.f13931h.y());
        float f10 = b10.f14939y;
        b v10 = i.v(b10.f14938x, f10, this.f13931h.b0());
        this.f13931h.J = Math.round((float) ((int) (b10.f14938x + (this.f13931h.d() * 3.5f))));
        this.f13931h.K = Math.round(f10);
        h hVar = this.f13931h;
        hVar.L = (int) (v10.f14938x + (hVar.d() * 3.5f));
        this.f13931h.M = Math.round(v10.f14939y);
        b.c(v10);
    }

    /* access modifiers changed from: protected */
    public void e(Canvas canvas, float f10, float f11, Path path) {
        path.moveTo(this.f13928a.i(), f11);
        path.lineTo(this.f13928a.h(), f11);
        canvas.drawPath(path, this.f13845d);
        path.reset();
    }

    /* access modifiers changed from: protected */
    public void g(Canvas canvas, float f10, e eVar) {
        float b02 = this.f13931h.b0();
        boolean A = this.f13931h.A();
        int i10 = this.f13931h.f20233n * 2;
        float[] fArr = new float[i10];
        for (int i11 = 0; i11 < i10; i11 += 2) {
            if (A) {
                fArr[i11 + 1] = this.f13931h.f20232m[i11 / 2];
            } else {
                fArr[i11 + 1] = this.f13931h.f20231l[i11 / 2];
            }
        }
        this.f13844c.k(fArr);
        for (int i12 = 0; i12 < i10; i12 += 2) {
            float f11 = fArr[i12 + 1];
            if (this.f13928a.F(f11)) {
                ab.h z10 = this.f13931h.z();
                h hVar = this.f13931h;
                f(canvas, z10.a(hVar.f20231l[i12 / 2], hVar), f10, f11, eVar, b02);
            }
        }
    }

    public RectF h() {
        this.f13934k.set(this.f13928a.p());
        this.f13934k.inset(0.0f, -this.f13843b.v());
        return this.f13934k;
    }

    public void i(Canvas canvas) {
        if (this.f13931h.f() && this.f13931h.E()) {
            float d10 = this.f13931h.d();
            this.f13846e.setTypeface(this.f13931h.c());
            this.f13846e.setTextSize(this.f13931h.b());
            this.f13846e.setColor(this.f13931h.a());
            e c10 = e.c(0.0f, 0.0f);
            if (this.f13931h.c0() == h.a.TOP) {
                c10.f14944x = 0.0f;
                c10.f14945y = 0.5f;
                g(canvas, this.f13928a.i() + d10, c10);
            } else if (this.f13931h.c0() == h.a.TOP_INSIDE) {
                c10.f14944x = 1.0f;
                c10.f14945y = 0.5f;
                g(canvas, this.f13928a.i() - d10, c10);
            } else if (this.f13931h.c0() == h.a.BOTTOM) {
                c10.f14944x = 1.0f;
                c10.f14945y = 0.5f;
                g(canvas, this.f13928a.h() - d10, c10);
            } else if (this.f13931h.c0() == h.a.BOTTOM_INSIDE) {
                c10.f14944x = 1.0f;
                c10.f14945y = 0.5f;
                g(canvas, this.f13928a.h() + d10, c10);
            } else {
                c10.f14944x = 0.0f;
                c10.f14945y = 0.5f;
                g(canvas, this.f13928a.i() + d10, c10);
                c10.f14944x = 1.0f;
                c10.f14945y = 0.5f;
                g(canvas, this.f13928a.h() - d10, c10);
            }
            e.h(c10);
        }
    }

    public void j(Canvas canvas) {
        if (this.f13931h.B() && this.f13931h.f()) {
            this.f13847f.setColor(this.f13931h.o());
            this.f13847f.setStrokeWidth(this.f13931h.q());
            if (this.f13931h.c0() == h.a.TOP || this.f13931h.c0() == h.a.TOP_INSIDE || this.f13931h.c0() == h.a.BOTH_SIDED) {
                canvas.drawLine(this.f13928a.i(), this.f13928a.j(), this.f13928a.i(), this.f13928a.f(), this.f13847f);
            }
            if (this.f13931h.c0() == h.a.BOTTOM || this.f13931h.c0() == h.a.BOTTOM_INSIDE || this.f13931h.c0() == h.a.BOTH_SIDED) {
                canvas.drawLine(this.f13928a.h(), this.f13928a.j(), this.f13928a.h(), this.f13928a.f(), this.f13847f);
            }
        }
    }

    public void n(Canvas canvas) {
        List x10 = this.f13931h.x();
        if (x10 != null && x10.size() > 0) {
            float[] fArr = this.f13935l;
            fArr[0] = 0.0f;
            fArr[1] = 0.0f;
            Path path = this.f13940q;
            path.reset();
            for (int i10 = 0; i10 < x10.size(); i10++) {
                ya.g gVar = (ya.g) x10.get(i10);
                if (gVar.f()) {
                    int save = canvas.save();
                    this.f13936m.set(this.f13928a.p());
                    this.f13936m.inset(0.0f, -gVar.r());
                    canvas.clipRect(this.f13936m);
                    this.f13848g.setStyle(Paint.Style.STROKE);
                    this.f13848g.setColor(gVar.q());
                    this.f13848g.setStrokeWidth(gVar.r());
                    this.f13848g.setPathEffect(gVar.m());
                    fArr[1] = gVar.p();
                    this.f13844c.k(fArr);
                    path.moveTo(this.f13928a.h(), fArr[1]);
                    path.lineTo(this.f13928a.i(), fArr[1]);
                    canvas.drawPath(path, this.f13848g);
                    path.reset();
                    String n10 = gVar.n();
                    if (n10 != null && !n10.equals("")) {
                        this.f13848g.setStyle(gVar.s());
                        this.f13848g.setPathEffect((PathEffect) null);
                        this.f13848g.setColor(gVar.a());
                        this.f13848g.setStrokeWidth(0.5f);
                        this.f13848g.setTextSize(gVar.b());
                        float a10 = (float) i.a(this.f13848g, n10);
                        float e10 = i.e(4.0f) + gVar.d();
                        float r10 = gVar.r() + a10 + gVar.e();
                        g.a o10 = gVar.o();
                        if (o10 == g.a.RIGHT_TOP) {
                            this.f13848g.setTextAlign(Paint.Align.RIGHT);
                            canvas.drawText(n10, this.f13928a.i() - e10, (fArr[1] - r10) + a10, this.f13848g);
                        } else if (o10 == g.a.RIGHT_BOTTOM) {
                            this.f13848g.setTextAlign(Paint.Align.RIGHT);
                            canvas.drawText(n10, this.f13928a.i() - e10, fArr[1] + r10, this.f13848g);
                        } else if (o10 == g.a.LEFT_TOP) {
                            this.f13848g.setTextAlign(Paint.Align.LEFT);
                            canvas.drawText(n10, this.f13928a.h() + e10, (fArr[1] - r10) + a10, this.f13848g);
                        } else {
                            this.f13848g.setTextAlign(Paint.Align.LEFT);
                            canvas.drawText(n10, this.f13928a.I() + e10, fArr[1] + r10, this.f13848g);
                        }
                    }
                    canvas.restoreToCount(save);
                }
            }
        }
    }
}
