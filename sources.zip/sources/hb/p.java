package hb;

import android.graphics.Canvas;
import android.graphics.drawable.Drawable;
import android.util.Log;
import bb.d;
import cb.h;
import db.k;
import hb.c;
import java.util.List;
import jb.e;
import jb.g;
import jb.i;
import jb.j;
import wa.a;
import za.b0;
import za.q;

public class p extends l {

    /* renamed from: i  reason: collision with root package name */
    protected h f13929i;

    /* renamed from: j  reason: collision with root package name */
    float[] f13930j = new float[2];

    public p(h hVar, a aVar, j jVar) {
        super(aVar, jVar);
        this.f13929i = hVar;
    }

    public void b(Canvas canvas) {
        for (k kVar : this.f13929i.getScatterData().g()) {
            if (kVar.isVisible()) {
                k(canvas, kVar);
            }
        }
    }

    public void c(Canvas canvas) {
    }

    public void d(Canvas canvas, d[] dVarArr) {
        b0 scatterData = this.f13929i.getScatterData();
        for (d dVar : dVarArr) {
            k kVar = (k) scatterData.e(dVar.d());
            if (kVar != null && kVar.M0()) {
                q t10 = kVar.t(dVar.h(), dVar.j());
                if (h(t10, kVar)) {
                    jb.d e10 = this.f13929i.e(kVar.G0()).e(t10.f(), t10.c() * this.f13874b.e());
                    dVar.m((float) e10.f14941x, (float) e10.f14942y);
                    j(canvas, (float) e10.f14941x, (float) e10.f14942y, kVar);
                }
            }
        }
    }

    public void e(Canvas canvas) {
        k kVar;
        q qVar;
        if (g(this.f13929i)) {
            List g10 = this.f13929i.getScatterData().g();
            for (int i10 = 0; i10 < this.f13929i.getScatterData().f(); i10++) {
                k kVar2 = (k) g10.get(i10);
                if (i(kVar2) && kVar2.I0() >= 1) {
                    a(kVar2);
                    this.f13855g.a(this.f13929i, kVar2);
                    g e10 = this.f13929i.e(kVar2.G0());
                    float d10 = this.f13874b.d();
                    float e11 = this.f13874b.e();
                    c.a aVar = this.f13855g;
                    float[] d11 = e10.d(kVar2, d10, e11, aVar.f13856a, aVar.f13857b);
                    float e12 = i.e(kVar2.e0());
                    ab.h L = kVar2.L();
                    e d12 = e.d(kVar2.J0());
                    d12.f14944x = i.e(d12.f14944x);
                    d12.f14945y = i.e(d12.f14945y);
                    int i11 = 0;
                    while (i11 < d11.length && this.f13928a.C(d11[i11])) {
                        if (this.f13928a.B(d11[i11])) {
                            int i12 = i11 + 1;
                            if (this.f13928a.F(d11[i12])) {
                                int i13 = i11 / 2;
                                q P = kVar2.P(this.f13855g.f13856a + i13);
                                if (kVar2.B0()) {
                                    String h10 = L.h(P);
                                    float f10 = d11[i11];
                                    float f11 = d11[i12] - e12;
                                    qVar = P;
                                    float f12 = f11;
                                    kVar = kVar2;
                                    l(canvas, h10, f10, f12, kVar2.f0(i13 + this.f13855g.f13856a));
                                } else {
                                    qVar = P;
                                    kVar = kVar2;
                                }
                                if (qVar.b() != null && kVar.x()) {
                                    Drawable b10 = qVar.b();
                                    i.f(canvas, b10, (int) (d11[i11] + d12.f14944x), (int) (d11[i12] + d12.f14945y), b10.getIntrinsicWidth(), b10.getIntrinsicHeight());
                                }
                                i11 += 2;
                                kVar2 = kVar;
                            }
                        }
                        kVar = kVar2;
                        i11 += 2;
                        kVar2 = kVar;
                    }
                    e.h(d12);
                }
            }
        }
    }

    public void f() {
    }

    /* access modifiers changed from: protected */
    public void k(Canvas canvas, k kVar) {
        int i10;
        k kVar2 = kVar;
        if (kVar.I0() >= 1) {
            j jVar = this.f13928a;
            g e10 = this.f13929i.e(kVar.G0());
            float e11 = this.f13874b.e();
            ib.e u02 = kVar.u0();
            if (u02 == null) {
                Log.i("MISSING", "There's no IShapeRenderer specified for ScatterDataSet");
                return;
            }
            int min = (int) Math.min(Math.ceil((double) (((float) kVar.I0()) * this.f13874b.d())), (double) ((float) kVar.I0()));
            int i11 = 0;
            while (i11 < min) {
                q P = kVar2.P(i11);
                this.f13930j[0] = P.f();
                this.f13930j[1] = P.c() * e11;
                e10.k(this.f13930j);
                if (jVar.C(this.f13930j[0])) {
                    if (!jVar.B(this.f13930j[0]) || !jVar.F(this.f13930j[1])) {
                        i10 = i11;
                    } else {
                        this.f13875c.setColor(kVar2.V(i11 / 2));
                        j jVar2 = this.f13928a;
                        float[] fArr = this.f13930j;
                        i10 = i11;
                        u02.a(canvas, kVar, jVar2, fArr[0], fArr[1], this.f13875c);
                    }
                    i11 = i10 + 1;
                } else {
                    return;
                }
            }
        }
    }

    public void l(Canvas canvas, String str, float f10, float f11, int i10) {
        this.f13878f.setColor(i10);
        canvas.drawText(str, f10, f11, this.f13878f);
    }
}
