package n3;

import android.content.Context;
import androidx.privacysandbox.ads.adservices.topics.f;
import jk.b0;
import jk.c0;
import jk.d0;
import jk.n0;
import kotlin.jvm.internal.DefaultConstructorMarker;
import mj.o;
import mj.u;
import qj.d;
import qj.g;
import sj.k;
import zj.p;

public abstract class a {

    /* renamed from: a  reason: collision with root package name */
    public static final b f16292a = new b((DefaultConstructorMarker) null);

    /* renamed from: n3.a$a  reason: collision with other inner class name */
    private static final class C0228a extends a {
        /* access modifiers changed from: private */

        /* renamed from: b  reason: collision with root package name */
        public final f f16293b;

        /* renamed from: n3.a$a$a  reason: collision with other inner class name */
        static final class C0229a extends k implements p {
            final /* synthetic */ C0228a A;
            final /* synthetic */ androidx.privacysandbox.ads.adservices.topics.b B;

            /* renamed from: z  reason: collision with root package name */
            int f16294z;

            /* JADX INFO: super call moved to the top of the method (can break code semantics) */
            C0229a(C0228a aVar, androidx.privacysandbox.ads.adservices.topics.b bVar, d dVar) {
                super(2, dVar);
                this.A = aVar;
                this.B = bVar;
            }

            public final d a(Object obj, d dVar) {
                return new C0229a(this.A, this.B, dVar);
            }

            public final Object j(Object obj) {
                Object c10 = d.c();
                int i10 = this.f16294z;
                if (i10 == 0) {
                    o.b(obj);
                    f c11 = this.A.f16293b;
                    androidx.privacysandbox.ads.adservices.topics.b bVar = this.B;
                    this.f16294z = 1;
                    obj = c11.a(bVar, this);
                    if (obj == c10) {
                        return c10;
                    }
                } else if (i10 == 1) {
                    o.b(obj);
                } else {
                    throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                }
                return obj;
            }

            /* renamed from: m */
            public final Object i(b0 b0Var, d dVar) {
                return ((C0229a) a(b0Var, dVar)).j(u.f47552a);
            }
        }

        public C0228a(f fVar) {
            ak.k.f(fVar, "mTopicsManager");
            this.f16293b = fVar;
        }

        public com.google.common.util.concurrent.o b(androidx.privacysandbox.ads.adservices.topics.b bVar) {
            ak.k.f(bVar, "request");
            return l3.b.c(g.b(c0.a(n0.c()), (g) null, (d0) null, new C0229a(this, bVar, (d) null), 3, (Object) null), (Object) null, 1, (Object) null);
        }
    }

    public static final class b {
        private b() {
        }

        public /* synthetic */ b(DefaultConstructorMarker defaultConstructorMarker) {
            this();
        }

        public final a a(Context context) {
            ak.k.f(context, "context");
            f a10 = f.f6827a.a(context);
            if (a10 != null) {
                return new C0228a(a10);
            }
            return null;
        }
    }

    public static final a a(Context context) {
        return f16292a.a(context);
    }

    public abstract com.google.common.util.concurrent.o b(androidx.privacysandbox.ads.adservices.topics.b bVar);
}
