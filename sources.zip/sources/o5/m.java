package o5;

import android.graphics.ColorSpace;
import android.graphics.ImageDecoder;
import android.os.Build;
import android.util.Log;
import android.util.Size;
import g5.b;
import g5.g;
import g5.h;
import g5.i;
import g5.j;
import i5.v;
import p5.n;
import p5.t;
import p5.y;

public abstract class m implements j {

    /* renamed from: a  reason: collision with root package name */
    final y f16568a = y.b();

    class a implements ImageDecoder.OnHeaderDecodedListener {

        /* renamed from: a  reason: collision with root package name */
        final /* synthetic */ int f16569a;

        /* renamed from: b  reason: collision with root package name */
        final /* synthetic */ int f16570b;

        /* renamed from: c  reason: collision with root package name */
        final /* synthetic */ boolean f16571c;

        /* renamed from: d  reason: collision with root package name */
        final /* synthetic */ b f16572d;

        /* renamed from: e  reason: collision with root package name */
        final /* synthetic */ n f16573e;

        /* renamed from: f  reason: collision with root package name */
        final /* synthetic */ i f16574f;

        /* renamed from: o5.m$a$a  reason: collision with other inner class name */
        class C0234a implements ImageDecoder.OnPartialImageListener {
            C0234a() {
            }

            public boolean onPartialImage(ImageDecoder.DecodeException decodeException) {
                return false;
            }
        }

        a(int i10, int i11, boolean z10, b bVar, n nVar, i iVar) {
            this.f16569a = i10;
            this.f16570b = i11;
            this.f16571c = z10;
            this.f16572d = bVar;
            this.f16573e = nVar;
            this.f16574f = iVar;
        }

        public void onHeaderDecoded(ImageDecoder imageDecoder, ImageDecoder.ImageInfo imageInfo, ImageDecoder.Source source) {
            ColorSpace.Named named;
            boolean z10 = false;
            if (m.this.f16568a.e(this.f16569a, this.f16570b, this.f16571c, false)) {
                imageDecoder.setAllocator(3);
            } else {
                imageDecoder.setAllocator(1);
            }
            if (this.f16572d == b.PREFER_RGB_565) {
                imageDecoder.setMemorySizePolicy(0);
            }
            imageDecoder.setOnPartialImageListener(new C0234a());
            Size a10 = imageInfo.getSize();
            int i10 = this.f16569a;
            if (i10 == Integer.MIN_VALUE) {
                i10 = a10.getWidth();
            }
            int i11 = this.f16570b;
            if (i11 == Integer.MIN_VALUE) {
                i11 = a10.getHeight();
            }
            float b10 = this.f16573e.b(a10.getWidth(), a10.getHeight(), i10, i11);
            int round = Math.round(((float) a10.getWidth()) * b10);
            int round2 = Math.round(((float) a10.getHeight()) * b10);
            if (Log.isLoggable("ImageDecoder", 2)) {
                Log.v("ImageDecoder", "Resizing from [" + a10.getWidth() + "x" + a10.getHeight() + "] to [" + round + "x" + round2 + "] scaleFactor: " + b10);
            }
            imageDecoder.setTargetSize(round, round2);
            int i12 = Build.VERSION.SDK_INT;
            if (i12 >= 28) {
                if (this.f16574f == i.DISPLAY_P3 && imageInfo.getColorSpace() != null && imageInfo.getColorSpace().isWideGamut()) {
                    z10 = true;
                }
                if (z10) {
                    named = ColorSpace.Named.DISPLAY_P3;
                } else {
                    named = ColorSpace.Named.SRGB;
                }
                imageDecoder.setTargetColorSpace(ColorSpace.get(named));
            } else if (i12 >= 26) {
                imageDecoder.setTargetColorSpace(ColorSpace.get(ColorSpace.Named.SRGB));
            }
        }
    }

    public /* bridge */ /* synthetic */ boolean a(Object obj, h hVar) {
        return e(a.a(obj), hVar);
    }

    public /* bridge */ /* synthetic */ v b(Object obj, int i10, int i11, h hVar) {
        return d(a.a(obj), i10, i11, hVar);
    }

    /* access modifiers changed from: protected */
    public abstract v c(ImageDecoder.Source source, int i10, int i11, ImageDecoder.OnHeaderDecodedListener onHeaderDecodedListener);

    public final v d(ImageDecoder.Source source, int i10, int i11, h hVar) {
        boolean z10;
        b bVar = (b) hVar.c(t.f16758f);
        n nVar = (n) hVar.c(n.f16753h);
        g gVar = t.f16762j;
        if (hVar.c(gVar) == null || !((Boolean) hVar.c(gVar)).booleanValue()) {
            z10 = false;
        } else {
            z10 = true;
        }
        return c(source, i10, i11, new a(i10, i11, z10, bVar, nVar, (i) hVar.c(t.f16759g)));
    }

    public final boolean e(ImageDecoder.Source source, h hVar) {
        return true;
    }
}
