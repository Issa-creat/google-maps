package o5;

import android.graphics.ImageDecoder;

public abstract /* synthetic */ class a {
    public static /* bridge */ /* synthetic */ ImageDecoder.Source a(Object obj) {
        return (ImageDecoder.Source) obj;
    }
}
