package o5;

import android.content.Context;
import g5.l;
import i5.v;
import java.security.MessageDigest;

public final class o implements l {

    /* renamed from: b  reason: collision with root package name */
    private static final l f16578b = new o();

    private o() {
    }

    public static o c() {
        return (o) f16578b;
    }

    public v a(Context context, v vVar, int i10, int i11) {
        return vVar;
    }

    public void b(MessageDigest messageDigest) {
    }
}
