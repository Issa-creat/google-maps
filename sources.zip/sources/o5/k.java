package o5;

public abstract /* synthetic */ class k {
}
