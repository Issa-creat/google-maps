package o5;

import b6.j;
import i5.v;

public abstract class n implements v {

    /* renamed from: a  reason: collision with root package name */
    protected final Object f16577a;

    public n(Object obj) {
        this.f16577a = j.d(obj);
    }

    public final int a() {
        return 1;
    }

    public Class b() {
        return this.f16577a.getClass();
    }

    public final Object get() {
        return this.f16577a;
    }

    public void recycle() {
    }
}
