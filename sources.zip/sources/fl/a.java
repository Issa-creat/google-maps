package fl;

import ak.k;
import okio.b;
import okio.e;
import okio.f0;
import okio.s;
import okio.x;

public abstract class a {

    /* renamed from: a  reason: collision with root package name */
    private static final byte[] f45607a = f0.a("0123456789abcdef");

    public static final e.a a(e eVar, e.a aVar) {
        boolean z10;
        k.f(eVar, "<this>");
        k.f(aVar, "unsafeCursor");
        e.a g10 = b.g(aVar);
        if (g10.f48233a == null) {
            z10 = true;
        } else {
            z10 = false;
        }
        if (z10) {
            g10.f48233a = eVar;
            g10.f48234w = true;
            return g10;
        }
        throw new IllegalStateException("already attached to a buffer".toString());
    }

    public static final byte[] b() {
        return f45607a;
    }

    public static final boolean c(x xVar, int i10, byte[] bArr, int i11, int i12) {
        k.f(xVar, "segment");
        k.f(bArr, "bytes");
        int i13 = xVar.f48282c;
        byte[] bArr2 = xVar.f48280a;
        while (i11 < i12) {
            if (i10 == i13) {
                xVar = xVar.f48285f;
                k.c(xVar);
                byte[] bArr3 = xVar.f48280a;
                int i14 = xVar.f48281b;
                bArr2 = bArr3;
                i10 = i14;
                i13 = xVar.f48282c;
            }
            if (bArr2[i10] != bArr[i11]) {
                return false;
            }
            i10++;
            i11++;
        }
        return true;
    }

    public static final String d(e eVar, long j10) {
        k.f(eVar, "<this>");
        if (j10 > 0) {
            long j11 = j10 - 1;
            if (eVar.o(j11) == 13) {
                String s12 = eVar.s1(j11);
                eVar.skip(2);
                return s12;
            }
        }
        String s13 = eVar.s1(j10);
        eVar.skip(1);
        return s13;
    }

    public static final int e(e eVar, s sVar, boolean z10) {
        int i10;
        int i11;
        boolean z11;
        int i12;
        x xVar;
        int i13;
        e eVar2 = eVar;
        k.f(eVar2, "<this>");
        k.f(sVar, "options");
        x xVar2 = eVar2.f48231a;
        if (xVar2 != null) {
            byte[] bArr = xVar2.f48280a;
            int i14 = xVar2.f48281b;
            int i15 = xVar2.f48282c;
            int[] m10 = sVar.m();
            x xVar3 = xVar2;
            int i16 = 0;
            int i17 = -1;
            loop0:
            while (true) {
                int i18 = i16 + 1;
                int i19 = m10[i16];
                int i20 = i18 + 1;
                int i21 = m10[i18];
                if (i21 != -1) {
                    i17 = i21;
                }
                if (xVar3 == null) {
                    break;
                }
                if (i19 < 0) {
                    int i22 = i20 + (i19 * -1);
                    while (true) {
                        int i23 = i14 + 1;
                        int i24 = i20 + 1;
                        if ((bArr[i14] & 255) != m10[i20]) {
                            return i17;
                        }
                        if (i24 == i22) {
                            z11 = true;
                        } else {
                            z11 = false;
                        }
                        if (i23 == i15) {
                            k.c(xVar3);
                            x xVar4 = xVar3.f48285f;
                            k.c(xVar4);
                            i13 = xVar4.f48281b;
                            byte[] bArr2 = xVar4.f48280a;
                            i12 = xVar4.f48282c;
                            if (xVar4 == xVar2) {
                                if (!z11) {
                                    break loop0;
                                }
                                bArr = bArr2;
                                xVar = null;
                            } else {
                                byte[] bArr3 = bArr2;
                                xVar = xVar4;
                                bArr = bArr3;
                            }
                        } else {
                            x xVar5 = xVar3;
                            i12 = i15;
                            i13 = i23;
                            xVar = xVar5;
                        }
                        if (z11) {
                            i11 = m10[i24];
                            i10 = i13;
                            i15 = i12;
                            xVar3 = xVar;
                            break;
                        }
                        i14 = i13;
                        i15 = i12;
                        i20 = i24;
                        xVar3 = xVar;
                    }
                } else {
                    i10 = i14 + 1;
                    byte b10 = bArr[i14] & 255;
                    int i25 = i20 + i19;
                    while (i20 != i25) {
                        if (b10 == m10[i20]) {
                            i11 = m10[i20 + i19];
                            if (i10 == i15) {
                                xVar3 = xVar3.f48285f;
                                k.c(xVar3);
                                i10 = xVar3.f48281b;
                                bArr = xVar3.f48280a;
                                i15 = xVar3.f48282c;
                                if (xVar3 == xVar2) {
                                    xVar3 = null;
                                }
                            }
                        } else {
                            i20++;
                        }
                    }
                    return i17;
                }
                if (i11 >= 0) {
                    return i11;
                }
                i16 = -i11;
                i14 = i10;
            }
            if (z10) {
                return -2;
            }
            return i17;
        } else if (z10) {
            return -2;
        } else {
            return -1;
        }
    }

    public static /* synthetic */ int f(e eVar, s sVar, boolean z10, int i10, Object obj) {
        if ((i10 & 2) != 0) {
            z10 = false;
        }
        return e(eVar, sVar, z10);
    }
}
