package fl;

import ak.k;
import okio.z;

public abstract class c {
    public static final int a(int[] iArr, int i10, int i11, int i12) {
        k.f(iArr, "<this>");
        int i13 = i12 - 1;
        while (i11 <= i13) {
            int i14 = (i11 + i13) >>> 1;
            int i15 = iArr[i14];
            if (i15 < i10) {
                i11 = i14 + 1;
            } else if (i15 <= i10) {
                return i14;
            } else {
                i13 = i14 - 1;
            }
        }
        return (-i11) - 1;
    }

    public static final int b(z zVar, int i10) {
        k.f(zVar, "<this>");
        int a10 = a(zVar.C(), i10 + 1, 0, zVar.D().length);
        if (a10 >= 0) {
            return a10;
        }
        return ~a10;
    }
}
