package wg;

import com.google.protobuf.p0;
import com.google.protobuf.w;
import com.google.protobuf.w0;

public final class a extends w implements p0 {
    public static final int CAMPAIGN_ID_FIELD_NUMBER = 1;
    /* access modifiers changed from: private */
    public static final a DEFAULT_INSTANCE;
    public static final int IMPRESSION_TIMESTAMP_MILLIS_FIELD_NUMBER = 2;
    private static volatile w0 PARSER;
    private String campaignId_ = "";
    private long impressionTimestampMillis_;

    /* renamed from: wg.a$a  reason: collision with other inner class name */
    static /* synthetic */ class C0429a {

        /* renamed from: a  reason: collision with root package name */
        static final /* synthetic */ int[] f43612a;

        /* JADX WARNING: Can't wrap try/catch for region: R(14:0|1|2|3|4|5|6|7|8|9|10|11|12|(3:13|14|16)) */
        /* JADX WARNING: Can't wrap try/catch for region: R(16:0|1|2|3|4|5|6|7|8|9|10|11|12|13|14|16) */
        /* JADX WARNING: Failed to process nested try/catch */
        /* JADX WARNING: Missing exception handler attribute for start block: B:11:0x003e */
        /* JADX WARNING: Missing exception handler attribute for start block: B:13:0x0049 */
        /* JADX WARNING: Missing exception handler attribute for start block: B:3:0x0012 */
        /* JADX WARNING: Missing exception handler attribute for start block: B:5:0x001d */
        /* JADX WARNING: Missing exception handler attribute for start block: B:7:0x0028 */
        /* JADX WARNING: Missing exception handler attribute for start block: B:9:0x0033 */
        static {
            /*
                com.google.protobuf.w$d[] r0 = com.google.protobuf.w.d.values()
                int r0 = r0.length
                int[] r0 = new int[r0]
                f43612a = r0
                com.google.protobuf.w$d r1 = com.google.protobuf.w.d.NEW_MUTABLE_INSTANCE     // Catch:{ NoSuchFieldError -> 0x0012 }
                int r1 = r1.ordinal()     // Catch:{ NoSuchFieldError -> 0x0012 }
                r2 = 1
                r0[r1] = r2     // Catch:{ NoSuchFieldError -> 0x0012 }
            L_0x0012:
                int[] r0 = f43612a     // Catch:{ NoSuchFieldError -> 0x001d }
                com.google.protobuf.w$d r1 = com.google.protobuf.w.d.NEW_BUILDER     // Catch:{ NoSuchFieldError -> 0x001d }
                int r1 = r1.ordinal()     // Catch:{ NoSuchFieldError -> 0x001d }
                r2 = 2
                r0[r1] = r2     // Catch:{ NoSuchFieldError -> 0x001d }
            L_0x001d:
                int[] r0 = f43612a     // Catch:{ NoSuchFieldError -> 0x0028 }
                com.google.protobuf.w$d r1 = com.google.protobuf.w.d.BUILD_MESSAGE_INFO     // Catch:{ NoSuchFieldError -> 0x0028 }
                int r1 = r1.ordinal()     // Catch:{ NoSuchFieldError -> 0x0028 }
                r2 = 3
                r0[r1] = r2     // Catch:{ NoSuchFieldError -> 0x0028 }
            L_0x0028:
                int[] r0 = f43612a     // Catch:{ NoSuchFieldError -> 0x0033 }
                com.google.protobuf.w$d r1 = com.google.protobuf.w.d.GET_DEFAULT_INSTANCE     // Catch:{ NoSuchFieldError -> 0x0033 }
                int r1 = r1.ordinal()     // Catch:{ NoSuchFieldError -> 0x0033 }
                r2 = 4
                r0[r1] = r2     // Catch:{ NoSuchFieldError -> 0x0033 }
            L_0x0033:
                int[] r0 = f43612a     // Catch:{ NoSuchFieldError -> 0x003e }
                com.google.protobuf.w$d r1 = com.google.protobuf.w.d.GET_PARSER     // Catch:{ NoSuchFieldError -> 0x003e }
                int r1 = r1.ordinal()     // Catch:{ NoSuchFieldError -> 0x003e }
                r2 = 5
                r0[r1] = r2     // Catch:{ NoSuchFieldError -> 0x003e }
            L_0x003e:
                int[] r0 = f43612a     // Catch:{ NoSuchFieldError -> 0x0049 }
                com.google.protobuf.w$d r1 = com.google.protobuf.w.d.GET_MEMOIZED_IS_INITIALIZED     // Catch:{ NoSuchFieldError -> 0x0049 }
                int r1 = r1.ordinal()     // Catch:{ NoSuchFieldError -> 0x0049 }
                r2 = 6
                r0[r1] = r2     // Catch:{ NoSuchFieldError -> 0x0049 }
            L_0x0049:
                int[] r0 = f43612a     // Catch:{ NoSuchFieldError -> 0x0054 }
                com.google.protobuf.w$d r1 = com.google.protobuf.w.d.SET_MEMOIZED_IS_INITIALIZED     // Catch:{ NoSuchFieldError -> 0x0054 }
                int r1 = r1.ordinal()     // Catch:{ NoSuchFieldError -> 0x0054 }
                r2 = 7
                r0[r1] = r2     // Catch:{ NoSuchFieldError -> 0x0054 }
            L_0x0054:
                return
            */
            throw new UnsupportedOperationException("Method not decompiled: wg.a.C0429a.<clinit>():void");
        }
    }

    public static final class b extends w.a implements p0 {
        /* synthetic */ b(C0429a aVar) {
            this();
        }

        public b v(String str) {
            p();
            ((a) this.f39631w).W(str);
            return this;
        }

        public b w(long j10) {
            p();
            ((a) this.f39631w).X(j10);
            return this;
        }

        private b() {
            super(a.DEFAULT_INSTANCE);
        }
    }

    static {
        a aVar = new a();
        DEFAULT_INSTANCE = aVar;
        w.N(a.class, aVar);
    }

    private a() {
    }

    public static b V() {
        return (b) DEFAULT_INSTANCE.s();
    }

    /* access modifiers changed from: private */
    public void W(String str) {
        str.getClass();
        this.campaignId_ = str;
    }

    /* access modifiers changed from: private */
    public void X(long j10) {
        this.impressionTimestampMillis_ = j10;
    }

    public String U() {
        return this.campaignId_;
    }

    /* access modifiers changed from: protected */
    public final Object w(w.d dVar, Object obj, Object obj2) {
        switch (C0429a.f43612a[dVar.ordinal()]) {
            case 1:
                return new a();
            case 2:
                return new b((C0429a) null);
            case 3:
                return w.K(DEFAULT_INSTANCE, "\u0000\u0002\u0000\u0000\u0001\u0002\u0002\u0000\u0000\u0000\u0001Ȉ\u0002\u0002", new Object[]{"campaignId_", "impressionTimestampMillis_"});
            case 4:
                return DEFAULT_INSTANCE;
            case 5:
                w0 w0Var = PARSER;
                if (w0Var == null) {
                    synchronized (a.class) {
                        w0Var = PARSER;
                        if (w0Var == null) {
                            w0Var = new w.b(DEFAULT_INSTANCE);
                            PARSER = w0Var;
                        }
                    }
                }
                return w0Var;
            case 6:
                return (byte) 1;
            case 7:
                return null;
            default:
                throw new UnsupportedOperationException();
        }
    }
}
