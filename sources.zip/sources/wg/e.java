package wg;

import com.google.protobuf.p0;
import com.google.protobuf.w;
import com.google.protobuf.w0;
import com.google.protobuf.y;
import java.util.List;
import vg.c;

public final class e extends w implements p0 {
    /* access modifiers changed from: private */
    public static final e DEFAULT_INSTANCE;
    public static final int EXPIRATION_EPOCH_TIMESTAMP_MILLIS_FIELD_NUMBER = 2;
    public static final int MESSAGES_FIELD_NUMBER = 1;
    private static volatile w0 PARSER;
    private long expirationEpochTimestampMillis_;
    private y.d messages_ = w.x();

    static /* synthetic */ class a {

        /* renamed from: a  reason: collision with root package name */
        static final /* synthetic */ int[] f43616a;

        /* JADX WARNING: Can't wrap try/catch for region: R(14:0|1|2|3|4|5|6|7|8|9|10|11|12|(3:13|14|16)) */
        /* JADX WARNING: Can't wrap try/catch for region: R(16:0|1|2|3|4|5|6|7|8|9|10|11|12|13|14|16) */
        /* JADX WARNING: Failed to process nested try/catch */
        /* JADX WARNING: Missing exception handler attribute for start block: B:11:0x003e */
        /* JADX WARNING: Missing exception handler attribute for start block: B:13:0x0049 */
        /* JADX WARNING: Missing exception handler attribute for start block: B:3:0x0012 */
        /* JADX WARNING: Missing exception handler attribute for start block: B:5:0x001d */
        /* JADX WARNING: Missing exception handler attribute for start block: B:7:0x0028 */
        /* JADX WARNING: Missing exception handler attribute for start block: B:9:0x0033 */
        static {
            /*
                com.google.protobuf.w$d[] r0 = com.google.protobuf.w.d.values()
                int r0 = r0.length
                int[] r0 = new int[r0]
                f43616a = r0
                com.google.protobuf.w$d r1 = com.google.protobuf.w.d.NEW_MUTABLE_INSTANCE     // Catch:{ NoSuchFieldError -> 0x0012 }
                int r1 = r1.ordinal()     // Catch:{ NoSuchFieldError -> 0x0012 }
                r2 = 1
                r0[r1] = r2     // Catch:{ NoSuchFieldError -> 0x0012 }
            L_0x0012:
                int[] r0 = f43616a     // Catch:{ NoSuchFieldError -> 0x001d }
                com.google.protobuf.w$d r1 = com.google.protobuf.w.d.NEW_BUILDER     // Catch:{ NoSuchFieldError -> 0x001d }
                int r1 = r1.ordinal()     // Catch:{ NoSuchFieldError -> 0x001d }
                r2 = 2
                r0[r1] = r2     // Catch:{ NoSuchFieldError -> 0x001d }
            L_0x001d:
                int[] r0 = f43616a     // Catch:{ NoSuchFieldError -> 0x0028 }
                com.google.protobuf.w$d r1 = com.google.protobuf.w.d.BUILD_MESSAGE_INFO     // Catch:{ NoSuchFieldError -> 0x0028 }
                int r1 = r1.ordinal()     // Catch:{ NoSuchFieldError -> 0x0028 }
                r2 = 3
                r0[r1] = r2     // Catch:{ NoSuchFieldError -> 0x0028 }
            L_0x0028:
                int[] r0 = f43616a     // Catch:{ NoSuchFieldError -> 0x0033 }
                com.google.protobuf.w$d r1 = com.google.protobuf.w.d.GET_DEFAULT_INSTANCE     // Catch:{ NoSuchFieldError -> 0x0033 }
                int r1 = r1.ordinal()     // Catch:{ NoSuchFieldError -> 0x0033 }
                r2 = 4
                r0[r1] = r2     // Catch:{ NoSuchFieldError -> 0x0033 }
            L_0x0033:
                int[] r0 = f43616a     // Catch:{ NoSuchFieldError -> 0x003e }
                com.google.protobuf.w$d r1 = com.google.protobuf.w.d.GET_PARSER     // Catch:{ NoSuchFieldError -> 0x003e }
                int r1 = r1.ordinal()     // Catch:{ NoSuchFieldError -> 0x003e }
                r2 = 5
                r0[r1] = r2     // Catch:{ NoSuchFieldError -> 0x003e }
            L_0x003e:
                int[] r0 = f43616a     // Catch:{ NoSuchFieldError -> 0x0049 }
                com.google.protobuf.w$d r1 = com.google.protobuf.w.d.GET_MEMOIZED_IS_INITIALIZED     // Catch:{ NoSuchFieldError -> 0x0049 }
                int r1 = r1.ordinal()     // Catch:{ NoSuchFieldError -> 0x0049 }
                r2 = 6
                r0[r1] = r2     // Catch:{ NoSuchFieldError -> 0x0049 }
            L_0x0049:
                int[] r0 = f43616a     // Catch:{ NoSuchFieldError -> 0x0054 }
                com.google.protobuf.w$d r1 = com.google.protobuf.w.d.SET_MEMOIZED_IS_INITIALIZED     // Catch:{ NoSuchFieldError -> 0x0054 }
                int r1 = r1.ordinal()     // Catch:{ NoSuchFieldError -> 0x0054 }
                r2 = 7
                r0[r1] = r2     // Catch:{ NoSuchFieldError -> 0x0054 }
            L_0x0054:
                return
            */
            throw new UnsupportedOperationException("Method not decompiled: wg.e.a.<clinit>():void");
        }
    }

    public static final class b extends w.a implements p0 {
        /* synthetic */ b(a aVar) {
            this();
        }

        public b v(long j10) {
            p();
            ((e) this.f39631w).Y(j10);
            return this;
        }

        private b() {
            super(e.DEFAULT_INSTANCE);
        }
    }

    static {
        e eVar = new e();
        DEFAULT_INSTANCE = eVar;
        w.N(e.class, eVar);
    }

    private e() {
    }

    public static e T() {
        return DEFAULT_INSTANCE;
    }

    public static b W() {
        return (b) DEFAULT_INSTANCE.s();
    }

    public static w0 X() {
        return DEFAULT_INSTANCE.i();
    }

    /* access modifiers changed from: private */
    public void Y(long j10) {
        this.expirationEpochTimestampMillis_ = j10;
    }

    public long U() {
        return this.expirationEpochTimestampMillis_;
    }

    public List V() {
        return this.messages_;
    }

    /* access modifiers changed from: protected */
    public final Object w(w.d dVar, Object obj, Object obj2) {
        switch (a.f43616a[dVar.ordinal()]) {
            case 1:
                return new e();
            case 2:
                return new b((a) null);
            case 3:
                return w.K(DEFAULT_INSTANCE, "\u0000\u0002\u0000\u0000\u0001\u0002\u0002\u0000\u0001\u0000\u0001\u001b\u0002\u0002", new Object[]{"messages_", c.class, "expirationEpochTimestampMillis_"});
            case 4:
                return DEFAULT_INSTANCE;
            case 5:
                w0 w0Var = PARSER;
                if (w0Var == null) {
                    synchronized (e.class) {
                        w0Var = PARSER;
                        if (w0Var == null) {
                            w0Var = new w.b(DEFAULT_INSTANCE);
                            PARSER = w0Var;
                        }
                    }
                }
                return w0Var;
            case 6:
                return (byte) 1;
            case 7:
                return null;
            default:
                throw new UnsupportedOperationException();
        }
    }
}
