package wg;

import com.google.protobuf.p0;
import com.google.protobuf.w;
import com.google.protobuf.w0;

public final class c extends w implements p0 {
    public static final int APP_INSTANCE_ID_FIELD_NUMBER = 2;
    public static final int APP_INSTANCE_ID_TOKEN_FIELD_NUMBER = 3;
    /* access modifiers changed from: private */
    public static final c DEFAULT_INSTANCE;
    public static final int GMP_APP_ID_FIELD_NUMBER = 1;
    private static volatile w0 PARSER;
    private String appInstanceIdToken_ = "";
    private String appInstanceId_ = "";
    private String gmpAppId_ = "";

    static /* synthetic */ class a {

        /* renamed from: a  reason: collision with root package name */
        static final /* synthetic */ int[] f43614a;

        /* JADX WARNING: Can't wrap try/catch for region: R(14:0|1|2|3|4|5|6|7|8|9|10|11|12|(3:13|14|16)) */
        /* JADX WARNING: Can't wrap try/catch for region: R(16:0|1|2|3|4|5|6|7|8|9|10|11|12|13|14|16) */
        /* JADX WARNING: Failed to process nested try/catch */
        /* JADX WARNING: Missing exception handler attribute for start block: B:11:0x003e */
        /* JADX WARNING: Missing exception handler attribute for start block: B:13:0x0049 */
        /* JADX WARNING: Missing exception handler attribute for start block: B:3:0x0012 */
        /* JADX WARNING: Missing exception handler attribute for start block: B:5:0x001d */
        /* JADX WARNING: Missing exception handler attribute for start block: B:7:0x0028 */
        /* JADX WARNING: Missing exception handler attribute for start block: B:9:0x0033 */
        static {
            /*
                com.google.protobuf.w$d[] r0 = com.google.protobuf.w.d.values()
                int r0 = r0.length
                int[] r0 = new int[r0]
                f43614a = r0
                com.google.protobuf.w$d r1 = com.google.protobuf.w.d.NEW_MUTABLE_INSTANCE     // Catch:{ NoSuchFieldError -> 0x0012 }
                int r1 = r1.ordinal()     // Catch:{ NoSuchFieldError -> 0x0012 }
                r2 = 1
                r0[r1] = r2     // Catch:{ NoSuchFieldError -> 0x0012 }
            L_0x0012:
                int[] r0 = f43614a     // Catch:{ NoSuchFieldError -> 0x001d }
                com.google.protobuf.w$d r1 = com.google.protobuf.w.d.NEW_BUILDER     // Catch:{ NoSuchFieldError -> 0x001d }
                int r1 = r1.ordinal()     // Catch:{ NoSuchFieldError -> 0x001d }
                r2 = 2
                r0[r1] = r2     // Catch:{ NoSuchFieldError -> 0x001d }
            L_0x001d:
                int[] r0 = f43614a     // Catch:{ NoSuchFieldError -> 0x0028 }
                com.google.protobuf.w$d r1 = com.google.protobuf.w.d.BUILD_MESSAGE_INFO     // Catch:{ NoSuchFieldError -> 0x0028 }
                int r1 = r1.ordinal()     // Catch:{ NoSuchFieldError -> 0x0028 }
                r2 = 3
                r0[r1] = r2     // Catch:{ NoSuchFieldError -> 0x0028 }
            L_0x0028:
                int[] r0 = f43614a     // Catch:{ NoSuchFieldError -> 0x0033 }
                com.google.protobuf.w$d r1 = com.google.protobuf.w.d.GET_DEFAULT_INSTANCE     // Catch:{ NoSuchFieldError -> 0x0033 }
                int r1 = r1.ordinal()     // Catch:{ NoSuchFieldError -> 0x0033 }
                r2 = 4
                r0[r1] = r2     // Catch:{ NoSuchFieldError -> 0x0033 }
            L_0x0033:
                int[] r0 = f43614a     // Catch:{ NoSuchFieldError -> 0x003e }
                com.google.protobuf.w$d r1 = com.google.protobuf.w.d.GET_PARSER     // Catch:{ NoSuchFieldError -> 0x003e }
                int r1 = r1.ordinal()     // Catch:{ NoSuchFieldError -> 0x003e }
                r2 = 5
                r0[r1] = r2     // Catch:{ NoSuchFieldError -> 0x003e }
            L_0x003e:
                int[] r0 = f43614a     // Catch:{ NoSuchFieldError -> 0x0049 }
                com.google.protobuf.w$d r1 = com.google.protobuf.w.d.GET_MEMOIZED_IS_INITIALIZED     // Catch:{ NoSuchFieldError -> 0x0049 }
                int r1 = r1.ordinal()     // Catch:{ NoSuchFieldError -> 0x0049 }
                r2 = 6
                r0[r1] = r2     // Catch:{ NoSuchFieldError -> 0x0049 }
            L_0x0049:
                int[] r0 = f43614a     // Catch:{ NoSuchFieldError -> 0x0054 }
                com.google.protobuf.w$d r1 = com.google.protobuf.w.d.SET_MEMOIZED_IS_INITIALIZED     // Catch:{ NoSuchFieldError -> 0x0054 }
                int r1 = r1.ordinal()     // Catch:{ NoSuchFieldError -> 0x0054 }
                r2 = 7
                r0[r1] = r2     // Catch:{ NoSuchFieldError -> 0x0054 }
            L_0x0054:
                return
            */
            throw new UnsupportedOperationException("Method not decompiled: wg.c.a.<clinit>():void");
        }
    }

    public static final class b extends w.a implements p0 {
        /* synthetic */ b(a aVar) {
            this();
        }

        public b v(String str) {
            p();
            ((c) this.f39631w).W(str);
            return this;
        }

        public b w(String str) {
            p();
            ((c) this.f39631w).X(str);
            return this;
        }

        public b x(String str) {
            p();
            ((c) this.f39631w).Y(str);
            return this;
        }

        private b() {
            super(c.DEFAULT_INSTANCE);
        }
    }

    static {
        c cVar = new c();
        DEFAULT_INSTANCE = cVar;
        w.N(c.class, cVar);
    }

    private c() {
    }

    public static b V() {
        return (b) DEFAULT_INSTANCE.s();
    }

    /* access modifiers changed from: private */
    public void W(String str) {
        str.getClass();
        this.appInstanceId_ = str;
    }

    /* access modifiers changed from: private */
    public void X(String str) {
        str.getClass();
        this.appInstanceIdToken_ = str;
    }

    /* access modifiers changed from: private */
    public void Y(String str) {
        str.getClass();
        this.gmpAppId_ = str;
    }

    /* access modifiers changed from: protected */
    public final Object w(w.d dVar, Object obj, Object obj2) {
        switch (a.f43614a[dVar.ordinal()]) {
            case 1:
                return new c();
            case 2:
                return new b((a) null);
            case 3:
                return w.K(DEFAULT_INSTANCE, "\u0000\u0003\u0000\u0000\u0001\u0003\u0003\u0000\u0000\u0000\u0001Ȉ\u0002Ȉ\u0003Ȉ", new Object[]{"gmpAppId_", "appInstanceId_", "appInstanceIdToken_"});
            case 4:
                return DEFAULT_INSTANCE;
            case 5:
                w0 w0Var = PARSER;
                if (w0Var == null) {
                    synchronized (c.class) {
                        w0Var = PARSER;
                        if (w0Var == null) {
                            w0Var = new w.b(DEFAULT_INSTANCE);
                            PARSER = w0Var;
                        }
                    }
                }
                return w0Var;
            case 6:
                return (byte) 1;
            case 7:
                return null;
            default:
                throw new UnsupportedOperationException();
        }
    }
}
