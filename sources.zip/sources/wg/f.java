package wg;

import gi.b;

abstract class f implements b.a {
}
