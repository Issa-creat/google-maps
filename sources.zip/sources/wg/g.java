package wg;

import ai.c;
import ai.d;
import ai.w0;
import gi.b;

public abstract class g {

    /* renamed from: a  reason: collision with root package name */
    private static volatile w0 f43617a;

    class a implements b.a {
        a() {
        }

        /* renamed from: b */
        public b a(d dVar, c cVar) {
            return new b(dVar, cVar, (f) null);
        }
    }

    public static final class b extends gi.a {
        /* synthetic */ b(d dVar, c cVar, f fVar) {
            this(dVar, cVar);
        }

        /* access modifiers changed from: protected */
        /* renamed from: g */
        public b a(d dVar, c cVar) {
            return new b(dVar, cVar);
        }

        public e h(d dVar) {
            return (e) gi.c.b(c(), g.a(), b(), dVar);
        }

        private b(d dVar, c cVar) {
            super(dVar, cVar);
        }
    }

    public static w0 a() {
        w0 w0Var = f43617a;
        if (w0Var == null) {
            synchronized (g.class) {
                w0Var = f43617a;
                if (w0Var == null) {
                    w0Var = w0.g().f(w0.d.UNARY).b(w0.b("google.internal.firebase.inappmessaging.v1.sdkserving.InAppMessagingSdkServing", "FetchEligibleCampaigns")).e(true).c(fi.b.b(d.Y())).d(fi.b.b(e.T())).a();
                    f43617a = w0Var;
                }
            }
        }
        return w0Var;
    }

    public static b b(d dVar) {
        return (b) gi.a.e(new a(), dVar);
    }
}
