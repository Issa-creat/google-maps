package t9;

public interface a {
    void a(boolean z10);

    boolean b();

    boolean c();
}
