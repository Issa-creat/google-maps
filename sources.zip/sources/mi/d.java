package mi;

public final class d {

    /* renamed from: a  reason: collision with root package name */
    final String f47534a;

    /* renamed from: b  reason: collision with root package name */
    final long f47535b;

    d(String str, long j10) {
        this.f47534a = str;
        this.f47535b = j10;
    }
}
