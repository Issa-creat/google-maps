package mi;

public final class b {

    /* renamed from: a  reason: collision with root package name */
    final long f47532a;

    b(long j10) {
        this.f47532a = j10;
    }
}
