package mi;

public class a {

    /* renamed from: a  reason: collision with root package name */
    static final d f47530a = new d("", Long.MIN_VALUE);

    /* renamed from: b  reason: collision with root package name */
    static final b f47531b = new b(Long.MIN_VALUE);

    protected a(d dVar) {
        if (dVar != f47530a) {
            throw new AssertionError("nope");
        }
    }

    /* access modifiers changed from: protected */
    public d a(String str, long j10) {
        return f47530a;
    }

    /* access modifiers changed from: protected */
    public void b(String str, d dVar) {
    }

    /* access modifiers changed from: protected */
    public void c(b bVar) {
    }

    /* access modifiers changed from: protected */
    public b d() {
        return f47531b;
    }

    /* access modifiers changed from: protected */
    public void e(String str) {
    }

    /* access modifiers changed from: protected */
    public void f(String str, d dVar) {
    }

    /* access modifiers changed from: protected */
    public void g(String str) {
    }

    /* access modifiers changed from: protected */
    public void h(String str, d dVar) {
    }
}
