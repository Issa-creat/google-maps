package si;

import hj.e;
import ni.f;
import qi.b;
import ti.d;

public abstract class a extends f {
    public final b L() {
        e eVar = new e();
        M(eVar);
        return eVar.f45903a;
    }

    public abstract void M(d dVar);
}
