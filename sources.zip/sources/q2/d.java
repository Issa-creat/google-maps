package q2;

import android.os.Parcel;
import android.os.Parcelable;
import com.google.common.primitives.c;
import y0.k0;
import y0.l0;
import y0.m0;
import y0.y;

public final class d implements l0.b {
    public static final Parcelable.Creator<d> CREATOR = new a();

    /* renamed from: a  reason: collision with root package name */
    public final float f16896a;

    /* renamed from: w  reason: collision with root package name */
    public final int f16897w;

    class a implements Parcelable.Creator {
        a() {
        }

        /* renamed from: a */
        public d createFromParcel(Parcel parcel) {
            return new d(parcel, (a) null);
        }

        /* renamed from: b */
        public d[] newArray(int i10) {
            return new d[i10];
        }
    }

    /* synthetic */ d(Parcel parcel, a aVar) {
        this(parcel);
    }

    public /* synthetic */ byte[] E() {
        return m0.a(this);
    }

    public int describeContents() {
        return 0;
    }

    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null || d.class != obj.getClass()) {
            return false;
        }
        d dVar = (d) obj;
        if (this.f16896a == dVar.f16896a && this.f16897w == dVar.f16897w) {
            return true;
        }
        return false;
    }

    public int hashCode() {
        return ((527 + c.a(this.f16896a)) * 31) + this.f16897w;
    }

    public /* synthetic */ y r() {
        return m0.b(this);
    }

    public String toString() {
        return "smta: captureFrameRate=" + this.f16896a + ", svcTemporalLayerCount=" + this.f16897w;
    }

    public /* synthetic */ void v(k0.b bVar) {
        m0.c(this, bVar);
    }

    public void writeToParcel(Parcel parcel, int i10) {
        parcel.writeFloat(this.f16896a);
        parcel.writeInt(this.f16897w);
    }

    public d(float f10, int i10) {
        this.f16896a = f10;
        this.f16897w = i10;
    }

    private d(Parcel parcel) {
        this.f16896a = parcel.readFloat();
        this.f16897w = parcel.readInt();
    }
}
