package q2;

import android.os.Parcel;
import android.os.Parcelable;
import androidx.media3.common.util.b1;
import ge.j;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import y0.k0;
import y0.l0;
import y0.m0;
import y0.y;

public final class b implements l0.b {
    public static final Parcelable.Creator<b> CREATOR = new a();

    /* renamed from: a  reason: collision with root package name */
    public final List f16891a;

    class a implements Parcelable.Creator {
        a() {
        }

        /* renamed from: a */
        public b createFromParcel(Parcel parcel) {
            ArrayList arrayList = new ArrayList();
            parcel.readList(arrayList, C0248b.class.getClassLoader());
            return new b(arrayList);
        }

        /* renamed from: b */
        public b[] newArray(int i10) {
            return new b[i10];
        }
    }

    /* renamed from: q2.b$b  reason: collision with other inner class name */
    public static final class C0248b implements Parcelable {
        public static final Parcelable.Creator<C0248b> CREATOR = new a();

        /* renamed from: y  reason: collision with root package name */
        public static final Comparator f16892y = new c();

        /* renamed from: a  reason: collision with root package name */
        public final long f16893a;

        /* renamed from: w  reason: collision with root package name */
        public final long f16894w;

        /* renamed from: x  reason: collision with root package name */
        public final int f16895x;

        /* renamed from: q2.b$b$a */
        class a implements Parcelable.Creator {
            a() {
            }

            /* renamed from: a */
            public C0248b createFromParcel(Parcel parcel) {
                return new C0248b(parcel.readLong(), parcel.readLong(), parcel.readInt());
            }

            /* renamed from: b */
            public C0248b[] newArray(int i10) {
                return new C0248b[i10];
            }
        }

        public C0248b(long j10, long j11, int i10) {
            boolean z10;
            if (j10 < j11) {
                z10 = true;
            } else {
                z10 = false;
            }
            androidx.media3.common.util.a.a(z10);
            this.f16893a = j10;
            this.f16894w = j11;
            this.f16895x = i10;
        }

        public int describeContents() {
            return 0;
        }

        public boolean equals(Object obj) {
            if (this == obj) {
                return true;
            }
            if (obj == null || C0248b.class != obj.getClass()) {
                return false;
            }
            C0248b bVar = (C0248b) obj;
            if (this.f16893a == bVar.f16893a && this.f16894w == bVar.f16894w && this.f16895x == bVar.f16895x) {
                return true;
            }
            return false;
        }

        public int hashCode() {
            return j.b(Long.valueOf(this.f16893a), Long.valueOf(this.f16894w), Integer.valueOf(this.f16895x));
        }

        public String toString() {
            return b1.K("Segment: startTimeMs=%d, endTimeMs=%d, speedDivisor=%d", Long.valueOf(this.f16893a), Long.valueOf(this.f16894w), Integer.valueOf(this.f16895x));
        }

        public void writeToParcel(Parcel parcel, int i10) {
            parcel.writeLong(this.f16893a);
            parcel.writeLong(this.f16894w);
            parcel.writeInt(this.f16895x);
        }
    }

    public b(List list) {
        this.f16891a = list;
        androidx.media3.common.util.a.a(!a(list));
    }

    private static boolean a(List list) {
        if (list.isEmpty()) {
            return false;
        }
        long j10 = ((C0248b) list.get(0)).f16894w;
        for (int i10 = 1; i10 < list.size(); i10++) {
            if (((C0248b) list.get(i10)).f16893a < j10) {
                return true;
            }
            j10 = ((C0248b) list.get(i10)).f16894w;
        }
        return false;
    }

    public /* synthetic */ byte[] E() {
        return m0.a(this);
    }

    public int describeContents() {
        return 0;
    }

    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null || b.class != obj.getClass()) {
            return false;
        }
        return this.f16891a.equals(((b) obj).f16891a);
    }

    public int hashCode() {
        return this.f16891a.hashCode();
    }

    public /* synthetic */ y r() {
        return m0.b(this);
    }

    public String toString() {
        return "SlowMotion: segments=" + this.f16891a;
    }

    public /* synthetic */ void v(k0.b bVar) {
        m0.c(this, bVar);
    }

    public void writeToParcel(Parcel parcel, int i10) {
        parcel.writeList(this.f16891a);
    }
}
