package q2;

import android.os.Parcel;
import android.os.Parcelable;
import com.google.common.primitives.h;
import y0.k0;
import y0.l0;
import y0.m0;
import y0.y;

public final class a implements l0.b {
    public static final Parcelable.Creator<a> CREATOR = new C0247a();

    /* renamed from: a  reason: collision with root package name */
    public final long f16886a;

    /* renamed from: w  reason: collision with root package name */
    public final long f16887w;

    /* renamed from: x  reason: collision with root package name */
    public final long f16888x;

    /* renamed from: y  reason: collision with root package name */
    public final long f16889y;

    /* renamed from: z  reason: collision with root package name */
    public final long f16890z;

    /* renamed from: q2.a$a  reason: collision with other inner class name */
    class C0247a implements Parcelable.Creator {
        C0247a() {
        }

        /* renamed from: a */
        public a createFromParcel(Parcel parcel) {
            return new a(parcel, (C0247a) null);
        }

        /* renamed from: b */
        public a[] newArray(int i10) {
            return new a[i10];
        }
    }

    /* synthetic */ a(Parcel parcel, C0247a aVar) {
        this(parcel);
    }

    public /* synthetic */ byte[] E() {
        return m0.a(this);
    }

    public int describeContents() {
        return 0;
    }

    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null || a.class != obj.getClass()) {
            return false;
        }
        a aVar = (a) obj;
        if (this.f16886a == aVar.f16886a && this.f16887w == aVar.f16887w && this.f16888x == aVar.f16888x && this.f16889y == aVar.f16889y && this.f16890z == aVar.f16890z) {
            return true;
        }
        return false;
    }

    public int hashCode() {
        return ((((((((527 + h.b(this.f16886a)) * 31) + h.b(this.f16887w)) * 31) + h.b(this.f16888x)) * 31) + h.b(this.f16889y)) * 31) + h.b(this.f16890z);
    }

    public /* synthetic */ y r() {
        return m0.b(this);
    }

    public String toString() {
        return "Motion photo metadata: photoStartPosition=" + this.f16886a + ", photoSize=" + this.f16887w + ", photoPresentationTimestampUs=" + this.f16888x + ", videoStartPosition=" + this.f16889y + ", videoSize=" + this.f16890z;
    }

    public /* synthetic */ void v(k0.b bVar) {
        m0.c(this, bVar);
    }

    public void writeToParcel(Parcel parcel, int i10) {
        parcel.writeLong(this.f16886a);
        parcel.writeLong(this.f16887w);
        parcel.writeLong(this.f16888x);
        parcel.writeLong(this.f16889y);
        parcel.writeLong(this.f16890z);
    }

    public a(long j10, long j11, long j12, long j13, long j14) {
        this.f16886a = j10;
        this.f16887w = j11;
        this.f16888x = j12;
        this.f16889y = j13;
        this.f16890z = j14;
    }

    private a(Parcel parcel) {
        this.f16886a = parcel.readLong();
        this.f16887w = parcel.readLong();
        this.f16888x = parcel.readLong();
        this.f16889y = parcel.readLong();
        this.f16890z = parcel.readLong();
    }
}
