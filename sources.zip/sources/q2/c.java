package q2;

import com.google.common.collect.p;
import java.util.Comparator;
import q2.b;

public final /* synthetic */ class c implements Comparator {
    public final int compare(Object obj, Object obj2) {
        return p.j().e(((b.C0248b) obj).f16893a, ((b.C0248b) obj2).f16893a).e(((b.C0248b) obj).f16894w, ((b.C0248b) obj2).f16894w).d(((b.C0248b) obj).f16895x, ((b.C0248b) obj2).f16895x).i();
    }
}
