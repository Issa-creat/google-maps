package pi;

import android.os.Handler;
import android.os.Message;
import java.util.concurrent.TimeUnit;
import ni.r;
import qi.c;

final class b extends r {

    /* renamed from: b  reason: collision with root package name */
    private final Handler f48580b;

    private static final class a extends r.b {

        /* renamed from: a  reason: collision with root package name */
        private final Handler f48581a;

        /* renamed from: w  reason: collision with root package name */
        private volatile boolean f48582w;

        a(Handler handler) {
            this.f48581a = handler;
        }

        public void b() {
            this.f48582w = true;
            this.f48581a.removeCallbacksAndMessages(this);
        }

        public qi.b d(Runnable runnable, long j10, TimeUnit timeUnit) {
            if (runnable == null) {
                throw new NullPointerException("run == null");
            } else if (timeUnit == null) {
                throw new NullPointerException("unit == null");
            } else if (this.f48582w) {
                return c.a();
            } else {
                C0497b bVar = new C0497b(this.f48581a, ij.a.s(runnable));
                Message obtain = Message.obtain(this.f48581a, bVar);
                obtain.obj = this;
                this.f48581a.sendMessageDelayed(obtain, timeUnit.toMillis(j10));
                if (!this.f48582w) {
                    return bVar;
                }
                this.f48581a.removeCallbacks(bVar);
                return c.a();
            }
        }

        public boolean f() {
            return this.f48582w;
        }
    }

    /* renamed from: pi.b$b  reason: collision with other inner class name */
    private static final class C0497b implements Runnable, qi.b {

        /* renamed from: a  reason: collision with root package name */
        private final Handler f48583a;

        /* renamed from: w  reason: collision with root package name */
        private final Runnable f48584w;

        /* renamed from: x  reason: collision with root package name */
        private volatile boolean f48585x;

        C0497b(Handler handler, Runnable runnable) {
            this.f48583a = handler;
            this.f48584w = runnable;
        }

        public void b() {
            this.f48585x = true;
            this.f48583a.removeCallbacks(this);
        }

        public boolean f() {
            return this.f48585x;
        }

        public void run() {
            try {
                this.f48584w.run();
            } catch (Throwable th2) {
                ij.a.q(th2);
            }
        }
    }

    b(Handler handler) {
        this.f48580b = handler;
    }

    public r.b a() {
        return new a(this.f48580b);
    }

    public qi.b c(Runnable runnable, long j10, TimeUnit timeUnit) {
        if (runnable == null) {
            throw new NullPointerException("run == null");
        } else if (timeUnit != null) {
            C0497b bVar = new C0497b(this.f48580b, ij.a.s(runnable));
            this.f48580b.postDelayed(bVar, timeUnit.toMillis(j10));
            return bVar;
        } else {
            throw new NullPointerException("unit == null");
        }
    }
}
