package pi;

import android.os.Handler;
import android.os.Looper;
import java.util.concurrent.Callable;
import ni.r;

public abstract class a {

    /* renamed from: a  reason: collision with root package name */
    private static final r f48578a = oi.a.d(new C0496a());

    /* renamed from: pi.a$a  reason: collision with other inner class name */
    static class C0496a implements Callable {
        C0496a() {
        }

        /* renamed from: a */
        public r call() {
            return b.f48579a;
        }
    }

    private static final class b {

        /* renamed from: a  reason: collision with root package name */
        static final r f48579a = new b(new Handler(Looper.getMainLooper()));
    }

    public static r a() {
        return oi.a.e(f48578a);
    }
}
