package q8;

import android.graphics.drawable.Drawable;
import r8.e;

public interface a {
    boolean a(e eVar);

    Drawable b(e eVar);
}
