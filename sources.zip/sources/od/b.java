package od;

import android.view.autofill.AutofillManager;

public abstract /* synthetic */ class b {
    public static /* bridge */ /* synthetic */ AutofillManager a(Object obj) {
        return (AutofillManager) obj;
    }
}
