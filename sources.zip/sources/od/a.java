package od;

import android.view.autofill.AutofillManager;

public abstract /* synthetic */ class a {
    public static /* bridge */ /* synthetic */ Class a() {
        return AutofillManager.class;
    }
}
