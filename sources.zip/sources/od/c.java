package od;

public abstract /* synthetic */ class c {
}
