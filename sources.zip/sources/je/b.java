package je;

public abstract class b {
    public static Throwable a(a aVar) {
        return aVar.c();
    }
}
