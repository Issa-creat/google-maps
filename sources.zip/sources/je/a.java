package je;

public abstract class a {
    protected a() {
    }

    /* access modifiers changed from: protected */
    public abstract Throwable c();
}
