package ia;

import android.view.View;
import com.facebook.react.uimanager.f;
import com.facebook.react.uimanager.g;

public class s extends f {
    public s(g gVar) {
        super(gVar);
    }

    public void b(View view, String str, Object obj) {
        str.hashCode();
        if (!str.equals("type")) {
            super.b(view, str, obj);
        } else {
            ((t) this.f11244a).setType(view, (String) obj);
        }
    }
}
