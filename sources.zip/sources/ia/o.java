package ia;

import android.view.View;
import com.facebook.react.bridge.ColorPropConverter;
import com.facebook.react.bridge.ReadableMap;
import com.facebook.react.uimanager.f;
import com.facebook.react.uimanager.g;
import okhttp3.internal.ws.WebSocketProtocol;
import xf.m;

public class o extends f {
    public o(g gVar) {
        super(gVar);
    }

    public void b(View view, String str, Object obj) {
        int i10;
        str.hashCode();
        boolean z10 = true;
        boolean z11 = false;
        char c10 = 65535;
        switch (str.hashCode()) {
            case -1937389126:
                if (str.equals("homeIndicatorHidden")) {
                    c10 = 0;
                    break;
                }
                break;
            case -1853558344:
                if (str.equals("gestureEnabled")) {
                    c10 = 1;
                    break;
                }
                break;
            case -1734097646:
                if (str.equals("hideKeyboardOnSwipe")) {
                    c10 = 2;
                    break;
                }
                break;
            case -1349152186:
                if (str.equals("sheetCornerRadius")) {
                    c10 = 3;
                    break;
                }
                break;
            case -1322084375:
                if (str.equals("navigationBarHidden")) {
                    c10 = 4;
                    break;
                }
                break;
            case -1156137512:
                if (str.equals("statusBarTranslucent")) {
                    c10 = 5;
                    break;
                }
                break;
            case -1150711358:
                if (str.equals("stackPresentation")) {
                    c10 = 6;
                    break;
                }
                break;
            case -1047235902:
                if (str.equals("activityState")) {
                    c10 = 7;
                    break;
                }
                break;
            case -973702878:
                if (str.equals("statusBarColor")) {
                    c10 = 8;
                    break;
                }
                break;
            case -958765200:
                if (str.equals("statusBarStyle")) {
                    c10 = 9;
                    break;
                }
                break;
            case -577711652:
                if (str.equals("stackAnimation")) {
                    c10 = 10;
                    break;
                }
                break;
            case -462720700:
                if (str.equals("navigationBarColor")) {
                    c10 = 11;
                    break;
                }
                break;
            case -274098190:
                if (str.equals("sheetAllowedDetents")) {
                    c10 = 12;
                    break;
                }
                break;
            case -257141968:
                if (str.equals("replaceAnimation")) {
                    c10 = 13;
                    break;
                }
                break;
            case -166356101:
                if (str.equals("preventNativeDismiss")) {
                    c10 = 14;
                    break;
                }
                break;
            case 17337291:
                if (str.equals("statusBarHidden")) {
                    c10 = 15;
                    break;
                }
                break;
            case 129956386:
                if (str.equals("fullScreenSwipeEnabled")) {
                    c10 = 16;
                    break;
                }
                break;
            case 187703999:
                if (str.equals("gestureResponseDistance")) {
                    c10 = 17;
                    break;
                }
                break;
            case 227582404:
                if (str.equals("screenOrientation")) {
                    c10 = 18;
                    break;
                }
                break;
            case 241896530:
                if (str.equals("sheetLargestUndimmedDetent")) {
                    c10 = 19;
                    break;
                }
                break;
            case 425064969:
                if (str.equals("transitionDuration")) {
                    c10 = 20;
                    break;
                }
                break;
            case 1082157413:
                if (str.equals("swipeDirection")) {
                    c10 = 21;
                    break;
                }
                break;
            case 1110843912:
                if (str.equals("customAnimationOnSwipe")) {
                    c10 = 22;
                    break;
                }
                break;
            case 1357942638:
                if (str.equals("sheetGrabberVisible")) {
                    c10 = 23;
                    break;
                }
                break;
            case 1387359683:
                if (str.equals("statusBarAnimation")) {
                    c10 = 24;
                    break;
                }
                break;
            case 1729091548:
                if (str.equals("nativeBackButtonDismissalEnabled")) {
                    c10 = 25;
                    break;
                }
                break;
            case 2097450072:
                if (str.equals("sheetExpandsWhenScrolledToEdge")) {
                    c10 = 26;
                    break;
                }
                break;
        }
        float f10 = -1.0f;
        String str2 = null;
        switch (c10) {
            case 0:
                p pVar = (p) this.f11244a;
                if (obj != null) {
                    z11 = ((Boolean) obj).booleanValue();
                }
                pVar.setHomeIndicatorHidden(view, z11);
                return;
            case 1:
                p pVar2 = (p) this.f11244a;
                if (obj != null) {
                    z10 = ((Boolean) obj).booleanValue();
                }
                pVar2.setGestureEnabled(view, z10);
                return;
            case 2:
                p pVar3 = (p) this.f11244a;
                if (obj != null) {
                    z11 = ((Boolean) obj).booleanValue();
                }
                pVar3.setHideKeyboardOnSwipe(view, z11);
                return;
            case 3:
                p pVar4 = (p) this.f11244a;
                if (obj != null) {
                    f10 = ((Double) obj).floatValue();
                }
                pVar4.setSheetCornerRadius(view, f10);
                return;
            case 4:
                p pVar5 = (p) this.f11244a;
                if (obj != null) {
                    z11 = ((Boolean) obj).booleanValue();
                }
                pVar5.setNavigationBarHidden(view, z11);
                return;
            case 5:
                p pVar6 = (p) this.f11244a;
                if (obj != null) {
                    z11 = ((Boolean) obj).booleanValue();
                }
                pVar6.setStatusBarTranslucent(view, z11);
                return;
            case 6:
                ((p) this.f11244a).setStackPresentation(view, (String) obj);
                return;
            case 7:
                p pVar7 = (p) this.f11244a;
                if (obj != null) {
                    f10 = ((Double) obj).floatValue();
                }
                pVar7.setActivityState(view, f10);
                return;
            case 8:
                ((p) this.f11244a).setStatusBarColor(view, ColorPropConverter.getColor(obj, view.getContext()));
                return;
            case 9:
                p pVar8 = (p) this.f11244a;
                if (obj != null) {
                    str2 = (String) obj;
                }
                pVar8.setStatusBarStyle(view, str2);
                return;
            case 10:
                ((p) this.f11244a).setStackAnimation(view, (String) obj);
                return;
            case 11:
                ((p) this.f11244a).setNavigationBarColor(view, ColorPropConverter.getColor(obj, view.getContext()));
                return;
            case m.OVERFLOW_POLICY_FIELD_NUMBER /*12*/:
                ((p) this.f11244a).setSheetAllowedDetents(view, (String) obj);
                return;
            case m.ONGOING_EXPERIMENTS_FIELD_NUMBER /*13*/:
                ((p) this.f11244a).setReplaceAnimation(view, (String) obj);
                return;
            case 14:
                p pVar9 = (p) this.f11244a;
                if (obj != null) {
                    z11 = ((Boolean) obj).booleanValue();
                }
                pVar9.setPreventNativeDismiss(view, z11);
                return;
            case WebSocketProtocol.B0_MASK_OPCODE /*15*/:
                p pVar10 = (p) this.f11244a;
                if (obj != null) {
                    z11 = ((Boolean) obj).booleanValue();
                }
                pVar10.setStatusBarHidden(view, z11);
                return;
            case WebSocketProtocol.B0_FLAG_RSV3 /*16*/:
                p pVar11 = (p) this.f11244a;
                if (obj != null) {
                    z11 = ((Boolean) obj).booleanValue();
                }
                pVar11.setFullScreenSwipeEnabled(view, z11);
                return;
            case 17:
                ((p) this.f11244a).setGestureResponseDistance(view, (ReadableMap) obj);
                return;
            case 18:
                p pVar12 = (p) this.f11244a;
                if (obj != null) {
                    str2 = (String) obj;
                }
                pVar12.setScreenOrientation(view, str2);
                return;
            case 19:
                ((p) this.f11244a).setSheetLargestUndimmedDetent(view, (String) obj);
                return;
            case 20:
                p pVar13 = (p) this.f11244a;
                if (obj == null) {
                    i10 = 350;
                } else {
                    i10 = ((Double) obj).intValue();
                }
                pVar13.setTransitionDuration(view, i10);
                return;
            case 21:
                ((p) this.f11244a).setSwipeDirection(view, (String) obj);
                return;
            case 22:
                p pVar14 = (p) this.f11244a;
                if (obj != null) {
                    z11 = ((Boolean) obj).booleanValue();
                }
                pVar14.setCustomAnimationOnSwipe(view, z11);
                return;
            case 23:
                p pVar15 = (p) this.f11244a;
                if (obj != null) {
                    z11 = ((Boolean) obj).booleanValue();
                }
                pVar15.setSheetGrabberVisible(view, z11);
                return;
            case 24:
                p pVar16 = (p) this.f11244a;
                if (obj != null) {
                    str2 = (String) obj;
                }
                pVar16.setStatusBarAnimation(view, str2);
                return;
            case 25:
                p pVar17 = (p) this.f11244a;
                if (obj != null) {
                    z11 = ((Boolean) obj).booleanValue();
                }
                pVar17.setNativeBackButtonDismissalEnabled(view, z11);
                return;
            case 26:
                p pVar18 = (p) this.f11244a;
                if (obj != null) {
                    z11 = ((Boolean) obj).booleanValue();
                }
                pVar18.setSheetExpandsWhenScrolledToEdge(view, z11);
                return;
            default:
                super.b(view, str, obj);
                return;
        }
    }
}
