package ia;

import android.view.View;

public interface d {
    void setAnimating(View view, boolean z10);

    void setColor(View view, Integer num);

    void setIndeterminate(View view, boolean z10);

    void setProgress(View view, double d10);

    void setStyleAttr(View view, String str);

    void setTestID(View view, String str);

    void setTypeAttr(View view, String str);
}
