package ia;

import android.view.View;

public interface t {
    void setType(View view, String str);
}
