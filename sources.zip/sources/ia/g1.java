package ia;

import android.view.View;
import com.facebook.react.bridge.ReadableArray;
import com.facebook.react.bridge.ReadableMap;

public interface g1 {
    void setAlignmentBaseline(View view, String str);

    void setBaselineShift(View view, Double d10);

    void setBaselineShift(View view, String str);

    void setClipPath(View view, String str);

    void setClipRule(View view, int i10);

    void setDisplay(View view, String str);

    void setDx(View view, ReadableArray readableArray);

    void setDy(View view, ReadableArray readableArray);

    void setFill(View view, ReadableMap readableMap);

    void setFillOpacity(View view, float f10);

    void setFillRule(View view, int i10);

    void setFont(View view, ReadableMap readableMap);

    void setFontSize(View view, Double d10);

    void setFontSize(View view, String str);

    void setFontWeight(View view, Double d10);

    void setFontWeight(View view, String str);

    void setInlineSize(View view, Double d10);

    void setInlineSize(View view, String str);

    void setLengthAdjust(View view, String str);

    void setMarkerEnd(View view, String str);

    void setMarkerMid(View view, String str);

    void setMarkerStart(View view, String str);

    void setMask(View view, String str);

    void setMatrix(View view, ReadableArray readableArray);

    void setName(View view, String str);

    void setPointerEvents(View view, String str);

    void setPropList(View view, ReadableArray readableArray);

    void setResponsible(View view, boolean z10);

    void setRotate(View view, ReadableArray readableArray);

    void setStroke(View view, ReadableMap readableMap);

    void setStrokeDasharray(View view, ReadableArray readableArray);

    void setStrokeDasharray(View view, String str);

    void setStrokeDashoffset(View view, float f10);

    void setStrokeLinecap(View view, int i10);

    void setStrokeLinejoin(View view, int i10);

    void setStrokeMiterlimit(View view, float f10);

    void setStrokeOpacity(View view, float f10);

    void setStrokeWidth(View view, Double d10);

    void setStrokeWidth(View view, String str);

    void setTextLength(View view, Double d10);

    void setTextLength(View view, String str);

    void setVectorEffect(View view, int i10);

    void setVerticalAlign(View view, String str);

    void setX(View view, ReadableArray readableArray);

    void setY(View view, ReadableArray readableArray);
}
