package ia;

import android.view.View;
import com.facebook.react.bridge.ReadableArray;
import com.facebook.react.bridge.ReadableMap;

public interface c0 {
    void setClipPath(View view, String str);

    void setClipRule(View view, int i10);

    void setCx(View view, Double d10);

    void setCx(View view, String str);

    void setCy(View view, Double d10);

    void setCy(View view, String str);

    void setDisplay(View view, String str);

    void setFill(View view, ReadableMap readableMap);

    void setFillOpacity(View view, float f10);

    void setFillRule(View view, int i10);

    void setMarkerEnd(View view, String str);

    void setMarkerMid(View view, String str);

    void setMarkerStart(View view, String str);

    void setMask(View view, String str);

    void setMatrix(View view, ReadableArray readableArray);

    void setName(View view, String str);

    void setPointerEvents(View view, String str);

    void setPropList(View view, ReadableArray readableArray);

    void setResponsible(View view, boolean z10);

    void setRx(View view, Double d10);

    void setRx(View view, String str);

    void setRy(View view, Double d10);

    void setRy(View view, String str);

    void setStroke(View view, ReadableMap readableMap);

    void setStrokeDasharray(View view, ReadableArray readableArray);

    void setStrokeDasharray(View view, String str);

    void setStrokeDashoffset(View view, float f10);

    void setStrokeLinecap(View view, int i10);

    void setStrokeLinejoin(View view, int i10);

    void setStrokeMiterlimit(View view, float f10);

    void setStrokeOpacity(View view, float f10);

    void setStrokeWidth(View view, Double d10);

    void setStrokeWidth(View view, String str);

    void setVectorEffect(View view, int i10);
}
