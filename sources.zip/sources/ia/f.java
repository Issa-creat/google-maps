package ia;

import android.view.View;
import com.facebook.react.bridge.ReadableArray;

public interface f {
    void setColors(View view, ReadableArray readableArray);

    void setEnabled(View view, boolean z10);

    void setNativeRefreshing(View view, boolean z10);

    void setProgressBackgroundColor(View view, Integer num);

    void setProgressViewOffset(View view, float f10);

    void setRefreshing(View view, boolean z10);

    void setSize(View view, String str);
}
