package ia;

import android.view.View;
import com.facebook.react.uimanager.f;
import com.facebook.react.uimanager.g;

public class k extends f {
    public k(g gVar) {
        super(gVar);
    }

    public void b(View view, String str, Object obj) {
        super.b(view, str, obj);
    }
}
