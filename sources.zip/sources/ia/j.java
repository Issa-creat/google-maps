package ia;

import android.view.View;
import com.facebook.react.bridge.ReadableArray;

public interface j {
    void setAnimated(View view, boolean z10);

    void setAnimationType(View view, String str);

    void setHardwareAccelerated(View view, boolean z10);

    void setIdentifier(View view, int i10);

    void setPresentationStyle(View view, String str);

    void setStatusBarTranslucent(View view, boolean z10);

    void setSupportedOrientations(View view, ReadableArray readableArray);

    void setTransparent(View view, boolean z10);

    void setVisible(View view, boolean z10);
}
