package ia;

import com.facebook.react.uimanager.f;
import com.facebook.react.uimanager.g;

public class f1 extends f {
    public f1(g gVar) {
        super(gVar);
    }

    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r2v0, resolved type: boolean} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r2v1, resolved type: boolean} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r2v2, resolved type: int} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r2v3, resolved type: boolean} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r2v4, resolved type: int} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r2v5, resolved type: boolean} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r2v6, resolved type: int} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r2v7, resolved type: boolean} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r2v8, resolved type: int} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r2v9, resolved type: boolean} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r2v11, resolved type: boolean} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r2v12, resolved type: boolean} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r2v13, resolved type: boolean} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r2v14, resolved type: boolean} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r2v15, resolved type: boolean} */
    /* JADX WARNING: Multi-variable type inference failed */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public void b(android.view.View r7, java.lang.String r8, java.lang.Object r9) {
        /*
            r6 = this;
            r8.hashCode()
            int r0 = r8.hashCode()
            r1 = 1
            r2 = 0
            r3 = -1
            switch(r0) {
                case -1603134955: goto L_0x020e;
                case -1267206133: goto L_0x0203;
                case -1171891896: goto L_0x01f8;
                case -1139902161: goto L_0x01ed;
                case -1081239615: goto L_0x01e2;
                case -993894751: goto L_0x01d7;
                case -933864895: goto L_0x01cc;
                case -933857362: goto L_0x01c1;
                case -925180581: goto L_0x01b3;
                case -891980232: goto L_0x01a5;
                case -734428249: goto L_0x0197;
                case -729118945: goto L_0x0189;
                case -416535885: goto L_0x017b;
                case -293492298: goto L_0x016d;
                case -53677816: goto L_0x015f;
                case -44578051: goto L_0x0151;
                case 120: goto L_0x0143;
                case 121: goto L_0x0135;
                case 3220: goto L_0x0127;
                case 3221: goto L_0x0119;
                case 3143043: goto L_0x010b;
                case 3148879: goto L_0x00fd;
                case 3344108: goto L_0x00ef;
                case 3373707: goto L_0x00e1;
                case 78845486: goto L_0x00d3;
                case 104482996: goto L_0x00c5;
                case 217109576: goto L_0x00b7;
                case 275888445: goto L_0x00a9;
                case 365601008: goto L_0x009b;
                case 401643183: goto L_0x008d;
                case 778043962: goto L_0x007f;
                case 917656469: goto L_0x0071;
                case 917735020: goto L_0x0063;
                case 1027575302: goto L_0x0055;
                case 1637488243: goto L_0x0047;
                case 1671764162: goto L_0x0039;
                case 1790285174: goto L_0x002b;
                case 1847674614: goto L_0x001d;
                case 1924065902: goto L_0x000f;
                default: goto L_0x000d;
            }
        L_0x000d:
            goto L_0x0218
        L_0x000f:
            java.lang.String r0 = "strokeWidth"
            boolean r0 = r8.equals(r0)
            if (r0 != 0) goto L_0x0019
            goto L_0x0218
        L_0x0019:
            r3 = 38
            goto L_0x0218
        L_0x001d:
            java.lang.String r0 = "responsible"
            boolean r0 = r8.equals(r0)
            if (r0 != 0) goto L_0x0027
            goto L_0x0218
        L_0x0027:
            r3 = 37
            goto L_0x0218
        L_0x002b:
            java.lang.String r0 = "strokeLinejoin"
            boolean r0 = r8.equals(r0)
            if (r0 != 0) goto L_0x0035
            goto L_0x0218
        L_0x0035:
            r3 = 36
            goto L_0x0218
        L_0x0039:
            java.lang.String r0 = "display"
            boolean r0 = r8.equals(r0)
            if (r0 != 0) goto L_0x0043
            goto L_0x0218
        L_0x0043:
            r3 = 35
            goto L_0x0218
        L_0x0047:
            java.lang.String r0 = "textLength"
            boolean r0 = r8.equals(r0)
            if (r0 != 0) goto L_0x0051
            goto L_0x0218
        L_0x0051:
            r3 = 34
            goto L_0x0218
        L_0x0055:
            java.lang.String r0 = "strokeLinecap"
            boolean r0 = r8.equals(r0)
            if (r0 != 0) goto L_0x005f
            goto L_0x0218
        L_0x005f:
            r3 = 33
            goto L_0x0218
        L_0x0063:
            java.lang.String r0 = "clipRule"
            boolean r0 = r8.equals(r0)
            if (r0 != 0) goto L_0x006d
            goto L_0x0218
        L_0x006d:
            r3 = 32
            goto L_0x0218
        L_0x0071:
            java.lang.String r0 = "clipPath"
            boolean r0 = r8.equals(r0)
            if (r0 != 0) goto L_0x007b
            goto L_0x0218
        L_0x007b:
            r3 = 31
            goto L_0x0218
        L_0x007f:
            java.lang.String r0 = "inlineSize"
            boolean r0 = r8.equals(r0)
            if (r0 != 0) goto L_0x0089
            goto L_0x0218
        L_0x0089:
            r3 = 30
            goto L_0x0218
        L_0x008d:
            java.lang.String r0 = "strokeDasharray"
            boolean r0 = r8.equals(r0)
            if (r0 != 0) goto L_0x0097
            goto L_0x0218
        L_0x0097:
            r3 = 29
            goto L_0x0218
        L_0x009b:
            java.lang.String r0 = "fontSize"
            boolean r0 = r8.equals(r0)
            if (r0 != 0) goto L_0x00a5
            goto L_0x0218
        L_0x00a5:
            r3 = 28
            goto L_0x0218
        L_0x00a9:
            java.lang.String r0 = "baselineShift"
            boolean r0 = r8.equals(r0)
            if (r0 != 0) goto L_0x00b3
            goto L_0x0218
        L_0x00b3:
            r3 = 27
            goto L_0x0218
        L_0x00b7:
            java.lang.String r0 = "markerStart"
            boolean r0 = r8.equals(r0)
            if (r0 != 0) goto L_0x00c1
            goto L_0x0218
        L_0x00c1:
            r3 = 26
            goto L_0x0218
        L_0x00c5:
            java.lang.String r0 = "vectorEffect"
            boolean r0 = r8.equals(r0)
            if (r0 != 0) goto L_0x00cf
            goto L_0x0218
        L_0x00cf:
            r3 = 25
            goto L_0x0218
        L_0x00d3:
            java.lang.String r0 = "strokeMiterlimit"
            boolean r0 = r8.equals(r0)
            if (r0 != 0) goto L_0x00dd
            goto L_0x0218
        L_0x00dd:
            r3 = 24
            goto L_0x0218
        L_0x00e1:
            java.lang.String r0 = "name"
            boolean r0 = r8.equals(r0)
            if (r0 != 0) goto L_0x00eb
            goto L_0x0218
        L_0x00eb:
            r3 = 23
            goto L_0x0218
        L_0x00ef:
            java.lang.String r0 = "mask"
            boolean r0 = r8.equals(r0)
            if (r0 != 0) goto L_0x00f9
            goto L_0x0218
        L_0x00f9:
            r3 = 22
            goto L_0x0218
        L_0x00fd:
            java.lang.String r0 = "font"
            boolean r0 = r8.equals(r0)
            if (r0 != 0) goto L_0x0107
            goto L_0x0218
        L_0x0107:
            r3 = 21
            goto L_0x0218
        L_0x010b:
            java.lang.String r0 = "fill"
            boolean r0 = r8.equals(r0)
            if (r0 != 0) goto L_0x0115
            goto L_0x0218
        L_0x0115:
            r3 = 20
            goto L_0x0218
        L_0x0119:
            java.lang.String r0 = "dy"
            boolean r0 = r8.equals(r0)
            if (r0 != 0) goto L_0x0123
            goto L_0x0218
        L_0x0123:
            r3 = 19
            goto L_0x0218
        L_0x0127:
            java.lang.String r0 = "dx"
            boolean r0 = r8.equals(r0)
            if (r0 != 0) goto L_0x0131
            goto L_0x0218
        L_0x0131:
            r3 = 18
            goto L_0x0218
        L_0x0135:
            java.lang.String r0 = "y"
            boolean r0 = r8.equals(r0)
            if (r0 != 0) goto L_0x013f
            goto L_0x0218
        L_0x013f:
            r3 = 17
            goto L_0x0218
        L_0x0143:
            java.lang.String r0 = "x"
            boolean r0 = r8.equals(r0)
            if (r0 != 0) goto L_0x014d
            goto L_0x0218
        L_0x014d:
            r3 = 16
            goto L_0x0218
        L_0x0151:
            java.lang.String r0 = "strokeDashoffset"
            boolean r0 = r8.equals(r0)
            if (r0 != 0) goto L_0x015b
            goto L_0x0218
        L_0x015b:
            r3 = 15
            goto L_0x0218
        L_0x015f:
            java.lang.String r0 = "fillOpacity"
            boolean r0 = r8.equals(r0)
            if (r0 != 0) goto L_0x0169
            goto L_0x0218
        L_0x0169:
            r3 = 14
            goto L_0x0218
        L_0x016d:
            java.lang.String r0 = "pointerEvents"
            boolean r0 = r8.equals(r0)
            if (r0 != 0) goto L_0x0177
            goto L_0x0218
        L_0x0177:
            r3 = 13
            goto L_0x0218
        L_0x017b:
            java.lang.String r0 = "strokeOpacity"
            boolean r0 = r8.equals(r0)
            if (r0 != 0) goto L_0x0185
            goto L_0x0218
        L_0x0185:
            r3 = 12
            goto L_0x0218
        L_0x0189:
            java.lang.String r0 = "fillRule"
            boolean r0 = r8.equals(r0)
            if (r0 != 0) goto L_0x0193
            goto L_0x0218
        L_0x0193:
            r3 = 11
            goto L_0x0218
        L_0x0197:
            java.lang.String r0 = "fontWeight"
            boolean r0 = r8.equals(r0)
            if (r0 != 0) goto L_0x01a1
            goto L_0x0218
        L_0x01a1:
            r3 = 10
            goto L_0x0218
        L_0x01a5:
            java.lang.String r0 = "stroke"
            boolean r0 = r8.equals(r0)
            if (r0 != 0) goto L_0x01af
            goto L_0x0218
        L_0x01af:
            r3 = 9
            goto L_0x0218
        L_0x01b3:
            java.lang.String r0 = "rotate"
            boolean r0 = r8.equals(r0)
            if (r0 != 0) goto L_0x01bd
            goto L_0x0218
        L_0x01bd:
            r3 = 8
            goto L_0x0218
        L_0x01c1:
            java.lang.String r0 = "markerMid"
            boolean r0 = r8.equals(r0)
            if (r0 != 0) goto L_0x01ca
            goto L_0x0218
        L_0x01ca:
            r3 = 7
            goto L_0x0218
        L_0x01cc:
            java.lang.String r0 = "markerEnd"
            boolean r0 = r8.equals(r0)
            if (r0 != 0) goto L_0x01d5
            goto L_0x0218
        L_0x01d5:
            r3 = 6
            goto L_0x0218
        L_0x01d7:
            java.lang.String r0 = "propList"
            boolean r0 = r8.equals(r0)
            if (r0 != 0) goto L_0x01e0
            goto L_0x0218
        L_0x01e0:
            r3 = 5
            goto L_0x0218
        L_0x01e2:
            java.lang.String r0 = "matrix"
            boolean r0 = r8.equals(r0)
            if (r0 != 0) goto L_0x01eb
            goto L_0x0218
        L_0x01eb:
            r3 = 4
            goto L_0x0218
        L_0x01ed:
            java.lang.String r0 = "verticalAlign"
            boolean r0 = r8.equals(r0)
            if (r0 != 0) goto L_0x01f6
            goto L_0x0218
        L_0x01f6:
            r3 = 3
            goto L_0x0218
        L_0x01f8:
            java.lang.String r0 = "alignmentBaseline"
            boolean r0 = r8.equals(r0)
            if (r0 != 0) goto L_0x0201
            goto L_0x0218
        L_0x0201:
            r3 = 2
            goto L_0x0218
        L_0x0203:
            java.lang.String r0 = "opacity"
            boolean r0 = r8.equals(r0)
            if (r0 != 0) goto L_0x020c
            goto L_0x0218
        L_0x020c:
            r3 = 1
            goto L_0x0218
        L_0x020e:
            java.lang.String r0 = "lengthAdjust"
            boolean r0 = r8.equals(r0)
            if (r0 != 0) goto L_0x0217
            goto L_0x0218
        L_0x0217:
            r3 = 0
        L_0x0218:
            r0 = 0
            r4 = 1065353216(0x3f800000, float:1.0)
            r5 = 0
            switch(r3) {
                case 0: goto L_0x04ef;
                case 1: goto L_0x04e0;
                case 2: goto L_0x04d2;
                case 3: goto L_0x04c4;
                case 4: goto L_0x04ba;
                case 5: goto L_0x04b0;
                case 6: goto L_0x04a2;
                case 7: goto L_0x0494;
                case 8: goto L_0x0489;
                case 9: goto L_0x047e;
                case 10: goto L_0x0457;
                case 11: goto L_0x0445;
                case 12: goto L_0x0433;
                case 13: goto L_0x0424;
                case 14: goto L_0x0412;
                case 15: goto L_0x0400;
                case 16: goto L_0x03f5;
                case 17: goto L_0x03ea;
                case 18: goto L_0x03df;
                case 19: goto L_0x03d4;
                case 20: goto L_0x03c9;
                case 21: goto L_0x03be;
                case 22: goto L_0x03af;
                case 23: goto L_0x03a0;
                case 24: goto L_0x038e;
                case 25: goto L_0x037c;
                case 26: goto L_0x036d;
                case 27: goto L_0x0346;
                case 28: goto L_0x031f;
                case 29: goto L_0x0301;
                case 30: goto L_0x02da;
                case 31: goto L_0x02cb;
                case 32: goto L_0x02b9;
                case 33: goto L_0x02a7;
                case 34: goto L_0x0280;
                case 35: goto L_0x0271;
                case 36: goto L_0x025f;
                case 37: goto L_0x024d;
                case 38: goto L_0x0224;
                default: goto L_0x021f;
            }
        L_0x021f:
            super.b(r7, r8, r9)
            goto L_0x04fc
        L_0x0224:
            boolean r8 = r9 instanceof java.lang.String
            if (r8 == 0) goto L_0x0233
            com.facebook.react.uimanager.g r8 = r6.f11244a
            ia.g1 r8 = (ia.g1) r8
            java.lang.String r9 = (java.lang.String) r9
            r8.setStrokeWidth((android.view.View) r7, (java.lang.String) r9)
            goto L_0x04fc
        L_0x0233:
            boolean r8 = r9 instanceof java.lang.Double
            if (r8 == 0) goto L_0x0242
            com.facebook.react.uimanager.g r8 = r6.f11244a
            ia.g1 r8 = (ia.g1) r8
            java.lang.Double r9 = (java.lang.Double) r9
            r8.setStrokeWidth((android.view.View) r7, (java.lang.Double) r9)
            goto L_0x04fc
        L_0x0242:
            com.facebook.react.uimanager.g r8 = r6.f11244a
            ia.g1 r8 = (ia.g1) r8
            java.lang.String r9 = "1"
            r8.setStrokeWidth((android.view.View) r7, (java.lang.String) r9)
            goto L_0x04fc
        L_0x024d:
            com.facebook.react.uimanager.g r8 = r6.f11244a
            ia.g1 r8 = (ia.g1) r8
            if (r9 != 0) goto L_0x0254
            goto L_0x025a
        L_0x0254:
            java.lang.Boolean r9 = (java.lang.Boolean) r9
            boolean r2 = r9.booleanValue()
        L_0x025a:
            r8.setResponsible(r7, r2)
            goto L_0x04fc
        L_0x025f:
            com.facebook.react.uimanager.g r8 = r6.f11244a
            ia.g1 r8 = (ia.g1) r8
            if (r9 != 0) goto L_0x0266
            goto L_0x026c
        L_0x0266:
            java.lang.Double r9 = (java.lang.Double) r9
            int r2 = r9.intValue()
        L_0x026c:
            r8.setStrokeLinejoin(r7, r2)
            goto L_0x04fc
        L_0x0271:
            com.facebook.react.uimanager.g r8 = r6.f11244a
            ia.g1 r8 = (ia.g1) r8
            if (r9 != 0) goto L_0x0278
            goto L_0x027b
        L_0x0278:
            r5 = r9
            java.lang.String r5 = (java.lang.String) r5
        L_0x027b:
            r8.setDisplay(r7, r5)
            goto L_0x04fc
        L_0x0280:
            boolean r8 = r9 instanceof java.lang.String
            if (r8 == 0) goto L_0x028f
            com.facebook.react.uimanager.g r8 = r6.f11244a
            ia.g1 r8 = (ia.g1) r8
            java.lang.String r9 = (java.lang.String) r9
            r8.setTextLength((android.view.View) r7, (java.lang.String) r9)
            goto L_0x04fc
        L_0x028f:
            boolean r8 = r9 instanceof java.lang.Double
            if (r8 == 0) goto L_0x029e
            com.facebook.react.uimanager.g r8 = r6.f11244a
            ia.g1 r8 = (ia.g1) r8
            java.lang.Double r9 = (java.lang.Double) r9
            r8.setTextLength((android.view.View) r7, (java.lang.Double) r9)
            goto L_0x04fc
        L_0x029e:
            com.facebook.react.uimanager.g r8 = r6.f11244a
            ia.g1 r8 = (ia.g1) r8
            r8.setTextLength((android.view.View) r7, (java.lang.Double) r5)
            goto L_0x04fc
        L_0x02a7:
            com.facebook.react.uimanager.g r8 = r6.f11244a
            ia.g1 r8 = (ia.g1) r8
            if (r9 != 0) goto L_0x02ae
            goto L_0x02b4
        L_0x02ae:
            java.lang.Double r9 = (java.lang.Double) r9
            int r2 = r9.intValue()
        L_0x02b4:
            r8.setStrokeLinecap(r7, r2)
            goto L_0x04fc
        L_0x02b9:
            com.facebook.react.uimanager.g r8 = r6.f11244a
            ia.g1 r8 = (ia.g1) r8
            if (r9 != 0) goto L_0x02c0
            goto L_0x02c6
        L_0x02c0:
            java.lang.Double r9 = (java.lang.Double) r9
            int r2 = r9.intValue()
        L_0x02c6:
            r8.setClipRule(r7, r2)
            goto L_0x04fc
        L_0x02cb:
            com.facebook.react.uimanager.g r8 = r6.f11244a
            ia.g1 r8 = (ia.g1) r8
            if (r9 != 0) goto L_0x02d2
            goto L_0x02d5
        L_0x02d2:
            r5 = r9
            java.lang.String r5 = (java.lang.String) r5
        L_0x02d5:
            r8.setClipPath(r7, r5)
            goto L_0x04fc
        L_0x02da:
            boolean r8 = r9 instanceof java.lang.String
            if (r8 == 0) goto L_0x02e9
            com.facebook.react.uimanager.g r8 = r6.f11244a
            ia.g1 r8 = (ia.g1) r8
            java.lang.String r9 = (java.lang.String) r9
            r8.setInlineSize((android.view.View) r7, (java.lang.String) r9)
            goto L_0x04fc
        L_0x02e9:
            boolean r8 = r9 instanceof java.lang.Double
            if (r8 == 0) goto L_0x02f8
            com.facebook.react.uimanager.g r8 = r6.f11244a
            ia.g1 r8 = (ia.g1) r8
            java.lang.Double r9 = (java.lang.Double) r9
            r8.setInlineSize((android.view.View) r7, (java.lang.Double) r9)
            goto L_0x04fc
        L_0x02f8:
            com.facebook.react.uimanager.g r8 = r6.f11244a
            ia.g1 r8 = (ia.g1) r8
            r8.setInlineSize((android.view.View) r7, (java.lang.Double) r5)
            goto L_0x04fc
        L_0x0301:
            boolean r8 = r9 instanceof java.lang.String
            if (r8 == 0) goto L_0x0310
            com.facebook.react.uimanager.g r8 = r6.f11244a
            ia.g1 r8 = (ia.g1) r8
            java.lang.String r9 = (java.lang.String) r9
            r8.setStrokeDasharray((android.view.View) r7, (java.lang.String) r9)
            goto L_0x04fc
        L_0x0310:
            boolean r8 = r9 instanceof com.facebook.react.bridge.ReadableArray
            if (r8 == 0) goto L_0x04fc
            com.facebook.react.uimanager.g r8 = r6.f11244a
            ia.g1 r8 = (ia.g1) r8
            com.facebook.react.bridge.ReadableArray r9 = (com.facebook.react.bridge.ReadableArray) r9
            r8.setStrokeDasharray((android.view.View) r7, (com.facebook.react.bridge.ReadableArray) r9)
            goto L_0x04fc
        L_0x031f:
            boolean r8 = r9 instanceof java.lang.String
            if (r8 == 0) goto L_0x032e
            com.facebook.react.uimanager.g r8 = r6.f11244a
            ia.g1 r8 = (ia.g1) r8
            java.lang.String r9 = (java.lang.String) r9
            r8.setFontSize((android.view.View) r7, (java.lang.String) r9)
            goto L_0x04fc
        L_0x032e:
            boolean r8 = r9 instanceof java.lang.Double
            if (r8 == 0) goto L_0x033d
            com.facebook.react.uimanager.g r8 = r6.f11244a
            ia.g1 r8 = (ia.g1) r8
            java.lang.Double r9 = (java.lang.Double) r9
            r8.setFontSize((android.view.View) r7, (java.lang.Double) r9)
            goto L_0x04fc
        L_0x033d:
            com.facebook.react.uimanager.g r8 = r6.f11244a
            ia.g1 r8 = (ia.g1) r8
            r8.setFontSize((android.view.View) r7, (java.lang.Double) r5)
            goto L_0x04fc
        L_0x0346:
            boolean r8 = r9 instanceof java.lang.String
            if (r8 == 0) goto L_0x0355
            com.facebook.react.uimanager.g r8 = r6.f11244a
            ia.g1 r8 = (ia.g1) r8
            java.lang.String r9 = (java.lang.String) r9
            r8.setBaselineShift((android.view.View) r7, (java.lang.String) r9)
            goto L_0x04fc
        L_0x0355:
            boolean r8 = r9 instanceof java.lang.Double
            if (r8 == 0) goto L_0x0364
            com.facebook.react.uimanager.g r8 = r6.f11244a
            ia.g1 r8 = (ia.g1) r8
            java.lang.Double r9 = (java.lang.Double) r9
            r8.setBaselineShift((android.view.View) r7, (java.lang.Double) r9)
            goto L_0x04fc
        L_0x0364:
            com.facebook.react.uimanager.g r8 = r6.f11244a
            ia.g1 r8 = (ia.g1) r8
            r8.setBaselineShift((android.view.View) r7, (java.lang.Double) r5)
            goto L_0x04fc
        L_0x036d:
            com.facebook.react.uimanager.g r8 = r6.f11244a
            ia.g1 r8 = (ia.g1) r8
            if (r9 != 0) goto L_0x0374
            goto L_0x0377
        L_0x0374:
            r5 = r9
            java.lang.String r5 = (java.lang.String) r5
        L_0x0377:
            r8.setMarkerStart(r7, r5)
            goto L_0x04fc
        L_0x037c:
            com.facebook.react.uimanager.g r8 = r6.f11244a
            ia.g1 r8 = (ia.g1) r8
            if (r9 != 0) goto L_0x0383
            goto L_0x0389
        L_0x0383:
            java.lang.Double r9 = (java.lang.Double) r9
            int r2 = r9.intValue()
        L_0x0389:
            r8.setVectorEffect(r7, r2)
            goto L_0x04fc
        L_0x038e:
            com.facebook.react.uimanager.g r8 = r6.f11244a
            ia.g1 r8 = (ia.g1) r8
            if (r9 != 0) goto L_0x0395
            goto L_0x039b
        L_0x0395:
            java.lang.Double r9 = (java.lang.Double) r9
            float r0 = r9.floatValue()
        L_0x039b:
            r8.setStrokeMiterlimit(r7, r0)
            goto L_0x04fc
        L_0x03a0:
            com.facebook.react.uimanager.g r8 = r6.f11244a
            ia.g1 r8 = (ia.g1) r8
            if (r9 != 0) goto L_0x03a7
            goto L_0x03aa
        L_0x03a7:
            r5 = r9
            java.lang.String r5 = (java.lang.String) r5
        L_0x03aa:
            r8.setName(r7, r5)
            goto L_0x04fc
        L_0x03af:
            com.facebook.react.uimanager.g r8 = r6.f11244a
            ia.g1 r8 = (ia.g1) r8
            if (r9 != 0) goto L_0x03b6
            goto L_0x03b9
        L_0x03b6:
            r5 = r9
            java.lang.String r5 = (java.lang.String) r5
        L_0x03b9:
            r8.setMask(r7, r5)
            goto L_0x04fc
        L_0x03be:
            com.facebook.react.uimanager.g r8 = r6.f11244a
            ia.g1 r8 = (ia.g1) r8
            com.facebook.react.bridge.ReadableMap r9 = (com.facebook.react.bridge.ReadableMap) r9
            r8.setFont(r7, r9)
            goto L_0x04fc
        L_0x03c9:
            com.facebook.react.uimanager.g r8 = r6.f11244a
            ia.g1 r8 = (ia.g1) r8
            com.facebook.react.bridge.ReadableMap r9 = (com.facebook.react.bridge.ReadableMap) r9
            r8.setFill(r7, r9)
            goto L_0x04fc
        L_0x03d4:
            com.facebook.react.uimanager.g r8 = r6.f11244a
            ia.g1 r8 = (ia.g1) r8
            com.facebook.react.bridge.ReadableArray r9 = (com.facebook.react.bridge.ReadableArray) r9
            r8.setDy(r7, r9)
            goto L_0x04fc
        L_0x03df:
            com.facebook.react.uimanager.g r8 = r6.f11244a
            ia.g1 r8 = (ia.g1) r8
            com.facebook.react.bridge.ReadableArray r9 = (com.facebook.react.bridge.ReadableArray) r9
            r8.setDx(r7, r9)
            goto L_0x04fc
        L_0x03ea:
            com.facebook.react.uimanager.g r8 = r6.f11244a
            ia.g1 r8 = (ia.g1) r8
            com.facebook.react.bridge.ReadableArray r9 = (com.facebook.react.bridge.ReadableArray) r9
            r8.setY(r7, r9)
            goto L_0x04fc
        L_0x03f5:
            com.facebook.react.uimanager.g r8 = r6.f11244a
            ia.g1 r8 = (ia.g1) r8
            com.facebook.react.bridge.ReadableArray r9 = (com.facebook.react.bridge.ReadableArray) r9
            r8.setX(r7, r9)
            goto L_0x04fc
        L_0x0400:
            com.facebook.react.uimanager.g r8 = r6.f11244a
            ia.g1 r8 = (ia.g1) r8
            if (r9 != 0) goto L_0x0407
            goto L_0x040d
        L_0x0407:
            java.lang.Double r9 = (java.lang.Double) r9
            float r0 = r9.floatValue()
        L_0x040d:
            r8.setStrokeDashoffset(r7, r0)
            goto L_0x04fc
        L_0x0412:
            com.facebook.react.uimanager.g r8 = r6.f11244a
            ia.g1 r8 = (ia.g1) r8
            if (r9 != 0) goto L_0x0419
            goto L_0x041f
        L_0x0419:
            java.lang.Double r9 = (java.lang.Double) r9
            float r4 = r9.floatValue()
        L_0x041f:
            r8.setFillOpacity(r7, r4)
            goto L_0x04fc
        L_0x0424:
            com.facebook.react.uimanager.g r8 = r6.f11244a
            ia.g1 r8 = (ia.g1) r8
            if (r9 != 0) goto L_0x042b
            goto L_0x042e
        L_0x042b:
            r5 = r9
            java.lang.String r5 = (java.lang.String) r5
        L_0x042e:
            r8.setPointerEvents(r7, r5)
            goto L_0x04fc
        L_0x0433:
            com.facebook.react.uimanager.g r8 = r6.f11244a
            ia.g1 r8 = (ia.g1) r8
            if (r9 != 0) goto L_0x043a
            goto L_0x0440
        L_0x043a:
            java.lang.Double r9 = (java.lang.Double) r9
            float r4 = r9.floatValue()
        L_0x0440:
            r8.setStrokeOpacity(r7, r4)
            goto L_0x04fc
        L_0x0445:
            com.facebook.react.uimanager.g r8 = r6.f11244a
            ia.g1 r8 = (ia.g1) r8
            if (r9 != 0) goto L_0x044c
            goto L_0x0452
        L_0x044c:
            java.lang.Double r9 = (java.lang.Double) r9
            int r1 = r9.intValue()
        L_0x0452:
            r8.setFillRule(r7, r1)
            goto L_0x04fc
        L_0x0457:
            boolean r8 = r9 instanceof java.lang.String
            if (r8 == 0) goto L_0x0466
            com.facebook.react.uimanager.g r8 = r6.f11244a
            ia.g1 r8 = (ia.g1) r8
            java.lang.String r9 = (java.lang.String) r9
            r8.setFontWeight((android.view.View) r7, (java.lang.String) r9)
            goto L_0x04fc
        L_0x0466:
            boolean r8 = r9 instanceof java.lang.Double
            if (r8 == 0) goto L_0x0475
            com.facebook.react.uimanager.g r8 = r6.f11244a
            ia.g1 r8 = (ia.g1) r8
            java.lang.Double r9 = (java.lang.Double) r9
            r8.setFontWeight((android.view.View) r7, (java.lang.Double) r9)
            goto L_0x04fc
        L_0x0475:
            com.facebook.react.uimanager.g r8 = r6.f11244a
            ia.g1 r8 = (ia.g1) r8
            r8.setFontWeight((android.view.View) r7, (java.lang.Double) r5)
            goto L_0x04fc
        L_0x047e:
            com.facebook.react.uimanager.g r8 = r6.f11244a
            ia.g1 r8 = (ia.g1) r8
            com.facebook.react.bridge.ReadableMap r9 = (com.facebook.react.bridge.ReadableMap) r9
            r8.setStroke(r7, r9)
            goto L_0x04fc
        L_0x0489:
            com.facebook.react.uimanager.g r8 = r6.f11244a
            ia.g1 r8 = (ia.g1) r8
            com.facebook.react.bridge.ReadableArray r9 = (com.facebook.react.bridge.ReadableArray) r9
            r8.setRotate(r7, r9)
            goto L_0x04fc
        L_0x0494:
            com.facebook.react.uimanager.g r8 = r6.f11244a
            ia.g1 r8 = (ia.g1) r8
            if (r9 != 0) goto L_0x049b
            goto L_0x049e
        L_0x049b:
            r5 = r9
            java.lang.String r5 = (java.lang.String) r5
        L_0x049e:
            r8.setMarkerMid(r7, r5)
            goto L_0x04fc
        L_0x04a2:
            com.facebook.react.uimanager.g r8 = r6.f11244a
            ia.g1 r8 = (ia.g1) r8
            if (r9 != 0) goto L_0x04a9
            goto L_0x04ac
        L_0x04a9:
            r5 = r9
            java.lang.String r5 = (java.lang.String) r5
        L_0x04ac:
            r8.setMarkerEnd(r7, r5)
            goto L_0x04fc
        L_0x04b0:
            com.facebook.react.uimanager.g r8 = r6.f11244a
            ia.g1 r8 = (ia.g1) r8
            com.facebook.react.bridge.ReadableArray r9 = (com.facebook.react.bridge.ReadableArray) r9
            r8.setPropList(r7, r9)
            goto L_0x04fc
        L_0x04ba:
            com.facebook.react.uimanager.g r8 = r6.f11244a
            ia.g1 r8 = (ia.g1) r8
            com.facebook.react.bridge.ReadableArray r9 = (com.facebook.react.bridge.ReadableArray) r9
            r8.setMatrix(r7, r9)
            goto L_0x04fc
        L_0x04c4:
            com.facebook.react.uimanager.g r8 = r6.f11244a
            ia.g1 r8 = (ia.g1) r8
            if (r9 != 0) goto L_0x04cb
            goto L_0x04ce
        L_0x04cb:
            r5 = r9
            java.lang.String r5 = (java.lang.String) r5
        L_0x04ce:
            r8.setVerticalAlign(r7, r5)
            goto L_0x04fc
        L_0x04d2:
            com.facebook.react.uimanager.g r8 = r6.f11244a
            ia.g1 r8 = (ia.g1) r8
            if (r9 != 0) goto L_0x04d9
            goto L_0x04dc
        L_0x04d9:
            r5 = r9
            java.lang.String r5 = (java.lang.String) r5
        L_0x04dc:
            r8.setAlignmentBaseline(r7, r5)
            goto L_0x04fc
        L_0x04e0:
            com.facebook.react.uimanager.g r8 = r6.f11244a
            if (r9 != 0) goto L_0x04e5
            goto L_0x04eb
        L_0x04e5:
            java.lang.Double r9 = (java.lang.Double) r9
            float r4 = r9.floatValue()
        L_0x04eb:
            r8.setOpacity(r7, r4)
            goto L_0x04fc
        L_0x04ef:
            com.facebook.react.uimanager.g r8 = r6.f11244a
            ia.g1 r8 = (ia.g1) r8
            if (r9 != 0) goto L_0x04f6
            goto L_0x04f9
        L_0x04f6:
            r5 = r9
            java.lang.String r5 = (java.lang.String) r5
        L_0x04f9:
            r8.setLengthAdjust(r7, r5)
        L_0x04fc:
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: ia.f1.b(android.view.View, java.lang.String, java.lang.Object):void");
    }
}
