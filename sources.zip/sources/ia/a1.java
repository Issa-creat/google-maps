package ia;

import android.view.View;
import com.facebook.react.bridge.ReadableMap;

public interface a1 {
    void setAccessible(View view, boolean z10);

    void setAlign(View view, String str);

    void setBackfaceVisibility(View view, String str);

    void setBbHeight(View view, Double d10);

    void setBbHeight(View view, String str);

    void setBbWidth(View view, Double d10);

    void setBbWidth(View view, String str);

    void setBorderBottomColor(View view, Integer num);

    void setBorderBottomEndRadius(View view, float f10);

    void setBorderBottomLeftRadius(View view, double d10);

    void setBorderBottomRightRadius(View view, double d10);

    void setBorderBottomStartRadius(View view, float f10);

    void setBorderColor(View view, Integer num);

    void setBorderEndColor(View view, Integer num);

    void setBorderLeftColor(View view, Integer num);

    void setBorderRadius(View view, double d10);

    void setBorderRightColor(View view, Integer num);

    void setBorderStartColor(View view, Integer num);

    void setBorderStyle(View view, String str);

    void setBorderTopColor(View view, Integer num);

    void setBorderTopEndRadius(View view, float f10);

    void setBorderTopLeftRadius(View view, double d10);

    void setBorderTopRightRadius(View view, double d10);

    void setBorderTopStartRadius(View view, float f10);

    void setColor(View view, Integer num);

    void setFocusable(View view, boolean z10);

    void setHasTVPreferredFocus(View view, boolean z10);

    void setHitSlop(View view, ReadableMap readableMap);

    void setMeetOrSlice(View view, int i10);

    void setMinX(View view, float f10);

    void setMinY(View view, float f10);

    void setNativeBackgroundAndroid(View view, ReadableMap readableMap);

    void setNativeForegroundAndroid(View view, ReadableMap readableMap);

    void setNeedsOffscreenAlphaCompositing(View view, boolean z10);

    void setNextFocusDown(View view, int i10);

    void setNextFocusForward(View view, int i10);

    void setNextFocusLeft(View view, int i10);

    void setNextFocusRight(View view, int i10);

    void setNextFocusUp(View view, int i10);

    void setPointerEvents(View view, String str);

    void setRemoveClippedSubviews(View view, boolean z10);

    void setTintColor(View view, Integer num);

    void setVbHeight(View view, float f10);

    void setVbWidth(View view, float f10);
}
