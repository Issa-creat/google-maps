package ia;

import android.view.View;
import com.facebook.react.bridge.ReadableArray;
import com.facebook.react.bridge.ReadableMap;

public interface o0 {
    void setAlign(View view, String str);

    void setClipPath(View view, String str);

    void setClipRule(View view, int i10);

    void setDisplay(View view, String str);

    void setFill(View view, ReadableMap readableMap);

    void setFillOpacity(View view, float f10);

    void setFillRule(View view, int i10);

    void setFont(View view, ReadableMap readableMap);

    void setFontSize(View view, Double d10);

    void setFontSize(View view, String str);

    void setFontWeight(View view, Double d10);

    void setFontWeight(View view, String str);

    void setMarkerEnd(View view, String str);

    void setMarkerHeight(View view, Double d10);

    void setMarkerHeight(View view, String str);

    void setMarkerMid(View view, String str);

    void setMarkerStart(View view, String str);

    void setMarkerUnits(View view, String str);

    void setMarkerWidth(View view, Double d10);

    void setMarkerWidth(View view, String str);

    void setMask(View view, String str);

    void setMatrix(View view, ReadableArray readableArray);

    void setMeetOrSlice(View view, int i10);

    void setMinX(View view, float f10);

    void setMinY(View view, float f10);

    void setName(View view, String str);

    void setOrient(View view, String str);

    void setPointerEvents(View view, String str);

    void setPropList(View view, ReadableArray readableArray);

    void setRefX(View view, Double d10);

    void setRefX(View view, String str);

    void setRefY(View view, Double d10);

    void setRefY(View view, String str);

    void setResponsible(View view, boolean z10);

    void setStroke(View view, ReadableMap readableMap);

    void setStrokeDasharray(View view, ReadableArray readableArray);

    void setStrokeDasharray(View view, String str);

    void setStrokeDashoffset(View view, float f10);

    void setStrokeLinecap(View view, int i10);

    void setStrokeLinejoin(View view, int i10);

    void setStrokeMiterlimit(View view, float f10);

    void setStrokeOpacity(View view, float f10);

    void setStrokeWidth(View view, Double d10);

    void setStrokeWidth(View view, String str);

    void setVbHeight(View view, float f10);

    void setVbWidth(View view, float f10);

    void setVectorEffect(View view, int i10);
}
