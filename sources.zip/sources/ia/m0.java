package ia;

import android.view.View;
import com.facebook.react.bridge.ReadableArray;

public interface m0 {
    void setClipPath(View view, String str);

    void setClipRule(View view, int i10);

    void setDisplay(View view, String str);

    void setGradient(View view, ReadableArray readableArray);

    void setGradientTransform(View view, ReadableArray readableArray);

    void setGradientUnits(View view, int i10);

    void setMarkerEnd(View view, String str);

    void setMarkerMid(View view, String str);

    void setMarkerStart(View view, String str);

    void setMask(View view, String str);

    void setMatrix(View view, ReadableArray readableArray);

    void setName(View view, String str);

    void setPointerEvents(View view, String str);

    void setResponsible(View view, boolean z10);

    void setX1(View view, Double d10);

    void setX1(View view, String str);

    void setX2(View view, Double d10);

    void setX2(View view, String str);

    void setY1(View view, Double d10);

    void setY1(View view, String str);

    void setY2(View view, Double d10);

    void setY2(View view, String str);
}
