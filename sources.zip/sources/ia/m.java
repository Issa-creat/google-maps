package ia;

import android.view.View;

public interface m {
    void setBorderless(View view, boolean z10);

    void setEnabled(View view, boolean z10);

    void setExclusive(View view, boolean z10);

    void setForeground(View view, boolean z10);

    void setRippleColor(View view, Integer num);

    void setRippleRadius(View view, int i10);

    void setTouchSoundDisabled(View view, boolean z10);
}
