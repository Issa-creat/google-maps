package ia;

import android.view.View;

public interface h {
    void setDisabled(View view, boolean z10);

    void setEnabled(View view, boolean z10);

    void setNativeValue(View view, boolean z10);

    void setOn(View view, boolean z10);

    void setThumbColor(View view, Integer num);

    void setThumbTintColor(View view, Integer num);

    void setTrackColorForFalse(View view, Integer num);

    void setTrackColorForTrue(View view, Integer num);

    void setTrackTintColor(View view, Integer num);

    void setValue(View view, boolean z10);
}
