package ia;

import com.facebook.react.uimanager.f;
import com.facebook.react.uimanager.g;

public class t0 extends f {
    public t0(g gVar) {
        super(gVar);
    }

    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r2v0, resolved type: boolean} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r2v1, resolved type: boolean} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r2v2, resolved type: int} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r2v3, resolved type: boolean} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r2v4, resolved type: int} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r2v5, resolved type: boolean} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r2v6, resolved type: int} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r2v7, resolved type: boolean} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r2v8, resolved type: int} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r2v9, resolved type: boolean} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r2v10, resolved type: int} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r2v11, resolved type: boolean} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r2v12, resolved type: int} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r2v13, resolved type: boolean} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r2v15, resolved type: boolean} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r2v16, resolved type: int} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r2v17, resolved type: boolean} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r2v18, resolved type: boolean} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r2v19, resolved type: boolean} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r2v20, resolved type: boolean} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r2v21, resolved type: boolean} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r2v22, resolved type: boolean} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r2v23, resolved type: boolean} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r2v24, resolved type: boolean} */
    /* JADX WARNING: Multi-variable type inference failed */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public void b(android.view.View r7, java.lang.String r8, java.lang.Object r9) {
        /*
            r6 = this;
            r8.hashCode()
            int r0 = r8.hashCode()
            r1 = 1
            r2 = 0
            r3 = -1
            switch(r0) {
                case -1567958285: goto L_0x022a;
                case -1267206133: goto L_0x021f;
                case -1221029593: goto L_0x0214;
                case -1081239615: goto L_0x0209;
                case -993894751: goto L_0x01fe;
                case -933864895: goto L_0x01f3;
                case -933857362: goto L_0x01e8;
                case -891980232: goto L_0x01dd;
                case -734428249: goto L_0x01cf;
                case -729118945: goto L_0x01c1;
                case -416535885: goto L_0x01b3;
                case -293492298: goto L_0x01a5;
                case -207800897: goto L_0x0197;
                case -128680410: goto L_0x0189;
                case -53677816: goto L_0x017b;
                case -44578051: goto L_0x016d;
                case 120: goto L_0x015f;
                case 121: goto L_0x0151;
                case 3143043: goto L_0x0143;
                case 3148879: goto L_0x0135;
                case 3344108: goto L_0x0127;
                case 3351622: goto L_0x0119;
                case 3351623: goto L_0x010b;
                case 3373707: goto L_0x00fd;
                case 78845486: goto L_0x00ef;
                case 92903173: goto L_0x00e1;
                case 104482996: goto L_0x00d3;
                case 113126854: goto L_0x00c5;
                case 217109576: goto L_0x00b7;
                case 240482938: goto L_0x00a9;
                case 365601008: goto L_0x009b;
                case 401643183: goto L_0x008d;
                case 746561980: goto L_0x007f;
                case 917656469: goto L_0x0071;
                case 917735020: goto L_0x0063;
                case 1027575302: goto L_0x0055;
                case 1671764162: goto L_0x0047;
                case 1790285174: goto L_0x0039;
                case 1847674614: goto L_0x002b;
                case 1908075304: goto L_0x001d;
                case 1924065902: goto L_0x000f;
                default: goto L_0x000d;
            }
        L_0x000d:
            goto L_0x0234
        L_0x000f:
            java.lang.String r0 = "strokeWidth"
            boolean r0 = r8.equals(r0)
            if (r0 != 0) goto L_0x0019
            goto L_0x0234
        L_0x0019:
            r3 = 40
            goto L_0x0234
        L_0x001d:
            java.lang.String r0 = "meetOrSlice"
            boolean r0 = r8.equals(r0)
            if (r0 != 0) goto L_0x0027
            goto L_0x0234
        L_0x0027:
            r3 = 39
            goto L_0x0234
        L_0x002b:
            java.lang.String r0 = "responsible"
            boolean r0 = r8.equals(r0)
            if (r0 != 0) goto L_0x0035
            goto L_0x0234
        L_0x0035:
            r3 = 38
            goto L_0x0234
        L_0x0039:
            java.lang.String r0 = "strokeLinejoin"
            boolean r0 = r8.equals(r0)
            if (r0 != 0) goto L_0x0043
            goto L_0x0234
        L_0x0043:
            r3 = 37
            goto L_0x0234
        L_0x0047:
            java.lang.String r0 = "display"
            boolean r0 = r8.equals(r0)
            if (r0 != 0) goto L_0x0051
            goto L_0x0234
        L_0x0051:
            r3 = 36
            goto L_0x0234
        L_0x0055:
            java.lang.String r0 = "strokeLinecap"
            boolean r0 = r8.equals(r0)
            if (r0 != 0) goto L_0x005f
            goto L_0x0234
        L_0x005f:
            r3 = 35
            goto L_0x0234
        L_0x0063:
            java.lang.String r0 = "clipRule"
            boolean r0 = r8.equals(r0)
            if (r0 != 0) goto L_0x006d
            goto L_0x0234
        L_0x006d:
            r3 = 34
            goto L_0x0234
        L_0x0071:
            java.lang.String r0 = "clipPath"
            boolean r0 = r8.equals(r0)
            if (r0 != 0) goto L_0x007b
            goto L_0x0234
        L_0x007b:
            r3 = 33
            goto L_0x0234
        L_0x007f:
            java.lang.String r0 = "patternTransform"
            boolean r0 = r8.equals(r0)
            if (r0 != 0) goto L_0x0089
            goto L_0x0234
        L_0x0089:
            r3 = 32
            goto L_0x0234
        L_0x008d:
            java.lang.String r0 = "strokeDasharray"
            boolean r0 = r8.equals(r0)
            if (r0 != 0) goto L_0x0097
            goto L_0x0234
        L_0x0097:
            r3 = 31
            goto L_0x0234
        L_0x009b:
            java.lang.String r0 = "fontSize"
            boolean r0 = r8.equals(r0)
            if (r0 != 0) goto L_0x00a5
            goto L_0x0234
        L_0x00a5:
            r3 = 30
            goto L_0x0234
        L_0x00a9:
            java.lang.String r0 = "vbWidth"
            boolean r0 = r8.equals(r0)
            if (r0 != 0) goto L_0x00b3
            goto L_0x0234
        L_0x00b3:
            r3 = 29
            goto L_0x0234
        L_0x00b7:
            java.lang.String r0 = "markerStart"
            boolean r0 = r8.equals(r0)
            if (r0 != 0) goto L_0x00c1
            goto L_0x0234
        L_0x00c1:
            r3 = 28
            goto L_0x0234
        L_0x00c5:
            java.lang.String r0 = "width"
            boolean r0 = r8.equals(r0)
            if (r0 != 0) goto L_0x00cf
            goto L_0x0234
        L_0x00cf:
            r3 = 27
            goto L_0x0234
        L_0x00d3:
            java.lang.String r0 = "vectorEffect"
            boolean r0 = r8.equals(r0)
            if (r0 != 0) goto L_0x00dd
            goto L_0x0234
        L_0x00dd:
            r3 = 26
            goto L_0x0234
        L_0x00e1:
            java.lang.String r0 = "align"
            boolean r0 = r8.equals(r0)
            if (r0 != 0) goto L_0x00eb
            goto L_0x0234
        L_0x00eb:
            r3 = 25
            goto L_0x0234
        L_0x00ef:
            java.lang.String r0 = "strokeMiterlimit"
            boolean r0 = r8.equals(r0)
            if (r0 != 0) goto L_0x00f9
            goto L_0x0234
        L_0x00f9:
            r3 = 24
            goto L_0x0234
        L_0x00fd:
            java.lang.String r0 = "name"
            boolean r0 = r8.equals(r0)
            if (r0 != 0) goto L_0x0107
            goto L_0x0234
        L_0x0107:
            r3 = 23
            goto L_0x0234
        L_0x010b:
            java.lang.String r0 = "minY"
            boolean r0 = r8.equals(r0)
            if (r0 != 0) goto L_0x0115
            goto L_0x0234
        L_0x0115:
            r3 = 22
            goto L_0x0234
        L_0x0119:
            java.lang.String r0 = "minX"
            boolean r0 = r8.equals(r0)
            if (r0 != 0) goto L_0x0123
            goto L_0x0234
        L_0x0123:
            r3 = 21
            goto L_0x0234
        L_0x0127:
            java.lang.String r0 = "mask"
            boolean r0 = r8.equals(r0)
            if (r0 != 0) goto L_0x0131
            goto L_0x0234
        L_0x0131:
            r3 = 20
            goto L_0x0234
        L_0x0135:
            java.lang.String r0 = "font"
            boolean r0 = r8.equals(r0)
            if (r0 != 0) goto L_0x013f
            goto L_0x0234
        L_0x013f:
            r3 = 19
            goto L_0x0234
        L_0x0143:
            java.lang.String r0 = "fill"
            boolean r0 = r8.equals(r0)
            if (r0 != 0) goto L_0x014d
            goto L_0x0234
        L_0x014d:
            r3 = 18
            goto L_0x0234
        L_0x0151:
            java.lang.String r0 = "y"
            boolean r0 = r8.equals(r0)
            if (r0 != 0) goto L_0x015b
            goto L_0x0234
        L_0x015b:
            r3 = 17
            goto L_0x0234
        L_0x015f:
            java.lang.String r0 = "x"
            boolean r0 = r8.equals(r0)
            if (r0 != 0) goto L_0x0169
            goto L_0x0234
        L_0x0169:
            r3 = 16
            goto L_0x0234
        L_0x016d:
            java.lang.String r0 = "strokeDashoffset"
            boolean r0 = r8.equals(r0)
            if (r0 != 0) goto L_0x0177
            goto L_0x0234
        L_0x0177:
            r3 = 15
            goto L_0x0234
        L_0x017b:
            java.lang.String r0 = "fillOpacity"
            boolean r0 = r8.equals(r0)
            if (r0 != 0) goto L_0x0185
            goto L_0x0234
        L_0x0185:
            r3 = 14
            goto L_0x0234
        L_0x0189:
            java.lang.String r0 = "patternContentUnits"
            boolean r0 = r8.equals(r0)
            if (r0 != 0) goto L_0x0193
            goto L_0x0234
        L_0x0193:
            r3 = 13
            goto L_0x0234
        L_0x0197:
            java.lang.String r0 = "patternUnits"
            boolean r0 = r8.equals(r0)
            if (r0 != 0) goto L_0x01a1
            goto L_0x0234
        L_0x01a1:
            r3 = 12
            goto L_0x0234
        L_0x01a5:
            java.lang.String r0 = "pointerEvents"
            boolean r0 = r8.equals(r0)
            if (r0 != 0) goto L_0x01af
            goto L_0x0234
        L_0x01af:
            r3 = 11
            goto L_0x0234
        L_0x01b3:
            java.lang.String r0 = "strokeOpacity"
            boolean r0 = r8.equals(r0)
            if (r0 != 0) goto L_0x01bd
            goto L_0x0234
        L_0x01bd:
            r3 = 10
            goto L_0x0234
        L_0x01c1:
            java.lang.String r0 = "fillRule"
            boolean r0 = r8.equals(r0)
            if (r0 != 0) goto L_0x01cb
            goto L_0x0234
        L_0x01cb:
            r3 = 9
            goto L_0x0234
        L_0x01cf:
            java.lang.String r0 = "fontWeight"
            boolean r0 = r8.equals(r0)
            if (r0 != 0) goto L_0x01d9
            goto L_0x0234
        L_0x01d9:
            r3 = 8
            goto L_0x0234
        L_0x01dd:
            java.lang.String r0 = "stroke"
            boolean r0 = r8.equals(r0)
            if (r0 != 0) goto L_0x01e6
            goto L_0x0234
        L_0x01e6:
            r3 = 7
            goto L_0x0234
        L_0x01e8:
            java.lang.String r0 = "markerMid"
            boolean r0 = r8.equals(r0)
            if (r0 != 0) goto L_0x01f1
            goto L_0x0234
        L_0x01f1:
            r3 = 6
            goto L_0x0234
        L_0x01f3:
            java.lang.String r0 = "markerEnd"
            boolean r0 = r8.equals(r0)
            if (r0 != 0) goto L_0x01fc
            goto L_0x0234
        L_0x01fc:
            r3 = 5
            goto L_0x0234
        L_0x01fe:
            java.lang.String r0 = "propList"
            boolean r0 = r8.equals(r0)
            if (r0 != 0) goto L_0x0207
            goto L_0x0234
        L_0x0207:
            r3 = 4
            goto L_0x0234
        L_0x0209:
            java.lang.String r0 = "matrix"
            boolean r0 = r8.equals(r0)
            if (r0 != 0) goto L_0x0212
            goto L_0x0234
        L_0x0212:
            r3 = 3
            goto L_0x0234
        L_0x0214:
            java.lang.String r0 = "height"
            boolean r0 = r8.equals(r0)
            if (r0 != 0) goto L_0x021d
            goto L_0x0234
        L_0x021d:
            r3 = 2
            goto L_0x0234
        L_0x021f:
            java.lang.String r0 = "opacity"
            boolean r0 = r8.equals(r0)
            if (r0 != 0) goto L_0x0228
            goto L_0x0234
        L_0x0228:
            r3 = 1
            goto L_0x0234
        L_0x022a:
            java.lang.String r0 = "vbHeight"
            boolean r0 = r8.equals(r0)
            if (r0 != 0) goto L_0x0233
            goto L_0x0234
        L_0x0233:
            r3 = 0
        L_0x0234:
            r0 = 1065353216(0x3f800000, float:1.0)
            r4 = 0
            r5 = 0
            switch(r3) {
                case 0: goto L_0x0563;
                case 1: goto L_0x0554;
                case 2: goto L_0x0530;
                case 3: goto L_0x0526;
                case 4: goto L_0x051c;
                case 5: goto L_0x050e;
                case 6: goto L_0x04ff;
                case 7: goto L_0x04f4;
                case 8: goto L_0x04cd;
                case 9: goto L_0x04bb;
                case 10: goto L_0x04a9;
                case 11: goto L_0x049a;
                case 12: goto L_0x0488;
                case 13: goto L_0x0476;
                case 14: goto L_0x0464;
                case 15: goto L_0x0452;
                case 16: goto L_0x042b;
                case 17: goto L_0x0404;
                case 18: goto L_0x03f9;
                case 19: goto L_0x03ee;
                case 20: goto L_0x03df;
                case 21: goto L_0x03cd;
                case 22: goto L_0x03bb;
                case 23: goto L_0x03ac;
                case 24: goto L_0x039a;
                case 25: goto L_0x038b;
                case 26: goto L_0x0379;
                case 27: goto L_0x0352;
                case 28: goto L_0x0343;
                case 29: goto L_0x0331;
                case 30: goto L_0x030a;
                case 31: goto L_0x02ec;
                case 32: goto L_0x02e1;
                case 33: goto L_0x02d2;
                case 34: goto L_0x02c0;
                case 35: goto L_0x02ae;
                case 36: goto L_0x029f;
                case 37: goto L_0x028d;
                case 38: goto L_0x027b;
                case 39: goto L_0x0269;
                case 40: goto L_0x0240;
                default: goto L_0x023b;
            }
        L_0x023b:
            super.b(r7, r8, r9)
            goto L_0x0573
        L_0x0240:
            boolean r8 = r9 instanceof java.lang.String
            if (r8 == 0) goto L_0x024f
            com.facebook.react.uimanager.g r8 = r6.f11244a
            ia.u0 r8 = (ia.u0) r8
            java.lang.String r9 = (java.lang.String) r9
            r8.setStrokeWidth((android.view.View) r7, (java.lang.String) r9)
            goto L_0x0573
        L_0x024f:
            boolean r8 = r9 instanceof java.lang.Double
            if (r8 == 0) goto L_0x025e
            com.facebook.react.uimanager.g r8 = r6.f11244a
            ia.u0 r8 = (ia.u0) r8
            java.lang.Double r9 = (java.lang.Double) r9
            r8.setStrokeWidth((android.view.View) r7, (java.lang.Double) r9)
            goto L_0x0573
        L_0x025e:
            com.facebook.react.uimanager.g r8 = r6.f11244a
            ia.u0 r8 = (ia.u0) r8
            java.lang.String r9 = "1"
            r8.setStrokeWidth((android.view.View) r7, (java.lang.String) r9)
            goto L_0x0573
        L_0x0269:
            com.facebook.react.uimanager.g r8 = r6.f11244a
            ia.u0 r8 = (ia.u0) r8
            if (r9 != 0) goto L_0x0270
            goto L_0x0276
        L_0x0270:
            java.lang.Double r9 = (java.lang.Double) r9
            int r2 = r9.intValue()
        L_0x0276:
            r8.setMeetOrSlice(r7, r2)
            goto L_0x0573
        L_0x027b:
            com.facebook.react.uimanager.g r8 = r6.f11244a
            ia.u0 r8 = (ia.u0) r8
            if (r9 != 0) goto L_0x0282
            goto L_0x0288
        L_0x0282:
            java.lang.Boolean r9 = (java.lang.Boolean) r9
            boolean r2 = r9.booleanValue()
        L_0x0288:
            r8.setResponsible(r7, r2)
            goto L_0x0573
        L_0x028d:
            com.facebook.react.uimanager.g r8 = r6.f11244a
            ia.u0 r8 = (ia.u0) r8
            if (r9 != 0) goto L_0x0294
            goto L_0x029a
        L_0x0294:
            java.lang.Double r9 = (java.lang.Double) r9
            int r2 = r9.intValue()
        L_0x029a:
            r8.setStrokeLinejoin(r7, r2)
            goto L_0x0573
        L_0x029f:
            com.facebook.react.uimanager.g r8 = r6.f11244a
            ia.u0 r8 = (ia.u0) r8
            if (r9 != 0) goto L_0x02a6
            goto L_0x02a9
        L_0x02a6:
            r5 = r9
            java.lang.String r5 = (java.lang.String) r5
        L_0x02a9:
            r8.setDisplay(r7, r5)
            goto L_0x0573
        L_0x02ae:
            com.facebook.react.uimanager.g r8 = r6.f11244a
            ia.u0 r8 = (ia.u0) r8
            if (r9 != 0) goto L_0x02b5
            goto L_0x02bb
        L_0x02b5:
            java.lang.Double r9 = (java.lang.Double) r9
            int r2 = r9.intValue()
        L_0x02bb:
            r8.setStrokeLinecap(r7, r2)
            goto L_0x0573
        L_0x02c0:
            com.facebook.react.uimanager.g r8 = r6.f11244a
            ia.u0 r8 = (ia.u0) r8
            if (r9 != 0) goto L_0x02c7
            goto L_0x02cd
        L_0x02c7:
            java.lang.Double r9 = (java.lang.Double) r9
            int r2 = r9.intValue()
        L_0x02cd:
            r8.setClipRule(r7, r2)
            goto L_0x0573
        L_0x02d2:
            com.facebook.react.uimanager.g r8 = r6.f11244a
            ia.u0 r8 = (ia.u0) r8
            if (r9 != 0) goto L_0x02d9
            goto L_0x02dc
        L_0x02d9:
            r5 = r9
            java.lang.String r5 = (java.lang.String) r5
        L_0x02dc:
            r8.setClipPath(r7, r5)
            goto L_0x0573
        L_0x02e1:
            com.facebook.react.uimanager.g r8 = r6.f11244a
            ia.u0 r8 = (ia.u0) r8
            com.facebook.react.bridge.ReadableArray r9 = (com.facebook.react.bridge.ReadableArray) r9
            r8.setPatternTransform(r7, r9)
            goto L_0x0573
        L_0x02ec:
            boolean r8 = r9 instanceof java.lang.String
            if (r8 == 0) goto L_0x02fb
            com.facebook.react.uimanager.g r8 = r6.f11244a
            ia.u0 r8 = (ia.u0) r8
            java.lang.String r9 = (java.lang.String) r9
            r8.setStrokeDasharray((android.view.View) r7, (java.lang.String) r9)
            goto L_0x0573
        L_0x02fb:
            boolean r8 = r9 instanceof com.facebook.react.bridge.ReadableArray
            if (r8 == 0) goto L_0x0573
            com.facebook.react.uimanager.g r8 = r6.f11244a
            ia.u0 r8 = (ia.u0) r8
            com.facebook.react.bridge.ReadableArray r9 = (com.facebook.react.bridge.ReadableArray) r9
            r8.setStrokeDasharray((android.view.View) r7, (com.facebook.react.bridge.ReadableArray) r9)
            goto L_0x0573
        L_0x030a:
            boolean r8 = r9 instanceof java.lang.String
            if (r8 == 0) goto L_0x0319
            com.facebook.react.uimanager.g r8 = r6.f11244a
            ia.u0 r8 = (ia.u0) r8
            java.lang.String r9 = (java.lang.String) r9
            r8.setFontSize((android.view.View) r7, (java.lang.String) r9)
            goto L_0x0573
        L_0x0319:
            boolean r8 = r9 instanceof java.lang.Double
            if (r8 == 0) goto L_0x0328
            com.facebook.react.uimanager.g r8 = r6.f11244a
            ia.u0 r8 = (ia.u0) r8
            java.lang.Double r9 = (java.lang.Double) r9
            r8.setFontSize((android.view.View) r7, (java.lang.Double) r9)
            goto L_0x0573
        L_0x0328:
            com.facebook.react.uimanager.g r8 = r6.f11244a
            ia.u0 r8 = (ia.u0) r8
            r8.setFontSize((android.view.View) r7, (java.lang.Double) r5)
            goto L_0x0573
        L_0x0331:
            com.facebook.react.uimanager.g r8 = r6.f11244a
            ia.u0 r8 = (ia.u0) r8
            if (r9 != 0) goto L_0x0338
            goto L_0x033e
        L_0x0338:
            java.lang.Double r9 = (java.lang.Double) r9
            float r4 = r9.floatValue()
        L_0x033e:
            r8.setVbWidth(r7, r4)
            goto L_0x0573
        L_0x0343:
            com.facebook.react.uimanager.g r8 = r6.f11244a
            ia.u0 r8 = (ia.u0) r8
            if (r9 != 0) goto L_0x034a
            goto L_0x034d
        L_0x034a:
            r5 = r9
            java.lang.String r5 = (java.lang.String) r5
        L_0x034d:
            r8.setMarkerStart(r7, r5)
            goto L_0x0573
        L_0x0352:
            boolean r8 = r9 instanceof java.lang.String
            if (r8 == 0) goto L_0x0361
            com.facebook.react.uimanager.g r8 = r6.f11244a
            ia.u0 r8 = (ia.u0) r8
            java.lang.String r9 = (java.lang.String) r9
            r8.setWidth((android.view.View) r7, (java.lang.String) r9)
            goto L_0x0573
        L_0x0361:
            boolean r8 = r9 instanceof java.lang.Double
            if (r8 == 0) goto L_0x0370
            com.facebook.react.uimanager.g r8 = r6.f11244a
            ia.u0 r8 = (ia.u0) r8
            java.lang.Double r9 = (java.lang.Double) r9
            r8.setWidth((android.view.View) r7, (java.lang.Double) r9)
            goto L_0x0573
        L_0x0370:
            com.facebook.react.uimanager.g r8 = r6.f11244a
            ia.u0 r8 = (ia.u0) r8
            r8.setWidth((android.view.View) r7, (java.lang.Double) r5)
            goto L_0x0573
        L_0x0379:
            com.facebook.react.uimanager.g r8 = r6.f11244a
            ia.u0 r8 = (ia.u0) r8
            if (r9 != 0) goto L_0x0380
            goto L_0x0386
        L_0x0380:
            java.lang.Double r9 = (java.lang.Double) r9
            int r2 = r9.intValue()
        L_0x0386:
            r8.setVectorEffect(r7, r2)
            goto L_0x0573
        L_0x038b:
            com.facebook.react.uimanager.g r8 = r6.f11244a
            ia.u0 r8 = (ia.u0) r8
            if (r9 != 0) goto L_0x0392
            goto L_0x0395
        L_0x0392:
            r5 = r9
            java.lang.String r5 = (java.lang.String) r5
        L_0x0395:
            r8.setAlign(r7, r5)
            goto L_0x0573
        L_0x039a:
            com.facebook.react.uimanager.g r8 = r6.f11244a
            ia.u0 r8 = (ia.u0) r8
            if (r9 != 0) goto L_0x03a1
            goto L_0x03a7
        L_0x03a1:
            java.lang.Double r9 = (java.lang.Double) r9
            float r4 = r9.floatValue()
        L_0x03a7:
            r8.setStrokeMiterlimit(r7, r4)
            goto L_0x0573
        L_0x03ac:
            com.facebook.react.uimanager.g r8 = r6.f11244a
            ia.u0 r8 = (ia.u0) r8
            if (r9 != 0) goto L_0x03b3
            goto L_0x03b6
        L_0x03b3:
            r5 = r9
            java.lang.String r5 = (java.lang.String) r5
        L_0x03b6:
            r8.setName(r7, r5)
            goto L_0x0573
        L_0x03bb:
            com.facebook.react.uimanager.g r8 = r6.f11244a
            ia.u0 r8 = (ia.u0) r8
            if (r9 != 0) goto L_0x03c2
            goto L_0x03c8
        L_0x03c2:
            java.lang.Double r9 = (java.lang.Double) r9
            float r4 = r9.floatValue()
        L_0x03c8:
            r8.setMinY(r7, r4)
            goto L_0x0573
        L_0x03cd:
            com.facebook.react.uimanager.g r8 = r6.f11244a
            ia.u0 r8 = (ia.u0) r8
            if (r9 != 0) goto L_0x03d4
            goto L_0x03da
        L_0x03d4:
            java.lang.Double r9 = (java.lang.Double) r9
            float r4 = r9.floatValue()
        L_0x03da:
            r8.setMinX(r7, r4)
            goto L_0x0573
        L_0x03df:
            com.facebook.react.uimanager.g r8 = r6.f11244a
            ia.u0 r8 = (ia.u0) r8
            if (r9 != 0) goto L_0x03e6
            goto L_0x03e9
        L_0x03e6:
            r5 = r9
            java.lang.String r5 = (java.lang.String) r5
        L_0x03e9:
            r8.setMask(r7, r5)
            goto L_0x0573
        L_0x03ee:
            com.facebook.react.uimanager.g r8 = r6.f11244a
            ia.u0 r8 = (ia.u0) r8
            com.facebook.react.bridge.ReadableMap r9 = (com.facebook.react.bridge.ReadableMap) r9
            r8.setFont(r7, r9)
            goto L_0x0573
        L_0x03f9:
            com.facebook.react.uimanager.g r8 = r6.f11244a
            ia.u0 r8 = (ia.u0) r8
            com.facebook.react.bridge.ReadableMap r9 = (com.facebook.react.bridge.ReadableMap) r9
            r8.setFill(r7, r9)
            goto L_0x0573
        L_0x0404:
            boolean r8 = r9 instanceof java.lang.String
            if (r8 == 0) goto L_0x0413
            com.facebook.react.uimanager.g r8 = r6.f11244a
            ia.u0 r8 = (ia.u0) r8
            java.lang.String r9 = (java.lang.String) r9
            r8.setY((android.view.View) r7, (java.lang.String) r9)
            goto L_0x0573
        L_0x0413:
            boolean r8 = r9 instanceof java.lang.Double
            if (r8 == 0) goto L_0x0422
            com.facebook.react.uimanager.g r8 = r6.f11244a
            ia.u0 r8 = (ia.u0) r8
            java.lang.Double r9 = (java.lang.Double) r9
            r8.setY((android.view.View) r7, (java.lang.Double) r9)
            goto L_0x0573
        L_0x0422:
            com.facebook.react.uimanager.g r8 = r6.f11244a
            ia.u0 r8 = (ia.u0) r8
            r8.setY((android.view.View) r7, (java.lang.Double) r5)
            goto L_0x0573
        L_0x042b:
            boolean r8 = r9 instanceof java.lang.String
            if (r8 == 0) goto L_0x043a
            com.facebook.react.uimanager.g r8 = r6.f11244a
            ia.u0 r8 = (ia.u0) r8
            java.lang.String r9 = (java.lang.String) r9
            r8.setX((android.view.View) r7, (java.lang.String) r9)
            goto L_0x0573
        L_0x043a:
            boolean r8 = r9 instanceof java.lang.Double
            if (r8 == 0) goto L_0x0449
            com.facebook.react.uimanager.g r8 = r6.f11244a
            ia.u0 r8 = (ia.u0) r8
            java.lang.Double r9 = (java.lang.Double) r9
            r8.setX((android.view.View) r7, (java.lang.Double) r9)
            goto L_0x0573
        L_0x0449:
            com.facebook.react.uimanager.g r8 = r6.f11244a
            ia.u0 r8 = (ia.u0) r8
            r8.setX((android.view.View) r7, (java.lang.Double) r5)
            goto L_0x0573
        L_0x0452:
            com.facebook.react.uimanager.g r8 = r6.f11244a
            ia.u0 r8 = (ia.u0) r8
            if (r9 != 0) goto L_0x0459
            goto L_0x045f
        L_0x0459:
            java.lang.Double r9 = (java.lang.Double) r9
            float r4 = r9.floatValue()
        L_0x045f:
            r8.setStrokeDashoffset(r7, r4)
            goto L_0x0573
        L_0x0464:
            com.facebook.react.uimanager.g r8 = r6.f11244a
            ia.u0 r8 = (ia.u0) r8
            if (r9 != 0) goto L_0x046b
            goto L_0x0471
        L_0x046b:
            java.lang.Double r9 = (java.lang.Double) r9
            float r0 = r9.floatValue()
        L_0x0471:
            r8.setFillOpacity(r7, r0)
            goto L_0x0573
        L_0x0476:
            com.facebook.react.uimanager.g r8 = r6.f11244a
            ia.u0 r8 = (ia.u0) r8
            if (r9 != 0) goto L_0x047d
            goto L_0x0483
        L_0x047d:
            java.lang.Double r9 = (java.lang.Double) r9
            int r2 = r9.intValue()
        L_0x0483:
            r8.setPatternContentUnits(r7, r2)
            goto L_0x0573
        L_0x0488:
            com.facebook.react.uimanager.g r8 = r6.f11244a
            ia.u0 r8 = (ia.u0) r8
            if (r9 != 0) goto L_0x048f
            goto L_0x0495
        L_0x048f:
            java.lang.Double r9 = (java.lang.Double) r9
            int r2 = r9.intValue()
        L_0x0495:
            r8.setPatternUnits(r7, r2)
            goto L_0x0573
        L_0x049a:
            com.facebook.react.uimanager.g r8 = r6.f11244a
            ia.u0 r8 = (ia.u0) r8
            if (r9 != 0) goto L_0x04a1
            goto L_0x04a4
        L_0x04a1:
            r5 = r9
            java.lang.String r5 = (java.lang.String) r5
        L_0x04a4:
            r8.setPointerEvents(r7, r5)
            goto L_0x0573
        L_0x04a9:
            com.facebook.react.uimanager.g r8 = r6.f11244a
            ia.u0 r8 = (ia.u0) r8
            if (r9 != 0) goto L_0x04b0
            goto L_0x04b6
        L_0x04b0:
            java.lang.Double r9 = (java.lang.Double) r9
            float r0 = r9.floatValue()
        L_0x04b6:
            r8.setStrokeOpacity(r7, r0)
            goto L_0x0573
        L_0x04bb:
            com.facebook.react.uimanager.g r8 = r6.f11244a
            ia.u0 r8 = (ia.u0) r8
            if (r9 != 0) goto L_0x04c2
            goto L_0x04c8
        L_0x04c2:
            java.lang.Double r9 = (java.lang.Double) r9
            int r1 = r9.intValue()
        L_0x04c8:
            r8.setFillRule(r7, r1)
            goto L_0x0573
        L_0x04cd:
            boolean r8 = r9 instanceof java.lang.String
            if (r8 == 0) goto L_0x04dc
            com.facebook.react.uimanager.g r8 = r6.f11244a
            ia.u0 r8 = (ia.u0) r8
            java.lang.String r9 = (java.lang.String) r9
            r8.setFontWeight((android.view.View) r7, (java.lang.String) r9)
            goto L_0x0573
        L_0x04dc:
            boolean r8 = r9 instanceof java.lang.Double
            if (r8 == 0) goto L_0x04eb
            com.facebook.react.uimanager.g r8 = r6.f11244a
            ia.u0 r8 = (ia.u0) r8
            java.lang.Double r9 = (java.lang.Double) r9
            r8.setFontWeight((android.view.View) r7, (java.lang.Double) r9)
            goto L_0x0573
        L_0x04eb:
            com.facebook.react.uimanager.g r8 = r6.f11244a
            ia.u0 r8 = (ia.u0) r8
            r8.setFontWeight((android.view.View) r7, (java.lang.Double) r5)
            goto L_0x0573
        L_0x04f4:
            com.facebook.react.uimanager.g r8 = r6.f11244a
            ia.u0 r8 = (ia.u0) r8
            com.facebook.react.bridge.ReadableMap r9 = (com.facebook.react.bridge.ReadableMap) r9
            r8.setStroke(r7, r9)
            goto L_0x0573
        L_0x04ff:
            com.facebook.react.uimanager.g r8 = r6.f11244a
            ia.u0 r8 = (ia.u0) r8
            if (r9 != 0) goto L_0x0506
            goto L_0x0509
        L_0x0506:
            r5 = r9
            java.lang.String r5 = (java.lang.String) r5
        L_0x0509:
            r8.setMarkerMid(r7, r5)
            goto L_0x0573
        L_0x050e:
            com.facebook.react.uimanager.g r8 = r6.f11244a
            ia.u0 r8 = (ia.u0) r8
            if (r9 != 0) goto L_0x0515
            goto L_0x0518
        L_0x0515:
            r5 = r9
            java.lang.String r5 = (java.lang.String) r5
        L_0x0518:
            r8.setMarkerEnd(r7, r5)
            goto L_0x0573
        L_0x051c:
            com.facebook.react.uimanager.g r8 = r6.f11244a
            ia.u0 r8 = (ia.u0) r8
            com.facebook.react.bridge.ReadableArray r9 = (com.facebook.react.bridge.ReadableArray) r9
            r8.setPropList(r7, r9)
            goto L_0x0573
        L_0x0526:
            com.facebook.react.uimanager.g r8 = r6.f11244a
            ia.u0 r8 = (ia.u0) r8
            com.facebook.react.bridge.ReadableArray r9 = (com.facebook.react.bridge.ReadableArray) r9
            r8.setMatrix(r7, r9)
            goto L_0x0573
        L_0x0530:
            boolean r8 = r9 instanceof java.lang.String
            if (r8 == 0) goto L_0x053e
            com.facebook.react.uimanager.g r8 = r6.f11244a
            ia.u0 r8 = (ia.u0) r8
            java.lang.String r9 = (java.lang.String) r9
            r8.setHeight((android.view.View) r7, (java.lang.String) r9)
            goto L_0x0573
        L_0x053e:
            boolean r8 = r9 instanceof java.lang.Double
            if (r8 == 0) goto L_0x054c
            com.facebook.react.uimanager.g r8 = r6.f11244a
            ia.u0 r8 = (ia.u0) r8
            java.lang.Double r9 = (java.lang.Double) r9
            r8.setHeight((android.view.View) r7, (java.lang.Double) r9)
            goto L_0x0573
        L_0x054c:
            com.facebook.react.uimanager.g r8 = r6.f11244a
            ia.u0 r8 = (ia.u0) r8
            r8.setHeight((android.view.View) r7, (java.lang.Double) r5)
            goto L_0x0573
        L_0x0554:
            com.facebook.react.uimanager.g r8 = r6.f11244a
            if (r9 != 0) goto L_0x0559
            goto L_0x055f
        L_0x0559:
            java.lang.Double r9 = (java.lang.Double) r9
            float r0 = r9.floatValue()
        L_0x055f:
            r8.setOpacity(r7, r0)
            goto L_0x0573
        L_0x0563:
            com.facebook.react.uimanager.g r8 = r6.f11244a
            ia.u0 r8 = (ia.u0) r8
            if (r9 != 0) goto L_0x056a
            goto L_0x0570
        L_0x056a:
            java.lang.Double r9 = (java.lang.Double) r9
            float r4 = r9.floatValue()
        L_0x0570:
            r8.setVbHeight(r7, r4)
        L_0x0573:
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: ia.t0.b(android.view.View, java.lang.String, java.lang.Object):void");
    }
}
