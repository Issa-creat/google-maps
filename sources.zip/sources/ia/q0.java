package ia;

import android.view.View;
import com.facebook.react.bridge.ReadableArray;
import com.facebook.react.bridge.ReadableMap;

public interface q0 {
    void setClipPath(View view, String str);

    void setClipRule(View view, int i10);

    void setDisplay(View view, String str);

    void setFill(View view, ReadableMap readableMap);

    void setFillOpacity(View view, float f10);

    void setFillRule(View view, int i10);

    void setFont(View view, ReadableMap readableMap);

    void setFontSize(View view, Double d10);

    void setFontSize(View view, String str);

    void setFontWeight(View view, Double d10);

    void setFontWeight(View view, String str);

    void setHeight(View view, Double d10);

    void setHeight(View view, String str);

    void setMarkerEnd(View view, String str);

    void setMarkerMid(View view, String str);

    void setMarkerStart(View view, String str);

    void setMask(View view, String str);

    void setMaskContentUnits(View view, int i10);

    void setMaskUnits(View view, int i10);

    void setMatrix(View view, ReadableArray readableArray);

    void setName(View view, String str);

    void setPointerEvents(View view, String str);

    void setPropList(View view, ReadableArray readableArray);

    void setResponsible(View view, boolean z10);

    void setStroke(View view, ReadableMap readableMap);

    void setStrokeDasharray(View view, ReadableArray readableArray);

    void setStrokeDasharray(View view, String str);

    void setStrokeDashoffset(View view, float f10);

    void setStrokeLinecap(View view, int i10);

    void setStrokeLinejoin(View view, int i10);

    void setStrokeMiterlimit(View view, float f10);

    void setStrokeOpacity(View view, float f10);

    void setStrokeWidth(View view, Double d10);

    void setStrokeWidth(View view, String str);

    void setVectorEffect(View view, int i10);

    void setWidth(View view, Double d10);

    void setWidth(View view, String str);

    void setX(View view, Double d10);

    void setX(View view, String str);

    void setY(View view, Double d10);

    void setY(View view, String str);
}
