package ia;

import android.view.View;
import com.facebook.react.bridge.ReadableArray;

public interface a0 {
    void setClipPath(View view, String str);

    void setClipRule(View view, int i10);

    void setDisplay(View view, String str);

    void setMarkerEnd(View view, String str);

    void setMarkerMid(View view, String str);

    void setMarkerStart(View view, String str);

    void setMask(View view, String str);

    void setMatrix(View view, ReadableArray readableArray);

    void setName(View view, String str);

    void setPointerEvents(View view, String str);

    void setResponsible(View view, boolean z10);
}
