package z0;

import y0.r0;

public interface c {
    long a(long j10);

    r0 b(r0 r0Var);

    long c();

    boolean d(boolean z10);

    b[] e();
}
