package z0;

import com.google.common.collect.y;
import java.nio.ByteBuffer;
import java.util.ArrayList;
import java.util.List;
import z0.b;

public final class a {

    /* renamed from: a  reason: collision with root package name */
    private final y f20394a;

    /* renamed from: b  reason: collision with root package name */
    private final List f20395b = new ArrayList();

    /* renamed from: c  reason: collision with root package name */
    private ByteBuffer[] f20396c = new ByteBuffer[0];

    /* renamed from: d  reason: collision with root package name */
    private b.a f20397d;

    /* renamed from: e  reason: collision with root package name */
    private b.a f20398e;

    /* renamed from: f  reason: collision with root package name */
    private boolean f20399f;

    public a(y yVar) {
        this.f20394a = yVar;
        b.a aVar = b.a.f20401e;
        this.f20397d = aVar;
        this.f20398e = aVar;
        this.f20399f = false;
    }

    private int c() {
        return this.f20396c.length - 1;
    }

    private void g(ByteBuffer byteBuffer) {
        boolean z10;
        ByteBuffer byteBuffer2;
        boolean z11;
        for (boolean z12 = true; z12; z12 = z10) {
            z10 = false;
            for (int i10 = 0; i10 <= c(); i10++) {
                if (!this.f20396c[i10].hasRemaining()) {
                    b bVar = (b) this.f20395b.get(i10);
                    if (!bVar.d()) {
                        if (i10 > 0) {
                            byteBuffer2 = this.f20396c[i10 - 1];
                        } else if (byteBuffer.hasRemaining()) {
                            byteBuffer2 = byteBuffer;
                        } else {
                            byteBuffer2 = b.f20400a;
                        }
                        bVar.e(byteBuffer2);
                        this.f20396c[i10] = bVar.b();
                        if (((long) byteBuffer2.remaining()) - ((long) byteBuffer2.remaining()) > 0 || this.f20396c[i10].hasRemaining()) {
                            z11 = true;
                        } else {
                            z11 = false;
                        }
                        z10 |= z11;
                    } else if (!this.f20396c[i10].hasRemaining() && i10 < c()) {
                        ((b) this.f20395b.get(i10 + 1)).f();
                    }
                }
            }
        }
    }

    public b.a a(b.a aVar) {
        if (!aVar.equals(b.a.f20401e)) {
            for (int i10 = 0; i10 < this.f20394a.size(); i10++) {
                b bVar = (b) this.f20394a.get(i10);
                b.a c10 = bVar.c(aVar);
                if (bVar.a()) {
                    androidx.media3.common.util.a.g(!c10.equals(b.a.f20401e));
                    aVar = c10;
                }
            }
            this.f20398e = aVar;
            return aVar;
        }
        throw new b.C0304b(aVar);
    }

    public void b() {
        this.f20395b.clear();
        this.f20397d = this.f20398e;
        this.f20399f = false;
        for (int i10 = 0; i10 < this.f20394a.size(); i10++) {
            b bVar = (b) this.f20394a.get(i10);
            bVar.flush();
            if (bVar.a()) {
                this.f20395b.add(bVar);
            }
        }
        this.f20396c = new ByteBuffer[this.f20395b.size()];
        for (int i11 = 0; i11 <= c(); i11++) {
            this.f20396c[i11] = ((b) this.f20395b.get(i11)).b();
        }
    }

    public ByteBuffer d() {
        if (!f()) {
            return b.f20400a;
        }
        ByteBuffer byteBuffer = this.f20396c[c()];
        if (byteBuffer.hasRemaining()) {
            return byteBuffer;
        }
        g(b.f20400a);
        return this.f20396c[c()];
    }

    public boolean e() {
        if (!this.f20399f || !((b) this.f20395b.get(c())).d() || this.f20396c[c()].hasRemaining()) {
            return false;
        }
        return true;
    }

    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (!(obj instanceof a)) {
            return false;
        }
        a aVar = (a) obj;
        if (this.f20394a.size() != aVar.f20394a.size()) {
            return false;
        }
        for (int i10 = 0; i10 < this.f20394a.size(); i10++) {
            if (this.f20394a.get(i10) != aVar.f20394a.get(i10)) {
                return false;
            }
        }
        return true;
    }

    public boolean f() {
        return !this.f20395b.isEmpty();
    }

    public void h() {
        if (f() && !this.f20399f) {
            this.f20399f = true;
            ((b) this.f20395b.get(0)).f();
        }
    }

    public int hashCode() {
        return this.f20394a.hashCode();
    }

    public void i(ByteBuffer byteBuffer) {
        if (f() && !this.f20399f) {
            g(byteBuffer);
        }
    }

    public void j() {
        for (int i10 = 0; i10 < this.f20394a.size(); i10++) {
            b bVar = (b) this.f20394a.get(i10);
            bVar.flush();
            bVar.reset();
        }
        this.f20396c = new ByteBuffer[0];
        b.a aVar = b.a.f20401e;
        this.f20397d = aVar;
        this.f20398e = aVar;
        this.f20399f = false;
    }
}
