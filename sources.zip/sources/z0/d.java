package z0;

import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import z0.b;

public abstract class d implements b {

    /* renamed from: b  reason: collision with root package name */
    protected b.a f20407b;

    /* renamed from: c  reason: collision with root package name */
    protected b.a f20408c;

    /* renamed from: d  reason: collision with root package name */
    private b.a f20409d;

    /* renamed from: e  reason: collision with root package name */
    private b.a f20410e;

    /* renamed from: f  reason: collision with root package name */
    private ByteBuffer f20411f;

    /* renamed from: g  reason: collision with root package name */
    private ByteBuffer f20412g;

    /* renamed from: h  reason: collision with root package name */
    private boolean f20413h;

    public d() {
        ByteBuffer byteBuffer = b.f20400a;
        this.f20411f = byteBuffer;
        this.f20412g = byteBuffer;
        b.a aVar = b.a.f20401e;
        this.f20409d = aVar;
        this.f20410e = aVar;
        this.f20407b = aVar;
        this.f20408c = aVar;
    }

    public boolean a() {
        if (this.f20410e != b.a.f20401e) {
            return true;
        }
        return false;
    }

    public ByteBuffer b() {
        ByteBuffer byteBuffer = this.f20412g;
        this.f20412g = b.f20400a;
        return byteBuffer;
    }

    public final b.a c(b.a aVar) {
        this.f20409d = aVar;
        this.f20410e = h(aVar);
        if (a()) {
            return this.f20410e;
        }
        return b.a.f20401e;
    }

    public boolean d() {
        if (!this.f20413h || this.f20412g != b.f20400a) {
            return false;
        }
        return true;
    }

    public final void f() {
        this.f20413h = true;
        j();
    }

    public final void flush() {
        this.f20412g = b.f20400a;
        this.f20413h = false;
        this.f20407b = this.f20409d;
        this.f20408c = this.f20410e;
        i();
    }

    /* access modifiers changed from: protected */
    public final boolean g() {
        return this.f20412g.hasRemaining();
    }

    /* access modifiers changed from: protected */
    public abstract b.a h(b.a aVar);

    /* access modifiers changed from: protected */
    public void i() {
    }

    /* access modifiers changed from: protected */
    public void j() {
    }

    /* access modifiers changed from: protected */
    public void k() {
    }

    /* access modifiers changed from: protected */
    public final ByteBuffer l(int i10) {
        if (this.f20411f.capacity() < i10) {
            this.f20411f = ByteBuffer.allocateDirect(i10).order(ByteOrder.nativeOrder());
        } else {
            this.f20411f.clear();
        }
        ByteBuffer byteBuffer = this.f20411f;
        this.f20412g = byteBuffer;
        return byteBuffer;
    }

    public final void reset() {
        flush();
        this.f20411f = b.f20400a;
        b.a aVar = b.a.f20401e;
        this.f20409d = aVar;
        this.f20410e = aVar;
        this.f20407b = aVar;
        this.f20408c = aVar;
        k();
    }
}
