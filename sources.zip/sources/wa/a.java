package wa;

import android.animation.ObjectAnimator;
import android.animation.ValueAnimator;
import wa.b;

public class a {

    /* renamed from: a  reason: collision with root package name */
    private ValueAnimator.AnimatorUpdateListener f19041a;

    /* renamed from: b  reason: collision with root package name */
    protected float f19042b = 1.0f;

    /* renamed from: c  reason: collision with root package name */
    protected float f19043c = 1.0f;

    public a(ValueAnimator.AnimatorUpdateListener animatorUpdateListener) {
        this.f19041a = animatorUpdateListener;
    }

    private ObjectAnimator f(int i10, b.c0 c0Var) {
        ObjectAnimator ofFloat = ObjectAnimator.ofFloat(this, "phaseX", new float[]{0.0f, 1.0f});
        ofFloat.setInterpolator(c0Var);
        ofFloat.setDuration((long) i10);
        return ofFloat;
    }

    private ObjectAnimator g(int i10, b.c0 c0Var) {
        ObjectAnimator ofFloat = ObjectAnimator.ofFloat(this, "phaseY", new float[]{0.0f, 1.0f});
        ofFloat.setInterpolator(c0Var);
        ofFloat.setDuration((long) i10);
        return ofFloat;
    }

    public void a(int i10, b.c0 c0Var) {
        ObjectAnimator f10 = f(i10, c0Var);
        f10.addUpdateListener(this.f19041a);
        f10.start();
    }

    public void b(int i10, int i11, b.c0 c0Var, b.c0 c0Var2) {
        ObjectAnimator f10 = f(i10, c0Var);
        ObjectAnimator g10 = g(i11, c0Var2);
        if (i10 > i11) {
            f10.addUpdateListener(this.f19041a);
        } else {
            g10.addUpdateListener(this.f19041a);
        }
        f10.start();
        g10.start();
    }

    public void c(int i10, b.c0 c0Var) {
        ObjectAnimator g10 = g(i10, c0Var);
        g10.addUpdateListener(this.f19041a);
        g10.start();
    }

    public float d() {
        return this.f19043c;
    }

    public float e() {
        return this.f19042b;
    }
}
