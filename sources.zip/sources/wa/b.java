package wa;

import android.animation.TimeInterpolator;

public abstract class b {
    public static final c0 A = new s();
    public static final c0 B = new t();

    /* renamed from: a  reason: collision with root package name */
    public static final c0 f19044a = new k();

    /* renamed from: b  reason: collision with root package name */
    public static final c0 f19045b = new u();

    /* renamed from: c  reason: collision with root package name */
    public static final c0 f19046c = new v();

    /* renamed from: d  reason: collision with root package name */
    public static final c0 f19047d = new w();

    /* renamed from: e  reason: collision with root package name */
    public static final c0 f19048e = new x();

    /* renamed from: f  reason: collision with root package name */
    public static final c0 f19049f = new y();

    /* renamed from: g  reason: collision with root package name */
    public static final c0 f19050g = new z();

    /* renamed from: h  reason: collision with root package name */
    public static final c0 f19051h = new a0();

    /* renamed from: i  reason: collision with root package name */
    public static final c0 f19052i = new b0();

    /* renamed from: j  reason: collision with root package name */
    public static final c0 f19053j = new a();

    /* renamed from: k  reason: collision with root package name */
    public static final c0 f19054k = new C0288b();

    /* renamed from: l  reason: collision with root package name */
    public static final c0 f19055l = new c();

    /* renamed from: m  reason: collision with root package name */
    public static final c0 f19056m = new d();

    /* renamed from: n  reason: collision with root package name */
    public static final c0 f19057n = new e();

    /* renamed from: o  reason: collision with root package name */
    public static final c0 f19058o = new f();

    /* renamed from: p  reason: collision with root package name */
    public static final c0 f19059p = new g();

    /* renamed from: q  reason: collision with root package name */
    public static final c0 f19060q = new h();

    /* renamed from: r  reason: collision with root package name */
    public static final c0 f19061r = new i();

    /* renamed from: s  reason: collision with root package name */
    public static final c0 f19062s = new j();

    /* renamed from: t  reason: collision with root package name */
    public static final c0 f19063t = new l();

    /* renamed from: u  reason: collision with root package name */
    public static final c0 f19064u = new m();

    /* renamed from: v  reason: collision with root package name */
    public static final c0 f19065v = new n();

    /* renamed from: w  reason: collision with root package name */
    public static final c0 f19066w = new o();

    /* renamed from: x  reason: collision with root package name */
    public static final c0 f19067x = new p();

    /* renamed from: y  reason: collision with root package name */
    public static final c0 f19068y = new q();

    /* renamed from: z  reason: collision with root package name */
    public static final c0 f19069z = new r();

    static class a implements c0 {
        a() {
        }

        public float getInterpolation(float f10) {
            float pow;
            float f11;
            float f12 = f10 * 2.0f;
            if (f12 < 1.0f) {
                pow = (float) Math.pow((double) f12, 4.0d);
                f11 = 0.5f;
            } else {
                pow = ((float) Math.pow((double) (f12 - 2.0f), 4.0d)) - 2.0f;
                f11 = -0.5f;
            }
            return pow * f11;
        }
    }

    static class a0 implements c0 {
        a0() {
        }

        public float getInterpolation(float f10) {
            return (float) Math.pow((double) f10, 4.0d);
        }
    }

    /* renamed from: wa.b$b  reason: collision with other inner class name */
    static class C0288b implements c0 {
        C0288b() {
        }

        public float getInterpolation(float f10) {
            return (-((float) Math.cos(((double) f10) * 1.5707963267948966d))) + 1.0f;
        }
    }

    static class b0 implements c0 {
        b0() {
        }

        public float getInterpolation(float f10) {
            return -(((float) Math.pow((double) (f10 - 1.0f), 4.0d)) - 1.0f);
        }
    }

    static class c implements c0 {
        c() {
        }

        public float getInterpolation(float f10) {
            return (float) Math.sin(((double) f10) * 1.5707963267948966d);
        }
    }

    public interface c0 extends TimeInterpolator {
        float getInterpolation(float f10);
    }

    static class d implements c0 {
        d() {
        }

        public float getInterpolation(float f10) {
            return (((float) Math.cos(((double) f10) * 3.141592653589793d)) - 1.0f) * -0.5f;
        }
    }

    static class e implements c0 {
        e() {
        }

        public float getInterpolation(float f10) {
            if (f10 == 0.0f) {
                return 0.0f;
            }
            return (float) Math.pow(2.0d, (double) ((f10 - 1.0f) * 10.0f));
        }
    }

    static class f implements c0 {
        f() {
        }

        public float getInterpolation(float f10) {
            if (f10 == 1.0f) {
                return 1.0f;
            }
            return -((float) Math.pow(2.0d, (double) ((f10 + 1.0f) * -10.0f)));
        }
    }

    static class g implements c0 {
        g() {
        }

        public float getInterpolation(float f10) {
            float f11;
            if (f10 == 0.0f) {
                return 0.0f;
            }
            if (f10 == 1.0f) {
                return 1.0f;
            }
            float f12 = f10 * 2.0f;
            if (f12 < 1.0f) {
                f11 = (float) Math.pow(2.0d, (double) ((f12 - 1.0f) * 10.0f));
            } else {
                f11 = (-((float) Math.pow(2.0d, (double) ((f12 - 1.0f) * -10.0f)))) + 2.0f;
            }
            return f11 * 0.5f;
        }
    }

    static class h implements c0 {
        h() {
        }

        public float getInterpolation(float f10) {
            return -(((float) Math.sqrt((double) (1.0f - (f10 * f10)))) - 1.0f);
        }
    }

    static class i implements c0 {
        i() {
        }

        public float getInterpolation(float f10) {
            float f11 = f10 - 1.0f;
            return (float) Math.sqrt((double) (1.0f - (f11 * f11)));
        }
    }

    static class j implements c0 {
        j() {
        }

        public float getInterpolation(float f10) {
            float sqrt;
            float f11;
            float f12 = f10 * 2.0f;
            if (f12 < 1.0f) {
                sqrt = ((float) Math.sqrt((double) (1.0f - (f12 * f12)))) - 1.0f;
                f11 = -0.5f;
            } else {
                float f13 = f12 - 2.0f;
                sqrt = ((float) Math.sqrt((double) (1.0f - (f13 * f13)))) + 1.0f;
                f11 = 0.5f;
            }
            return sqrt * f11;
        }
    }

    static class k implements c0 {
        k() {
        }

        public float getInterpolation(float f10) {
            return f10;
        }
    }

    static class l implements c0 {
        l() {
        }

        public float getInterpolation(float f10) {
            if (f10 == 0.0f) {
                return 0.0f;
            }
            if (f10 == 1.0f) {
                return 1.0f;
            }
            float f11 = f10 - 1.0f;
            return -(((float) Math.pow(2.0d, (double) (10.0f * f11))) * ((float) Math.sin((double) (((f11 - (0.047746483f * ((float) Math.asin(1.0d)))) * 6.2831855f) / 0.3f))));
        }
    }

    static class m implements c0 {
        m() {
        }

        public float getInterpolation(float f10) {
            if (f10 == 0.0f) {
                return 0.0f;
            }
            if (f10 == 1.0f) {
                return 1.0f;
            }
            return (((float) Math.pow(2.0d, (double) (-10.0f * f10))) * ((float) Math.sin((double) (((f10 - (0.047746483f * ((float) Math.asin(1.0d)))) * 6.2831855f) / 0.3f)))) + 1.0f;
        }
    }

    static class n implements c0 {
        n() {
        }

        public float getInterpolation(float f10) {
            if (f10 == 0.0f) {
                return 0.0f;
            }
            float f11 = f10 * 2.0f;
            if (f11 == 2.0f) {
                return 1.0f;
            }
            float asin = ((float) Math.asin(1.0d)) * 0.07161972f;
            if (f11 < 1.0f) {
                float f12 = f11 - 1.0f;
                return ((float) Math.pow(2.0d, (double) (10.0f * f12))) * ((float) Math.sin((double) (((f12 * 1.0f) - asin) * 6.2831855f * 2.2222223f))) * -0.5f;
            }
            float f13 = f11 - 1.0f;
            return (((float) Math.pow(2.0d, (double) (-10.0f * f13))) * 0.5f * ((float) Math.sin((double) (((f13 * 1.0f) - asin) * 6.2831855f * 2.2222223f)))) + 1.0f;
        }
    }

    static class o implements c0 {
        o() {
        }

        public float getInterpolation(float f10) {
            return f10 * f10 * ((f10 * 2.70158f) - 1.70158f);
        }
    }

    static class p implements c0 {
        p() {
        }

        public float getInterpolation(float f10) {
            float f11 = f10 - 1.0f;
            return (f11 * f11 * ((f11 * 2.70158f) + 1.70158f)) + 1.0f;
        }
    }

    static class q implements c0 {
        q() {
        }

        public float getInterpolation(float f10) {
            float f11 = f10 * 2.0f;
            if (f11 < 1.0f) {
                return f11 * f11 * ((3.5949094f * f11) - 2.5949094f) * 0.5f;
            }
            float f12 = f11 - 2.0f;
            return ((f12 * f12 * ((3.5949094f * f12) + 2.5949094f)) + 2.0f) * 0.5f;
        }
    }

    static class r implements c0 {
        r() {
        }

        public float getInterpolation(float f10) {
            return 1.0f - b.A.getInterpolation(1.0f - f10);
        }
    }

    static class s implements c0 {
        s() {
        }

        public float getInterpolation(float f10) {
            if (f10 < 0.36363637f) {
                return 7.5625f * f10 * f10;
            }
            if (f10 < 0.72727275f) {
                float f11 = f10 - 0.54545456f;
                return (7.5625f * f11 * f11) + 0.75f;
            } else if (f10 < 0.90909094f) {
                float f12 = f10 - 0.8181818f;
                return (7.5625f * f12 * f12) + 0.9375f;
            } else {
                float f13 = f10 - 0.95454544f;
                return (7.5625f * f13 * f13) + 0.984375f;
            }
        }
    }

    static class t implements c0 {
        t() {
        }

        public float getInterpolation(float f10) {
            if (f10 < 0.5f) {
                return b.f19069z.getInterpolation(f10 * 2.0f) * 0.5f;
            }
            return (b.A.getInterpolation((f10 * 2.0f) - 1.0f) * 0.5f) + 0.5f;
        }
    }

    static class u implements c0 {
        u() {
        }

        public float getInterpolation(float f10) {
            return f10 * f10;
        }
    }

    static class v implements c0 {
        v() {
        }

        public float getInterpolation(float f10) {
            return (-f10) * (f10 - 2.0f);
        }
    }

    static class w implements c0 {
        w() {
        }

        public float getInterpolation(float f10) {
            float f11 = f10 * 2.0f;
            if (f11 < 1.0f) {
                return 0.5f * f11 * f11;
            }
            float f12 = f11 - 1.0f;
            return ((f12 * (f12 - 2.0f)) - 1.0f) * -0.5f;
        }
    }

    static class x implements c0 {
        x() {
        }

        public float getInterpolation(float f10) {
            return (float) Math.pow((double) f10, 3.0d);
        }
    }

    static class y implements c0 {
        y() {
        }

        public float getInterpolation(float f10) {
            return ((float) Math.pow((double) (f10 - 1.0f), 3.0d)) + 1.0f;
        }
    }

    static class z implements c0 {
        z() {
        }

        public float getInterpolation(float f10) {
            float pow;
            float f11 = f10 * 2.0f;
            if (f11 < 1.0f) {
                pow = (float) Math.pow((double) f11, 3.0d);
            } else {
                pow = ((float) Math.pow((double) (f11 - 2.0f), 3.0d)) + 2.0f;
            }
            return pow * 0.5f;
        }
    }
}
