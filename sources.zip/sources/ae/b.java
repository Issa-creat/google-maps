package ae;

import android.graphics.drawable.Drawable;

public interface b {
    void a(int i10, int i11, int i12, int i13);

    void c(Drawable drawable);

    boolean d();
}
