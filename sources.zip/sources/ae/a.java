package ae;

import android.graphics.Canvas;
import android.graphics.LinearGradient;
import android.graphics.Matrix;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RadialGradient;
import android.graphics.RectF;
import android.graphics.Region;
import android.graphics.Shader;

public class a {

    /* renamed from: i  reason: collision with root package name */
    private static final int[] f21017i = new int[3];

    /* renamed from: j  reason: collision with root package name */
    private static final float[] f21018j = {0.0f, 0.5f, 1.0f};

    /* renamed from: k  reason: collision with root package name */
    private static final int[] f21019k = new int[4];

    /* renamed from: l  reason: collision with root package name */
    private static final float[] f21020l = {0.0f, 0.0f, 0.5f, 1.0f};

    /* renamed from: a  reason: collision with root package name */
    private final Paint f21021a;

    /* renamed from: b  reason: collision with root package name */
    private final Paint f21022b;

    /* renamed from: c  reason: collision with root package name */
    private final Paint f21023c;

    /* renamed from: d  reason: collision with root package name */
    private int f21024d;

    /* renamed from: e  reason: collision with root package name */
    private int f21025e;

    /* renamed from: f  reason: collision with root package name */
    private int f21026f;

    /* renamed from: g  reason: collision with root package name */
    private final Path f21027g;

    /* renamed from: h  reason: collision with root package name */
    private final Paint f21028h;

    public a() {
        this(-16777216);
    }

    public void a(Canvas canvas, Matrix matrix, RectF rectF, int i10, float f10, float f11) {
        boolean z10;
        Canvas canvas2 = canvas;
        RectF rectF2 = rectF;
        int i11 = i10;
        float f12 = f11;
        if (f12 < 0.0f) {
            z10 = true;
        } else {
            z10 = false;
        }
        Path path = this.f21027g;
        if (z10) {
            int[] iArr = f21019k;
            iArr[0] = 0;
            iArr[1] = this.f21026f;
            iArr[2] = this.f21025e;
            iArr[3] = this.f21024d;
            float f13 = f10;
        } else {
            path.rewind();
            path.moveTo(rectF.centerX(), rectF.centerY());
            path.arcTo(rectF2, f10, f12);
            path.close();
            float f14 = (float) (-i11);
            rectF2.inset(f14, f14);
            int[] iArr2 = f21019k;
            iArr2[0] = 0;
            iArr2[1] = this.f21024d;
            iArr2[2] = this.f21025e;
            iArr2[3] = this.f21026f;
        }
        float width = rectF.width() / 2.0f;
        if (width > 0.0f) {
            float f15 = 1.0f - (((float) i11) / width);
            float[] fArr = f21020l;
            fArr[1] = f15;
            fArr[2] = ((1.0f - f15) / 2.0f) + f15;
            this.f21022b.setShader(new RadialGradient(rectF.centerX(), rectF.centerY(), width, f21019k, fArr, Shader.TileMode.CLAMP));
            canvas.save();
            canvas.concat(matrix);
            canvas2.scale(1.0f, rectF.height() / rectF.width());
            if (!z10) {
                canvas2.clipPath(path, Region.Op.DIFFERENCE);
                canvas2.drawPath(path, this.f21028h);
            }
            canvas.drawArc(rectF, f10, f11, true, this.f21022b);
            canvas.restore();
        }
    }

    public void b(Canvas canvas, Matrix matrix, RectF rectF, int i10) {
        rectF.bottom += (float) i10;
        rectF.offset(0.0f, (float) (-i10));
        int[] iArr = f21017i;
        iArr[0] = this.f21026f;
        iArr[1] = this.f21025e;
        iArr[2] = this.f21024d;
        Paint paint = this.f21023c;
        float f10 = rectF.left;
        paint.setShader(new LinearGradient(f10, rectF.top, f10, rectF.bottom, iArr, f21018j, Shader.TileMode.CLAMP));
        canvas.save();
        canvas.concat(matrix);
        canvas.drawRect(rectF, this.f21023c);
        canvas.restore();
    }

    public Paint c() {
        return this.f21021a;
    }

    public void d(int i10) {
        this.f21024d = androidx.core.graphics.a.k(i10, 68);
        this.f21025e = androidx.core.graphics.a.k(i10, 20);
        this.f21026f = androidx.core.graphics.a.k(i10, 0);
        this.f21021a.setColor(this.f21024d);
    }

    public a(int i10) {
        this.f21027g = new Path();
        Paint paint = new Paint();
        this.f21028h = paint;
        this.f21021a = new Paint();
        d(i10);
        paint.setColor(0);
        Paint paint2 = new Paint(4);
        this.f21022b = paint2;
        paint2.setStyle(Paint.Style.FILL);
        this.f21023c = new Paint(paint2);
    }
}
