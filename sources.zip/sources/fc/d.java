package fc;

import android.content.Context;
import android.os.Looper;
import com.google.android.gms.common.api.a;
import com.google.android.gms.common.api.e;
import fc.a;
import vc.f;

final class d extends a.C0319a {
    d() {
    }

    public final /* synthetic */ a.f a(Context context, Looper looper, com.google.android.gms.common.internal.d dVar, Object obj, e.a aVar, e.b bVar) {
        return new f(context, looper, dVar, (a.C0369a) obj, aVar, bVar);
    }
}
