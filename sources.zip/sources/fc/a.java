package fc;

import android.os.Bundle;
import com.google.android.gms.auth.api.signin.internal.h;
import com.google.android.gms.common.api.a;
import com.google.android.gms.common.internal.n;
import vc.e;

public abstract class a {

    /* renamed from: a  reason: collision with root package name */
    public static final com.google.android.gms.common.api.a f40625a = b.f40641a;

    /* renamed from: b  reason: collision with root package name */
    public static final com.google.android.gms.common.api.a f40626b;

    /* renamed from: c  reason: collision with root package name */
    public static final com.google.android.gms.common.api.a f40627c;

    /* renamed from: d  reason: collision with root package name */
    public static final hc.a f40628d = b.f40642b;

    /* renamed from: e  reason: collision with root package name */
    public static final gc.a f40629e = new e();

    /* renamed from: f  reason: collision with root package name */
    public static final ic.a f40630f = new h();

    /* renamed from: g  reason: collision with root package name */
    public static final a.g f40631g;

    /* renamed from: h  reason: collision with root package name */
    public static final a.g f40632h;

    /* renamed from: i  reason: collision with root package name */
    private static final a.C0319a f40633i;

    /* renamed from: j  reason: collision with root package name */
    private static final a.C0319a f40634j;

    /* renamed from: fc.a$a  reason: collision with other inner class name */
    public static class C0369a implements a.d {

        /* renamed from: y  reason: collision with root package name */
        public static final C0369a f40635y = new C0369a(new C0370a());
        /* access modifiers changed from: private */

        /* renamed from: a  reason: collision with root package name */
        public final String f40636a = null;
        /* access modifiers changed from: private */

        /* renamed from: w  reason: collision with root package name */
        public final boolean f40637w;
        /* access modifiers changed from: private */

        /* renamed from: x  reason: collision with root package name */
        public final String f40638x;

        /* renamed from: fc.a$a$a  reason: collision with other inner class name */
        public static class C0370a {

            /* renamed from: a  reason: collision with root package name */
            protected Boolean f40639a = Boolean.FALSE;

            /* renamed from: b  reason: collision with root package name */
            protected String f40640b;

            public C0370a() {
            }

            public final C0370a a(String str) {
                this.f40640b = str;
                return this;
            }

            public C0370a(C0369a aVar) {
                String unused = aVar.f40636a;
                this.f40639a = Boolean.valueOf(aVar.f40637w);
                this.f40640b = aVar.f40638x;
            }
        }

        public C0369a(C0370a aVar) {
            this.f40637w = aVar.f40639a.booleanValue();
            this.f40638x = aVar.f40640b;
        }

        public final Bundle a() {
            Bundle bundle = new Bundle();
            bundle.putString("consumer_package", (String) null);
            bundle.putBoolean("force_save_dialog", this.f40637w);
            bundle.putString("log_session_id", this.f40638x);
            return bundle;
        }

        public boolean equals(Object obj) {
            if (obj == this) {
                return true;
            }
            if (!(obj instanceof C0369a)) {
                return false;
            }
            C0369a aVar = (C0369a) obj;
            String str = aVar.f40636a;
            if (!n.a((Object) null, (Object) null) || this.f40637w != aVar.f40637w || !n.a(this.f40638x, aVar.f40638x)) {
                return false;
            }
            return true;
        }

        public int hashCode() {
            return n.b(null, Boolean.valueOf(this.f40637w), this.f40638x);
        }
    }

    static {
        a.g gVar = new a.g();
        f40631g = gVar;
        a.g gVar2 = new a.g();
        f40632h = gVar2;
        d dVar = new d();
        f40633i = dVar;
        e eVar = new e();
        f40634j = eVar;
        f40626b = new com.google.android.gms.common.api.a("Auth.CREDENTIALS_API", dVar, gVar);
        f40627c = new com.google.android.gms.common.api.a("Auth.GOOGLE_SIGN_IN_API", eVar, gVar2);
    }
}
