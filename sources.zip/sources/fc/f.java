package fc;

import android.content.Context;
import android.os.Looper;
import com.google.android.gms.common.api.a;
import com.google.android.gms.common.api.internal.e;
import com.google.android.gms.common.api.internal.l;
import com.google.android.gms.common.internal.d;

final class f extends a.C0319a {
    f() {
    }

    public final /* synthetic */ a.f b(Context context, Looper looper, d dVar, Object obj, e eVar, l lVar) {
        android.support.v4.media.a.a(obj);
        return new com.google.android.gms.internal.auth.d(context, looper, dVar, (c) null, eVar, lVar);
    }
}
