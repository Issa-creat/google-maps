package fc;

import com.google.android.gms.common.api.a;
import com.google.android.gms.internal.auth.f;

public abstract class b {

    /* renamed from: a  reason: collision with root package name */
    public static final a f40641a;

    /* renamed from: b  reason: collision with root package name */
    public static final hc.a f40642b = new f();

    /* renamed from: c  reason: collision with root package name */
    public static final a.g f40643c;

    /* renamed from: d  reason: collision with root package name */
    private static final a.C0319a f40644d;

    static {
        a.g gVar = new a.g();
        f40643c = gVar;
        f fVar = new f();
        f40644d = fVar;
        f40641a = new a("Auth.PROXY_API", fVar, gVar);
    }
}
