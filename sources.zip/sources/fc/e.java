package fc;

import android.content.Context;
import android.os.Looper;
import com.google.android.gms.auth.api.signin.GoogleSignInOptions;
import com.google.android.gms.auth.api.signin.internal.i;
import com.google.android.gms.common.api.a;
import com.google.android.gms.common.api.e;
import com.google.android.gms.common.internal.d;

final class e extends a.C0319a {
    e() {
    }

    public final /* synthetic */ a.f a(Context context, Looper looper, d dVar, Object obj, e.a aVar, e.b bVar) {
        return new i(context, looper, dVar, (GoogleSignInOptions) obj, aVar, bVar);
    }
}
