package ug;

import com.google.firebase.components.ComponentRegistrar;
import java.util.ArrayList;
import java.util.List;
import ye.c;
import ye.e;
import ye.j;

public class b implements j {
    /* access modifiers changed from: private */
    public static /* synthetic */ Object c(String str, c cVar, e eVar) {
        try {
            c.b(str);
            return cVar.h().a(eVar);
        } finally {
            c.a();
        }
    }

    public List a(ComponentRegistrar componentRegistrar) {
        ArrayList arrayList = new ArrayList();
        for (c cVar : componentRegistrar.getComponents()) {
            String i10 = cVar.i();
            if (i10 != null) {
                cVar = cVar.t(new a(i10, cVar));
            }
            arrayList.add(cVar);
        }
        return arrayList;
    }
}
