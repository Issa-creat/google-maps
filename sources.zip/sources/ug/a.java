package ug;

import ye.c;
import ye.e;
import ye.h;

public final /* synthetic */ class a implements h {

    /* renamed from: a  reason: collision with root package name */
    public final /* synthetic */ String f43552a;

    /* renamed from: b  reason: collision with root package name */
    public final /* synthetic */ c f43553b;

    public /* synthetic */ a(String str, c cVar) {
        this.f43552a = str;
        this.f43553b = cVar;
    }

    public final Object a(e eVar) {
        return b.c(this.f43552a, this.f43553b, eVar);
    }
}
