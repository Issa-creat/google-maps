package sg;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.ThreadFactory;

public interface a {
    ExecutorService a(ThreadFactory threadFactory, c cVar);
}
