package sg;

public enum c {
    LOW_POWER,
    HIGH_SPEED
}
