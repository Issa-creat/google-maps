package u1;

import androidx.media3.common.util.b1;
import d1.h;
import d1.o;
import d1.p;
import java.util.Arrays;
import okhttp3.internal.http2.Http2;
import y0.y;

public abstract class k extends e {

    /* renamed from: j  reason: collision with root package name */
    private byte[] f18077j;

    /* renamed from: k  reason: collision with root package name */
    private volatile boolean f18078k;

    public k(h hVar, p pVar, int i10, y yVar, int i11, Object obj, byte[] bArr) {
        super(hVar, pVar, i10, yVar, i11, obj, -9223372036854775807L, -9223372036854775807L);
        k kVar;
        byte[] bArr2;
        if (bArr == null) {
            bArr2 = b1.f3700f;
            kVar = this;
        } else {
            kVar = this;
            bArr2 = bArr;
        }
        kVar.f18077j = bArr2;
    }

    private void i(int i10) {
        byte[] bArr = this.f18077j;
        if (bArr.length < i10 + Http2.INITIAL_MAX_FRAME_SIZE) {
            this.f18077j = Arrays.copyOf(bArr, bArr.length + Http2.INITIAL_MAX_FRAME_SIZE);
        }
    }

    public final void a() {
        try {
            this.f18058i.c(this.f18051b);
            int i10 = 0;
            int i11 = 0;
            while (i10 != -1 && !this.f18078k) {
                i(i11);
                i10 = this.f18058i.read(this.f18077j, i11, Http2.INITIAL_MAX_FRAME_SIZE);
                if (i10 != -1) {
                    i11 += i10;
                }
            }
            if (!this.f18078k) {
                g(this.f18077j, i11);
            }
        } finally {
            o.a(this.f18058i);
        }
    }

    public final void c() {
        this.f18078k = true;
    }

    /* access modifiers changed from: protected */
    public abstract void g(byte[] bArr, int i10);

    public byte[] h() {
        return this.f18077j;
    }
}
