package u1;

import b2.h;
import b2.s0;
import h1.c4;
import java.util.List;
import y0.y;
import y2.s;

public interface f {

    public interface a {
        a a(s.a aVar);

        a b(boolean z10);

        y c(y yVar);

        f d(int i10, y yVar, boolean z10, List list, s0 s0Var, c4 c4Var);
    }

    public interface b {
        s0 b(int i10, int i11);
    }

    boolean a(b2.s sVar);

    void c(b bVar, long j10, long j11);

    y[] d();

    h e();

    void release();
}
