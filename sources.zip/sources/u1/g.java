package u1;

public final class g {

    /* renamed from: a  reason: collision with root package name */
    public e f18059a;

    /* renamed from: b  reason: collision with root package name */
    public boolean f18060b;

    public void a() {
        this.f18059a = null;
        this.f18060b = false;
    }
}
