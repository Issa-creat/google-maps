package u1;

import b2.j;
import d1.f0;
import d1.h;
import d1.o;
import d1.p;
import u1.f;
import y0.y;

public final class l extends e {

    /* renamed from: j  reason: collision with root package name */
    private final f f18079j;

    /* renamed from: k  reason: collision with root package name */
    private f.b f18080k;

    /* renamed from: l  reason: collision with root package name */
    private long f18081l;

    /* renamed from: m  reason: collision with root package name */
    private volatile boolean f18082m;

    public l(h hVar, p pVar, y yVar, int i10, Object obj, f fVar) {
        super(hVar, pVar, 2, yVar, i10, obj, -9223372036854775807L, -9223372036854775807L);
        this.f18079j = fVar;
    }

    public void a() {
        j jVar;
        if (this.f18081l == 0) {
            this.f18079j.c(this.f18080k, -9223372036854775807L, -9223372036854775807L);
        }
        try {
            p e10 = this.f18051b.e(this.f18081l);
            f0 f0Var = this.f18058i;
            jVar = new j(f0Var, e10.f12174g, f0Var.c(e10));
            do {
                if (this.f18082m || !this.f18079j.a(jVar)) {
                    break;
                }
                break;
                break;
            } while (!this.f18079j.a(jVar));
            break;
            this.f18081l = jVar.getPosition() - this.f18051b.f12174g;
            o.a(this.f18058i);
        } catch (Throwable th2) {
            o.a(this.f18058i);
            throw th2;
        }
    }

    public void c() {
        this.f18082m = true;
    }

    public void g(f.b bVar) {
        this.f18080k = bVar;
    }
}
