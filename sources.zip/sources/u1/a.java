package u1;

import d1.h;
import d1.p;
import y0.y;

public abstract class a extends m {

    /* renamed from: k  reason: collision with root package name */
    public final long f18027k;

    /* renamed from: l  reason: collision with root package name */
    public final long f18028l;

    /* renamed from: m  reason: collision with root package name */
    private c f18029m;

    /* renamed from: n  reason: collision with root package name */
    private int[] f18030n;

    /* JADX INFO: super call moved to the top of the method (can break code semantics) */
    public a(h hVar, p pVar, y yVar, int i10, Object obj, long j10, long j11, long j12, long j13, long j14) {
        super(hVar, pVar, yVar, i10, obj, j10, j11, j14);
        this.f18027k = j12;
        this.f18028l = j13;
    }

    public final int i(int i10) {
        return ((int[]) androidx.media3.common.util.a.i(this.f18030n))[i10];
    }

    /* access modifiers changed from: protected */
    public final c j() {
        return (c) androidx.media3.common.util.a.i(this.f18029m);
    }

    public void k(c cVar) {
        this.f18029m = cVar;
        this.f18030n = cVar.a();
    }
}
