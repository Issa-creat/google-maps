package u1;

import androidx.media3.exoplayer.a2;
import androidx.media3.exoplayer.d2;
import androidx.media3.exoplayer.i3;
import g1.i;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import k1.v;
import k1.x;
import s1.a1;
import s1.b1;
import s1.c1;
import s1.m0;
import x1.n;
import x1.o;
import y0.y;

public class h implements b1, c1, o.b, o.f {
    private final c1.a A;
    /* access modifiers changed from: private */
    public final m0.a B;
    private final n C;
    private final o D;
    private final g E;
    private final ArrayList F;
    private final List G;
    private final a1 H;
    private final a1[] I;
    private final c J;
    private e K;
    private y L;
    private b M;
    private long N;
    /* access modifiers changed from: private */
    public long O;
    private int P;
    /* access modifiers changed from: private */
    public a Q;
    boolean R;

    /* renamed from: a  reason: collision with root package name */
    public final int f18061a;
    /* access modifiers changed from: private */

    /* renamed from: w  reason: collision with root package name */
    public final int[] f18062w;
    /* access modifiers changed from: private */

    /* renamed from: x  reason: collision with root package name */
    public final y[] f18063x;
    /* access modifiers changed from: private */

    /* renamed from: y  reason: collision with root package name */
    public final boolean[] f18064y;

    /* renamed from: z  reason: collision with root package name */
    private final i f18065z;

    public final class a implements b1 {

        /* renamed from: a  reason: collision with root package name */
        public final h f18066a;

        /* renamed from: w  reason: collision with root package name */
        private final a1 f18067w;

        /* renamed from: x  reason: collision with root package name */
        private final int f18068x;

        /* renamed from: y  reason: collision with root package name */
        private boolean f18069y;

        public a(h hVar, a1 a1Var, int i10) {
            this.f18066a = hVar;
            this.f18067w = a1Var;
            this.f18068x = i10;
        }

        private void c() {
            if (!this.f18069y) {
                h.this.B.h(h.this.f18062w[this.f18068x], h.this.f18063x[this.f18068x], 0, (Object) null, h.this.O);
                this.f18069y = true;
            }
        }

        public void a() {
        }

        public boolean b() {
            if (h.this.I() || !this.f18067w.L(h.this.R)) {
                return false;
            }
            return true;
        }

        public void d() {
            androidx.media3.common.util.a.g(h.this.f18064y[this.f18068x]);
            h.this.f18064y[this.f18068x] = false;
        }

        public int h(a2 a2Var, i iVar, int i10) {
            if (h.this.I()) {
                return -3;
            }
            if (h.this.Q != null && h.this.Q.i(this.f18068x + 1) <= this.f18067w.D()) {
                return -3;
            }
            c();
            return this.f18067w.T(a2Var, iVar, i10, h.this.R);
        }

        public int q(long j10) {
            if (h.this.I()) {
                return 0;
            }
            int F = this.f18067w.F(j10, h.this.R);
            if (h.this.Q != null) {
                F = Math.min(F, h.this.Q.i(this.f18068x + 1) - this.f18067w.D());
            }
            this.f18067w.f0(F);
            if (F > 0) {
                c();
            }
            return F;
        }
    }

    public interface b {
        void a(h hVar);
    }

    public h(int i10, int[] iArr, y[] yVarArr, i iVar, c1.a aVar, x1.b bVar, long j10, x xVar, v.a aVar2, n nVar, m0.a aVar3) {
        this.f18061a = i10;
        int i11 = 0;
        iArr = iArr == null ? new int[0] : iArr;
        this.f18062w = iArr;
        this.f18063x = yVarArr == null ? new y[0] : yVarArr;
        this.f18065z = iVar;
        this.A = aVar;
        this.B = aVar3;
        this.C = nVar;
        this.D = new o("ChunkSampleStream");
        this.E = new g();
        ArrayList arrayList = new ArrayList();
        this.F = arrayList;
        this.G = Collections.unmodifiableList(arrayList);
        int length = iArr.length;
        this.I = new a1[length];
        this.f18064y = new boolean[length];
        int i12 = length + 1;
        int[] iArr2 = new int[i12];
        a1[] a1VarArr = new a1[i12];
        a1 k10 = a1.k(bVar, xVar, aVar2);
        this.H = k10;
        iArr2[0] = i10;
        a1VarArr[0] = k10;
        while (i11 < length) {
            a1 l10 = a1.l(bVar);
            this.I[i11] = l10;
            int i13 = i11 + 1;
            a1VarArr[i13] = l10;
            iArr2[i13] = this.f18062w[i11];
            i11 = i13;
        }
        this.J = new c(iArr2, a1VarArr);
        this.N = j10;
        this.O = j10;
    }

    private void B(int i10) {
        int min = Math.min(O(i10, 0), this.P);
        if (min > 0) {
            androidx.media3.common.util.b1.p1(this.F, 0, min);
            this.P -= min;
        }
    }

    private void C(int i10) {
        androidx.media3.common.util.a.g(!this.D.j());
        int size = this.F.size();
        while (true) {
            if (i10 >= size) {
                i10 = -1;
                break;
            } else if (!G(i10)) {
                break;
            } else {
                i10++;
            }
        }
        if (i10 != -1) {
            long j10 = F().f18057h;
            a D2 = D(i10);
            if (this.F.isEmpty()) {
                this.N = this.O;
            }
            this.R = false;
            this.B.C(this.f18061a, D2.f18056g, j10);
        }
    }

    private a D(int i10) {
        a aVar = (a) this.F.get(i10);
        ArrayList arrayList = this.F;
        androidx.media3.common.util.b1.p1(arrayList, i10, arrayList.size());
        this.P = Math.max(this.P, this.F.size());
        int i11 = 0;
        this.H.u(aVar.i(0));
        while (true) {
            a1[] a1VarArr = this.I;
            if (i11 >= a1VarArr.length) {
                return aVar;
            }
            a1 a1Var = a1VarArr[i11];
            i11++;
            a1Var.u(aVar.i(i11));
        }
    }

    private a F() {
        ArrayList arrayList = this.F;
        return (a) arrayList.get(arrayList.size() - 1);
    }

    private boolean G(int i10) {
        int D2;
        a aVar = (a) this.F.get(i10);
        if (this.H.D() > aVar.i(0)) {
            return true;
        }
        int i11 = 0;
        do {
            a1[] a1VarArr = this.I;
            if (i11 >= a1VarArr.length) {
                return false;
            }
            D2 = a1VarArr[i11].D();
            i11++;
        } while (D2 <= aVar.i(i11));
        return true;
    }

    private boolean H(e eVar) {
        return eVar instanceof a;
    }

    private void J() {
        int O2 = O(this.H.D(), this.P - 1);
        while (true) {
            int i10 = this.P;
            if (i10 <= O2) {
                this.P = i10 + 1;
                K(i10);
            } else {
                return;
            }
        }
    }

    private void K(int i10) {
        a aVar = (a) this.F.get(i10);
        y yVar = aVar.f18053d;
        if (!yVar.equals(this.L)) {
            this.B.h(this.f18061a, yVar, aVar.f18054e, aVar.f18055f, aVar.f18056g);
        }
        this.L = yVar;
    }

    private int O(int i10, int i11) {
        do {
            i11++;
            if (i11 >= this.F.size()) {
                return this.F.size() - 1;
            }
        } while (((a) this.F.get(i11)).i(0) <= i10);
        return i11 - 1;
    }

    private void R() {
        this.H.W();
        for (a1 W : this.I) {
            W.W();
        }
    }

    public i E() {
        return this.f18065z;
    }

    /* access modifiers changed from: package-private */
    public boolean I() {
        if (this.N != -9223372036854775807L) {
            return true;
        }
        return false;
    }

    /* renamed from: L */
    public void j(e eVar, long j10, long j11, boolean z10) {
        e eVar2 = eVar;
        this.K = null;
        this.Q = null;
        s1.y yVar = new s1.y(eVar2.f18050a, eVar2.f18051b, eVar.f(), eVar.e(), j10, j11, eVar.b());
        this.C.c(eVar2.f18050a);
        this.B.q(yVar, eVar2.f18052c, this.f18061a, eVar2.f18053d, eVar2.f18054e, eVar2.f18055f, eVar2.f18056g, eVar2.f18057h);
        if (!z10) {
            if (I()) {
                R();
            } else if (H(eVar)) {
                D(this.F.size() - 1);
                if (this.F.isEmpty()) {
                    this.N = this.O;
                }
            }
            this.A.h(this);
        }
    }

    /* renamed from: M */
    public void o(e eVar, long j10, long j11) {
        e eVar2 = eVar;
        this.K = null;
        this.f18065z.c(eVar2);
        s1.y yVar = new s1.y(eVar2.f18050a, eVar2.f18051b, eVar.f(), eVar.e(), j10, j11, eVar.b());
        this.C.c(eVar2.f18050a);
        this.B.t(yVar, eVar2.f18052c, this.f18061a, eVar2.f18053d, eVar2.f18054e, eVar2.f18055f, eVar2.f18056g, eVar2.f18057h);
        this.A.h(this);
    }

    /* JADX WARNING: Removed duplicated region for block: B:22:0x00a9  */
    /* JADX WARNING: Removed duplicated region for block: B:28:0x00f1  */
    /* renamed from: N */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public x1.o.c t(u1.e r31, long r32, long r34, java.io.IOException r36, int r37) {
        /*
            r30 = this;
            r0 = r30
            r1 = r31
            long r12 = r31.b()
            boolean r14 = r30.H(r31)
            java.util.ArrayList r2 = r0.F
            int r2 = r2.size()
            r15 = 1
            int r10 = r2 + -1
            r2 = 0
            r11 = 0
            int r4 = (r12 > r2 ? 1 : (r12 == r2 ? 0 : -1))
            if (r4 == 0) goto L_0x0027
            if (r14 == 0) goto L_0x0027
            boolean r2 = r0.G(r10)
            if (r2 != 0) goto L_0x0025
            goto L_0x0027
        L_0x0025:
            r8 = 0
            goto L_0x0028
        L_0x0027:
            r8 = 1
        L_0x0028:
            s1.y r9 = new s1.y
            long r3 = r1.f18050a
            d1.p r5 = r1.f18051b
            android.net.Uri r6 = r31.f()
            java.util.Map r7 = r31.e()
            r2 = r9
            r15 = r8
            r17 = r14
            r14 = r9
            r8 = r32
            r29 = r10
            r10 = r34
            r2.<init>(r3, r5, r6, r7, r8, r10, r12)
            s1.b0 r2 = new s1.b0
            int r3 = r1.f18052c
            int r4 = r0.f18061a
            y0.y r5 = r1.f18053d
            int r6 = r1.f18054e
            java.lang.Object r7 = r1.f18055f
            long r8 = r1.f18056g
            long r24 = androidx.media3.common.util.b1.N1(r8)
            long r8 = r1.f18057h
            long r26 = androidx.media3.common.util.b1.N1(r8)
            r18 = r2
            r19 = r3
            r20 = r4
            r21 = r5
            r22 = r6
            r23 = r7
            r18.<init>(r19, r20, r21, r22, r23, r24, r26)
            x1.n$c r3 = new x1.n$c
            r4 = r36
            r5 = r37
            r3.<init>(r14, r2, r4, r5)
            u1.i r2 = r0.f18065z
            x1.n r5 = r0.C
            boolean r2 = r2.h(r1, r15, r3, r5)
            if (r2 == 0) goto L_0x00a6
            if (r15 == 0) goto L_0x009f
            x1.o$c r2 = x1.o.f19303f
            if (r17 == 0) goto L_0x00a7
            r6 = r29
            u1.a r6 = r0.D(r6)
            if (r6 != r1) goto L_0x008e
            r11 = 1
            goto L_0x008f
        L_0x008e:
            r11 = 0
        L_0x008f:
            androidx.media3.common.util.a.g(r11)
            java.util.ArrayList r6 = r0.F
            boolean r6 = r6.isEmpty()
            if (r6 == 0) goto L_0x00a7
            long r6 = r0.O
            r0.N = r6
            goto L_0x00a7
        L_0x009f:
            java.lang.String r2 = "ChunkSampleStream"
            java.lang.String r6 = "Ignoring attempt to cancel non-cancelable load."
            androidx.media3.common.util.s.i(r2, r6)
        L_0x00a6:
            r2 = 0
        L_0x00a7:
            if (r2 != 0) goto L_0x00c0
            x1.n r2 = r0.C
            long r2 = r2.b(r3)
            r6 = -9223372036854775807(0x8000000000000001, double:-4.9E-324)
            int r8 = (r2 > r6 ? 1 : (r2 == r6 ? 0 : -1))
            if (r8 == 0) goto L_0x00be
            r6 = 0
            x1.o$c r2 = x1.o.h(r6, r2)
            goto L_0x00c0
        L_0x00be:
            x1.o$c r2 = x1.o.f19304g
        L_0x00c0:
            boolean r3 = r2.c()
            r6 = 1
            r3 = r3 ^ r6
            s1.m0$a r6 = r0.B
            int r7 = r1.f18052c
            int r8 = r0.f18061a
            y0.y r9 = r1.f18053d
            int r10 = r1.f18054e
            java.lang.Object r11 = r1.f18055f
            long r12 = r1.f18056g
            long r4 = r1.f18057h
            r16 = r6
            r17 = r14
            r18 = r7
            r19 = r8
            r20 = r9
            r21 = r10
            r22 = r11
            r23 = r12
            r25 = r4
            r27 = r36
            r28 = r3
            r16.v(r17, r18, r19, r20, r21, r22, r23, r25, r27, r28)
            if (r3 == 0) goto L_0x0100
            r3 = 0
            r0.K = r3
            x1.n r3 = r0.C
            long r4 = r1.f18050a
            r3.c(r4)
            s1.c1$a r1 = r0.A
            r1.h(r0)
        L_0x0100:
            return r2
        */
        throw new UnsupportedOperationException("Method not decompiled: u1.h.t(u1.e, long, long, java.io.IOException, int):x1.o$c");
    }

    public void P() {
        Q((b) null);
    }

    public void Q(b bVar) {
        this.M = bVar;
        this.H.S();
        for (a1 S : this.I) {
            S.S();
        }
        this.D.m(this);
    }

    public void S(long j10) {
        a aVar;
        boolean z10;
        boolean z11;
        this.O = j10;
        if (I()) {
            this.N = j10;
            return;
        }
        int i10 = 0;
        int i11 = 0;
        while (true) {
            if (i11 >= this.F.size()) {
                break;
            }
            aVar = (a) this.F.get(i11);
            int i12 = (aVar.f18056g > j10 ? 1 : (aVar.f18056g == j10 ? 0 : -1));
            if (i12 == 0 && aVar.f18027k == -9223372036854775807L) {
                break;
            } else if (i12 > 0) {
                break;
            } else {
                i11++;
            }
        }
        aVar = null;
        if (aVar != null) {
            z10 = this.H.Z(aVar.i(0));
        } else {
            a1 a1Var = this.H;
            if (j10 < d()) {
                z11 = true;
            } else {
                z11 = false;
            }
            z10 = a1Var.a0(j10, z11);
        }
        if (z10) {
            this.P = O(this.H.D(), 0);
            a1[] a1VarArr = this.I;
            int length = a1VarArr.length;
            while (i10 < length) {
                a1VarArr[i10].a0(j10, true);
                i10++;
            }
            return;
        }
        this.N = j10;
        this.R = false;
        this.F.clear();
        this.P = 0;
        if (this.D.j()) {
            this.H.r();
            a1[] a1VarArr2 = this.I;
            int length2 = a1VarArr2.length;
            while (i10 < length2) {
                a1VarArr2[i10].r();
                i10++;
            }
            this.D.f();
            return;
        }
        this.D.g();
        R();
    }

    public a T(long j10, int i10) {
        for (int i11 = 0; i11 < this.I.length; i11++) {
            if (this.f18062w[i11] == i10) {
                androidx.media3.common.util.a.g(!this.f18064y[i11]);
                this.f18064y[i11] = true;
                this.I[i11].a0(j10, true);
                return new a(this, this.I[i11], i11);
            }
        }
        throw new IllegalStateException();
    }

    public void a() {
        this.D.a();
        this.H.O();
        if (!this.D.j()) {
            this.f18065z.a();
        }
    }

    public boolean b() {
        if (I() || !this.H.L(this.R)) {
            return false;
        }
        return true;
    }

    public boolean c(d2 d2Var) {
        long j10;
        List list;
        if (this.R || this.D.j() || this.D.i()) {
            return false;
        }
        boolean I2 = I();
        if (I2) {
            list = Collections.emptyList();
            j10 = this.N;
        } else {
            list = this.G;
            j10 = F().f18057h;
        }
        this.f18065z.g(d2Var, j10, list, this.E);
        g gVar = this.E;
        boolean z10 = gVar.f18060b;
        e eVar = gVar.f18059a;
        gVar.a();
        if (z10) {
            this.N = -9223372036854775807L;
            this.R = true;
            return true;
        } else if (eVar == null) {
            return false;
        } else {
            this.K = eVar;
            if (H(eVar)) {
                a aVar = (a) eVar;
                if (I2) {
                    long j11 = aVar.f18056g;
                    long j12 = this.N;
                    if (j11 != j12) {
                        this.H.c0(j12);
                        for (a1 c02 : this.I) {
                            c02.c0(this.N);
                        }
                    }
                    this.N = -9223372036854775807L;
                }
                aVar.k(this.J);
                this.F.add(aVar);
            } else if (eVar instanceof l) {
                ((l) eVar).g(this.J);
            }
            this.B.z(new s1.y(eVar.f18050a, eVar.f18051b, this.D.n(eVar, this, this.C.d(eVar.f18052c))), eVar.f18052c, this.f18061a, eVar.f18053d, eVar.f18054e, eVar.f18055f, eVar.f18056g, eVar.f18057h);
            return true;
        }
    }

    public long d() {
        if (I()) {
            return this.N;
        }
        if (this.R) {
            return Long.MIN_VALUE;
        }
        return F().f18057h;
    }

    public long e(long j10, i3 i3Var) {
        return this.f18065z.e(j10, i3Var);
    }

    public long f() {
        if (this.R) {
            return Long.MIN_VALUE;
        }
        if (I()) {
            return this.N;
        }
        long j10 = this.O;
        a F2 = F();
        if (!F2.h()) {
            if (this.F.size() > 1) {
                ArrayList arrayList = this.F;
                F2 = (a) arrayList.get(arrayList.size() - 2);
            } else {
                F2 = null;
            }
        }
        if (F2 != null) {
            j10 = Math.max(j10, F2.f18057h);
        }
        return Math.max(j10, this.H.A());
    }

    public void g(long j10) {
        if (!this.D.i() && !I()) {
            if (this.D.j()) {
                e eVar = (e) androidx.media3.common.util.a.e(this.K);
                if ((!H(eVar) || !G(this.F.size() - 1)) && this.f18065z.f(j10, eVar, this.G)) {
                    this.D.f();
                    if (H(eVar)) {
                        this.Q = (a) eVar;
                        return;
                    }
                    return;
                }
                return;
            }
            int i10 = this.f18065z.i(j10, this.G);
            if (i10 < this.F.size()) {
                C(i10);
            }
        }
    }

    public int h(a2 a2Var, i iVar, int i10) {
        if (I()) {
            return -3;
        }
        a aVar = this.Q;
        if (aVar != null && aVar.i(0) <= this.H.D()) {
            return -3;
        }
        J();
        return this.H.T(a2Var, iVar, i10, this.R);
    }

    public void i() {
        this.H.U();
        for (a1 U : this.I) {
            U.U();
        }
        this.f18065z.release();
        b bVar = this.M;
        if (bVar != null) {
            bVar.a(this);
        }
    }

    public boolean n() {
        return this.D.j();
    }

    public int q(long j10) {
        if (I()) {
            return 0;
        }
        int F2 = this.H.F(j10, this.R);
        a aVar = this.Q;
        if (aVar != null) {
            F2 = Math.min(F2, aVar.i(0) - this.H.D());
        }
        this.H.f0(F2);
        J();
        return F2;
    }

    public void u(long j10, boolean z10) {
        if (!I()) {
            int y10 = this.H.y();
            this.H.q(j10, z10, true);
            int y11 = this.H.y();
            if (y11 > y10) {
                long z11 = this.H.z();
                int i10 = 0;
                while (true) {
                    a1[] a1VarArr = this.I;
                    if (i10 >= a1VarArr.length) {
                        break;
                    }
                    a1VarArr[i10].q(z11, z10, this.f18064y[i10]);
                    i10++;
                }
            }
            B(y11);
        }
    }
}
