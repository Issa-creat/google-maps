package u1;

import java.util.NoSuchElementException;

public abstract class b implements n {

    /* renamed from: b  reason: collision with root package name */
    private final long f18031b;

    /* renamed from: c  reason: collision with root package name */
    private final long f18032c;

    /* renamed from: d  reason: collision with root package name */
    private long f18033d;

    public b(long j10, long j11) {
        this.f18031b = j10;
        this.f18032c = j11;
        f();
    }

    /* access modifiers changed from: protected */
    public final void c() {
        long j10 = this.f18033d;
        if (j10 < this.f18031b || j10 > this.f18032c) {
            throw new NoSuchElementException();
        }
    }

    /* access modifiers changed from: protected */
    public final long d() {
        return this.f18033d;
    }

    public boolean e() {
        if (this.f18033d > this.f18032c) {
            return true;
        }
        return false;
    }

    public void f() {
        this.f18033d = this.f18031b - 1;
    }

    public boolean next() {
        this.f18033d++;
        return !e();
    }
}
