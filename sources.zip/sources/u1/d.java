package u1;

import android.util.SparseArray;
import androidx.media3.common.util.b1;
import androidx.media3.common.util.f0;
import b2.h;
import b2.l0;
import b2.m0;
import b2.n;
import b2.r;
import b2.r0;
import b2.s0;
import b2.t;
import u1.f;
import y0.y;
import y2.g;
import y2.s;

public final class d implements t, f {
    public static final b E = new b();
    private static final l0 F = new l0();
    private f.b A;
    private long B;
    private m0 C;
    private y[] D;

    /* renamed from: a  reason: collision with root package name */
    private final r f18036a;

    /* renamed from: w  reason: collision with root package name */
    private final int f18037w;

    /* renamed from: x  reason: collision with root package name */
    private final y f18038x;

    /* renamed from: y  reason: collision with root package name */
    private final SparseArray f18039y = new SparseArray();

    /* renamed from: z  reason: collision with root package name */
    private boolean f18040z;

    private static final class a implements s0 {

        /* renamed from: a  reason: collision with root package name */
        private final int f18041a;

        /* renamed from: b  reason: collision with root package name */
        private final int f18042b;

        /* renamed from: c  reason: collision with root package name */
        private final y f18043c;

        /* renamed from: d  reason: collision with root package name */
        private final n f18044d = new n();

        /* renamed from: e  reason: collision with root package name */
        public y f18045e;

        /* renamed from: f  reason: collision with root package name */
        private s0 f18046f;

        /* renamed from: g  reason: collision with root package name */
        private long f18047g;

        public a(int i10, int i11, y yVar) {
            this.f18041a = i10;
            this.f18042b = i11;
            this.f18043c = yVar;
        }

        public int a(y0.n nVar, int i10, boolean z10, int i11) {
            return ((s0) b1.l(this.f18046f)).f(nVar, i10, z10);
        }

        public void b(f0 f0Var, int i10, int i11) {
            ((s0) b1.l(this.f18046f)).c(f0Var, i10);
        }

        public /* synthetic */ void c(f0 f0Var, int i10) {
            r0.b(this, f0Var, i10);
        }

        public void d(y yVar) {
            y yVar2 = this.f18043c;
            if (yVar2 != null) {
                yVar = yVar.l(yVar2);
            }
            this.f18045e = yVar;
            ((s0) b1.l(this.f18046f)).d(this.f18045e);
        }

        public void e(long j10, int i10, int i11, int i12, s0.a aVar) {
            long j11 = this.f18047g;
            if (j11 != -9223372036854775807L && j10 >= j11) {
                this.f18046f = this.f18044d;
            }
            ((s0) b1.l(this.f18046f)).e(j10, i10, i11, i12, aVar);
        }

        public /* synthetic */ int f(y0.n nVar, int i10, boolean z10) {
            return r0.a(this, nVar, i10, z10);
        }

        public void g(f.b bVar, long j10) {
            if (bVar == null) {
                this.f18046f = this.f18044d;
                return;
            }
            this.f18047g = j10;
            s0 b10 = bVar.b(this.f18041a, this.f18042b);
            this.f18046f = b10;
            y yVar = this.f18045e;
            if (yVar != null) {
                b10.d(yVar);
            }
        }
    }

    public static final class b implements f.a {

        /* renamed from: a  reason: collision with root package name */
        private s.a f18048a = new g();

        /* renamed from: b  reason: collision with root package name */
        private boolean f18049b;

        public y c(y yVar) {
            String str;
            if (!this.f18049b || !this.f18048a.a(yVar)) {
                return yVar;
            }
            y.b S = yVar.a().o0("application/x-media3-cues").S(this.f18048a.c(yVar));
            StringBuilder sb2 = new StringBuilder();
            sb2.append(yVar.f20071n);
            if (yVar.f20067j != null) {
                str = " " + yVar.f20067j;
            } else {
                str = "";
            }
            sb2.append(str);
            return S.O(sb2.toString()).s0(Long.MAX_VALUE).K();
        }

        /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r10v1, resolved type: v2.h} */
        /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r10v2, resolved type: y2.t} */
        /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r10v3, resolved type: y2.t} */
        /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r10v11, resolved type: j2.a} */
        /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r10v13, resolved type: t2.e} */
        /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r10v15, resolved type: y2.n} */
        /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r10v16, resolved type: v2.h} */
        /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r10v17, resolved type: v2.h} */
        /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r10v18, resolved type: v2.h} */
        /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r10v19, resolved type: v2.h} */
        /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r0v8, resolved type: v2.h} */
        /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r10v20, resolved type: v2.h} */
        /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r10v21, resolved type: v2.h} */
        /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r10v22, resolved type: v2.h} */
        /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r10v23, resolved type: v2.h} */
        /* JADX WARNING: type inference failed for: r10v10, types: [x2.a] */
        /* JADX WARNING: Multi-variable type inference failed */
        /* Code decompiled incorrectly, please refer to instructions dump. */
        public u1.f d(int r8, y0.y r9, boolean r10, java.util.List r11, b2.s0 r12, h1.c4 r13) {
            /*
                r7 = this;
                java.lang.String r13 = r9.f20070m
                boolean r0 = y0.n0.r(r13)
                if (r0 == 0) goto L_0x001a
                boolean r10 = r7.f18049b
                if (r10 != 0) goto L_0x000e
                r8 = 0
                return r8
            L_0x000e:
                y2.n r10 = new y2.n
                y2.s$a r11 = r7.f18048a
                y2.s r11 = r11.b(r9)
                r10.<init>(r11, r9)
                goto L_0x0062
            L_0x001a:
                boolean r0 = y0.n0.q(r13)
                r1 = 1
                if (r0 == 0) goto L_0x002e
                boolean r10 = r7.f18049b
                if (r10 != 0) goto L_0x0026
                r1 = 3
            L_0x0026:
                t2.e r10 = new t2.e
                y2.s$a r11 = r7.f18048a
                r10.<init>(r11, r1)
                goto L_0x0062
            L_0x002e:
                java.lang.String r0 = "image/jpeg"
                boolean r0 = java.util.Objects.equals(r13, r0)
                if (r0 == 0) goto L_0x003c
                j2.a r10 = new j2.a
                r10.<init>(r1)
                goto L_0x0062
            L_0x003c:
                java.lang.String r0 = "image/png"
                boolean r0 = java.util.Objects.equals(r13, r0)
                if (r0 == 0) goto L_0x004a
                x2.a r10 = new x2.a
                r10.<init>()
                goto L_0x0062
            L_0x004a:
                if (r10 == 0) goto L_0x004e
                r10 = 4
                goto L_0x004f
            L_0x004e:
                r10 = 0
            L_0x004f:
                boolean r0 = r7.f18049b
                if (r0 != 0) goto L_0x0055
                r10 = r10 | 32
            L_0x0055:
                r2 = r10
                v2.h r10 = new v2.h
                y2.s$a r1 = r7.f18048a
                r3 = 0
                r4 = 0
                r0 = r10
                r5 = r11
                r6 = r12
                r0.<init>(r1, r2, r3, r4, r5, r6)
            L_0x0062:
                boolean r11 = r7.f18049b
                if (r11 == 0) goto L_0x0084
                boolean r11 = y0.n0.r(r13)
                if (r11 != 0) goto L_0x0084
                b2.r r11 = r10.d()
                boolean r11 = r11 instanceof v2.h
                if (r11 != 0) goto L_0x0084
                b2.r r11 = r10.d()
                boolean r11 = r11 instanceof t2.e
                if (r11 != 0) goto L_0x0084
                y2.t r11 = new y2.t
                y2.s$a r12 = r7.f18048a
                r11.<init>(r10, r12)
                r10 = r11
            L_0x0084:
                u1.d r11 = new u1.d
                r11.<init>(r10, r8, r9)
                return r11
            */
            throw new UnsupportedOperationException("Method not decompiled: u1.d.b.d(int, y0.y, boolean, java.util.List, b2.s0, h1.c4):u1.f");
        }

        /* renamed from: e */
        public b b(boolean z10) {
            this.f18049b = z10;
            return this;
        }

        /* renamed from: f */
        public b a(s.a aVar) {
            this.f18048a = (s.a) androidx.media3.common.util.a.e(aVar);
            return this;
        }
    }

    public d(r rVar, int i10, y yVar) {
        this.f18036a = rVar;
        this.f18037w = i10;
        this.f18038x = yVar;
    }

    public boolean a(b2.s sVar) {
        boolean z10;
        int g10 = this.f18036a.g(sVar, F);
        if (g10 != 1) {
            z10 = true;
        } else {
            z10 = false;
        }
        androidx.media3.common.util.a.g(z10);
        if (g10 == 0) {
            return true;
        }
        return false;
    }

    public s0 b(int i10, int i11) {
        boolean z10;
        y yVar;
        a aVar = (a) this.f18039y.get(i10);
        if (aVar == null) {
            if (this.D == null) {
                z10 = true;
            } else {
                z10 = false;
            }
            androidx.media3.common.util.a.g(z10);
            if (i11 == this.f18037w) {
                yVar = this.f18038x;
            } else {
                yVar = null;
            }
            aVar = new a(i10, i11, yVar);
            aVar.g(this.A, this.B);
            this.f18039y.put(i10, aVar);
        }
        return aVar;
    }

    public void c(f.b bVar, long j10, long j11) {
        this.A = bVar;
        this.B = j11;
        if (!this.f18040z) {
            this.f18036a.b(this);
            if (j10 != -9223372036854775807L) {
                this.f18036a.c(0, j10);
            }
            this.f18040z = true;
            return;
        }
        r rVar = this.f18036a;
        if (j10 == -9223372036854775807L) {
            j10 = 0;
        }
        rVar.c(0, j10);
        for (int i10 = 0; i10 < this.f18039y.size(); i10++) {
            ((a) this.f18039y.valueAt(i10)).g(bVar, j11);
        }
    }

    public y[] d() {
        return this.D;
    }

    public h e() {
        m0 m0Var = this.C;
        if (m0Var instanceof h) {
            return (h) m0Var;
        }
        return null;
    }

    public void h() {
        y[] yVarArr = new y[this.f18039y.size()];
        for (int i10 = 0; i10 < this.f18039y.size(); i10++) {
            yVarArr[i10] = (y) androidx.media3.common.util.a.i(((a) this.f18039y.valueAt(i10)).f18045e);
        }
        this.D = yVarArr;
    }

    public void q(m0 m0Var) {
        this.C = m0Var;
    }

    public void release() {
        this.f18036a.release();
    }
}
