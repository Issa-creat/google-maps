package u1;

import androidx.media3.common.util.f0;
import b2.s0;
import d1.h;
import d1.o;
import d1.p;
import u1.f;
import y0.n0;
import y0.y;

public class j extends a {

    /* renamed from: o  reason: collision with root package name */
    private final int f18071o;

    /* renamed from: p  reason: collision with root package name */
    private final long f18072p;

    /* renamed from: q  reason: collision with root package name */
    private final f f18073q;

    /* renamed from: r  reason: collision with root package name */
    private long f18074r;

    /* renamed from: s  reason: collision with root package name */
    private volatile boolean f18075s;

    /* renamed from: t  reason: collision with root package name */
    private boolean f18076t;

    /* JADX INFO: super call moved to the top of the method (can break code semantics) */
    public j(h hVar, p pVar, y yVar, int i10, Object obj, long j10, long j11, long j12, long j13, long j14, int i11, long j15, f fVar) {
        super(hVar, pVar, yVar, i10, obj, j10, j11, j12, j13, j14);
        this.f18071o = i11;
        this.f18072p = j15;
        this.f18073q = fVar;
    }

    private void m(c cVar) {
        if (n0.p(this.f18053d.f20070m)) {
            y yVar = this.f18053d;
            int i10 = yVar.I;
            if ((i10 > 1 || yVar.J > 1) && i10 != -1 && yVar.J != -1) {
                s0 b10 = cVar.b(0, 4);
                y yVar2 = this.f18053d;
                int i11 = yVar2.J * yVar2.I;
                long j10 = (this.f18057h - this.f18056g) / ((long) i11);
                for (int i12 = 1; i12 < i11; i12++) {
                    b10.c(new f0(), 0);
                    b10.e(((long) i12) * j10, 0, 0, 0, (s0.a) null);
                }
            }
        }
    }

    public final void a() {
        b2.j jVar;
        long j10;
        long j11;
        c j12 = j();
        if (this.f18074r == 0) {
            j12.c(this.f18072p);
            f fVar = this.f18073q;
            f.b l10 = l(j12);
            long j13 = this.f18027k;
            if (j13 == -9223372036854775807L) {
                j10 = -9223372036854775807L;
            } else {
                j10 = j13 - this.f18072p;
            }
            long j14 = this.f18028l;
            if (j14 == -9223372036854775807L) {
                j11 = -9223372036854775807L;
            } else {
                j11 = j14 - this.f18072p;
            }
            fVar.c(l10, j10, j11);
        }
        try {
            p e10 = this.f18051b.e(this.f18074r);
            d1.f0 f0Var = this.f18058i;
            jVar = new b2.j(f0Var, e10.f12174g, f0Var.c(e10));
            while (!this.f18075s && this.f18073q.a(jVar)) {
            }
            m(j12);
            this.f18074r = jVar.getPosition() - this.f18051b.f12174g;
            o.a(this.f18058i);
            this.f18076t = !this.f18075s;
        } catch (Throwable th2) {
            o.a(this.f18058i);
            throw th2;
        }
    }

    public final void c() {
        this.f18075s = true;
    }

    public long g() {
        return this.f18083j + ((long) this.f18071o);
    }

    public boolean h() {
        return this.f18076t;
    }

    /* access modifiers changed from: protected */
    public f.b l(c cVar) {
        return cVar;
    }
}
