package u1;

import androidx.media3.exoplayer.d2;
import androidx.media3.exoplayer.i3;
import java.util.List;
import x1.n;

public interface i {
    void a();

    void c(e eVar);

    long e(long j10, i3 i3Var);

    boolean f(long j10, e eVar, List list);

    void g(d2 d2Var, long j10, List list, g gVar);

    boolean h(e eVar, boolean z10, n.c cVar, n nVar);

    int i(long j10, List list);

    void release();
}
