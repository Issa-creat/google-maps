package u1;

import java.util.NoSuchElementException;

public interface n {

    /* renamed from: a  reason: collision with root package name */
    public static final n f18084a = new a();

    class a implements n {
        a() {
        }

        public long a() {
            throw new NoSuchElementException();
        }

        public long b() {
            throw new NoSuchElementException();
        }

        public boolean next() {
            return false;
        }
    }

    long a();

    long b();

    boolean next();
}
