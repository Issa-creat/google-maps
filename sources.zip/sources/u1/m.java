package u1;

import androidx.media3.common.util.a;
import d1.h;
import d1.p;
import y0.y;

public abstract class m extends e {

    /* renamed from: j  reason: collision with root package name */
    public final long f18083j;

    public m(h hVar, p pVar, y yVar, int i10, Object obj, long j10, long j11, long j12) {
        super(hVar, pVar, 1, yVar, i10, obj, j10, j11);
        a.e(yVar);
        this.f18083j = j12;
    }

    public long g() {
        long j10 = this.f18083j;
        if (j10 != -1) {
            return 1 + j10;
        }
        return -1;
    }

    public abstract boolean h();
}
