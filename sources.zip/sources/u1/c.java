package u1;

import androidx.media3.common.util.s;
import b2.n;
import b2.s0;
import s1.a1;
import u1.f;

public final class c implements f.b {

    /* renamed from: a  reason: collision with root package name */
    private final int[] f18034a;

    /* renamed from: b  reason: collision with root package name */
    private final a1[] f18035b;

    public c(int[] iArr, a1[] a1VarArr) {
        this.f18034a = iArr;
        this.f18035b = a1VarArr;
    }

    public int[] a() {
        int[] iArr = new int[this.f18035b.length];
        int i10 = 0;
        while (true) {
            a1[] a1VarArr = this.f18035b;
            if (i10 >= a1VarArr.length) {
                return iArr;
            }
            iArr[i10] = a1VarArr[i10].H();
            i10++;
        }
    }

    public s0 b(int i10, int i11) {
        int i12 = 0;
        while (true) {
            int[] iArr = this.f18034a;
            if (i12 >= iArr.length) {
                s.d("BaseMediaChunkOutput", "Unmatched track of type: " + i11);
                return new n();
            } else if (i11 == iArr[i12]) {
                return this.f18035b[i12];
            } else {
                i12++;
            }
        }
    }

    public void c(long j10) {
        for (a1 b02 : this.f18035b) {
            b02.b0(j10);
        }
    }
}
