package u1;

import android.net.Uri;
import androidx.media3.common.util.a;
import d1.f0;
import d1.h;
import d1.p;
import java.util.Map;
import s1.y;
import x1.o;

public abstract class e implements o.e {

    /* renamed from: a  reason: collision with root package name */
    public final long f18050a = y.a();

    /* renamed from: b  reason: collision with root package name */
    public final p f18051b;

    /* renamed from: c  reason: collision with root package name */
    public final int f18052c;

    /* renamed from: d  reason: collision with root package name */
    public final y0.y f18053d;

    /* renamed from: e  reason: collision with root package name */
    public final int f18054e;

    /* renamed from: f  reason: collision with root package name */
    public final Object f18055f;

    /* renamed from: g  reason: collision with root package name */
    public final long f18056g;

    /* renamed from: h  reason: collision with root package name */
    public final long f18057h;

    /* renamed from: i  reason: collision with root package name */
    protected final f0 f18058i;

    public e(h hVar, p pVar, int i10, y0.y yVar, int i11, Object obj, long j10, long j11) {
        this.f18058i = new f0(hVar);
        this.f18051b = (p) a.e(pVar);
        this.f18052c = i10;
        this.f18053d = yVar;
        this.f18054e = i11;
        this.f18055f = obj;
        this.f18056g = j10;
        this.f18057h = j11;
    }

    public final long b() {
        return this.f18058i.p();
    }

    public final long d() {
        return this.f18057h - this.f18056g;
    }

    public final Map e() {
        return this.f18058i.r();
    }

    public final Uri f() {
        return this.f18058i.q();
    }
}
