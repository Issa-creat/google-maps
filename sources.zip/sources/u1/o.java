package u1;

import b2.j;
import b2.s0;
import d1.h;
import d1.p;
import y0.y;

public final class o extends a {

    /* renamed from: o  reason: collision with root package name */
    private final int f18085o;

    /* renamed from: p  reason: collision with root package name */
    private final y f18086p;

    /* renamed from: q  reason: collision with root package name */
    private long f18087q;

    /* renamed from: r  reason: collision with root package name */
    private boolean f18088r;

    /* JADX INFO: super call moved to the top of the method (can break code semantics) */
    public o(h hVar, p pVar, y yVar, int i10, Object obj, long j10, long j11, long j12, int i11, y yVar2) {
        super(hVar, pVar, yVar, i10, obj, j10, j11, -9223372036854775807L, -9223372036854775807L, j12);
        this.f18085o = i11;
        this.f18086p = yVar2;
    }

    /* JADX INFO: finally extract failed */
    public void a() {
        c j10 = j();
        j10.c(0);
        s0 b10 = j10.b(0, this.f18085o);
        b10.d(this.f18086p);
        try {
            long c10 = this.f18058i.c(this.f18051b.e(this.f18087q));
            if (c10 != -1) {
                c10 += this.f18087q;
            }
            j jVar = new j(this.f18058i, this.f18087q, c10);
            for (int i10 = 0; i10 != -1; i10 = b10.f(jVar, Integer.MAX_VALUE, true)) {
                this.f18087q += (long) i10;
            }
            b10.e(this.f18056g, 1, (int) this.f18087q, 0, (s0.a) null);
            d1.o.a(this.f18058i);
            this.f18088r = true;
        } catch (Throwable th2) {
            d1.o.a(this.f18058i);
            throw th2;
        }
    }

    public void c() {
    }

    public boolean h() {
        return this.f18088r;
    }
}
