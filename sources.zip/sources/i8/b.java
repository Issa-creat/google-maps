package i8;

import ak.k;
import android.net.Uri;
import android.os.Looper;
import android.os.SystemClock;
import com.facebook.imagepipeline.producers.e;
import com.facebook.imagepipeline.producers.l;
import com.facebook.imagepipeline.producers.p0;
import com.facebook.imagepipeline.producers.u0;
import com.facebook.imagepipeline.producers.y;
import java.io.IOException;
import java.util.Map;
import java.util.concurrent.Executor;
import kotlin.jvm.internal.DefaultConstructorMarker;
import mj.q;
import okhttp3.CacheControl;
import okhttp3.Call;
import okhttp3.Callback;
import okhttp3.Request;

public class b extends com.facebook.imagepipeline.producers.c {

    /* renamed from: d  reason: collision with root package name */
    private static final a f14306d = new a((DefaultConstructorMarker) null);

    /* renamed from: a  reason: collision with root package name */
    private final Call.Factory f14307a;
    /* access modifiers changed from: private */

    /* renamed from: b  reason: collision with root package name */
    public final Executor f14308b;

    /* renamed from: c  reason: collision with root package name */
    private final CacheControl f14309c;

    private static final class a {
        private a() {
        }

        public /* synthetic */ a(DefaultConstructorMarker defaultConstructorMarker) {
            this();
        }
    }

    /* renamed from: i8.b$b  reason: collision with other inner class name */
    public static final class C0192b extends y {

        /* renamed from: f  reason: collision with root package name */
        public long f14310f;

        /* renamed from: g  reason: collision with root package name */
        public long f14311g;

        /* renamed from: h  reason: collision with root package name */
        public long f14312h;

        /* JADX INFO: super call moved to the top of the method (can break code semantics) */
        public C0192b(l lVar, u0 u0Var) {
            super(lVar, u0Var);
            k.f(lVar, "consumer");
            k.f(u0Var, "producerContext");
        }
    }

    public static final class c extends e {

        /* renamed from: a  reason: collision with root package name */
        final /* synthetic */ Call f14313a;

        /* renamed from: b  reason: collision with root package name */
        final /* synthetic */ b f14314b;

        c(Call call, b bVar) {
            this.f14313a = call;
            this.f14314b = bVar;
        }

        /* access modifiers changed from: private */
        public static final void f(Call call) {
            call.cancel();
        }

        public void a() {
            if (!k.b(Looper.myLooper(), Looper.getMainLooper())) {
                this.f14313a.cancel();
            } else {
                this.f14314b.f14308b.execute(new c(this.f14313a));
            }
        }
    }

    public static final class d implements Callback {

        /* renamed from: a  reason: collision with root package name */
        final /* synthetic */ C0192b f14315a;

        /* renamed from: w  reason: collision with root package name */
        final /* synthetic */ b f14316w;

        /* renamed from: x  reason: collision with root package name */
        final /* synthetic */ p0.a f14317x;

        d(C0192b bVar, b bVar2, p0.a aVar) {
            this.f14315a = bVar;
            this.f14316w = bVar2;
            this.f14317x = aVar;
        }

        public void onFailure(Call call, IOException iOException) {
            k.f(call, "call");
            k.f(iOException, "e");
            this.f14316w.l(call, iOException, this.f14317x);
        }

        /* JADX WARNING: Code restructure failed: missing block: B:27:0x0088, code lost:
            r11 = move-exception;
         */
        /* JADX WARNING: Code restructure failed: missing block: B:28:0x0089, code lost:
            xj.a.a(r0, r10);
         */
        /* JADX WARNING: Code restructure failed: missing block: B:29:0x008c, code lost:
            throw r11;
         */
        /* Code decompiled incorrectly, please refer to instructions dump. */
        public void onResponse(okhttp3.Call r10, okhttp3.Response r11) {
            /*
                r9 = this;
                java.lang.String r0 = "call"
                ak.k.f(r10, r0)
                java.lang.String r0 = "response"
                ak.k.f(r11, r0)
                i8.b$b r0 = r9.f14315a
                long r1 = android.os.SystemClock.elapsedRealtime()
                r0.f14311g = r1
                okhttp3.ResponseBody r0 = r11.body()
                r1 = 0
                if (r0 == 0) goto L_0x008d
                i8.b r2 = r9.f14316w
                com.facebook.imagepipeline.producers.p0$a r3 = r9.f14317x
                i8.b$b r4 = r9.f14315a
                boolean r5 = r11.isSuccessful()     // Catch:{ Exception -> 0x007b }
                if (r5 != 0) goto L_0x003f
                java.io.IOException r4 = new java.io.IOException     // Catch:{ Exception -> 0x007b }
                java.lang.StringBuilder r5 = new java.lang.StringBuilder     // Catch:{ Exception -> 0x007b }
                r5.<init>()     // Catch:{ Exception -> 0x007b }
                java.lang.String r6 = "Unexpected HTTP code "
                r5.append(r6)     // Catch:{ Exception -> 0x007b }
                r5.append(r11)     // Catch:{ Exception -> 0x007b }
                java.lang.String r5 = r5.toString()     // Catch:{ Exception -> 0x007b }
                r4.<init>(r5)     // Catch:{ Exception -> 0x007b }
                r2.l(r10, r4, r3)     // Catch:{ Exception -> 0x007b }
                goto L_0x007f
            L_0x003f:
                l8.a$b r5 = l8.a.f15487c     // Catch:{ Exception -> 0x007b }
                java.lang.String r6 = "Content-Range"
                java.lang.String r6 = r11.header(r6)     // Catch:{ Exception -> 0x007b }
                l8.a r5 = r5.c(r6)     // Catch:{ Exception -> 0x007b }
                if (r5 == 0) goto L_0x0060
                int r6 = r5.f15489a     // Catch:{ Exception -> 0x007b }
                if (r6 != 0) goto L_0x0058
                int r6 = r5.f15490b     // Catch:{ Exception -> 0x007b }
                r7 = 2147483647(0x7fffffff, float:NaN)
                if (r6 == r7) goto L_0x0060
            L_0x0058:
                r4.j(r5)     // Catch:{ Exception -> 0x007b }
                r5 = 8
                r4.i(r5)     // Catch:{ Exception -> 0x007b }
            L_0x0060:
                long r4 = r0.contentLength()     // Catch:{ Exception -> 0x007b }
                r6 = 0
                int r8 = (r4 > r6 ? 1 : (r4 == r6 ? 0 : -1))
                if (r8 >= 0) goto L_0x006c
                r4 = 0
                goto L_0x0071
            L_0x006c:
                long r4 = r0.contentLength()     // Catch:{ Exception -> 0x007b }
                int r4 = (int) r4     // Catch:{ Exception -> 0x007b }
            L_0x0071:
                java.io.InputStream r5 = r0.byteStream()     // Catch:{ Exception -> 0x007b }
                r3.c(r5, r4)     // Catch:{ Exception -> 0x007b }
                goto L_0x007f
            L_0x0079:
                r10 = move-exception
                goto L_0x0087
            L_0x007b:
                r4 = move-exception
                r2.l(r10, r4, r3)     // Catch:{ all -> 0x0079 }
            L_0x007f:
                mj.u r2 = mj.u.f47552a     // Catch:{ all -> 0x0079 }
                xj.a.a(r0, r1)
                mj.u r1 = mj.u.f47552a
                goto L_0x008d
            L_0x0087:
                throw r10     // Catch:{ all -> 0x0088 }
            L_0x0088:
                r11 = move-exception
                xj.a.a(r0, r10)
                throw r11
            L_0x008d:
                if (r1 != 0) goto L_0x00ac
                i8.b r0 = r9.f14316w
                java.io.IOException r1 = new java.io.IOException
                java.lang.StringBuilder r2 = new java.lang.StringBuilder
                r2.<init>()
                java.lang.String r3 = "Response body null: "
                r2.append(r3)
                r2.append(r11)
                java.lang.String r11 = r2.toString()
                r1.<init>(r11)
                com.facebook.imagepipeline.producers.p0$a r11 = r9.f14317x
                r0.l(r10, r1, r11)
            L_0x00ac:
                return
            */
            throw new UnsupportedOperationException("Method not decompiled: i8.b.d.onResponse(okhttp3.Call, okhttp3.Response):void");
        }
    }

    /* JADX INFO: this call moved to the top of the method (can break code semantics) */
    public /* synthetic */ b(Call.Factory factory, Executor executor, boolean z10, int i10, DefaultConstructorMarker defaultConstructorMarker) {
        this(factory, executor, (i10 & 4) != 0 ? true : z10);
    }

    /* access modifiers changed from: private */
    public final void l(Call call, Exception exc, p0.a aVar) {
        if (call.isCanceled()) {
            aVar.b();
        } else {
            aVar.a(exc);
        }
    }

    /* renamed from: h */
    public C0192b e(l lVar, u0 u0Var) {
        k.f(lVar, "consumer");
        k.f(u0Var, "context");
        return new C0192b(lVar, u0Var);
    }

    /* renamed from: i */
    public void d(C0192b bVar, p0.a aVar) {
        k.f(bVar, "fetchState");
        k.f(aVar, "callback");
        bVar.f14310f = SystemClock.elapsedRealtime();
        Uri g10 = bVar.g();
        k.e(g10, "fetchState.uri");
        try {
            Request.Builder builder = new Request.Builder().url(g10.toString()).get();
            CacheControl cacheControl = this.f14309c;
            if (cacheControl != null) {
                k.e(builder, "requestBuilder");
                builder.cacheControl(cacheControl);
            }
            l8.a b10 = bVar.b().c().b();
            if (b10 != null) {
                builder.addHeader("Range", b10.d());
            }
            Request build = builder.build();
            k.e(build, "requestBuilder.build()");
            j(bVar, aVar, build);
        } catch (Exception e10) {
            aVar.a(e10);
        }
    }

    /* access modifiers changed from: protected */
    public void j(C0192b bVar, p0.a aVar, Request request) {
        k.f(bVar, "fetchState");
        k.f(aVar, "callback");
        k.f(request, "request");
        Call newCall = this.f14307a.newCall(request);
        bVar.b().d(new c(newCall, this));
        newCall.enqueue(new d(bVar, this, aVar));
    }

    /* renamed from: k */
    public Map c(C0192b bVar, int i10) {
        k.f(bVar, "fetchState");
        return h0.k(q.a("queue_time", String.valueOf(bVar.f14311g - bVar.f14310f)), q.a("fetch_time", String.valueOf(bVar.f14312h - bVar.f14311g)), q.a("total_time", String.valueOf(bVar.f14312h - bVar.f14310f)), q.a("image_size", String.valueOf(i10)));
    }

    /* renamed from: m */
    public void a(C0192b bVar, int i10) {
        k.f(bVar, "fetchState");
        bVar.f14312h = SystemClock.elapsedRealtime();
    }

    public b(Call.Factory factory, Executor executor, boolean z10) {
        k.f(factory, "callFactory");
        k.f(executor, "cancellationExecutor");
        this.f14307a = factory;
        this.f14308b = executor;
        this.f14309c = z10 ? new CacheControl.Builder().noStore().build() : null;
    }

    /* JADX WARNING: Illegal instructions before constructor call */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public b(okhttp3.OkHttpClient r8) {
        /*
            r7 = this;
            java.lang.String r0 = "okHttpClient"
            ak.k.f(r8, r0)
            okhttp3.Dispatcher r0 = r8.dispatcher()
            java.util.concurrent.ExecutorService r3 = r0.executorService()
            java.lang.String r0 = "okHttpClient.dispatcher().executorService()"
            ak.k.e(r3, r0)
            r4 = 0
            r5 = 4
            r6 = 0
            r1 = r7
            r2 = r8
            r1.<init>(r2, r3, r4, r5, r6)
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: i8.b.<init>(okhttp3.OkHttpClient):void");
    }
}
