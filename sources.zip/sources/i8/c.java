package i8;

import i8.b;
import okhttp3.Call;

public final /* synthetic */ class c implements Runnable {

    /* renamed from: a  reason: collision with root package name */
    public final /* synthetic */ Call f14318a;

    public /* synthetic */ c(Call call) {
        this.f14318a = call;
    }

    public final void run() {
        b.c.f(this.f14318a);
    }
}
