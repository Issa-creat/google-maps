package i8;

import ak.k;
import android.content.Context;
import m8.h;
import okhttp3.OkHttpClient;

public final class a {

    /* renamed from: a  reason: collision with root package name */
    public static final a f14305a = new a();

    private a() {
    }

    public static final h.a a(Context context, OkHttpClient okHttpClient) {
        k.f(context, "context");
        k.f(okHttpClient, "okHttpClient");
        return h.L.i(context).P(new b(okHttpClient));
    }
}
