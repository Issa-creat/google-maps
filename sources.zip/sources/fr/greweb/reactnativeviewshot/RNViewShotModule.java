package fr.greweb.reactnativeviewshot;

import android.app.Activity;
import android.content.Context;
import android.net.Uri;
import android.os.AsyncTask;
import android.util.Log;
import com.facebook.react.bridge.GuardedAsyncTask;
import com.facebook.react.bridge.Promise;
import com.facebook.react.bridge.ReactApplicationContext;
import com.facebook.react.bridge.ReactContext;
import com.facebook.react.bridge.ReactContextBaseJavaModule;
import com.facebook.react.bridge.ReactMethod;
import com.facebook.react.bridge.ReadableMap;
import com.facebook.react.uimanager.UIManagerModule;
import com.swmansion.reanimated.layoutReanimation.Snapshot;
import java.io.File;
import java.io.FilenameFilter;
import java.io.IOException;
import java.util.Collections;
import java.util.Map;
import java.util.concurrent.Executor;
import java.util.concurrent.Executors;

public class RNViewShotModule extends ReactContextBaseJavaModule {
    public static final String RNVIEW_SHOT = "RNViewShot";
    private static final String TEMP_FILE_PREFIX = "ReactNative-snapshot-image";
    private final Executor executor = Executors.newCachedThreadPool();
    private final ReactApplicationContext reactContext;

    private static class a extends GuardedAsyncTask implements FilenameFilter {

        /* renamed from: a  reason: collision with root package name */
        private final File f45731a;

        /* renamed from: b  reason: collision with root package name */
        private final File f45732b;

        private void a(File file) {
            File[] listFiles = file.listFiles(this);
            if (listFiles != null) {
                for (File file2 : listFiles) {
                    if (file2.delete()) {
                        Log.d(RNViewShotModule.RNVIEW_SHOT, "deleted file: " + file2.getAbsolutePath());
                    }
                }
            }
        }

        public final boolean accept(File file, String str) {
            return str.startsWith(RNViewShotModule.TEMP_FILE_PREFIX);
        }

        /* access modifiers changed from: protected */
        /* renamed from: b */
        public void doInBackgroundGuarded(Void... voidArr) {
            File file = this.f45731a;
            if (file != null) {
                a(file);
            }
            File file2 = this.f45732b;
            if (file2 != null) {
                a(file2);
            }
        }

        private a(ReactContext reactContext) {
            super(reactContext);
            this.f45731a = reactContext.getCacheDir();
            this.f45732b = reactContext.getExternalCacheDir();
        }
    }

    public RNViewShotModule(ReactApplicationContext reactApplicationContext) {
        super(reactApplicationContext);
        this.reactContext = reactApplicationContext;
    }

    private File createTempFile(Context context, String str, String str2) {
        File externalCacheDir = context.getExternalCacheDir();
        File cacheDir = context.getCacheDir();
        if (externalCacheDir == null && cacheDir == null) {
            throw new IOException("No cache directory available");
        }
        if (externalCacheDir == null || (cacheDir != null && externalCacheDir.getFreeSpace() <= cacheDir.getFreeSpace())) {
            externalCacheDir = cacheDir;
        }
        String str3 = "." + str;
        if (str2 != null) {
            return File.createTempFile(str2, str3, externalCacheDir);
        }
        return File.createTempFile(TEMP_FILE_PREFIX, str3, externalCacheDir);
    }

    @ReactMethod
    public void captureRef(int i10, ReadableMap readableMap, Promise promise) {
        int i11;
        Integer num;
        Integer num2;
        String str;
        boolean z10;
        int i12 = i10;
        ReadableMap readableMap2 = readableMap;
        getReactApplicationContext().getResources().getDisplayMetrics();
        String string = readableMap2.getString("format");
        if ("jpg".equals(string)) {
            i11 = 0;
        } else if ("webm".equals(string)) {
            i11 = 2;
        } else if ("raw".equals(string)) {
            i11 = -1;
        } else {
            i11 = 1;
        }
        double d10 = readableMap2.getDouble("quality");
        File file = null;
        if (readableMap2.hasKey(Snapshot.WIDTH)) {
            num = Integer.valueOf(readableMap2.getInt(Snapshot.WIDTH));
        } else {
            num = null;
        }
        if (readableMap2.hasKey(Snapshot.HEIGHT)) {
            num2 = Integer.valueOf(readableMap2.getInt(Snapshot.HEIGHT));
        } else {
            num2 = null;
        }
        String string2 = readableMap2.getString("result");
        if (readableMap2.hasKey("fileName")) {
            str = readableMap2.getString("fileName");
        } else {
            str = null;
        }
        Boolean valueOf = Boolean.valueOf(readableMap2.getBoolean("snapshotContentContainer"));
        if (!readableMap2.hasKey("handleGLSurfaceViewOnAndroid") || !readableMap2.getBoolean("handleGLSurfaceViewOnAndroid")) {
            z10 = false;
        } else {
            z10 = true;
        }
        try {
            if ("tmpfile".equals(string2)) {
                file = createTempFile(getReactApplicationContext(), string, str);
            }
            Activity currentActivity = getCurrentActivity();
            ReactApplicationContext reactApplicationContext = this.reactContext;
            boolean z11 = z10;
            Executor executor2 = this.executor;
            a aVar = r2;
            UIManagerModule uIManagerModule = (UIManagerModule) this.reactContext.getNativeModule(UIManagerModule.class);
            a aVar2 = new a(i10, string, i11, d10, num, num2, file, string2, valueOf, reactApplicationContext, currentActivity, z11, promise, executor2);
            uIManagerModule.addUIBlock(aVar);
        } catch (Throwable th2) {
            StringBuilder sb2 = new StringBuilder();
            sb2.append("Failed to snapshot view tag ");
            int i13 = i10;
            sb2.append(i13);
            Log.e(RNVIEW_SHOT, sb2.toString(), th2);
            promise.reject("E_UNABLE_TO_SNAPSHOT", "Failed to snapshot view tag " + i13);
        }
    }

    @ReactMethod
    public void captureScreen(ReadableMap readableMap, Promise promise) {
        captureRef(-1, readableMap, promise);
    }

    public Map<String, Object> getConstants() {
        return Collections.emptyMap();
    }

    public String getName() {
        return RNVIEW_SHOT;
    }

    public void onCatalystInstanceDestroy() {
        super.onCatalystInstanceDestroy();
        new a(getReactApplicationContext()).executeOnExecutor(AsyncTask.THREAD_POOL_EXECUTOR, new Void[0]);
    }

    @ReactMethod
    public void releaseCapture(String str) {
        String path = Uri.parse(str).getPath();
        if (path != null) {
            File file = new File(path);
            if (file.exists()) {
                File parentFile = file.getParentFile();
                if (parentFile.equals(this.reactContext.getExternalCacheDir()) || parentFile.equals(this.reactContext.getCacheDir())) {
                    file.delete();
                }
            }
        }
    }
}
