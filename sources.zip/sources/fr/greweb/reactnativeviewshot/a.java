package fr.greweb.reactnativeviewshot;

import android.app.Activity;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Matrix;
import android.graphics.Paint;
import android.graphics.Point;
import android.net.Uri;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;
import android.util.Base64;
import android.util.Log;
import android.view.PixelCopy;
import android.view.SurfaceView;
import android.view.TextureView;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ScrollView;
import com.facebook.react.bridge.Promise;
import com.facebook.react.bridge.ReactApplicationContext;
import com.facebook.react.uimanager.d1;
import com.facebook.react.uimanager.v;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.OutputStream;
import java.nio.ByteBuffer;
import java.nio.charset.Charset;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import java.util.Locale;
import java.util.Set;
import java.util.WeakHashMap;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.Executor;
import java.util.concurrent.TimeUnit;
import java.util.zip.Deflater;

public class a implements d1 {
    /* access modifiers changed from: private */

    /* renamed from: o  reason: collision with root package name */
    public static final String f45733o = "a";
    /* access modifiers changed from: private */

    /* renamed from: p  reason: collision with root package name */
    public static byte[] f45734p = new byte[65536];

    /* renamed from: q  reason: collision with root package name */
    private static final Object f45735q = new Object();

    /* renamed from: r  reason: collision with root package name */
    private static final Set f45736r = Collections.newSetFromMap(new WeakHashMap());
    /* access modifiers changed from: private */

    /* renamed from: a  reason: collision with root package name */
    public final int f45737a;

    /* renamed from: b  reason: collision with root package name */
    private final String f45738b;
    /* access modifiers changed from: private */

    /* renamed from: c  reason: collision with root package name */
    public final int f45739c;

    /* renamed from: d  reason: collision with root package name */
    private final double f45740d;

    /* renamed from: e  reason: collision with root package name */
    private final Integer f45741e;

    /* renamed from: f  reason: collision with root package name */
    private final Integer f45742f;

    /* renamed from: g  reason: collision with root package name */
    private final File f45743g;
    /* access modifiers changed from: private */

    /* renamed from: h  reason: collision with root package name */
    public final String f45744h;
    /* access modifiers changed from: private */

    /* renamed from: i  reason: collision with root package name */
    public final Promise f45745i;

    /* renamed from: j  reason: collision with root package name */
    private final Boolean f45746j;

    /* renamed from: k  reason: collision with root package name */
    private final ReactApplicationContext f45747k;

    /* renamed from: l  reason: collision with root package name */
    private final boolean f45748l;
    /* access modifiers changed from: private */

    /* renamed from: m  reason: collision with root package name */
    public final Activity f45749m;

    /* renamed from: n  reason: collision with root package name */
    private final Executor f45750n;

    /* renamed from: fr.greweb.reactnativeviewshot.a$a  reason: collision with other inner class name */
    class C0463a implements Runnable {

        /* renamed from: a  reason: collision with root package name */
        final /* synthetic */ v f45751a;

        C0463a(v vVar) {
            this.f45751a = vVar;
        }

        public void run() {
            View view;
            try {
                if (a.this.f45737a == -1) {
                    view = a.this.f45749m.getWindow().getDecorView().findViewById(16908290);
                } else {
                    view = this.f45751a.resolveView(a.this.f45737a);
                }
                if (view == null) {
                    String k10 = a.f45733o;
                    Log.e(k10, "No view found with reactTag: " + a.this.f45737a, new AssertionError());
                    Promise c10 = a.this.f45745i;
                    c10.reject("E_UNABLE_TO_SNAPSHOT", "No view found with reactTag: " + a.this.f45737a);
                    return;
                }
                d dVar = new d(a.f45734p);
                dVar.e(a.w(view));
                a.f45734p = dVar.d();
                if ("tmpfile".equals(a.this.f45744h) && -1 == a.this.f45739c) {
                    a.this.A(view);
                } else if (!"tmpfile".equals(a.this.f45744h) || -1 == a.this.f45739c) {
                    if (!"base64".equals(a.this.f45744h)) {
                        if (!"zip-base64".equals(a.this.f45744h)) {
                            if ("data-uri".equals(a.this.f45744h)) {
                                a.this.z(view);
                                return;
                            }
                            return;
                        }
                    }
                    a.this.y(view);
                } else {
                    a.this.B(view);
                }
            } catch (Throwable th2) {
                Log.e(a.f45733o, "Failed to capture view snapshot", th2);
                a.this.f45745i.reject("E_UNABLE_TO_SNAPSHOT", "Failed to capture view snapshot");
            }
        }
    }

    class b implements PixelCopy.OnPixelCopyFinishedListener {

        /* renamed from: a  reason: collision with root package name */
        final /* synthetic */ Canvas f45753a;

        /* renamed from: b  reason: collision with root package name */
        final /* synthetic */ View f45754b;

        /* renamed from: c  reason: collision with root package name */
        final /* synthetic */ View f45755c;

        /* renamed from: d  reason: collision with root package name */
        final /* synthetic */ Bitmap f45756d;

        /* renamed from: e  reason: collision with root package name */
        final /* synthetic */ Paint f45757e;

        /* renamed from: f  reason: collision with root package name */
        final /* synthetic */ CountDownLatch f45758f;

        b(Canvas canvas, View view, View view2, Bitmap bitmap, Paint paint, CountDownLatch countDownLatch) {
            this.f45753a = canvas;
            this.f45754b = view;
            this.f45755c = view2;
            this.f45756d = bitmap;
            this.f45757e = paint;
            this.f45758f = countDownLatch;
        }

        public void onPixelCopyFinished(int i10) {
            int save = this.f45753a.save();
            Matrix unused = a.this.p(this.f45753a, this.f45754b, this.f45755c);
            this.f45753a.drawBitmap(this.f45756d, 0.0f, 0.0f, this.f45757e);
            this.f45753a.restoreToCount(save);
            a.x(this.f45756d);
            this.f45758f.countDown();
        }
    }

    public @interface c {

        /* renamed from: a  reason: collision with root package name */
        public static final Bitmap.CompressFormat[] f45760a = {Bitmap.CompressFormat.JPEG, Bitmap.CompressFormat.PNG, Bitmap.CompressFormat.WEBP};
    }

    public static class d extends ByteArrayOutputStream {
        public d(byte[] bArr) {
            super(0);
            this.buf = bArr;
        }

        protected static int c(int i10) {
            if (i10 < 0) {
                throw new OutOfMemoryError();
            } else if (i10 > 2147483639) {
                return Integer.MAX_VALUE;
            } else {
                return 2147483639;
            }
        }

        public ByteBuffer a(int i10) {
            if (this.buf.length < i10) {
                b(i10);
            }
            return ByteBuffer.wrap(this.buf);
        }

        /* access modifiers changed from: protected */
        public void b(int i10) {
            int length = this.buf.length << 1;
            if (length - i10 < 0) {
                length = i10;
            }
            if (length - 2147483639 > 0) {
                length = c(i10);
            }
            this.buf = Arrays.copyOf(this.buf, length);
        }

        public byte[] d() {
            return this.buf;
        }

        public void e(int i10) {
            this.count = i10;
        }
    }

    public a(int i10, String str, int i11, double d10, Integer num, Integer num2, File file, String str2, Boolean bool, ReactApplicationContext reactApplicationContext, Activity activity, boolean z10, Promise promise, Executor executor) {
        this.f45737a = i10;
        this.f45738b = str;
        this.f45739c = i11;
        this.f45740d = d10;
        this.f45741e = num;
        this.f45742f = num2;
        this.f45743g = file;
        this.f45744h = str2;
        this.f45746j = bool;
        this.f45747k = reactApplicationContext;
        this.f45749m = activity;
        this.f45748l = z10;
        this.f45745i = promise;
        this.f45750n = executor;
    }

    /* access modifiers changed from: private */
    public void A(View view) {
        String uri = Uri.fromFile(this.f45743g).toString();
        FileOutputStream fileOutputStream = new FileOutputStream(this.f45743g);
        d dVar = new d(f45734p);
        Point q10 = q(view, dVar);
        f45734p = dVar.d();
        int size = dVar.size();
        fileOutputStream.write(String.format(Locale.US, "%d:%d|", new Object[]{Integer.valueOf(q10.x), Integer.valueOf(q10.y)}).getBytes(Charset.forName("US-ASCII")));
        fileOutputStream.write(f45734p, 0, size);
        fileOutputStream.close();
        this.f45745i.resolve(uri);
    }

    /* access modifiers changed from: private */
    public void B(View view) {
        q(view, new FileOutputStream(this.f45743g));
        this.f45745i.resolve(Uri.fromFile(this.f45743g).toString());
    }

    /* access modifiers changed from: private */
    public Matrix p(Canvas canvas, View view, View view2) {
        int i10;
        Matrix matrix = new Matrix();
        LinkedList linkedList = new LinkedList();
        View view3 = view2;
        do {
            linkedList.add(view3);
            view3 = (View) view3.getParent();
        } while (view3 != view);
        Collections.reverse(linkedList);
        Iterator it = linkedList.iterator();
        while (it.hasNext()) {
            View view4 = (View) it.next();
            canvas.save();
            int left = view4.getLeft();
            int i11 = 0;
            if (view4 != view2) {
                i10 = view4.getPaddingLeft();
            } else {
                i10 = 0;
            }
            float translationX = ((float) (left + i10)) + view4.getTranslationX();
            int top = view4.getTop();
            if (view4 != view2) {
                i11 = view4.getPaddingTop();
            }
            float translationY = ((float) (top + i11)) + view4.getTranslationY();
            canvas.translate(translationX, translationY);
            canvas.rotate(view4.getRotation(), view4.getPivotX(), view4.getPivotY());
            canvas.scale(view4.getScaleX(), view4.getScaleY());
            matrix.postTranslate(translationX, translationY);
            matrix.postRotate(view4.getRotation(), view4.getPivotX(), view4.getPivotY());
            matrix.postScale(view4.getScaleX(), view4.getScaleY());
        }
        return matrix;
    }

    private Point q(View view, OutputStream outputStream) {
        try {
            return r(view, outputStream);
        } finally {
            outputStream.close();
        }
    }

    private Point r(View view, OutputStream outputStream) {
        int i10;
        Bitmap bitmap;
        OutputStream outputStream2;
        Bitmap bitmap2;
        Point point;
        Canvas canvas;
        Paint paint;
        Paint paint2;
        SurfaceView surfaceView;
        View view2 = view;
        OutputStream outputStream3 = outputStream;
        int width = view.getWidth();
        int height = view.getHeight();
        if (width <= 0 || height <= 0) {
            throw new RuntimeException("Impossible to snapshot the view: view is invalid");
        }
        boolean z10 = false;
        if (this.f45746j.booleanValue()) {
            ScrollView scrollView = (ScrollView) view2;
            int i11 = 0;
            for (int i12 = 0; i12 < scrollView.getChildCount(); i12++) {
                i11 += scrollView.getChildAt(i12).getHeight();
            }
            i10 = i11;
        } else {
            i10 = height;
        }
        Point point2 = new Point(width, i10);
        Bitmap u10 = u(width, i10);
        Paint paint3 = new Paint();
        int i13 = 1;
        paint3.setAntiAlias(true);
        paint3.setFilterBitmap(true);
        paint3.setDither(true);
        Canvas canvas2 = new Canvas(u10);
        view2.draw(canvas2);
        for (View view3 : t(view)) {
            if (view3 instanceof TextureView) {
                if (view3.getVisibility() == 0) {
                    TextureView textureView = (TextureView) view3;
                    textureView.setOpaque(z10);
                    Bitmap bitmap3 = textureView.getBitmap(v(view3.getWidth(), view3.getHeight()));
                    int save = canvas2.save();
                    p(canvas2, view2, view3);
                    canvas2.drawBitmap(bitmap3, 0.0f, 0.0f, paint3);
                    canvas2.restoreToCount(save);
                    x(bitmap3);
                }
            } else if ((view3 instanceof SurfaceView) && this.f45748l) {
                SurfaceView surfaceView2 = (SurfaceView) view3;
                CountDownLatch countDownLatch = new CountDownLatch(i13);
                if (Build.VERSION.SDK_INT >= 24) {
                    Bitmap v10 = v(view3.getWidth(), view3.getHeight());
                    try {
                        b bVar = r1;
                        CountDownLatch countDownLatch2 = countDownLatch;
                        Canvas canvas3 = canvas2;
                        surfaceView = surfaceView2;
                        point = point2;
                        canvas = canvas2;
                        View view4 = view3;
                        Bitmap bitmap4 = v10;
                        paint2 = paint3;
                        bitmap2 = u10;
                        try {
                            b bVar2 = new b(canvas3, view, view4, v10, paint3, countDownLatch2);
                            PixelCopy.request(surfaceView, bitmap4, bVar, new Handler(Looper.getMainLooper()));
                            countDownLatch2.await(5, TimeUnit.SECONDS);
                        } catch (Exception e10) {
                            e = e10;
                        }
                    } catch (Exception e11) {
                        e = e11;
                        surfaceView = surfaceView2;
                        paint2 = paint3;
                        bitmap2 = u10;
                        point = point2;
                        canvas = canvas2;
                        String str = f45733o;
                        Log.e(str, "Cannot PixelCopy for " + surfaceView, e);
                        paint = paint2;
                        view2 = view;
                        OutputStream outputStream4 = outputStream;
                        paint3 = paint;
                        canvas2 = canvas;
                        point2 = point;
                        u10 = bitmap2;
                        i13 = 1;
                        z10 = false;
                    }
                } else {
                    SurfaceView surfaceView3 = surfaceView2;
                    paint2 = paint3;
                    bitmap2 = u10;
                    point = point2;
                    canvas = canvas2;
                    if (surfaceView3.getDrawingCache() != null) {
                        paint = paint2;
                        canvas.drawBitmap(surfaceView3.getDrawingCache(), 0.0f, 0.0f, paint);
                        view2 = view;
                        OutputStream outputStream42 = outputStream;
                        paint3 = paint;
                        canvas2 = canvas;
                        point2 = point;
                        u10 = bitmap2;
                        i13 = 1;
                        z10 = false;
                    }
                }
                paint = paint2;
                view2 = view;
                OutputStream outputStream422 = outputStream;
                paint3 = paint;
                canvas2 = canvas;
                point2 = point;
                u10 = bitmap2;
                i13 = 1;
                z10 = false;
            }
            paint = paint3;
            bitmap2 = u10;
            point = point2;
            canvas = canvas2;
            view2 = view;
            OutputStream outputStream4222 = outputStream;
            paint3 = paint;
            canvas2 = canvas;
            point2 = point;
            u10 = bitmap2;
            i13 = 1;
            z10 = false;
        }
        Bitmap bitmap5 = u10;
        Point point3 = point2;
        Integer num = this.f45741e;
        if (num == null || this.f45742f == null || (num.intValue() == width && this.f45742f.intValue() == i10)) {
            bitmap = bitmap5;
        } else {
            Bitmap bitmap6 = bitmap5;
            bitmap = Bitmap.createScaledBitmap(bitmap6, this.f45741e.intValue(), this.f45742f.intValue(), true);
            x(bitmap6);
        }
        int i14 = this.f45739c;
        if (-1 == i14) {
            outputStream2 = outputStream;
            if (outputStream2 instanceof d) {
                int i15 = width * i10 * 4;
                d dVar = (d) s(outputStream);
                bitmap.copyPixelsToBuffer(dVar.a(i15));
                dVar.e(i15);
                x(bitmap);
                return point3;
            }
        } else {
            outputStream2 = outputStream;
        }
        bitmap.compress(c.f45760a[i14], (int) (this.f45740d * 100.0d), outputStream2);
        x(bitmap);
        return point3;
    }

    private static Object s(Object obj) {
        return obj;
    }

    private List t(View view) {
        if (!(view instanceof ViewGroup)) {
            ArrayList arrayList = new ArrayList();
            arrayList.add(view);
            return arrayList;
        }
        ArrayList arrayList2 = new ArrayList();
        ViewGroup viewGroup = (ViewGroup) view;
        for (int i10 = 0; i10 < viewGroup.getChildCount(); i10++) {
            arrayList2.addAll(t(viewGroup.getChildAt(i10)));
        }
        return arrayList2;
    }

    private static Bitmap u(int i10, int i11) {
        synchronized (f45735q) {
            for (Bitmap bitmap : f45736r) {
                if (bitmap.getWidth() == i10 && bitmap.getHeight() == i11) {
                    f45736r.remove(bitmap);
                    bitmap.eraseColor(0);
                    return bitmap;
                }
            }
            return Bitmap.createBitmap(i10, i11, Bitmap.Config.ARGB_8888);
        }
    }

    private static Bitmap v(int i10, int i11) {
        synchronized (f45735q) {
            for (Bitmap bitmap : f45736r) {
                if (bitmap.getWidth() == i10 && bitmap.getHeight() == i11) {
                    f45736r.remove(bitmap);
                    bitmap.eraseColor(0);
                    return bitmap;
                }
            }
            return Bitmap.createBitmap(i10, i11, Bitmap.Config.ARGB_8888);
        }
    }

    /* access modifiers changed from: private */
    public static int w(View view) {
        return Math.min(view.getWidth() * view.getHeight() * 4, 32);
    }

    /* access modifiers changed from: private */
    public static void x(Bitmap bitmap) {
        synchronized (f45735q) {
            f45736r.add(bitmap);
        }
    }

    /* access modifiers changed from: private */
    public void y(View view) {
        boolean z10;
        String str;
        if (-1 == this.f45739c) {
            z10 = true;
        } else {
            z10 = false;
        }
        boolean equals = "zip-base64".equals(this.f45744h);
        d dVar = new d(f45734p);
        Point q10 = q(view, dVar);
        f45734p = dVar.d();
        int size = dVar.size();
        String format = String.format(Locale.US, "%d:%d|", new Object[]{Integer.valueOf(q10.x), Integer.valueOf(q10.y)});
        if (!z10) {
            format = "";
        }
        if (equals) {
            Deflater deflater = new Deflater();
            deflater.setInput(f45734p, 0, size);
            deflater.finish();
            d dVar2 = new d(new byte[32]);
            byte[] bArr = new byte[1024];
            while (!deflater.finished()) {
                dVar2.write(bArr, 0, deflater.deflate(bArr));
            }
            str = format + Base64.encodeToString(dVar2.d(), 0, dVar2.size(), 2);
        } else {
            str = format + Base64.encodeToString(f45734p, 0, size, 2);
        }
        this.f45745i.resolve(str);
    }

    /* access modifiers changed from: private */
    public void z(View view) {
        String str;
        d dVar = new d(f45734p);
        q(view, dVar);
        f45734p = dVar.d();
        String encodeToString = Base64.encodeToString(f45734p, 0, dVar.size(), 2);
        if ("jpg".equals(this.f45738b)) {
            str = "jpeg";
        } else {
            str = this.f45738b;
        }
        Promise promise = this.f45745i;
        promise.resolve("data:image/" + str + ";base64," + encodeToString);
    }

    public void execute(v vVar) {
        this.f45750n.execute(new C0463a(vVar));
    }
}
