package rm;

public interface c {
    byte[] getEncoded();
}
