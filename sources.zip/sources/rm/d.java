package rm;

public abstract class d {
    public static Integer a(int i10) {
        return Integer.valueOf(i10);
    }
}
