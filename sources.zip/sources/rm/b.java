package rm;

import java.math.BigInteger;

public abstract class b {

    /* renamed from: a  reason: collision with root package name */
    public static final BigInteger f48764a = BigInteger.valueOf(0);

    /* renamed from: b  reason: collision with root package name */
    public static final BigInteger f48765b = BigInteger.valueOf(1);

    /* renamed from: c  reason: collision with root package name */
    public static final BigInteger f48766c = BigInteger.valueOf(2);

    /* renamed from: d  reason: collision with root package name */
    private static final BigInteger f48767d = BigInteger.valueOf(3);

    /* renamed from: e  reason: collision with root package name */
    private static final BigInteger f48768e = new BigInteger("8138e8a0fcf3a4e84a771d40fd305d7f4aa59306d7251de54d98af8fe95729a1f73d893fa424cd2edc8636a6c3285e022b0e3866a565ae8108eed8591cd4fe8d2ce86165a978d719ebf647f362d33fca29cd179fb42401cbaf3df0c614056f9c8f3cfd51e474afb6bc6974f78db8aba8e9e517fded658591ab7502bd41849462f", 16);

    /* renamed from: f  reason: collision with root package name */
    private static final int f48769f = BigInteger.valueOf(743).bitLength();
}
