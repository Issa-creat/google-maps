package c1;

import android.database.SQLException;
import java.io.IOException;

public final class a extends IOException {
    public a(SQLException sQLException) {
        super(sQLException);
    }
}
