package c1;

import android.database.sqlite.SQLiteDatabase;

public interface b {
    SQLiteDatabase getReadableDatabase();

    SQLiteDatabase getWritableDatabase();
}
