package h1;

import androidx.media3.common.util.r;
import h1.c;
import java.io.IOException;
import s1.b0;
import s1.y;

public final /* synthetic */ class s0 implements r.a {

    /* renamed from: a  reason: collision with root package name */
    public final /* synthetic */ c.a f13298a;

    /* renamed from: b  reason: collision with root package name */
    public final /* synthetic */ y f13299b;

    /* renamed from: c  reason: collision with root package name */
    public final /* synthetic */ b0 f13300c;

    /* renamed from: d  reason: collision with root package name */
    public final /* synthetic */ IOException f13301d;

    /* renamed from: e  reason: collision with root package name */
    public final /* synthetic */ boolean f13302e;

    public /* synthetic */ s0(c.a aVar, y yVar, b0 b0Var, IOException iOException, boolean z10) {
        this.f13298a = aVar;
        this.f13299b = yVar;
        this.f13300c = b0Var;
        this.f13301d = iOException;
        this.f13302e = z10;
    }

    public final void invoke(Object obj) {
        ((c) obj).r0(this.f13298a, this.f13299b, this.f13300c, this.f13301d, this.f13302e);
    }
}
