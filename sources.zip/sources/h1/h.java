package h1;

import androidx.media3.common.util.r;
import h1.c;

public final /* synthetic */ class h implements r.a {

    /* renamed from: a  reason: collision with root package name */
    public final /* synthetic */ c.a f13223a;

    /* renamed from: b  reason: collision with root package name */
    public final /* synthetic */ int f13224b;

    /* renamed from: c  reason: collision with root package name */
    public final /* synthetic */ long f13225c;

    /* renamed from: d  reason: collision with root package name */
    public final /* synthetic */ long f13226d;

    public /* synthetic */ h(c.a aVar, int i10, long j10, long j11) {
        this.f13223a = aVar;
        this.f13224b = i10;
        this.f13225c = j10;
        this.f13226d = j11;
    }

    public final void invoke(Object obj) {
        ((c) obj).E(this.f13223a, this.f13224b, this.f13225c, this.f13226d);
    }
}
