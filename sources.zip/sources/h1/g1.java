package h1;

import androidx.media3.common.util.r;
import h1.c;

public final /* synthetic */ class g1 implements r.a {

    /* renamed from: a  reason: collision with root package name */
    public final /* synthetic */ c.a f13220a;

    /* renamed from: b  reason: collision with root package name */
    public final /* synthetic */ boolean f13221b;

    /* renamed from: c  reason: collision with root package name */
    public final /* synthetic */ int f13222c;

    public /* synthetic */ g1(c.a aVar, boolean z10, int i10) {
        this.f13220a = aVar;
        this.f13221b = z10;
        this.f13222c = i10;
    }

    public final void invoke(Object obj) {
        ((c) obj).n0(this.f13220a, this.f13221b, this.f13222c);
    }
}
