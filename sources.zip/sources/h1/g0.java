package h1;

import androidx.media3.common.util.r;
import h1.c;
import y0.e0;

public final /* synthetic */ class g0 implements r.a {

    /* renamed from: a  reason: collision with root package name */
    public final /* synthetic */ c.a f13217a;

    /* renamed from: b  reason: collision with root package name */
    public final /* synthetic */ e0 f13218b;

    /* renamed from: c  reason: collision with root package name */
    public final /* synthetic */ int f13219c;

    public /* synthetic */ g0(c.a aVar, e0 e0Var, int i10) {
        this.f13217a = aVar;
        this.f13218b = e0Var;
        this.f13219c = i10;
    }

    public final void invoke(Object obj) {
        ((c) obj).n(this.f13217a, this.f13218b, this.f13219c);
    }
}
