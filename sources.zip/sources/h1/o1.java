package h1;

import androidx.media3.common.util.r;
import androidx.media3.exoplayer.audio.a0;
import h1.c;

public final /* synthetic */ class o1 implements r.a {

    /* renamed from: a  reason: collision with root package name */
    public final /* synthetic */ c.a f13273a;

    /* renamed from: b  reason: collision with root package name */
    public final /* synthetic */ a0.a f13274b;

    public /* synthetic */ o1(c.a aVar, a0.a aVar2) {
        this.f13273a = aVar;
        this.f13274b = aVar2;
    }

    public final void invoke(Object obj) {
        ((c) obj).Z(this.f13273a, this.f13274b);
    }
}
