package h1;

import androidx.media3.common.util.r;
import androidx.media3.exoplayer.audio.a0;
import h1.c;

public final /* synthetic */ class k1 implements r.a {

    /* renamed from: a  reason: collision with root package name */
    public final /* synthetic */ c.a f13250a;

    /* renamed from: b  reason: collision with root package name */
    public final /* synthetic */ a0.a f13251b;

    public /* synthetic */ k1(c.a aVar, a0.a aVar2) {
        this.f13250a = aVar;
        this.f13251b = aVar2;
    }

    public final void invoke(Object obj) {
        ((c) obj).A(this.f13250a, this.f13251b);
    }
}
