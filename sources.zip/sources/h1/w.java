package h1;

import androidx.media3.common.util.r;
import h1.c;
import y0.q0;

public final /* synthetic */ class w implements r.a {

    /* renamed from: a  reason: collision with root package name */
    public final /* synthetic */ c.a f13333a;

    /* renamed from: b  reason: collision with root package name */
    public final /* synthetic */ q0 f13334b;

    public /* synthetic */ w(c.a aVar, q0 q0Var) {
        this.f13333a = aVar;
        this.f13334b = q0Var;
    }

    public final void invoke(Object obj) {
        ((c) obj).e0(this.f13333a, this.f13334b);
    }
}
