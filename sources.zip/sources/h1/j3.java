package h1;

public abstract /* synthetic */ class j3 {
}
