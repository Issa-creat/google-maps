package h1;

import androidx.media3.common.util.r;
import h1.c;
import s1.b0;
import s1.y;

public final /* synthetic */ class e1 implements r.a {

    /* renamed from: a  reason: collision with root package name */
    public final /* synthetic */ c.a f13206a;

    /* renamed from: b  reason: collision with root package name */
    public final /* synthetic */ y f13207b;

    /* renamed from: c  reason: collision with root package name */
    public final /* synthetic */ b0 f13208c;

    public /* synthetic */ e1(c.a aVar, y yVar, b0 b0Var) {
        this.f13206a = aVar;
        this.f13207b = yVar;
        this.f13208c = b0Var;
    }

    public final void invoke(Object obj) {
        ((c) obj).s0(this.f13206a, this.f13207b, this.f13208c);
    }
}
