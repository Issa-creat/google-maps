package h1;

import androidx.media3.common.util.r;
import h1.c;
import y0.s0;

public final /* synthetic */ class j implements r.a {

    /* renamed from: a  reason: collision with root package name */
    public final /* synthetic */ c.a f13237a;

    /* renamed from: b  reason: collision with root package name */
    public final /* synthetic */ int f13238b;

    /* renamed from: c  reason: collision with root package name */
    public final /* synthetic */ s0.e f13239c;

    /* renamed from: d  reason: collision with root package name */
    public final /* synthetic */ s0.e f13240d;

    public /* synthetic */ j(c.a aVar, int i10, s0.e eVar, s0.e eVar2) {
        this.f13237a = aVar;
        this.f13238b = i10;
        this.f13239c = eVar;
        this.f13240d = eVar2;
    }

    public final void invoke(Object obj) {
        v1.R2(this.f13237a, this.f13238b, this.f13239c, this.f13240d, (c) obj);
    }
}
