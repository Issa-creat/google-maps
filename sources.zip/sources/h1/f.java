package h1;

import androidx.media3.common.util.r;
import h1.c;

public final /* synthetic */ class f implements r.a {

    /* renamed from: a  reason: collision with root package name */
    public final /* synthetic */ c.a f13209a;

    /* renamed from: b  reason: collision with root package name */
    public final /* synthetic */ int f13210b;

    public /* synthetic */ f(c.a aVar, int i10) {
        this.f13209a = aVar;
        this.f13210b = i10;
    }

    public final void invoke(Object obj) {
        ((c) obj).S(this.f13209a, this.f13210b);
    }
}
