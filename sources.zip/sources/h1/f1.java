package h1;

import androidx.media3.common.util.r;
import h1.c;
import y0.p1;

public final /* synthetic */ class f1 implements r.a {

    /* renamed from: a  reason: collision with root package name */
    public final /* synthetic */ c.a f13213a;

    /* renamed from: b  reason: collision with root package name */
    public final /* synthetic */ p1 f13214b;

    public /* synthetic */ f1(c.a aVar, p1 p1Var) {
        this.f13213a = aVar;
        this.f13214b = p1Var;
    }

    public final void invoke(Object obj) {
        v1.k3(this.f13213a, this.f13214b, (c) obj);
    }
}
