package h1;

import androidx.media3.common.util.r;
import h1.c;

public final /* synthetic */ class j1 implements r.a {

    /* renamed from: a  reason: collision with root package name */
    public final /* synthetic */ c.a f13244a;

    /* renamed from: b  reason: collision with root package name */
    public final /* synthetic */ long f13245b;

    public /* synthetic */ j1(c.a aVar, long j10) {
        this.f13244a = aVar;
        this.f13245b = j10;
    }

    public final void invoke(Object obj) {
        ((c) obj).t(this.f13244a, this.f13245b);
    }
}
