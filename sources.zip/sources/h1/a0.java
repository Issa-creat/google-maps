package h1;

import androidx.media3.common.util.r;
import androidx.media3.exoplayer.n;
import h1.c;

public final /* synthetic */ class a0 implements r.a {

    /* renamed from: a  reason: collision with root package name */
    public final /* synthetic */ c.a f13135a;

    /* renamed from: b  reason: collision with root package name */
    public final /* synthetic */ n f13136b;

    public /* synthetic */ a0(c.a aVar, n nVar) {
        this.f13135a = aVar;
        this.f13136b = nVar;
    }

    public final void invoke(Object obj) {
        ((c) obj).k(this.f13135a, this.f13136b);
    }
}
