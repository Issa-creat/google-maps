package h1;

import android.media.metrics.PlaybackErrorEvent;

public abstract /* synthetic */ class y1 {
    public static /* synthetic */ PlaybackErrorEvent.Builder a() {
        return new PlaybackErrorEvent.Builder();
    }
}
