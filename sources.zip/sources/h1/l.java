package h1;

import androidx.media3.common.util.r;
import h1.c;
import y0.q;

public final /* synthetic */ class l implements r.a {

    /* renamed from: a  reason: collision with root package name */
    public final /* synthetic */ c.a f13252a;

    /* renamed from: b  reason: collision with root package name */
    public final /* synthetic */ q f13253b;

    public /* synthetic */ l(c.a aVar, q qVar) {
        this.f13252a = aVar;
        this.f13253b = qVar;
    }

    public final void invoke(Object obj) {
        ((c) obj).x(this.f13252a, this.f13253b);
    }
}
