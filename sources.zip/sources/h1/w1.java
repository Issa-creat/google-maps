package h1;

import ge.s;

public final /* synthetic */ class w1 implements s {
    public final Object get() {
        return x1.m();
    }
}
