package h1;

import androidx.media3.common.util.r;
import h1.c;

public final /* synthetic */ class r0 implements r.a {

    /* renamed from: a  reason: collision with root package name */
    public final /* synthetic */ c.a f13288a;

    /* renamed from: b  reason: collision with root package name */
    public final /* synthetic */ int f13289b;

    /* renamed from: c  reason: collision with root package name */
    public final /* synthetic */ int f13290c;

    public /* synthetic */ r0(c.a aVar, int i10, int i11) {
        this.f13288a = aVar;
        this.f13289b = i10;
        this.f13290c = i11;
    }

    public final void invoke(Object obj) {
        ((c) obj).c(this.f13288a, this.f13289b, this.f13290c);
    }
}
