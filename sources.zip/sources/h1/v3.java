package h1;

import android.media.metrics.MediaMetricsManager;

public abstract /* synthetic */ class v3 {
    public static /* bridge */ /* synthetic */ MediaMetricsManager a(Object obj) {
        return (MediaMetricsManager) obj;
    }
}
