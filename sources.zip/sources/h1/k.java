package h1;

import androidx.media3.common.util.r;
import h1.c;
import y0.s0;

public final /* synthetic */ class k implements r.a {

    /* renamed from: a  reason: collision with root package name */
    public final /* synthetic */ c.a f13246a;

    /* renamed from: b  reason: collision with root package name */
    public final /* synthetic */ s0.b f13247b;

    public /* synthetic */ k(c.a aVar, s0.b bVar) {
        this.f13246a = aVar;
        this.f13247b = bVar;
    }

    public final void invoke(Object obj) {
        ((c) obj).a0(this.f13246a, this.f13247b);
    }
}
