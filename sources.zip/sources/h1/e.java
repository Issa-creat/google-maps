package h1;

import androidx.media3.common.util.r;
import y0.v;

public final /* synthetic */ class e implements r.b {
    public final void a(Object obj, v vVar) {
        v1.X1((c) obj, vVar);
    }
}
