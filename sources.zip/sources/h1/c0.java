package h1;

import androidx.media3.common.util.r;
import h1.c;

public final /* synthetic */ class c0 implements r.a {

    /* renamed from: a  reason: collision with root package name */
    public final /* synthetic */ c.a f13186a;

    /* renamed from: b  reason: collision with root package name */
    public final /* synthetic */ boolean f13187b;

    /* renamed from: c  reason: collision with root package name */
    public final /* synthetic */ int f13188c;

    public /* synthetic */ c0(c.a aVar, boolean z10, int i10) {
        this.f13186a = aVar;
        this.f13187b = z10;
        this.f13188c = i10;
    }

    public final void invoke(Object obj) {
        ((c) obj).j(this.f13186a, this.f13187b, this.f13188c);
    }
}
