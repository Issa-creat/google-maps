package h1;

import androidx.media3.common.util.r;
import h1.c;

public final /* synthetic */ class n1 implements r.a {

    /* renamed from: a  reason: collision with root package name */
    public final /* synthetic */ c.a f13266a;

    /* renamed from: b  reason: collision with root package name */
    public final /* synthetic */ long f13267b;

    public /* synthetic */ n1(c.a aVar, long j10) {
        this.f13266a = aVar;
        this.f13267b = j10;
    }

    public final void invoke(Object obj) {
        ((c) obj).c0(this.f13266a, this.f13267b);
    }
}
