package h1;

import androidx.media3.common.util.r;
import h1.c;
import s1.b0;
import s1.y;

public final /* synthetic */ class d1 implements r.a {

    /* renamed from: a  reason: collision with root package name */
    public final /* synthetic */ c.a f13201a;

    /* renamed from: b  reason: collision with root package name */
    public final /* synthetic */ y f13202b;

    /* renamed from: c  reason: collision with root package name */
    public final /* synthetic */ b0 f13203c;

    public /* synthetic */ d1(c.a aVar, y yVar, b0 b0Var) {
        this.f13201a = aVar;
        this.f13202b = yVar;
        this.f13203c = b0Var;
    }

    public final void invoke(Object obj) {
        ((c) obj).f(this.f13201a, this.f13202b, this.f13203c);
    }
}
