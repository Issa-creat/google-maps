package h1;

import android.media.metrics.TrackChangeEvent;

public abstract /* synthetic */ class j2 {
    public static /* synthetic */ TrackChangeEvent.Builder a(int i10) {
        return new TrackChangeEvent.Builder(i10);
    }
}
