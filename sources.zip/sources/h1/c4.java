package h1;

import android.media.metrics.LogSessionId;
import androidx.media3.common.util.b1;
import java.util.Objects;

public final class c4 {

    /* renamed from: d  reason: collision with root package name */
    public static final c4 f13190d;

    /* renamed from: a  reason: collision with root package name */
    public final String f13191a;

    /* renamed from: b  reason: collision with root package name */
    private final a f13192b;

    /* renamed from: c  reason: collision with root package name */
    private final Object f13193c;

    private static final class a {

        /* renamed from: b  reason: collision with root package name */
        public static final a f13194b = new a(LogSessionId.LOG_SESSION_ID_NONE);

        /* renamed from: a  reason: collision with root package name */
        public final LogSessionId f13195a;

        public a(LogSessionId logSessionId) {
            this.f13195a = logSessionId;
        }
    }

    static {
        c4 c4Var;
        if (b1.f3695a < 31) {
            c4Var = new c4("");
        } else {
            c4Var = new c4(a.f13194b, "");
        }
        f13190d = c4Var;
    }

    public c4(String str) {
        androidx.media3.common.util.a.g(b1.f3695a < 31);
        this.f13191a = str;
        this.f13192b = null;
        this.f13193c = new Object();
    }

    public LogSessionId a() {
        return ((a) androidx.media3.common.util.a.e(this.f13192b)).f13195a;
    }

    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (!(obj instanceof c4)) {
            return false;
        }
        c4 c4Var = (c4) obj;
        if (!Objects.equals(this.f13191a, c4Var.f13191a) || !Objects.equals(this.f13192b, c4Var.f13192b) || !Objects.equals(this.f13193c, c4Var.f13193c)) {
            return false;
        }
        return true;
    }

    public int hashCode() {
        return Objects.hash(new Object[]{this.f13191a, this.f13192b, this.f13193c});
    }

    public c4(LogSessionId logSessionId, String str) {
        this(new a(logSessionId), str);
    }

    private c4(a aVar, String str) {
        this.f13192b = aVar;
        this.f13191a = str;
        this.f13193c = new Object();
    }
}
