package h1;

import a1.d;
import androidx.media3.exoplayer.audio.a0;
import androidx.media3.exoplayer.n;
import androidx.media3.exoplayer.o;
import h1.c;
import java.util.List;
import s1.b0;
import s1.y;
import y0.e;
import y0.e0;
import y0.h1;
import y0.k0;
import y0.l0;
import y0.l1;
import y0.q;
import y0.q0;
import y0.r0;
import y0.s0;

public abstract /* synthetic */ class b {
    public static void A(c cVar, s0 s0Var, c.b bVar) {
    }

    public static void B(c cVar, c.a aVar, boolean z10) {
    }

    public static void C(c cVar, c.a aVar, boolean z10) {
    }

    public static void D(c cVar, c.a aVar, y yVar, b0 b0Var) {
    }

    public static void E(c cVar, c.a aVar, y yVar, b0 b0Var) {
    }

    public static void F(c cVar, c.a aVar, y yVar, b0 b0Var) {
    }

    public static void G(c cVar, c.a aVar, boolean z10) {
    }

    public static void H(c cVar, c.a aVar, long j10) {
    }

    public static void I(c cVar, c.a aVar, e0 e0Var, int i10) {
    }

    public static void J(c cVar, c.a aVar, k0 k0Var) {
    }

    public static void K(c cVar, c.a aVar, l0 l0Var) {
    }

    public static void L(c cVar, c.a aVar, boolean z10, int i10) {
    }

    public static void M(c cVar, c.a aVar, r0 r0Var) {
    }

    public static void N(c cVar, c.a aVar, int i10) {
    }

    public static void O(c cVar, c.a aVar, int i10) {
    }

    public static void P(c cVar, c.a aVar, q0 q0Var) {
    }

    public static void Q(c cVar, c.a aVar) {
    }

    public static void R(c cVar, c.a aVar, boolean z10, int i10) {
    }

    public static void S(c cVar, c.a aVar, k0 k0Var) {
    }

    public static void T(c cVar, c.a aVar, int i10) {
    }

    public static void U(c cVar, c.a aVar, Object obj, long j10) {
    }

    public static void V(c cVar, c.a aVar, int i10) {
    }

    public static void W(c cVar, c.a aVar, long j10) {
    }

    public static void X(c cVar, c.a aVar, long j10) {
    }

    public static void Y(c cVar, c.a aVar) {
    }

    public static void Z(c cVar, c.a aVar, boolean z10) {
    }

    public static void a(c cVar, c.a aVar, e eVar) {
    }

    public static void a0(c cVar, c.a aVar, boolean z10) {
    }

    public static void b(c cVar, c.a aVar, Exception exc) {
    }

    public static void b0(c cVar, c.a aVar, int i10, int i11) {
    }

    public static void c(c cVar, c.a aVar, String str, long j10) {
    }

    public static void c0(c cVar, c.a aVar, int i10) {
    }

    public static void d(c cVar, c.a aVar, String str, long j10, long j11) {
    }

    public static void d0(c cVar, c.a aVar, h1 h1Var) {
    }

    public static void e(c cVar, c.a aVar, String str) {
    }

    public static void e0(c cVar, c.a aVar, l1 l1Var) {
    }

    public static void f(c cVar, c.a aVar, n nVar) {
    }

    public static void f0(c cVar, c.a aVar, b0 b0Var) {
    }

    public static void g(c cVar, c.a aVar, n nVar) {
    }

    public static void g0(c cVar, c.a aVar, Exception exc) {
    }

    public static void h(c cVar, c.a aVar, y0.y yVar, o oVar) {
    }

    public static void h0(c cVar, c.a aVar, String str, long j10) {
    }

    public static void i(c cVar, c.a aVar, long j10) {
    }

    public static void i0(c cVar, c.a aVar, String str, long j10, long j11) {
    }

    public static void j(c cVar, c.a aVar, Exception exc) {
    }

    public static void j0(c cVar, c.a aVar, String str) {
    }

    public static void k(c cVar, c.a aVar, a0.a aVar2) {
    }

    public static void k0(c cVar, c.a aVar, n nVar) {
    }

    public static void l(c cVar, c.a aVar, a0.a aVar2) {
    }

    public static void l0(c cVar, c.a aVar, long j10, int i10) {
    }

    public static void m(c cVar, c.a aVar, int i10, long j10, long j11) {
    }

    public static void m0(c cVar, c.a aVar, y0.y yVar, o oVar) {
    }

    public static void n(c cVar, c.a aVar, s0.b bVar) {
    }

    public static void n0(c cVar, c.a aVar, int i10, int i11, int i12, float f10) {
    }

    public static void o(c cVar, c.a aVar, d dVar) {
    }

    public static void o0(c cVar, c.a aVar, float f10) {
    }

    public static void p(c cVar, c.a aVar, List list) {
    }

    public static void q(c cVar, c.a aVar, q qVar) {
    }

    public static void r(c cVar, c.a aVar, int i10, boolean z10) {
    }

    public static void s(c cVar, c.a aVar) {
    }

    public static void t(c cVar, c.a aVar) {
    }

    public static void u(c cVar, c.a aVar) {
    }

    public static void v(c cVar, c.a aVar) {
    }

    public static void w(c cVar, c.a aVar, int i10) {
    }

    public static void x(c cVar, c.a aVar, Exception exc) {
    }

    public static void y(c cVar, c.a aVar) {
    }

    public static void z(c cVar, c.a aVar, int i10, long j10) {
    }
}
