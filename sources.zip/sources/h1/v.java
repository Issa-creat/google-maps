package h1;

import androidx.media3.common.util.r;
import androidx.media3.exoplayer.n;
import h1.c;

public final /* synthetic */ class v implements r.a {

    /* renamed from: a  reason: collision with root package name */
    public final /* synthetic */ c.a f13318a;

    /* renamed from: b  reason: collision with root package name */
    public final /* synthetic */ n f13319b;

    public /* synthetic */ v(c.a aVar, n nVar) {
        this.f13318a = aVar;
        this.f13319b = nVar;
    }

    public final void invoke(Object obj) {
        ((c) obj).R(this.f13318a, this.f13319b);
    }
}
