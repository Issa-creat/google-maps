package h1;

import android.media.MediaDrmResetException;

public abstract /* synthetic */ class u3 {
    public static /* bridge */ /* synthetic */ boolean a(Object obj) {
        return obj instanceof MediaDrmResetException;
    }
}
