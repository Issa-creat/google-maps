package h1;

import androidx.media3.common.util.r;
import h1.c;

public final /* synthetic */ class o0 implements r.a {

    /* renamed from: a  reason: collision with root package name */
    public final /* synthetic */ c.a f13271a;

    /* renamed from: b  reason: collision with root package name */
    public final /* synthetic */ long f13272b;

    public /* synthetic */ o0(c.a aVar, long j10) {
        this.f13271a = aVar;
        this.f13272b = j10;
    }

    public final void invoke(Object obj) {
        ((c) obj).I(this.f13271a, this.f13272b);
    }
}
