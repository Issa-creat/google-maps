package h1;

public abstract /* synthetic */ class i3 {
}
