package h1;

import android.media.metrics.PlaybackStateEvent;

public abstract /* synthetic */ class f3 {
    public static /* synthetic */ PlaybackStateEvent.Builder a() {
        return new PlaybackStateEvent.Builder();
    }
}
