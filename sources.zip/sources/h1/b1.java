package h1;

import androidx.media3.common.util.r;
import h1.c;
import y0.k0;

public final /* synthetic */ class b1 implements r.a {

    /* renamed from: a  reason: collision with root package name */
    public final /* synthetic */ c.a f13172a;

    /* renamed from: b  reason: collision with root package name */
    public final /* synthetic */ k0 f13173b;

    public /* synthetic */ b1(c.a aVar, k0 k0Var) {
        this.f13172a = aVar;
        this.f13173b = k0Var;
    }

    public final void invoke(Object obj) {
        ((c) obj).F(this.f13172a, this.f13173b);
    }
}
