package h1;

import androidx.media3.common.util.r;
import h1.c;
import y0.l1;

public final /* synthetic */ class m implements r.a {

    /* renamed from: a  reason: collision with root package name */
    public final /* synthetic */ c.a f13258a;

    /* renamed from: b  reason: collision with root package name */
    public final /* synthetic */ l1 f13259b;

    public /* synthetic */ m(c.a aVar, l1 l1Var) {
        this.f13258a = aVar;
        this.f13259b = l1Var;
    }

    public final void invoke(Object obj) {
        ((c) obj).N(this.f13258a, this.f13259b);
    }
}
