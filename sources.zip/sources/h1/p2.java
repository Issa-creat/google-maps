package h1;

public abstract /* synthetic */ class p2 {
}
