package h1;

import androidx.media3.common.util.r;
import h1.c;

public final /* synthetic */ class s implements r.a {

    /* renamed from: a  reason: collision with root package name */
    public final /* synthetic */ c.a f13294a;

    /* renamed from: b  reason: collision with root package name */
    public final /* synthetic */ String f13295b;

    /* renamed from: c  reason: collision with root package name */
    public final /* synthetic */ long f13296c;

    /* renamed from: d  reason: collision with root package name */
    public final /* synthetic */ long f13297d;

    public /* synthetic */ s(c.a aVar, String str, long j10, long j11) {
        this.f13294a = aVar;
        this.f13295b = str;
        this.f13296c = j10;
        this.f13297d = j11;
    }

    public final void invoke(Object obj) {
        v1.e3(this.f13294a, this.f13295b, this.f13296c, this.f13297d, (c) obj);
    }
}
