package h1;

import androidx.media3.common.util.r;
import h1.c;

public final /* synthetic */ class y implements r.a {

    /* renamed from: a  reason: collision with root package name */
    public final /* synthetic */ c.a f13359a;

    /* renamed from: b  reason: collision with root package name */
    public final /* synthetic */ String f13360b;

    /* renamed from: c  reason: collision with root package name */
    public final /* synthetic */ long f13361c;

    /* renamed from: d  reason: collision with root package name */
    public final /* synthetic */ long f13362d;

    public /* synthetic */ y(c.a aVar, String str, long j10, long j11) {
        this.f13359a = aVar;
        this.f13360b = str;
        this.f13361c = j10;
        this.f13362d = j11;
    }

    public final void invoke(Object obj) {
        v1.b2(this.f13359a, this.f13360b, this.f13361c, this.f13362d, (c) obj);
    }
}
