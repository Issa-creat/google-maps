package h1;

import androidx.media3.common.util.r;
import h1.c;
import y0.r0;

public final /* synthetic */ class u1 implements r.a {

    /* renamed from: a  reason: collision with root package name */
    public final /* synthetic */ c.a f13316a;

    /* renamed from: b  reason: collision with root package name */
    public final /* synthetic */ r0 f13317b;

    public /* synthetic */ u1(c.a aVar, r0 r0Var) {
        this.f13316a = aVar;
        this.f13317b = r0Var;
    }

    public final void invoke(Object obj) {
        ((c) obj).v(this.f13316a, this.f13317b);
    }
}
