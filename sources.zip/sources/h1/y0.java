package h1;

import androidx.media3.common.util.r;
import h1.c;
import y0.h1;

public final /* synthetic */ class y0 implements r.a {

    /* renamed from: a  reason: collision with root package name */
    public final /* synthetic */ c.a f13363a;

    /* renamed from: b  reason: collision with root package name */
    public final /* synthetic */ h1 f13364b;

    public /* synthetic */ y0(c.a aVar, h1 h1Var) {
        this.f13363a = aVar;
        this.f13364b = h1Var;
    }

    public final void invoke(Object obj) {
        ((c) obj).D(this.f13363a, this.f13364b);
    }
}
