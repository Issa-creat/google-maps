package h1;

import androidx.media3.common.util.r;
import h1.c;
import y0.l0;

public final /* synthetic */ class x implements r.a {

    /* renamed from: a  reason: collision with root package name */
    public final /* synthetic */ c.a f13339a;

    /* renamed from: b  reason: collision with root package name */
    public final /* synthetic */ l0 f13340b;

    public /* synthetic */ x(c.a aVar, l0 l0Var) {
        this.f13339a = aVar;
        this.f13340b = l0Var;
    }

    public final void invoke(Object obj) {
        ((c) obj).z(this.f13339a, this.f13340b);
    }
}
