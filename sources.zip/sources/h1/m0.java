package h1;

import androidx.media3.common.util.r;
import h1.c;
import y0.e;

public final /* synthetic */ class m0 implements r.a {

    /* renamed from: a  reason: collision with root package name */
    public final /* synthetic */ c.a f13260a;

    /* renamed from: b  reason: collision with root package name */
    public final /* synthetic */ e f13261b;

    public /* synthetic */ m0(c.a aVar, e eVar) {
        this.f13260a = aVar;
        this.f13261b = eVar;
    }

    public final void invoke(Object obj) {
        ((c) obj).m(this.f13260a, this.f13261b);
    }
}
