package h1;

import a1.d;
import android.util.SparseArray;
import androidx.media3.exoplayer.audio.a0;
import androidx.media3.exoplayer.n;
import androidx.media3.exoplayer.o;
import ge.j;
import java.io.IOException;
import java.util.List;
import s1.b0;
import s1.f0;
import y0.c1;
import y0.e;
import y0.e0;
import y0.h1;
import y0.k0;
import y0.l0;
import y0.l1;
import y0.p1;
import y0.q;
import y0.q0;
import y0.r0;
import y0.s0;
import y0.v;
import y0.y;

public interface c {

    public static final class a {

        /* renamed from: a  reason: collision with root package name */
        public final long f13174a;

        /* renamed from: b  reason: collision with root package name */
        public final c1 f13175b;

        /* renamed from: c  reason: collision with root package name */
        public final int f13176c;

        /* renamed from: d  reason: collision with root package name */
        public final f0.b f13177d;

        /* renamed from: e  reason: collision with root package name */
        public final long f13178e;

        /* renamed from: f  reason: collision with root package name */
        public final c1 f13179f;

        /* renamed from: g  reason: collision with root package name */
        public final int f13180g;

        /* renamed from: h  reason: collision with root package name */
        public final f0.b f13181h;

        /* renamed from: i  reason: collision with root package name */
        public final long f13182i;

        /* renamed from: j  reason: collision with root package name */
        public final long f13183j;

        public a(long j10, c1 c1Var, int i10, f0.b bVar, long j11, c1 c1Var2, int i11, f0.b bVar2, long j12, long j13) {
            this.f13174a = j10;
            this.f13175b = c1Var;
            this.f13176c = i10;
            this.f13177d = bVar;
            this.f13178e = j11;
            this.f13179f = c1Var2;
            this.f13180g = i11;
            this.f13181h = bVar2;
            this.f13182i = j12;
            this.f13183j = j13;
        }

        public boolean equals(Object obj) {
            if (this == obj) {
                return true;
            }
            if (obj == null || a.class != obj.getClass()) {
                return false;
            }
            a aVar = (a) obj;
            if (this.f13174a == aVar.f13174a && this.f13176c == aVar.f13176c && this.f13178e == aVar.f13178e && this.f13180g == aVar.f13180g && this.f13182i == aVar.f13182i && this.f13183j == aVar.f13183j && j.a(this.f13175b, aVar.f13175b) && j.a(this.f13177d, aVar.f13177d) && j.a(this.f13179f, aVar.f13179f) && j.a(this.f13181h, aVar.f13181h)) {
                return true;
            }
            return false;
        }

        public int hashCode() {
            return j.b(Long.valueOf(this.f13174a), this.f13175b, Integer.valueOf(this.f13176c), this.f13177d, Long.valueOf(this.f13178e), this.f13179f, Integer.valueOf(this.f13180g), this.f13181h, Long.valueOf(this.f13182i), Long.valueOf(this.f13183j));
        }
    }

    public static final class b {

        /* renamed from: a  reason: collision with root package name */
        private final v f13184a;

        /* renamed from: b  reason: collision with root package name */
        private final SparseArray f13185b;

        public b(v vVar, SparseArray sparseArray) {
            this.f13184a = vVar;
            SparseArray sparseArray2 = new SparseArray(vVar.d());
            for (int i10 = 0; i10 < vVar.d(); i10++) {
                int c10 = vVar.c(i10);
                sparseArray2.append(c10, (a) androidx.media3.common.util.a.e((a) sparseArray.get(c10)));
            }
            this.f13185b = sparseArray2;
        }

        public boolean a(int i10) {
            return this.f13184a.a(i10);
        }

        public int b(int i10) {
            return this.f13184a.c(i10);
        }

        public a c(int i10) {
            return (a) androidx.media3.common.util.a.e((a) this.f13185b.get(i10));
        }

        public int d() {
            return this.f13184a.d();
        }
    }

    void A(a aVar, a0.a aVar2);

    void B(a aVar, int i10);

    void C(a aVar);

    void D(a aVar, h1 h1Var);

    void E(a aVar, int i10, long j10, long j11);

    void F(a aVar, k0 k0Var);

    void G(a aVar, Object obj, long j10);

    void H(a aVar, y yVar, o oVar);

    void I(a aVar, long j10);

    void J(a aVar);

    void K(a aVar);

    void L(a aVar, Exception exc);

    void M(a aVar, int i10);

    void N(a aVar, l1 l1Var);

    void P(a aVar, Exception exc);

    void R(a aVar, n nVar);

    void S(a aVar, int i10);

    void T(a aVar, d dVar);

    void U(a aVar, boolean z10);

    void V(a aVar, boolean z10);

    void W(a aVar, List list);

    void X(a aVar, s0.e eVar, s0.e eVar2, int i10);

    void Y(a aVar, q0 q0Var);

    void Z(a aVar, a0.a aVar2);

    void a(a aVar, b0 b0Var);

    void a0(a aVar, s0.b bVar);

    void b(a aVar);

    void b0(a aVar, Exception exc);

    void c(a aVar, int i10, int i11);

    void c0(a aVar, long j10);

    void d(a aVar, String str, long j10, long j11);

    void d0(a aVar, long j10);

    void e(a aVar, b0 b0Var);

    void e0(a aVar, q0 q0Var);

    void f(a aVar, s1.y yVar, b0 b0Var);

    void f0(a aVar, p1 p1Var);

    void g(s0 s0Var, b bVar);

    void g0(a aVar, long j10, int i10);

    void h(a aVar);

    void h0(a aVar, int i10);

    void i(a aVar);

    void i0(a aVar, int i10, int i11, int i12, float f10);

    void j(a aVar, boolean z10, int i10);

    void j0(a aVar, int i10, boolean z10);

    void k(a aVar, n nVar);

    void k0(a aVar, y yVar, o oVar);

    void l(a aVar, int i10, long j10);

    void l0(a aVar, String str);

    void m(a aVar, e eVar);

    void m0(a aVar, k0 k0Var);

    void n(a aVar, e0 e0Var, int i10);

    void n0(a aVar, boolean z10, int i10);

    void o(a aVar, n nVar);

    void o0(a aVar, String str, long j10, long j11);

    void p(a aVar, float f10);

    void p0(a aVar, String str, long j10);

    void q0(a aVar, n nVar);

    void r(a aVar, Exception exc);

    void r0(a aVar, s1.y yVar, b0 b0Var, IOException iOException, boolean z10);

    void s(a aVar, int i10, long j10, long j11);

    void s0(a aVar, s1.y yVar, b0 b0Var);

    void t(a aVar, long j10);

    void t0(a aVar, boolean z10);

    void u0(a aVar, boolean z10);

    void v(a aVar, r0 r0Var);

    void v0(a aVar);

    void w(a aVar, int i10);

    void w0(a aVar, String str, long j10);

    void x(a aVar, q qVar);

    void x0(a aVar, boolean z10);

    void y(a aVar, String str);

    void y0(a aVar, s1.y yVar, b0 b0Var);

    void z(a aVar, l0 l0Var);

    void z0(a aVar, int i10);
}
