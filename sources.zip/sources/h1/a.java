package h1;

import android.os.Looper;
import androidx.media3.exoplayer.audio.a0;
import androidx.media3.exoplayer.n;
import androidx.media3.exoplayer.o;
import java.util.List;
import k1.v;
import s1.f0;
import s1.m0;
import x1.e;
import y0.s0;
import y0.y;

public interface a extends s0.d, m0, e.a, v {
    void A(long j10, int i10);

    void Q(s0 s0Var, Looper looper);

    void R();

    void V(List list, f0.b bVar);

    void a(a0.a aVar);

    void b(a0.a aVar);

    void e(Exception exc);

    void f(String str);

    void i(String str, long j10, long j11);

    void j(String str);

    void k(String str, long j10, long j11);

    void l(y yVar, o oVar);

    void l0(c cVar);

    void m(int i10, long j10);

    void o(n nVar);

    void p(n nVar);

    void p0(c cVar);

    void q(Object obj, long j10);

    void r(y yVar, o oVar);

    void release();

    void u(n nVar);

    void v(long j10);

    void w(Exception exc);

    void x(Exception exc);

    void y(int i10, long j10, long j11);

    void z(n nVar);
}
