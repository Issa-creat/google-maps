package h1;

import android.media.metrics.PlaybackMetrics;

public abstract /* synthetic */ class u2 {
    public static /* synthetic */ PlaybackMetrics.Builder a() {
        return new PlaybackMetrics.Builder();
    }
}
