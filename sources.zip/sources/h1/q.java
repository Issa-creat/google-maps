package h1;

import androidx.media3.common.util.r;
import y0.s0;
import y0.v;

public final /* synthetic */ class q implements r.b {

    /* renamed from: a  reason: collision with root package name */
    public final /* synthetic */ v1 f13281a;

    /* renamed from: b  reason: collision with root package name */
    public final /* synthetic */ s0 f13282b;

    public /* synthetic */ q(v1 v1Var, s0 s0Var) {
        this.f13281a = v1Var;
        this.f13282b = s0Var;
    }

    public final void a(Object obj, v vVar) {
        this.f13281a.n3(this.f13282b, (c) obj, vVar);
    }
}
