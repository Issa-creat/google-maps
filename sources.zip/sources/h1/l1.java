package h1;

import androidx.media3.common.util.r;
import h1.c;

public final /* synthetic */ class l1 implements r.a {

    /* renamed from: a  reason: collision with root package name */
    public final /* synthetic */ c.a f13256a;

    /* renamed from: b  reason: collision with root package name */
    public final /* synthetic */ long f13257b;

    public /* synthetic */ l1(c.a aVar, long j10) {
        this.f13256a = aVar;
        this.f13257b = j10;
    }

    public final void invoke(Object obj) {
        ((c) obj).d0(this.f13256a, this.f13257b);
    }
}
