package h1;

import androidx.media3.common.util.r;
import h1.c;
import s1.b0;

public final /* synthetic */ class a1 implements r.a {

    /* renamed from: a  reason: collision with root package name */
    public final /* synthetic */ c.a f13137a;

    /* renamed from: b  reason: collision with root package name */
    public final /* synthetic */ b0 f13138b;

    public /* synthetic */ a1(c.a aVar, b0 b0Var) {
        this.f13137a = aVar;
        this.f13138b = b0Var;
    }

    public final void invoke(Object obj) {
        ((c) obj).a(this.f13137a, this.f13138b);
    }
}
