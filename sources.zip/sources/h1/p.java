package h1;

import androidx.media3.common.util.r;
import h1.c;

public final /* synthetic */ class p implements r.a {

    /* renamed from: a  reason: collision with root package name */
    public final /* synthetic */ c.a f13275a;

    /* renamed from: b  reason: collision with root package name */
    public final /* synthetic */ int f13276b;

    /* renamed from: c  reason: collision with root package name */
    public final /* synthetic */ boolean f13277c;

    public /* synthetic */ p(c.a aVar, int i10, boolean z10) {
        this.f13275a = aVar;
        this.f13276b = i10;
        this.f13277c = z10;
    }

    public final void invoke(Object obj) {
        ((c) obj).j0(this.f13275a, this.f13276b, this.f13277c);
    }
}
