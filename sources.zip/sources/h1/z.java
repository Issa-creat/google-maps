package h1;

import androidx.media3.common.util.r;
import h1.c;

public final /* synthetic */ class z implements r.a {

    /* renamed from: a  reason: collision with root package name */
    public final /* synthetic */ c.a f13365a;

    /* renamed from: b  reason: collision with root package name */
    public final /* synthetic */ int f13366b;

    public /* synthetic */ z(c.a aVar, int i10) {
        this.f13365a = aVar;
        this.f13366b = i10;
    }

    public final void invoke(Object obj) {
        ((c) obj).w(this.f13365a, this.f13366b);
    }
}
