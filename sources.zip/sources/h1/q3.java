package h1;

import android.media.metrics.NetworkEvent;

public abstract /* synthetic */ class q3 {
    public static /* synthetic */ NetworkEvent.Builder a() {
        return new NetworkEvent.Builder();
    }
}
