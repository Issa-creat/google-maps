package h1;

import androidx.media3.common.util.r;
import h1.c;

public final /* synthetic */ class p0 implements r.a {

    /* renamed from: a  reason: collision with root package name */
    public final /* synthetic */ c.a f13278a;

    public /* synthetic */ p0(c.a aVar) {
        this.f13278a = aVar;
    }

    public final void invoke(Object obj) {
        ((c) obj).b(this.f13278a);
    }
}
