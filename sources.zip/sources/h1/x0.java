package h1;

import androidx.media3.common.util.r;
import h1.c;

public final /* synthetic */ class x0 implements r.a {

    /* renamed from: a  reason: collision with root package name */
    public final /* synthetic */ c.a f13341a;

    public /* synthetic */ x0(c.a aVar) {
        this.f13341a = aVar;
    }

    public final void invoke(Object obj) {
        ((c) obj).J(this.f13341a);
    }
}
