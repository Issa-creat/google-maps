package h1;

import androidx.media3.common.util.r;
import h1.c;

public final /* synthetic */ class w0 implements r.a {

    /* renamed from: a  reason: collision with root package name */
    public final /* synthetic */ c.a f13335a;

    /* renamed from: b  reason: collision with root package name */
    public final /* synthetic */ int f13336b;

    /* renamed from: c  reason: collision with root package name */
    public final /* synthetic */ long f13337c;

    /* renamed from: d  reason: collision with root package name */
    public final /* synthetic */ long f13338d;

    public /* synthetic */ w0(c.a aVar, int i10, long j10, long j11) {
        this.f13335a = aVar;
        this.f13336b = i10;
        this.f13337c = j10;
        this.f13338d = j11;
    }

    public final void invoke(Object obj) {
        ((c) obj).s(this.f13335a, this.f13336b, this.f13337c, this.f13338d);
    }
}
