package h1;

import androidx.media3.common.util.r;
import h1.c;

public final /* synthetic */ class f0 implements r.a {

    /* renamed from: a  reason: collision with root package name */
    public final /* synthetic */ c.a f13211a;

    /* renamed from: b  reason: collision with root package name */
    public final /* synthetic */ int f13212b;

    public /* synthetic */ f0(c.a aVar, int i10) {
        this.f13211a = aVar;
        this.f13212b = i10;
    }

    public final void invoke(Object obj) {
        ((c) obj).M(this.f13211a, this.f13212b);
    }
}
