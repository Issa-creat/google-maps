package h1;

import android.util.Base64;
import androidx.media3.common.util.b1;
import ge.s;
import h1.b4;
import h1.c;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Random;
import s1.f0;
import y0.c1;

public final class x1 implements b4 {

    /* renamed from: i  reason: collision with root package name */
    public static final s f13342i = new w1();

    /* renamed from: j  reason: collision with root package name */
    private static final Random f13343j = new Random();
    /* access modifiers changed from: private */

    /* renamed from: a  reason: collision with root package name */
    public final c1.d f13344a;
    /* access modifiers changed from: private */

    /* renamed from: b  reason: collision with root package name */
    public final c1.b f13345b;

    /* renamed from: c  reason: collision with root package name */
    private final HashMap f13346c;

    /* renamed from: d  reason: collision with root package name */
    private final s f13347d;

    /* renamed from: e  reason: collision with root package name */
    private b4.a f13348e;

    /* renamed from: f  reason: collision with root package name */
    private c1 f13349f;

    /* renamed from: g  reason: collision with root package name */
    private String f13350g;

    /* renamed from: h  reason: collision with root package name */
    private long f13351h;

    private final class a {
        /* access modifiers changed from: private */

        /* renamed from: a  reason: collision with root package name */
        public final String f13352a;
        /* access modifiers changed from: private */

        /* renamed from: b  reason: collision with root package name */
        public int f13353b;
        /* access modifiers changed from: private */

        /* renamed from: c  reason: collision with root package name */
        public long f13354c;
        /* access modifiers changed from: private */

        /* renamed from: d  reason: collision with root package name */
        public f0.b f13355d;
        /* access modifiers changed from: private */

        /* renamed from: e  reason: collision with root package name */
        public boolean f13356e;
        /* access modifiers changed from: private */

        /* renamed from: f  reason: collision with root package name */
        public boolean f13357f;

        public a(String str, int i10, f0.b bVar) {
            long j10;
            this.f13352a = str;
            this.f13353b = i10;
            if (bVar == null) {
                j10 = -1;
            } else {
                j10 = bVar.f17425d;
            }
            this.f13354c = j10;
            if (bVar != null && bVar.b()) {
                this.f13355d = bVar;
            }
        }

        private int l(c1 c1Var, c1 c1Var2, int i10) {
            if (i10 < c1Var.t()) {
                c1Var.r(i10, x1.this.f13344a);
                for (int i11 = x1.this.f13344a.f19584n; i11 <= x1.this.f13344a.f19585o; i11++) {
                    int f10 = c1Var2.f(c1Var.q(i11));
                    if (f10 != -1) {
                        return c1Var2.j(f10, x1.this.f13345b).f19552c;
                    }
                }
                return -1;
            } else if (i10 < c1Var2.t()) {
                return i10;
            } else {
                return -1;
            }
        }

        public boolean i(int i10, f0.b bVar) {
            if (bVar != null) {
                f0.b bVar2 = this.f13355d;
                if (bVar2 == null) {
                    if (bVar.b() || bVar.f17425d != this.f13354c) {
                        return false;
                    }
                    return true;
                } else if (bVar.f17425d == bVar2.f17425d && bVar.f17423b == bVar2.f17423b && bVar.f17424c == bVar2.f17424c) {
                    return true;
                } else {
                    return false;
                }
            } else if (i10 == this.f13353b) {
                return true;
            } else {
                return false;
            }
        }

        public boolean j(c.a aVar) {
            f0.b bVar = aVar.f13177d;
            if (bVar != null) {
                long j10 = this.f13354c;
                if (j10 == -1) {
                    return false;
                }
                if (bVar.f17425d > j10) {
                    return true;
                }
                if (this.f13355d == null) {
                    return false;
                }
                int f10 = aVar.f13175b.f(bVar.f17422a);
                int f11 = aVar.f13175b.f(this.f13355d.f17422a);
                f0.b bVar2 = aVar.f13177d;
                if (bVar2.f17425d < this.f13355d.f17425d || f10 < f11) {
                    return false;
                }
                if (f10 > f11) {
                    return true;
                }
                if (bVar2.b()) {
                    f0.b bVar3 = aVar.f13177d;
                    int i10 = bVar3.f17423b;
                    int i11 = bVar3.f17424c;
                    f0.b bVar4 = this.f13355d;
                    int i12 = bVar4.f17423b;
                    if (i10 > i12) {
                        return true;
                    }
                    if (i10 != i12 || i11 <= bVar4.f17424c) {
                        return false;
                    }
                    return true;
                }
                int i13 = aVar.f13177d.f17426e;
                if (i13 == -1 || i13 > this.f13355d.f17423b) {
                    return true;
                }
                return false;
            } else if (this.f13353b != aVar.f13176c) {
                return true;
            } else {
                return false;
            }
        }

        public void k(int i10, f0.b bVar) {
            if (this.f13354c == -1 && i10 == this.f13353b && bVar != null && bVar.f17425d >= x1.this.n()) {
                this.f13354c = bVar.f17425d;
            }
        }

        public boolean m(c1 c1Var, c1 c1Var2) {
            int l10 = l(c1Var, c1Var2, this.f13353b);
            this.f13353b = l10;
            if (l10 == -1) {
                return false;
            }
            f0.b bVar = this.f13355d;
            if (bVar != null && c1Var2.f(bVar.f17422a) == -1) {
                return false;
            }
            return true;
        }
    }

    public x1() {
        this(f13342i);
    }

    private void l(a aVar) {
        if (aVar.f13354c != -1) {
            this.f13351h = aVar.f13354c;
        }
        this.f13350g = null;
    }

    /* access modifiers changed from: private */
    public static String m() {
        byte[] bArr = new byte[12];
        f13343j.nextBytes(bArr);
        return Base64.encodeToString(bArr, 10);
    }

    /* access modifiers changed from: private */
    public long n() {
        a aVar = (a) this.f13346c.get(this.f13350g);
        if (aVar == null || aVar.f13354c == -1) {
            return this.f13351h + 1;
        }
        return aVar.f13354c;
    }

    private a o(int i10, f0.b bVar) {
        int i11;
        a aVar = null;
        long j10 = Long.MAX_VALUE;
        for (a aVar2 : this.f13346c.values()) {
            aVar2.k(i10, bVar);
            if (aVar2.i(i10, bVar)) {
                long b10 = aVar2.f13354c;
                if (b10 == -1 || b10 < j10) {
                    aVar = aVar2;
                    j10 = b10;
                } else if (!(i11 != 0 || ((a) b1.l(aVar)).f13355d == null || aVar2.f13355d == null)) {
                    aVar = aVar2;
                }
            }
        }
        if (aVar != null) {
            return aVar;
        }
        String str = (String) this.f13347d.get();
        a aVar3 = new a(str, i10, bVar);
        this.f13346c.put(str, aVar3);
        return aVar3;
    }

    private void p(c.a aVar) {
        if (aVar.f13175b.u()) {
            String str = this.f13350g;
            if (str != null) {
                l((a) androidx.media3.common.util.a.e((a) this.f13346c.get(str)));
                return;
            }
            return;
        }
        a aVar2 = (a) this.f13346c.get(this.f13350g);
        a o10 = o(aVar.f13176c, aVar.f13177d);
        this.f13350g = o10.f13352a;
        d(aVar);
        f0.b bVar = aVar.f13177d;
        if (bVar != null && bVar.b()) {
            if (aVar2 == null || aVar2.f13354c != aVar.f13177d.f17425d || aVar2.f13355d == null || aVar2.f13355d.f17423b != aVar.f13177d.f17423b || aVar2.f13355d.f17424c != aVar.f13177d.f17424c) {
                f0.b bVar2 = aVar.f13177d;
                this.f13348e.u(aVar, o(aVar.f13176c, new f0.b(bVar2.f17422a, bVar2.f17425d)).f13352a, o10.f13352a);
            }
        }
    }

    public synchronized String a() {
        return this.f13350g;
    }

    public synchronized void b(c.a aVar, int i10) {
        boolean z10;
        boolean z11;
        androidx.media3.common.util.a.e(this.f13348e);
        if (i10 == 0) {
            z10 = true;
        } else {
            z10 = false;
        }
        Iterator it = this.f13346c.values().iterator();
        while (it.hasNext()) {
            a aVar2 = (a) it.next();
            if (aVar2.j(aVar)) {
                it.remove();
                if (aVar2.f13356e) {
                    boolean equals = aVar2.f13352a.equals(this.f13350g);
                    if (!z10 || !equals || !aVar2.f13357f) {
                        z11 = false;
                    } else {
                        z11 = true;
                    }
                    if (equals) {
                        l(aVar2);
                    }
                    this.f13348e.q(aVar, aVar2.f13352a, z11);
                }
            }
        }
        p(aVar);
    }

    public synchronized String c(c1 c1Var, f0.b bVar) {
        return o(c1Var.l(bVar.f17422a, this.f13345b).f19552c, bVar).f13352a;
    }

    /* JADX WARNING: Code restructure failed: missing block: B:46:0x0111, code lost:
        return;
     */
    /* JADX WARNING: Removed duplicated region for block: B:38:0x00db  */
    /* JADX WARNING: Removed duplicated region for block: B:39:0x00ed  */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public synchronized void d(h1.c.a r25) {
        /*
            r24 = this;
            r1 = r24
            r0 = r25
            monitor-enter(r24)
            h1.b4$a r2 = r1.f13348e     // Catch:{ all -> 0x0112 }
            androidx.media3.common.util.a.e(r2)     // Catch:{ all -> 0x0112 }
            y0.c1 r2 = r0.f13175b     // Catch:{ all -> 0x0112 }
            boolean r2 = r2.u()     // Catch:{ all -> 0x0112 }
            if (r2 == 0) goto L_0x0014
            monitor-exit(r24)
            return
        L_0x0014:
            s1.f0$b r2 = r0.f13177d     // Catch:{ all -> 0x0112 }
            if (r2 == 0) goto L_0x0044
            long r2 = r2.f17425d     // Catch:{ all -> 0x0112 }
            long r4 = r24.n()     // Catch:{ all -> 0x0112 }
            int r6 = (r2 > r4 ? 1 : (r2 == r4 ? 0 : -1))
            if (r6 >= 0) goto L_0x0024
            monitor-exit(r24)
            return
        L_0x0024:
            java.util.HashMap r2 = r1.f13346c     // Catch:{ all -> 0x0112 }
            java.lang.String r3 = r1.f13350g     // Catch:{ all -> 0x0112 }
            java.lang.Object r2 = r2.get(r3)     // Catch:{ all -> 0x0112 }
            h1.x1$a r2 = (h1.x1.a) r2     // Catch:{ all -> 0x0112 }
            if (r2 == 0) goto L_0x0044
            long r3 = r2.f13354c     // Catch:{ all -> 0x0112 }
            r5 = -1
            int r7 = (r3 > r5 ? 1 : (r3 == r5 ? 0 : -1))
            if (r7 != 0) goto L_0x0044
            int r2 = r2.f13353b     // Catch:{ all -> 0x0112 }
            int r3 = r0.f13176c     // Catch:{ all -> 0x0112 }
            if (r2 == r3) goto L_0x0044
            monitor-exit(r24)
            return
        L_0x0044:
            int r2 = r0.f13176c     // Catch:{ all -> 0x0112 }
            s1.f0$b r3 = r0.f13177d     // Catch:{ all -> 0x0112 }
            h1.x1$a r2 = r1.o(r2, r3)     // Catch:{ all -> 0x0112 }
            java.lang.String r3 = r1.f13350g     // Catch:{ all -> 0x0112 }
            if (r3 != 0) goto L_0x0056
            java.lang.String r3 = r2.f13352a     // Catch:{ all -> 0x0112 }
            r1.f13350g = r3     // Catch:{ all -> 0x0112 }
        L_0x0056:
            s1.f0$b r3 = r0.f13177d     // Catch:{ all -> 0x0112 }
            r4 = 1
            if (r3 == 0) goto L_0x00d3
            boolean r3 = r3.b()     // Catch:{ all -> 0x0112 }
            if (r3 == 0) goto L_0x00d3
            s1.f0$b r10 = new s1.f0$b     // Catch:{ all -> 0x0112 }
            s1.f0$b r3 = r0.f13177d     // Catch:{ all -> 0x0112 }
            java.lang.Object r5 = r3.f17422a     // Catch:{ all -> 0x0112 }
            long r6 = r3.f17425d     // Catch:{ all -> 0x0112 }
            int r3 = r3.f17423b     // Catch:{ all -> 0x0112 }
            r10.<init>(r5, r6, r3)     // Catch:{ all -> 0x0112 }
            int r3 = r0.f13176c     // Catch:{ all -> 0x0112 }
            h1.x1$a r3 = r1.o(r3, r10)     // Catch:{ all -> 0x0112 }
            boolean r5 = r3.f13356e     // Catch:{ all -> 0x0112 }
            if (r5 != 0) goto L_0x00d3
            boolean unused = r3.f13356e = r4     // Catch:{ all -> 0x0112 }
            y0.c1 r5 = r0.f13175b     // Catch:{ all -> 0x0112 }
            s1.f0$b r6 = r0.f13177d     // Catch:{ all -> 0x0112 }
            java.lang.Object r6 = r6.f17422a     // Catch:{ all -> 0x0112 }
            y0.c1$b r7 = r1.f13345b     // Catch:{ all -> 0x0112 }
            r5.l(r6, r7)     // Catch:{ all -> 0x0112 }
            y0.c1$b r5 = r1.f13345b     // Catch:{ all -> 0x0112 }
            s1.f0$b r6 = r0.f13177d     // Catch:{ all -> 0x0112 }
            int r6 = r6.f17423b     // Catch:{ all -> 0x0112 }
            long r5 = r5.h(r6)     // Catch:{ all -> 0x0112 }
            long r5 = androidx.media3.common.util.b1.N1(r5)     // Catch:{ all -> 0x0112 }
            y0.c1$b r7 = r1.f13345b     // Catch:{ all -> 0x0112 }
            long r7 = r7.p()     // Catch:{ all -> 0x0112 }
            long r5 = r5 + r7
            r7 = 0
            long r11 = java.lang.Math.max(r7, r5)     // Catch:{ all -> 0x0112 }
            h1.c$a r15 = new h1.c$a     // Catch:{ all -> 0x0112 }
            long r6 = r0.f13174a     // Catch:{ all -> 0x0112 }
            y0.c1 r8 = r0.f13175b     // Catch:{ all -> 0x0112 }
            int r9 = r0.f13176c     // Catch:{ all -> 0x0112 }
            y0.c1 r13 = r0.f13179f     // Catch:{ all -> 0x0112 }
            int r14 = r0.f13180g     // Catch:{ all -> 0x0112 }
            s1.f0$b r5 = r0.f13181h     // Catch:{ all -> 0x0112 }
            r16 = r5
            long r4 = r0.f13182i     // Catch:{ all -> 0x0112 }
            r20 = r2
            r21 = r3
            long r2 = r0.f13183j     // Catch:{ all -> 0x0112 }
            r22 = r4
            r4 = r16
            r16 = r22
            r5 = r15
            r0 = r15
            r15 = r4
            r18 = r2
            r5.<init>(r6, r8, r9, r10, r11, r13, r14, r15, r16, r18)     // Catch:{ all -> 0x0112 }
            h1.b4$a r2 = r1.f13348e     // Catch:{ all -> 0x0112 }
            java.lang.String r3 = r21.f13352a     // Catch:{ all -> 0x0112 }
            r2.Q(r0, r3)     // Catch:{ all -> 0x0112 }
            goto L_0x00d5
        L_0x00d3:
            r20 = r2
        L_0x00d5:
            boolean r0 = r20.f13356e     // Catch:{ all -> 0x0112 }
            if (r0 != 0) goto L_0x00ed
            r0 = r20
            r2 = 1
            boolean unused = r0.f13356e = r2     // Catch:{ all -> 0x0112 }
            h1.b4$a r2 = r1.f13348e     // Catch:{ all -> 0x0112 }
            java.lang.String r3 = r0.f13352a     // Catch:{ all -> 0x0112 }
            r4 = r25
            r2.Q(r4, r3)     // Catch:{ all -> 0x0112 }
            goto L_0x00f1
        L_0x00ed:
            r4 = r25
            r0 = r20
        L_0x00f1:
            java.lang.String r2 = r0.f13352a     // Catch:{ all -> 0x0112 }
            java.lang.String r3 = r1.f13350g     // Catch:{ all -> 0x0112 }
            boolean r2 = r2.equals(r3)     // Catch:{ all -> 0x0112 }
            if (r2 == 0) goto L_0x0110
            boolean r2 = r0.f13357f     // Catch:{ all -> 0x0112 }
            if (r2 != 0) goto L_0x0110
            r2 = 1
            boolean unused = r0.f13357f = r2     // Catch:{ all -> 0x0112 }
            h1.b4$a r2 = r1.f13348e     // Catch:{ all -> 0x0112 }
            java.lang.String r0 = r0.f13352a     // Catch:{ all -> 0x0112 }
            r2.O(r4, r0)     // Catch:{ all -> 0x0112 }
        L_0x0110:
            monitor-exit(r24)
            return
        L_0x0112:
            r0 = move-exception
            monitor-exit(r24)
            throw r0
        */
        throw new UnsupportedOperationException("Method not decompiled: h1.x1.d(h1.c$a):void");
    }

    public void e(b4.a aVar) {
        this.f13348e = aVar;
    }

    public synchronized void f(c.a aVar) {
        b4.a aVar2;
        String str = this.f13350g;
        if (str != null) {
            l((a) androidx.media3.common.util.a.e((a) this.f13346c.get(str)));
        }
        Iterator it = this.f13346c.values().iterator();
        while (it.hasNext()) {
            a aVar3 = (a) it.next();
            it.remove();
            if (aVar3.f13356e && (aVar2 = this.f13348e) != null) {
                aVar2.q(aVar, aVar3.f13352a, false);
            }
        }
    }

    public synchronized void g(c.a aVar) {
        androidx.media3.common.util.a.e(this.f13348e);
        c1 c1Var = this.f13349f;
        this.f13349f = aVar.f13175b;
        Iterator it = this.f13346c.values().iterator();
        while (it.hasNext()) {
            a aVar2 = (a) it.next();
            if (!aVar2.m(c1Var, this.f13349f) || aVar2.j(aVar)) {
                it.remove();
                if (aVar2.f13356e) {
                    if (aVar2.f13352a.equals(this.f13350g)) {
                        l(aVar2);
                    }
                    this.f13348e.q(aVar, aVar2.f13352a, false);
                }
            }
        }
        p(aVar);
    }

    public x1(s sVar) {
        this.f13347d = sVar;
        this.f13344a = new c1.d();
        this.f13345b = new c1.b();
        this.f13346c = new HashMap();
        this.f13349f = c1.f19541a;
        this.f13351h = -1;
    }
}
