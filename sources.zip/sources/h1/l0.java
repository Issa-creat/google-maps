package h1;

import androidx.media3.common.util.r;
import androidx.media3.exoplayer.n;
import h1.c;

public final /* synthetic */ class l0 implements r.a {

    /* renamed from: a  reason: collision with root package name */
    public final /* synthetic */ c.a f13254a;

    /* renamed from: b  reason: collision with root package name */
    public final /* synthetic */ n f13255b;

    public /* synthetic */ l0(c.a aVar, n nVar) {
        this.f13254a = aVar;
        this.f13255b = nVar;
    }

    public final void invoke(Object obj) {
        ((c) obj).o(this.f13254a, this.f13255b);
    }
}
