package h1;

import androidx.media3.common.util.r;
import h1.c;

public final /* synthetic */ class u implements r.a {

    /* renamed from: a  reason: collision with root package name */
    public final /* synthetic */ c.a f13311a;

    /* renamed from: b  reason: collision with root package name */
    public final /* synthetic */ int f13312b;

    /* renamed from: c  reason: collision with root package name */
    public final /* synthetic */ long f13313c;

    public /* synthetic */ u(c.a aVar, int i10, long j10) {
        this.f13311a = aVar;
        this.f13312b = i10;
        this.f13313c = j10;
    }

    public final void invoke(Object obj) {
        ((c) obj).l(this.f13311a, this.f13312b, this.f13313c);
    }
}
