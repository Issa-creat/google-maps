package h1;

import h1.c;
import s1.f0;
import y0.c1;

public interface b4 {

    public interface a {
        void O(c.a aVar, String str);

        void Q(c.a aVar, String str);

        void q(c.a aVar, String str, boolean z10);

        void u(c.a aVar, String str, String str2);
    }

    String a();

    void b(c.a aVar, int i10);

    String c(c1 c1Var, f0.b bVar);

    void d(c.a aVar);

    void e(a aVar);

    void f(c.a aVar);

    void g(c.a aVar);
}
