package h1;

public final /* synthetic */ class n0 implements Runnable {

    /* renamed from: a  reason: collision with root package name */
    public final /* synthetic */ v1 f13265a;

    public /* synthetic */ n0(v1 v1Var) {
        this.f13265a = v1Var;
    }

    public final void run() {
        this.f13265a.o3();
    }
}
