package h1;

import androidx.media3.common.util.r;
import androidx.media3.exoplayer.o;
import h1.c;
import y0.y;

public final /* synthetic */ class r1 implements r.a {

    /* renamed from: a  reason: collision with root package name */
    public final /* synthetic */ c.a f13291a;

    /* renamed from: b  reason: collision with root package name */
    public final /* synthetic */ y f13292b;

    /* renamed from: c  reason: collision with root package name */
    public final /* synthetic */ o f13293c;

    public /* synthetic */ r1(c.a aVar, y yVar, o oVar) {
        this.f13291a = aVar;
        this.f13292b = yVar;
        this.f13293c = oVar;
    }

    public final void invoke(Object obj) {
        ((c) obj).H(this.f13291a, this.f13292b, this.f13293c);
    }
}
