package h1;

import androidx.media3.common.util.r;
import h1.c;

public final /* synthetic */ class e0 implements r.a {

    /* renamed from: a  reason: collision with root package name */
    public final /* synthetic */ c.a f13204a;

    /* renamed from: b  reason: collision with root package name */
    public final /* synthetic */ boolean f13205b;

    public /* synthetic */ e0(c.a aVar, boolean z10) {
        this.f13204a = aVar;
        this.f13205b = z10;
    }

    public final void invoke(Object obj) {
        ((c) obj).U(this.f13204a, this.f13205b);
    }
}
