package h1;

import androidx.media3.common.util.r;
import h1.c;

public final /* synthetic */ class q1 implements r.a {

    /* renamed from: a  reason: collision with root package name */
    public final /* synthetic */ c.a f13285a;

    public /* synthetic */ q1(c.a aVar) {
        this.f13285a = aVar;
    }

    public final void invoke(Object obj) {
        ((c) obj).h(this.f13285a);
    }
}
