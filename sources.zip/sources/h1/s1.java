package h1;

import androidx.media3.common.util.r;
import h1.c;

public final /* synthetic */ class s1 implements r.a {

    /* renamed from: a  reason: collision with root package name */
    public final /* synthetic */ c.a f13303a;

    /* renamed from: b  reason: collision with root package name */
    public final /* synthetic */ String f13304b;

    public /* synthetic */ s1(c.a aVar, String str) {
        this.f13303a = aVar;
        this.f13304b = str;
    }

    public final void invoke(Object obj) {
        ((c) obj).y(this.f13303a, this.f13304b);
    }
}
