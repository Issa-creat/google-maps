package h1;

import androidx.media3.common.util.r;
import androidx.media3.exoplayer.n;
import h1.c;

public final /* synthetic */ class q0 implements r.a {

    /* renamed from: a  reason: collision with root package name */
    public final /* synthetic */ c.a f13283a;

    /* renamed from: b  reason: collision with root package name */
    public final /* synthetic */ n f13284b;

    public /* synthetic */ q0(c.a aVar, n nVar) {
        this.f13283a = aVar;
        this.f13284b = nVar;
    }

    public final void invoke(Object obj) {
        ((c) obj).q0(this.f13283a, this.f13284b);
    }
}
