package h1;

import androidx.media3.common.util.r;
import androidx.media3.exoplayer.o;
import h1.c;
import y0.y;

public final /* synthetic */ class j0 implements r.a {

    /* renamed from: a  reason: collision with root package name */
    public final /* synthetic */ c.a f13241a;

    /* renamed from: b  reason: collision with root package name */
    public final /* synthetic */ y f13242b;

    /* renamed from: c  reason: collision with root package name */
    public final /* synthetic */ o f13243c;

    public /* synthetic */ j0(c.a aVar, y yVar, o oVar) {
        this.f13241a = aVar;
        this.f13242b = yVar;
        this.f13243c = oVar;
    }

    public final void invoke(Object obj) {
        ((c) obj).k0(this.f13241a, this.f13242b, this.f13243c);
    }
}
