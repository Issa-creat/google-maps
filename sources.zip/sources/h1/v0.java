package h1;

import androidx.media3.common.util.r;
import h1.c;

public final /* synthetic */ class v0 implements r.a {

    /* renamed from: a  reason: collision with root package name */
    public final /* synthetic */ c.a f13320a;

    /* renamed from: b  reason: collision with root package name */
    public final /* synthetic */ String f13321b;

    public /* synthetic */ v0(c.a aVar, String str) {
        this.f13320a = aVar;
        this.f13321b = str;
    }

    public final void invoke(Object obj) {
        ((c) obj).l0(this.f13320a, this.f13321b);
    }
}
