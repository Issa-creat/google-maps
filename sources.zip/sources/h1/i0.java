package h1;

import androidx.media3.common.util.r;
import h1.c;
import y0.k0;

public final /* synthetic */ class i0 implements r.a {

    /* renamed from: a  reason: collision with root package name */
    public final /* synthetic */ c.a f13234a;

    /* renamed from: b  reason: collision with root package name */
    public final /* synthetic */ k0 f13235b;

    public /* synthetic */ i0(c.a aVar, k0 k0Var) {
        this.f13234a = aVar;
        this.f13235b = k0Var;
    }

    public final void invoke(Object obj) {
        ((c) obj).m0(this.f13234a, this.f13235b);
    }
}
