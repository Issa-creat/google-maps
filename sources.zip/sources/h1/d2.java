package h1;

public abstract /* synthetic */ class d2 {
}
