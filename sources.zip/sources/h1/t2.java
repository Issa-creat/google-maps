package h1;

import android.media.metrics.PlaybackMetrics;

public abstract /* synthetic */ class t2 {
    public static /* bridge */ /* synthetic */ PlaybackMetrics.Builder a(Object obj) {
        return (PlaybackMetrics.Builder) obj;
    }
}
