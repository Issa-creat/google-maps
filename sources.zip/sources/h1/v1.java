package h1;

import a1.d;
import android.os.Handler;
import android.os.Looper;
import android.util.SparseArray;
import androidx.media3.common.util.b1;
import androidx.media3.common.util.f;
import androidx.media3.common.util.o;
import androidx.media3.common.util.r;
import androidx.media3.exoplayer.audio.a0;
import androidx.media3.exoplayer.n;
import androidx.media3.exoplayer.t;
import com.google.common.collect.a0;
import com.google.common.collect.d0;
import com.google.common.collect.y;
import ge.j;
import h1.c;
import java.io.IOException;
import java.util.List;
import okhttp3.internal.ws.WebSocketProtocol;
import s1.b0;
import s1.f0;
import y0.c1;
import y0.e;
import y0.e0;
import y0.h1;
import y0.k0;
import y0.l0;
import y0.l1;
import y0.p1;
import y0.q;
import y0.q0;
import y0.r0;
import y0.s0;
import y0.v;

public class v1 implements a {
    private r A;
    private s0 B;
    private o C;
    private boolean D;

    /* renamed from: a  reason: collision with root package name */
    private final f f13322a;

    /* renamed from: w  reason: collision with root package name */
    private final c1.b f13323w;

    /* renamed from: x  reason: collision with root package name */
    private final c1.d f13324x = new c1.d();

    /* renamed from: y  reason: collision with root package name */
    private final a f13325y;

    /* renamed from: z  reason: collision with root package name */
    private final SparseArray f13326z;

    private static final class a {

        /* renamed from: a  reason: collision with root package name */
        private final c1.b f13327a;
        /* access modifiers changed from: private */

        /* renamed from: b  reason: collision with root package name */
        public y f13328b = y.C();

        /* renamed from: c  reason: collision with root package name */
        private a0 f13329c = a0.k();

        /* renamed from: d  reason: collision with root package name */
        private f0.b f13330d;

        /* renamed from: e  reason: collision with root package name */
        private f0.b f13331e;

        /* renamed from: f  reason: collision with root package name */
        private f0.b f13332f;

        public a(c1.b bVar) {
            this.f13327a = bVar;
        }

        private void b(a0.a aVar, f0.b bVar, c1 c1Var) {
            if (bVar != null) {
                if (c1Var.f(bVar.f17422a) != -1) {
                    aVar.f(bVar, c1Var);
                    return;
                }
                c1 c1Var2 = (c1) this.f13329c.get(bVar);
                if (c1Var2 != null) {
                    aVar.f(bVar, c1Var2);
                }
            }
        }

        private static f0.b c(s0 s0Var, y yVar, f0.b bVar, c1.b bVar2) {
            Object obj;
            int i10;
            c1 M0 = s0Var.M0();
            int Q = s0Var.Q();
            if (M0.u()) {
                obj = null;
            } else {
                obj = M0.q(Q);
            }
            if (s0Var.C() || M0.u()) {
                i10 = -1;
            } else {
                i10 = M0.j(Q, bVar2).f(b1.c1(s0Var.Y0()) - bVar2.q());
            }
            for (int i11 = 0; i11 < yVar.size(); i11++) {
                f0.b bVar3 = (f0.b) yVar.get(i11);
                if (i(bVar3, obj, s0Var.C(), s0Var.D0(), s0Var.d0(), i10)) {
                    return bVar3;
                }
            }
            if (yVar.isEmpty() && bVar != null) {
                if (i(bVar, obj, s0Var.C(), s0Var.D0(), s0Var.d0(), i10)) {
                    return bVar;
                }
            }
            return null;
        }

        private static boolean i(f0.b bVar, Object obj, boolean z10, int i10, int i11, int i12) {
            if (!bVar.f17422a.equals(obj)) {
                return false;
            }
            if ((z10 && bVar.f17423b == i10 && bVar.f17424c == i11) || (!z10 && bVar.f17423b == -1 && bVar.f17426e == i12)) {
                return true;
            }
            return false;
        }

        private void m(c1 c1Var) {
            a0.a a10 = a0.a();
            if (this.f13328b.isEmpty()) {
                b(a10, this.f13331e, c1Var);
                if (!j.a(this.f13332f, this.f13331e)) {
                    b(a10, this.f13332f, c1Var);
                }
                if (!j.a(this.f13330d, this.f13331e) && !j.a(this.f13330d, this.f13332f)) {
                    b(a10, this.f13330d, c1Var);
                }
            } else {
                for (int i10 = 0; i10 < this.f13328b.size(); i10++) {
                    b(a10, (f0.b) this.f13328b.get(i10), c1Var);
                }
                if (!this.f13328b.contains(this.f13330d)) {
                    b(a10, this.f13330d, c1Var);
                }
            }
            this.f13329c = a10.c();
        }

        public f0.b d() {
            return this.f13330d;
        }

        public f0.b e() {
            if (this.f13328b.isEmpty()) {
                return null;
            }
            return (f0.b) d0.d(this.f13328b);
        }

        public c1 f(f0.b bVar) {
            return (c1) this.f13329c.get(bVar);
        }

        public f0.b g() {
            return this.f13331e;
        }

        public f0.b h() {
            return this.f13332f;
        }

        public void j(s0 s0Var) {
            this.f13330d = c(s0Var, this.f13328b, this.f13331e, this.f13327a);
        }

        public void k(List list, f0.b bVar, s0 s0Var) {
            this.f13328b = y.w(list);
            if (!list.isEmpty()) {
                this.f13331e = (f0.b) list.get(0);
                this.f13332f = (f0.b) androidx.media3.common.util.a.e(bVar);
            }
            if (this.f13330d == null) {
                this.f13330d = c(s0Var, this.f13328b, this.f13331e, this.f13327a);
            }
            m(s0Var.M0());
        }

        public void l(s0 s0Var) {
            this.f13330d = c(s0Var, this.f13328b, this.f13331e, this.f13327a);
            m(s0Var.M0());
        }
    }

    public v1(f fVar) {
        this.f13322a = (f) androidx.media3.common.util.a.e(fVar);
        this.A = new r(b1.b0(), fVar, new e());
        c1.b bVar = new c1.b();
        this.f13323w = bVar;
        this.f13325y = new a(bVar);
        this.f13326z = new SparseArray();
    }

    private c.a Q1(f0.b bVar) {
        c1 c1Var;
        boolean z10;
        androidx.media3.common.util.a.e(this.B);
        if (bVar == null) {
            c1Var = null;
        } else {
            c1Var = this.f13325y.f(bVar);
        }
        if (bVar != null && c1Var != null) {
            return R1(c1Var, c1Var.l(bVar.f17422a, this.f13323w).f19552c, bVar);
        }
        int E0 = this.B.E0();
        c1 M0 = this.B.M0();
        if (E0 < M0.t()) {
            z10 = true;
        } else {
            z10 = false;
        }
        if (!z10) {
            M0 = c1.f19541a;
        }
        return R1(M0, E0, (f0.b) null);
    }

    /* access modifiers changed from: private */
    public static /* synthetic */ void R2(c.a aVar, int i10, s0.e eVar, s0.e eVar2, c cVar) {
        cVar.z0(aVar, i10);
        cVar.X(aVar, eVar, eVar2, i10);
    }

    private c.a S1() {
        return Q1(this.f13325y.e());
    }

    private c.a T1(int i10, f0.b bVar) {
        androidx.media3.common.util.a.e(this.B);
        boolean z10 = true;
        if (bVar != null) {
            if (this.f13325y.f(bVar) == null) {
                z10 = false;
            }
            if (z10) {
                return Q1(bVar);
            }
            return R1(c1.f19541a, i10, bVar);
        }
        c1 M0 = this.B.M0();
        if (i10 >= M0.t()) {
            z10 = false;
        }
        if (!z10) {
            M0 = c1.f19541a;
        }
        return R1(M0, i10, (f0.b) null);
    }

    private c.a U1() {
        return Q1(this.f13325y.g());
    }

    private c.a V1() {
        return Q1(this.f13325y.h());
    }

    private c.a W1(q0 q0Var) {
        f0.b bVar;
        if (!(q0Var instanceof t) || (bVar = ((t) q0Var).J) == null) {
            return P1();
        }
        return Q1(bVar);
    }

    /* access modifiers changed from: private */
    public static /* synthetic */ void X1(c cVar, v vVar) {
    }

    /* access modifiers changed from: private */
    public static /* synthetic */ void b2(c.a aVar, String str, long j10, long j11, c cVar) {
        cVar.p0(aVar, str, j10);
        cVar.d(aVar, str, j11, j10);
    }

    /* access modifiers changed from: private */
    public static /* synthetic */ void e3(c.a aVar, String str, long j10, long j11, c cVar) {
        cVar.w0(aVar, str, j10);
        cVar.o0(aVar, str, j11, j10);
    }

    /* access modifiers changed from: private */
    public static /* synthetic */ void k3(c.a aVar, p1 p1Var, c cVar) {
        cVar.f0(aVar, p1Var);
        cVar.i0(aVar, p1Var.f19970a, p1Var.f19971b, p1Var.f19972c, p1Var.f19973d);
    }

    /* access modifiers changed from: private */
    public /* synthetic */ void n3(s0 s0Var, c cVar, v vVar) {
        cVar.g(s0Var, new c.b(vVar, this.f13326z));
    }

    /* access modifiers changed from: private */
    public void o3() {
        c.a P1 = P1();
        p3(P1, 1028, new c1(P1));
        this.A.j();
    }

    /* access modifiers changed from: private */
    public static /* synthetic */ void v2(c.a aVar, int i10, c cVar) {
        cVar.K(aVar);
        cVar.B(aVar, i10);
    }

    /* access modifiers changed from: private */
    public static /* synthetic */ void z2(c.a aVar, boolean z10, c cVar) {
        cVar.t0(aVar, z10);
        cVar.x0(aVar, z10);
    }

    public final void A(long j10, int i10) {
        c.a U1 = U1();
        p3(U1, 1021, new d(U1, j10, i10));
    }

    public final void B(int i10) {
        c.a P1 = P1();
        p3(P1, 6, new z(P1, i10));
    }

    public final void C(int i10) {
        c.a P1 = P1();
        p3(P1, 8, new f(P1, i10));
    }

    public void D(boolean z10) {
    }

    public final void E(int i10, f0.b bVar) {
        c.a T1 = T1(i10, bVar);
        p3(T1, 1025, new i1(T1));
    }

    public void F(int i10) {
    }

    public void G(q qVar) {
        c.a P1 = P1();
        p3(P1, 29, new l(P1, qVar));
    }

    public final void H(c1 c1Var, int i10) {
        this.f13325y.l((s0) androidx.media3.common.util.a.e(this.B));
        c.a P1 = P1();
        p3(P1, 0, new t(P1, i10));
    }

    public final void I(boolean z10) {
        c.a P1 = P1();
        p3(P1, 3, new k0(P1, z10));
    }

    public /* synthetic */ void J(int i10, f0.b bVar) {
        k1.o.a(this, i10, bVar);
    }

    public final void K(int i10, f0.b bVar) {
        c.a T1 = T1(i10, bVar);
        p3(T1, 1027, new x0(T1));
    }

    public final void L(float f10) {
        c.a V1 = V1();
        p3(V1, 22, new t1(V1, f10));
    }

    public final void M(e eVar) {
        c.a V1 = V1();
        p3(V1, 20, new m0(V1, eVar));
    }

    public final void N(s0.e eVar, s0.e eVar2, int i10) {
        if (i10 == 1) {
            this.D = false;
        }
        this.f13325y.j((s0) androidx.media3.common.util.a.e(this.B));
        c.a P1 = P1();
        p3(P1, 11, new j(P1, i10, eVar, eVar2));
    }

    public final void O(int i10) {
        c.a P1 = P1();
        p3(P1, 4, new f0(P1, i10));
    }

    public final void P(int i10, long j10, long j11) {
        c.a S1 = S1();
        p3(S1, 1006, new h(S1, i10, j10, j11));
    }

    /* access modifiers changed from: protected */
    public final c.a P1() {
        return Q1(this.f13325y.d());
    }

    public void Q(s0 s0Var, Looper looper) {
        boolean z10;
        if (this.B == null || this.f13325y.f13328b.isEmpty()) {
            z10 = true;
        } else {
            z10 = false;
        }
        androidx.media3.common.util.a.g(z10);
        this.B = (s0) androidx.media3.common.util.a.e(s0Var);
        this.C = this.f13322a.d(looper, (Handler.Callback) null);
        this.A = this.A.e(looper, new q(this, s0Var));
    }

    public final void R() {
        if (!this.D) {
            c.a P1 = P1();
            this.D = true;
            p3(P1, -1, new p0(P1));
        }
    }

    /* access modifiers changed from: protected */
    public final c.a R1(c1 c1Var, int i10, f0.b bVar) {
        f0.b bVar2;
        boolean z10;
        long j10;
        c1 c1Var2 = c1Var;
        int i11 = i10;
        if (c1Var.u()) {
            bVar2 = null;
        } else {
            bVar2 = bVar;
        }
        long b10 = this.f13322a.b();
        boolean z11 = true;
        if (!c1Var2.equals(this.B.M0()) || i11 != this.B.E0()) {
            z10 = false;
        } else {
            z10 = true;
        }
        long j11 = 0;
        if (bVar2 != null && bVar2.b()) {
            if (!(z10 && this.B.D0() == bVar2.f17423b && this.B.d0() == bVar2.f17424c)) {
                z11 = false;
            }
            if (z11) {
                j11 = this.B.Y0();
            }
        } else if (z10) {
            j10 = this.B.r0();
            return new c.a(b10, c1Var, i10, bVar2, j10, this.B.M0(), this.B.E0(), this.f13325y.d(), this.B.Y0(), this.B.E());
        } else if (!c1Var.u()) {
            j11 = c1Var2.r(i11, this.f13324x).c();
        }
        j10 = j11;
        return new c.a(b10, c1Var, i10, bVar2, j10, this.B.M0(), this.B.E0(), this.f13325y.d(), this.B.Y0(), this.B.E());
    }

    public final void S(boolean z10) {
        c.a P1 = P1();
        p3(P1, 9, new e0(P1, z10));
    }

    public final void T(int i10, f0.b bVar) {
        c.a T1 = T1(i10, bVar);
        p3(T1, 1026, new q1(T1));
    }

    public final void U(int i10, f0.b bVar, s1.y yVar, b0 b0Var) {
        c.a T1 = T1(i10, bVar);
        p3(T1, 1002, new d1(T1, yVar, b0Var));
    }

    public final void V(List list, f0.b bVar) {
        this.f13325y.k(list, bVar, (s0) androidx.media3.common.util.a.e(this.B));
    }

    public final void W(e0 e0Var, int i10) {
        c.a P1 = P1();
        p3(P1, 1, new g0(P1, e0Var, i10));
    }

    public void X(k0 k0Var) {
        c.a P1 = P1();
        p3(P1, 14, new i0(P1, k0Var));
    }

    public void Y(s0 s0Var, s0.c cVar) {
    }

    public void Z(int i10, boolean z10) {
        c.a P1 = P1();
        p3(P1, 30, new p(P1, i10, z10));
    }

    public void a(a0.a aVar) {
        c.a V1 = V1();
        p3(V1, 1031, new k1(V1, aVar));
    }

    public final void a0(boolean z10, int i10) {
        c.a P1 = P1();
        p3(P1, -1, new g1(P1, z10, i10));
    }

    public void b(a0.a aVar) {
        c.a V1 = V1();
        p3(V1, 1032, new o1(V1, aVar));
    }

    public final void b0(int i10, f0.b bVar, Exception exc) {
        c.a T1 = T1(i10, bVar);
        p3(T1, 1024, new t0(T1, exc));
    }

    public final void c(p1 p1Var) {
        c.a V1 = V1();
        p3(V1, 25, new f1(V1, p1Var));
    }

    public void c0(long j10) {
        c.a P1 = P1();
        p3(P1, 16, new n1(P1, j10));
    }

    public final void d(boolean z10) {
        c.a V1 = V1();
        p3(V1, 23, new p1(V1, z10));
    }

    public final void d0(q0 q0Var) {
        c.a W1 = W1(q0Var);
        p3(W1, 10, new w(W1, q0Var));
    }

    public final void e(Exception exc) {
        c.a V1 = V1();
        p3(V1, 1014, new i(V1, exc));
    }

    public final void e0(int i10, f0.b bVar, s1.y yVar, b0 b0Var, IOException iOException, boolean z10) {
        c.a T1 = T1(i10, bVar);
        p3(T1, 1003, new s0(T1, yVar, b0Var, iOException, z10));
    }

    public final void f(String str) {
        c.a V1 = V1();
        p3(V1, 1019, new s1(V1, str));
    }

    public void f0(s0.b bVar) {
        c.a P1 = P1();
        p3(P1, 13, new k(P1, bVar));
    }

    public final void g(r0 r0Var) {
        c.a P1 = P1();
        p3(P1, 12, new u1(P1, r0Var));
    }

    public void g0(long j10) {
        c.a P1 = P1();
        p3(P1, 17, new l1(P1, j10));
    }

    public final void h(l0 l0Var) {
        c.a P1 = P1();
        p3(P1, 28, new x(P1, l0Var));
    }

    public final void h0(int i10, f0.b bVar, int i11) {
        c.a T1 = T1(i10, bVar);
        p3(T1, 1022, new z0(T1, i11));
    }

    public final void i(String str, long j10, long j11) {
        c.a V1 = V1();
        p3(V1, 1016, new s(V1, str, j11, j10));
    }

    public void i0(l1 l1Var) {
        c.a P1 = P1();
        p3(P1, 2, new m(P1, l1Var));
    }

    public final void j(String str) {
        c.a V1 = V1();
        p3(V1, 1012, new v0(V1, str));
    }

    public final void j0(int i10, f0.b bVar, b0 b0Var) {
        c.a T1 = T1(i10, bVar);
        p3(T1, WebSocketProtocol.CLOSE_NO_STATUS_CODE, new u0(T1, b0Var));
    }

    public final void k(String str, long j10, long j11) {
        c.a V1 = V1();
        p3(V1, 1008, new y(V1, str, j11, j10));
    }

    public void k0() {
    }

    public final void l(y0.y yVar, androidx.media3.exoplayer.o oVar) {
        c.a V1 = V1();
        p3(V1, 1009, new j0(V1, yVar, oVar));
    }

    public void l0(c cVar) {
        androidx.media3.common.util.a.e(cVar);
        this.A.c(cVar);
    }

    public final void m(int i10, long j10) {
        c.a U1 = U1();
        p3(U1, 1018, new u(U1, i10, j10));
    }

    public final void m0(int i10, f0.b bVar, b0 b0Var) {
        c.a T1 = T1(i10, bVar);
        p3(T1, 1004, new a1(T1, b0Var));
    }

    public final void n(int i10, f0.b bVar, s1.y yVar, b0 b0Var) {
        c.a T1 = T1(i10, bVar);
        p3(T1, 1000, new o(T1, yVar, b0Var));
    }

    public void n0(q0 q0Var) {
        c.a W1 = W1(q0Var);
        p3(W1, 10, new h0(W1, q0Var));
    }

    public final void o(n nVar) {
        c.a V1 = V1();
        p3(V1, 1007, new a0(V1, nVar));
    }

    public final void o0(int i10, f0.b bVar, s1.y yVar, b0 b0Var) {
        c.a T1 = T1(i10, bVar);
        p3(T1, WebSocketProtocol.CLOSE_CLIENT_GOING_AWAY, new e1(T1, yVar, b0Var));
    }

    public final void p(n nVar) {
        c.a V1 = V1();
        p3(V1, 1015, new v(V1, nVar));
    }

    public void p0(c cVar) {
        this.A.k(cVar);
    }

    /* access modifiers changed from: protected */
    public final void p3(c.a aVar, int i10, r.a aVar2) {
        this.f13326z.put(i10, aVar);
        this.A.l(i10, aVar2);
    }

    public final void q(Object obj, long j10) {
        c.a V1 = V1();
        p3(V1, 26, new h1(V1, obj, j10));
    }

    public final void q0(int i10, f0.b bVar) {
        c.a T1 = T1(i10, bVar);
        p3(T1, 1023, new m1(T1));
    }

    public final void r(y0.y yVar, androidx.media3.exoplayer.o oVar) {
        c.a V1 = V1();
        p3(V1, 1017, new r1(V1, yVar, oVar));
    }

    public void r0(long j10) {
        c.a P1 = P1();
        p3(P1, 18, new j1(P1, j10));
    }

    public void release() {
        ((o) androidx.media3.common.util.a.i(this.C)).c(new n0(this));
    }

    public void s(d dVar) {
        c.a P1 = P1();
        p3(P1, 27, new b0(P1, dVar));
    }

    public final void s0(boolean z10, int i10) {
        c.a P1 = P1();
        p3(P1, 5, new c0(P1, z10, i10));
    }

    public void t(List list) {
        c.a P1 = P1();
        p3(P1, 27, new r(P1, list));
    }

    public void t0(h1 h1Var) {
        c.a P1 = P1();
        p3(P1, 19, new y0(P1, h1Var));
    }

    public final void u(n nVar) {
        c.a U1 = U1();
        p3(U1, 1020, new q0(U1, nVar));
    }

    public final void u0(int i10, int i11) {
        c.a V1 = V1();
        p3(V1, 24, new r0(V1, i10, i11));
    }

    public final void v(long j10) {
        c.a V1 = V1();
        p3(V1, 1010, new o0(V1, j10));
    }

    public void v0(k0 k0Var) {
        c.a P1 = P1();
        p3(P1, 15, new b1(P1, k0Var));
    }

    public final void w(Exception exc) {
        c.a V1 = V1();
        p3(V1, 1029, new n(V1, exc));
    }

    public void w0(boolean z10) {
        c.a P1 = P1();
        p3(P1, 7, new d0(P1, z10));
    }

    public final void x(Exception exc) {
        c.a V1 = V1();
        p3(V1, 1030, new g(V1, exc));
    }

    public final void y(int i10, long j10, long j11) {
        c.a V1 = V1();
        p3(V1, 1011, new w0(V1, i10, j10, j11));
    }

    public final void z(n nVar) {
        c.a U1 = U1();
        p3(U1, 1013, new l0(U1, nVar));
    }
}
