package h1;

import a1.d;
import androidx.media3.common.util.r;
import h1.c;

public final /* synthetic */ class b0 implements r.a {

    /* renamed from: a  reason: collision with root package name */
    public final /* synthetic */ c.a f13170a;

    /* renamed from: b  reason: collision with root package name */
    public final /* synthetic */ d f13171b;

    public /* synthetic */ b0(c.a aVar, d dVar) {
        this.f13170a = aVar;
        this.f13171b = dVar;
    }

    public final void invoke(Object obj) {
        ((c) obj).T(this.f13170a, this.f13171b);
    }
}
