package h1;

import androidx.media3.common.util.r;
import h1.c;
import s1.b0;

public final /* synthetic */ class u0 implements r.a {

    /* renamed from: a  reason: collision with root package name */
    public final /* synthetic */ c.a f13314a;

    /* renamed from: b  reason: collision with root package name */
    public final /* synthetic */ b0 f13315b;

    public /* synthetic */ u0(c.a aVar, b0 b0Var) {
        this.f13314a = aVar;
        this.f13315b = b0Var;
    }

    public final void invoke(Object obj) {
        ((c) obj).e(this.f13314a, this.f13315b);
    }
}
