package h1;

import a1.d;
import android.content.Context;
import android.media.DeniedByServerException;
import android.media.MediaCodec;
import android.media.MediaDrm;
import android.media.NotProvisionedException;
import android.media.metrics.LogSessionId;
import android.media.metrics.MediaMetricsManager;
import android.media.metrics.PlaybackMetrics;
import android.media.metrics.PlaybackSession;
import android.media.metrics.TrackChangeEvent;
import android.os.SystemClock;
import android.system.ErrnoException;
import android.system.OsConstants;
import android.util.Pair;
import androidx.media3.common.util.NetworkTypeObserver;
import androidx.media3.common.util.b1;
import androidx.media3.exoplayer.audio.a0;
import androidx.media3.exoplayer.o;
import androidx.media3.exoplayer.t;
import com.google.common.collect.e1;
import d1.i0;
import d1.u;
import d1.x;
import d1.z;
import h1.b4;
import h1.c;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.net.SocketTimeoutException;
import java.net.UnknownHostException;
import java.util.HashMap;
import java.util.List;
import java.util.UUID;
import k1.h;
import k1.n;
import k1.t0;
import o1.b0;
import o1.s;
import s1.f0;
import y0.c1;
import y0.e;
import y0.e0;
import y0.h1;
import y0.k0;
import y0.l;
import y0.l0;
import y0.l1;
import y0.o0;
import y0.p1;
import y0.q;
import y0.q0;
import y0.r;
import y0.r0;
import y0.s0;
import y0.y;

public final class a4 implements c, b4.a {
    private boolean A;

    /* renamed from: a  reason: collision with root package name */
    private final Context f13139a;

    /* renamed from: b  reason: collision with root package name */
    private final b4 f13140b;

    /* renamed from: c  reason: collision with root package name */
    private final PlaybackSession f13141c;

    /* renamed from: d  reason: collision with root package name */
    private final long f13142d = SystemClock.elapsedRealtime();

    /* renamed from: e  reason: collision with root package name */
    private final c1.d f13143e = new c1.d();

    /* renamed from: f  reason: collision with root package name */
    private final c1.b f13144f = new c1.b();

    /* renamed from: g  reason: collision with root package name */
    private final HashMap f13145g = new HashMap();

    /* renamed from: h  reason: collision with root package name */
    private final HashMap f13146h = new HashMap();

    /* renamed from: i  reason: collision with root package name */
    private String f13147i;

    /* renamed from: j  reason: collision with root package name */
    private PlaybackMetrics.Builder f13148j;

    /* renamed from: k  reason: collision with root package name */
    private int f13149k;

    /* renamed from: l  reason: collision with root package name */
    private int f13150l = 0;

    /* renamed from: m  reason: collision with root package name */
    private int f13151m = 0;

    /* renamed from: n  reason: collision with root package name */
    private q0 f13152n;

    /* renamed from: o  reason: collision with root package name */
    private b f13153o;

    /* renamed from: p  reason: collision with root package name */
    private b f13154p;

    /* renamed from: q  reason: collision with root package name */
    private b f13155q;

    /* renamed from: r  reason: collision with root package name */
    private y f13156r;

    /* renamed from: s  reason: collision with root package name */
    private y f13157s;

    /* renamed from: t  reason: collision with root package name */
    private y f13158t;

    /* renamed from: u  reason: collision with root package name */
    private boolean f13159u;

    /* renamed from: v  reason: collision with root package name */
    private int f13160v;

    /* renamed from: w  reason: collision with root package name */
    private boolean f13161w;

    /* renamed from: x  reason: collision with root package name */
    private int f13162x;

    /* renamed from: y  reason: collision with root package name */
    private int f13163y;

    /* renamed from: z  reason: collision with root package name */
    private int f13164z;

    private static final class a {

        /* renamed from: a  reason: collision with root package name */
        public final int f13165a;

        /* renamed from: b  reason: collision with root package name */
        public final int f13166b;

        public a(int i10, int i11) {
            this.f13165a = i10;
            this.f13166b = i11;
        }
    }

    private static final class b {

        /* renamed from: a  reason: collision with root package name */
        public final y f13167a;

        /* renamed from: b  reason: collision with root package name */
        public final int f13168b;

        /* renamed from: c  reason: collision with root package name */
        public final String f13169c;

        public b(y yVar, int i10, String str) {
            this.f13167a = yVar;
            this.f13168b = i10;
            this.f13169c = str;
        }
    }

    private a4(Context context, PlaybackSession playbackSession) {
        this.f13139a = context.getApplicationContext();
        this.f13141c = playbackSession;
        x1 x1Var = new x1();
        this.f13140b = x1Var;
        x1Var.e(this);
    }

    private boolean A0(b bVar) {
        if (bVar == null || !bVar.f13169c.equals(this.f13140b.a())) {
            return false;
        }
        return true;
    }

    public static a4 B0(Context context) {
        MediaMetricsManager a10 = v3.a(context.getSystemService("media_metrics"));
        if (a10 == null) {
            return null;
        }
        return new a4(context, a10.createPlaybackSession());
    }

    private void C0() {
        long j10;
        long j11;
        int i10;
        PlaybackMetrics.Builder builder = this.f13148j;
        if (builder != null && this.A) {
            PlaybackMetrics.Builder unused = builder.setAudioUnderrunCount(this.f13164z);
            PlaybackMetrics.Builder unused2 = this.f13148j.setVideoFramesDropped(this.f13162x);
            PlaybackMetrics.Builder unused3 = this.f13148j.setVideoFramesPlayed(this.f13163y);
            Long l10 = (Long) this.f13145g.get(this.f13147i);
            PlaybackMetrics.Builder builder2 = this.f13148j;
            if (l10 == null) {
                j10 = 0;
            } else {
                j10 = l10.longValue();
            }
            PlaybackMetrics.Builder unused4 = builder2.setNetworkTransferDurationMillis(j10);
            Long l11 = (Long) this.f13146h.get(this.f13147i);
            PlaybackMetrics.Builder builder3 = this.f13148j;
            if (l11 == null) {
                j11 = 0;
            } else {
                j11 = l11.longValue();
            }
            PlaybackMetrics.Builder unused5 = builder3.setNetworkBytesRead(j11);
            PlaybackMetrics.Builder builder4 = this.f13148j;
            if (l11 == null || l11.longValue() <= 0) {
                i10 = 0;
            } else {
                i10 = 1;
            }
            PlaybackMetrics.Builder unused6 = builder4.setStreamSource(i10);
            this.f13141c.reportPlaybackMetrics(this.f13148j.build());
        }
        this.f13148j = null;
        this.f13147i = null;
        this.f13164z = 0;
        this.f13162x = 0;
        this.f13163y = 0;
        this.f13156r = null;
        this.f13157s = null;
        this.f13158t = null;
        this.A = false;
    }

    private static int D0(int i10) {
        switch (b1.g0(i10)) {
            case 6002:
                return 24;
            case 6003:
                return 28;
            case 6004:
                return 25;
            case 6005:
                return 26;
            default:
                return 27;
        }
    }

    private static r E0(com.google.common.collect.y yVar) {
        r rVar;
        e1 p10 = yVar.iterator();
        while (p10.hasNext()) {
            l1.a aVar = (l1.a) p10.next();
            int i10 = 0;
            while (true) {
                if (i10 < aVar.f19929a) {
                    if (aVar.j(i10) && (rVar = aVar.d(i10).f20075r) != null) {
                        return rVar;
                    }
                    i10++;
                }
            }
        }
        return null;
    }

    private static int F0(r rVar) {
        for (int i10 = 0; i10 < rVar.f19995y; i10++) {
            UUID uuid = rVar.e(i10).f19997w;
            if (uuid.equals(l.f19918d)) {
                return 3;
            }
            if (uuid.equals(l.f19919e)) {
                return 2;
            }
            if (uuid.equals(l.f19917c)) {
                return 6;
            }
        }
        return 1;
    }

    private static a G0(q0 q0Var, Context context, boolean z10) {
        boolean z11;
        int i10;
        int i11;
        if (q0Var.f19989a == 1001) {
            return new a(20, 0);
        }
        if (q0Var instanceof t) {
            t tVar = (t) q0Var;
            if (tVar.E == 1) {
                z11 = true;
            } else {
                z11 = false;
            }
            i10 = tVar.I;
        } else {
            i10 = 0;
            z11 = false;
        }
        Throwable th2 = (Throwable) androidx.media3.common.util.a.e(q0Var.getCause());
        if (th2 instanceof IOException) {
            if (th2 instanceof z) {
                return new a(5, ((z) th2).f12237y);
            }
            if ((th2 instanceof d1.y) || (th2 instanceof o0)) {
                if (z10) {
                    i11 = 10;
                } else {
                    i11 = 11;
                }
                return new a(i11, 0);
            } else if ((th2 instanceof x) || (th2 instanceof i0.a)) {
                if (NetworkTypeObserver.d(context).f() == 1) {
                    return new a(3, 0);
                }
                Throwable cause = th2.getCause();
                if (cause instanceof UnknownHostException) {
                    return new a(6, 0);
                }
                if (cause instanceof SocketTimeoutException) {
                    return new a(7, 0);
                }
                if (!(th2 instanceof x) || ((x) th2).f12235x != 1) {
                    return new a(8, 0);
                }
                return new a(4, 0);
            } else if (q0Var.f19989a == 1002) {
                return new a(21, 0);
            } else {
                if (th2 instanceof n.a) {
                    Throwable th3 = (Throwable) androidx.media3.common.util.a.e(th2.getCause());
                    int i12 = b1.f3695a;
                    if (i12 >= 21 && (th3 instanceof MediaDrm.MediaDrmStateException)) {
                        int h02 = b1.h0(((MediaDrm.MediaDrmStateException) th3).getDiagnosticInfo());
                        return new a(D0(h02), h02);
                    } else if (i12 >= 23 && u3.a(th3)) {
                        return new a(27, 0);
                    } else {
                        if (th3 instanceof NotProvisionedException) {
                            return new a(24, 0);
                        }
                        if (th3 instanceof DeniedByServerException) {
                            return new a(29, 0);
                        }
                        if (th3 instanceof t0) {
                            return new a(23, 0);
                        }
                        if (th3 instanceof h.e) {
                            return new a(28, 0);
                        }
                        return new a(30, 0);
                    }
                } else if (!(th2 instanceof u.c) || !(th2.getCause() instanceof FileNotFoundException)) {
                    return new a(9, 0);
                } else {
                    Throwable cause2 = ((Throwable) androidx.media3.common.util.a.e(th2.getCause())).getCause();
                    if (b1.f3695a < 21 || !(cause2 instanceof ErrnoException) || ((ErrnoException) cause2).errno != OsConstants.EACCES) {
                        return new a(31, 0);
                    }
                    return new a(32, 0);
                }
            }
        } else if (z11 && (i10 == 0 || i10 == 1)) {
            return new a(35, 0);
        } else {
            if (z11 && i10 == 3) {
                return new a(15, 0);
            }
            if (z11 && i10 == 2) {
                return new a(23, 0);
            }
            if (th2 instanceof b0.d) {
                return new a(13, b1.h0(((b0.d) th2).f16447y));
            }
            if (th2 instanceof s) {
                return new a(14, ((s) th2).f16526x);
            }
            if (th2 instanceof OutOfMemoryError) {
                return new a(14, 0);
            }
            if (th2 instanceof a0.c) {
                return new a(17, ((a0.c) th2).f3891a);
            }
            if (th2 instanceof a0.f) {
                return new a(18, ((a0.f) th2).f3896a);
            }
            if (!(th2 instanceof MediaCodec.CryptoException)) {
                return new a(22, 0);
            }
            int errorCode = ((MediaCodec.CryptoException) th2).getErrorCode();
            return new a(D0(errorCode), errorCode);
        }
    }

    private static Pair H0(String str) {
        String str2;
        String[] C1 = b1.C1(str, "-");
        String str3 = C1[0];
        if (C1.length >= 2) {
            str2 = C1[1];
        } else {
            str2 = null;
        }
        return Pair.create(str3, str2);
    }

    private static int J0(Context context) {
        switch (NetworkTypeObserver.d(context).f()) {
            case 0:
                return 0;
            case 1:
                return 9;
            case 2:
                return 2;
            case 3:
                return 4;
            case 4:
                return 5;
            case 5:
                return 6;
            case 7:
                return 3;
            case 9:
                return 8;
            case 10:
                return 7;
            default:
                return 1;
        }
    }

    private static int K0(e0 e0Var) {
        e0.h hVar = e0Var.f19617b;
        if (hVar == null) {
            return 0;
        }
        int J0 = b1.J0(hVar.f19715a, hVar.f19716b);
        if (J0 == 0) {
            return 3;
        }
        if (J0 == 1) {
            return 5;
        }
        if (J0 != 2) {
            return 1;
        }
        return 4;
    }

    private static int L0(int i10) {
        if (i10 == 1) {
            return 2;
        }
        if (i10 != 2) {
            return i10 != 3 ? 1 : 4;
        }
        return 3;
    }

    private void M0(c.b bVar) {
        for (int i10 = 0; i10 < bVar.d(); i10++) {
            int b10 = bVar.b(i10);
            c.a c10 = bVar.c(b10);
            if (b10 == 0) {
                this.f13140b.g(c10);
            } else if (b10 == 11) {
                this.f13140b.b(c10, this.f13149k);
            } else {
                this.f13140b.d(c10);
            }
        }
    }

    private void N0(long j10) {
        int J0 = J0(this.f13139a);
        if (J0 != this.f13151m) {
            this.f13151m = J0;
            this.f13141c.reportNetworkEvent(q3.a().setNetworkType(J0).setTimeSinceCreatedMillis(j10 - this.f13142d).build());
        }
    }

    private void O0(long j10) {
        boolean z10;
        q0 q0Var = this.f13152n;
        if (q0Var != null) {
            Context context = this.f13139a;
            if (this.f13160v == 4) {
                z10 = true;
            } else {
                z10 = false;
            }
            a G0 = G0(q0Var, context, z10);
            this.f13141c.reportPlaybackErrorEvent(y1.a().setTimeSinceCreatedMillis(j10 - this.f13142d).setErrorCode(G0.f13165a).setSubErrorCode(G0.f13166b).setException(q0Var).build());
            this.A = true;
            this.f13152n = null;
        }
    }

    private void P0(s0 s0Var, c.b bVar, long j10) {
        if (s0Var.f() != 2) {
            this.f13159u = false;
        }
        if (s0Var.n0() == null) {
            this.f13161w = false;
        } else if (bVar.a(10)) {
            this.f13161w = true;
        }
        int X0 = X0(s0Var);
        if (this.f13150l != X0) {
            this.f13150l = X0;
            this.A = true;
            this.f13141c.reportPlaybackStateEvent(f3.a().setState(this.f13150l).setTimeSinceCreatedMillis(j10 - this.f13142d).build());
        }
    }

    private void Q0(s0 s0Var, c.b bVar, long j10) {
        if (bVar.a(2)) {
            l1 x02 = s0Var.x0();
            boolean d10 = x02.d(2);
            boolean d11 = x02.d(1);
            boolean d12 = x02.d(3);
            if (d10 || d11 || d12) {
                if (!d10) {
                    V0(j10, (y) null, 0);
                }
                if (!d11) {
                    R0(j10, (y) null, 0);
                }
                if (!d12) {
                    T0(j10, (y) null, 0);
                }
            }
        }
        if (A0(this.f13153o)) {
            b bVar2 = this.f13153o;
            y yVar = bVar2.f13167a;
            if (yVar.f20078u != -1) {
                V0(j10, yVar, bVar2.f13168b);
                this.f13153o = null;
            }
        }
        if (A0(this.f13154p)) {
            b bVar3 = this.f13154p;
            R0(j10, bVar3.f13167a, bVar3.f13168b);
            this.f13154p = null;
        }
        if (A0(this.f13155q)) {
            b bVar4 = this.f13155q;
            T0(j10, bVar4.f13167a, bVar4.f13168b);
            this.f13155q = null;
        }
    }

    private void R0(long j10, y yVar, int i10) {
        int i11;
        if (!b1.f(this.f13157s, yVar)) {
            if (this.f13157s == null && i10 == 0) {
                i11 = 1;
            } else {
                i11 = i10;
            }
            this.f13157s = yVar;
            W0(0, j10, yVar, i11);
        }
    }

    private void S0(s0 s0Var, c.b bVar) {
        r E0;
        if (bVar.a(0)) {
            c.a c10 = bVar.c(0);
            if (this.f13148j != null) {
                U0(c10.f13175b, c10.f13177d);
            }
        }
        if (!(!bVar.a(2) || this.f13148j == null || (E0 = E0(s0Var.x0().b())) == null)) {
            PlaybackMetrics.Builder unused = t2.a(b1.l(this.f13148j)).setDrmType(F0(E0));
        }
        if (bVar.a(1011)) {
            this.f13164z++;
        }
    }

    private void T0(long j10, y yVar, int i10) {
        int i11;
        if (!b1.f(this.f13158t, yVar)) {
            if (this.f13158t == null && i10 == 0) {
                i11 = 1;
            } else {
                i11 = i10;
            }
            this.f13158t = yVar;
            W0(2, j10, yVar, i11);
        }
    }

    private void U0(c1 c1Var, f0.b bVar) {
        int f10;
        int i10;
        PlaybackMetrics.Builder builder = this.f13148j;
        if (bVar != null && (f10 = c1Var.f(bVar.f17422a)) != -1) {
            c1Var.j(f10, this.f13144f);
            c1Var.r(this.f13144f.f19552c, this.f13143e);
            PlaybackMetrics.Builder unused = builder.setStreamType(K0(this.f13143e.f19573c));
            c1.d dVar = this.f13143e;
            if (dVar.f19583m != -9223372036854775807L && !dVar.f19581k && !dVar.f19579i && !dVar.g()) {
                PlaybackMetrics.Builder unused2 = builder.setMediaDurationMillis(this.f13143e.e());
            }
            if (this.f13143e.g()) {
                i10 = 2;
            } else {
                i10 = 1;
            }
            PlaybackMetrics.Builder unused3 = builder.setPlaybackType(i10);
            this.A = true;
        }
    }

    private void V0(long j10, y yVar, int i10) {
        int i11;
        if (!b1.f(this.f13156r, yVar)) {
            if (this.f13156r == null && i10 == 0) {
                i11 = 1;
            } else {
                i11 = i10;
            }
            this.f13156r = yVar;
            W0(1, j10, yVar, i11);
        }
    }

    private void W0(int i10, long j10, y yVar, int i11) {
        TrackChangeEvent.Builder a10 = j2.a(i10).setTimeSinceCreatedMillis(j10 - this.f13142d);
        if (yVar != null) {
            TrackChangeEvent.Builder unused = a10.setTrackState(1);
            TrackChangeEvent.Builder unused2 = a10.setTrackChangeReason(L0(i11));
            String str = yVar.f20070m;
            if (str != null) {
                TrackChangeEvent.Builder unused3 = a10.setContainerMimeType(str);
            }
            String str2 = yVar.f20071n;
            if (str2 != null) {
                TrackChangeEvent.Builder unused4 = a10.setSampleMimeType(str2);
            }
            String str3 = yVar.f20067j;
            if (str3 != null) {
                TrackChangeEvent.Builder unused5 = a10.setCodecName(str3);
            }
            int i12 = yVar.f20066i;
            if (i12 != -1) {
                TrackChangeEvent.Builder unused6 = a10.setBitrate(i12);
            }
            int i13 = yVar.f20077t;
            if (i13 != -1) {
                TrackChangeEvent.Builder unused7 = a10.setWidth(i13);
            }
            int i14 = yVar.f20078u;
            if (i14 != -1) {
                TrackChangeEvent.Builder unused8 = a10.setHeight(i14);
            }
            int i15 = yVar.B;
            if (i15 != -1) {
                TrackChangeEvent.Builder unused9 = a10.setChannelCount(i15);
            }
            int i16 = yVar.C;
            if (i16 != -1) {
                TrackChangeEvent.Builder unused10 = a10.setAudioSampleRate(i16);
            }
            String str4 = yVar.f20061d;
            if (str4 != null) {
                Pair H0 = H0(str4);
                TrackChangeEvent.Builder unused11 = a10.setLanguage((String) H0.first);
                Object obj = H0.second;
                if (obj != null) {
                    TrackChangeEvent.Builder unused12 = a10.setLanguageRegion((String) obj);
                }
            }
            float f10 = yVar.f20079v;
            if (f10 != -1.0f) {
                TrackChangeEvent.Builder unused13 = a10.setVideoFrameRate(f10);
            }
        } else {
            TrackChangeEvent.Builder unused14 = a10.setTrackState(0);
        }
        this.A = true;
        this.f13141c.reportTrackChangeEvent(a10.build());
    }

    private int X0(s0 s0Var) {
        int f10 = s0Var.f();
        if (this.f13159u) {
            return 5;
        }
        if (this.f13161w) {
            return 13;
        }
        if (f10 == 4) {
            return 11;
        }
        if (f10 == 2) {
            int i10 = this.f13150l;
            if (i10 == 0 || i10 == 2 || i10 == 12) {
                return 2;
            }
            if (!s0Var.I()) {
                return 7;
            }
            if (s0Var.J0() != 0) {
                return 10;
            }
            return 6;
        } else if (f10 == 3) {
            if (!s0Var.I()) {
                return 4;
            }
            if (s0Var.J0() != 0) {
                return 9;
            }
            return 3;
        } else if (f10 != 1 || this.f13150l == 0) {
            return this.f13150l;
        } else {
            return 12;
        }
    }

    public /* synthetic */ void A(c.a aVar, a0.a aVar2) {
        b.k(this, aVar, aVar2);
    }

    public /* synthetic */ void B(c.a aVar, int i10) {
        b.w(this, aVar, i10);
    }

    public /* synthetic */ void C(c.a aVar) {
        b.u(this, aVar);
    }

    public /* synthetic */ void D(c.a aVar, h1 h1Var) {
        b.d0(this, aVar, h1Var);
    }

    public void E(c.a aVar, int i10, long j10, long j11) {
        long j12;
        f0.b bVar = aVar.f13177d;
        if (bVar != null) {
            String c10 = this.f13140b.c(aVar.f13175b, (f0.b) androidx.media3.common.util.a.e(bVar));
            Long l10 = (Long) this.f13146h.get(c10);
            Long l11 = (Long) this.f13145g.get(c10);
            HashMap hashMap = this.f13146h;
            long j13 = 0;
            if (l10 == null) {
                j12 = 0;
            } else {
                j12 = l10.longValue();
            }
            hashMap.put(c10, Long.valueOf(j12 + j10));
            HashMap hashMap2 = this.f13145g;
            if (l11 != null) {
                j13 = l11.longValue();
            }
            hashMap2.put(c10, Long.valueOf(j13 + ((long) i10)));
        }
    }

    public /* synthetic */ void F(c.a aVar, k0 k0Var) {
        b.S(this, aVar, k0Var);
    }

    public /* synthetic */ void G(c.a aVar, Object obj, long j10) {
        b.U(this, aVar, obj, j10);
    }

    public /* synthetic */ void H(c.a aVar, y yVar, o oVar) {
        b.m0(this, aVar, yVar, oVar);
    }

    public /* synthetic */ void I(c.a aVar, long j10) {
        b.i(this, aVar, j10);
    }

    public LogSessionId I0() {
        return this.f13141c.getSessionId();
    }

    public /* synthetic */ void J(c.a aVar) {
        b.y(this, aVar);
    }

    public /* synthetic */ void K(c.a aVar) {
        b.v(this, aVar);
    }

    public /* synthetic */ void L(c.a aVar, Exception exc) {
        b.g0(this, aVar, exc);
    }

    public /* synthetic */ void M(c.a aVar, int i10) {
        b.N(this, aVar, i10);
    }

    public /* synthetic */ void N(c.a aVar, l1 l1Var) {
        b.e0(this, aVar, l1Var);
    }

    public void O(c.a aVar, String str) {
        f0.b bVar = aVar.f13177d;
        if (bVar == null || !bVar.b()) {
            C0();
            this.f13147i = str;
            this.f13148j = u2.a().setPlayerName("AndroidXMedia3").setPlayerVersion("1.4.1");
            U0(aVar.f13175b, aVar.f13177d);
        }
    }

    public /* synthetic */ void P(c.a aVar, Exception exc) {
        b.j(this, aVar, exc);
    }

    public void Q(c.a aVar, String str) {
    }

    public /* synthetic */ void R(c.a aVar, androidx.media3.exoplayer.n nVar) {
        b.k0(this, aVar, nVar);
    }

    public /* synthetic */ void S(c.a aVar, int i10) {
        b.V(this, aVar, i10);
    }

    public /* synthetic */ void T(c.a aVar, d dVar) {
        b.o(this, aVar, dVar);
    }

    public /* synthetic */ void U(c.a aVar, boolean z10) {
        b.Z(this, aVar, z10);
    }

    public /* synthetic */ void V(c.a aVar, boolean z10) {
        b.C(this, aVar, z10);
    }

    public /* synthetic */ void W(c.a aVar, List list) {
        b.p(this, aVar, list);
    }

    public void X(c.a aVar, s0.e eVar, s0.e eVar2, int i10) {
        if (i10 == 1) {
            this.f13159u = true;
        }
        this.f13149k = i10;
    }

    public /* synthetic */ void Y(c.a aVar, q0 q0Var) {
        b.P(this, aVar, q0Var);
    }

    public /* synthetic */ void Z(c.a aVar, a0.a aVar2) {
        b.l(this, aVar, aVar2);
    }

    public void a(c.a aVar, s1.b0 b0Var) {
        if (aVar.f13177d != null) {
            b bVar = new b((y) androidx.media3.common.util.a.e(b0Var.f17383c), b0Var.f17384d, this.f13140b.c(aVar.f13175b, (f0.b) androidx.media3.common.util.a.e(aVar.f13177d)));
            int i10 = b0Var.f17382b;
            if (i10 != 0) {
                if (i10 == 1) {
                    this.f13154p = bVar;
                    return;
                } else if (i10 != 2) {
                    if (i10 == 3) {
                        this.f13155q = bVar;
                        return;
                    }
                    return;
                }
            }
            this.f13153o = bVar;
        }
    }

    public /* synthetic */ void a0(c.a aVar, s0.b bVar) {
        b.n(this, aVar, bVar);
    }

    public /* synthetic */ void b(c.a aVar) {
        b.Y(this, aVar);
    }

    public /* synthetic */ void b0(c.a aVar, Exception exc) {
        b.b(this, aVar, exc);
    }

    public /* synthetic */ void c(c.a aVar, int i10, int i11) {
        b.b0(this, aVar, i10, i11);
    }

    public /* synthetic */ void c0(c.a aVar, long j10) {
        b.W(this, aVar, j10);
    }

    public /* synthetic */ void d(c.a aVar, String str, long j10, long j11) {
        b.d(this, aVar, str, j10, j11);
    }

    public /* synthetic */ void d0(c.a aVar, long j10) {
        b.X(this, aVar, j10);
    }

    public /* synthetic */ void e(c.a aVar, s1.b0 b0Var) {
        b.f0(this, aVar, b0Var);
    }

    public void e0(c.a aVar, q0 q0Var) {
        this.f13152n = q0Var;
    }

    public /* synthetic */ void f(c.a aVar, s1.y yVar, s1.b0 b0Var) {
        b.D(this, aVar, yVar, b0Var);
    }

    public void f0(c.a aVar, p1 p1Var) {
        b bVar = this.f13153o;
        if (bVar != null) {
            y yVar = bVar.f13167a;
            if (yVar.f20078u == -1) {
                this.f13153o = new b(yVar.a().v0(p1Var.f19970a).Y(p1Var.f19971b).K(), bVar.f13168b, bVar.f13169c);
            }
        }
    }

    public void g(s0 s0Var, c.b bVar) {
        if (bVar.d() != 0) {
            M0(bVar);
            long elapsedRealtime = SystemClock.elapsedRealtime();
            S0(s0Var, bVar);
            O0(elapsedRealtime);
            Q0(s0Var, bVar, elapsedRealtime);
            N0(elapsedRealtime);
            P0(s0Var, bVar, elapsedRealtime);
            if (bVar.a(1028)) {
                this.f13140b.f(bVar.c(1028));
            }
        }
    }

    public /* synthetic */ void g0(c.a aVar, long j10, int i10) {
        b.l0(this, aVar, j10, i10);
    }

    public /* synthetic */ void h(c.a aVar) {
        b.t(this, aVar);
    }

    public /* synthetic */ void h0(c.a aVar, int i10) {
        b.c0(this, aVar, i10);
    }

    public /* synthetic */ void i(c.a aVar) {
        b.s(this, aVar);
    }

    public /* synthetic */ void i0(c.a aVar, int i10, int i11, int i12, float f10) {
        b.n0(this, aVar, i10, i11, i12, f10);
    }

    public /* synthetic */ void j(c.a aVar, boolean z10, int i10) {
        b.L(this, aVar, z10, i10);
    }

    public /* synthetic */ void j0(c.a aVar, int i10, boolean z10) {
        b.r(this, aVar, i10, z10);
    }

    public /* synthetic */ void k(c.a aVar, androidx.media3.exoplayer.n nVar) {
        b.g(this, aVar, nVar);
    }

    public /* synthetic */ void k0(c.a aVar, y yVar, o oVar) {
        b.h(this, aVar, yVar, oVar);
    }

    public /* synthetic */ void l(c.a aVar, int i10, long j10) {
        b.z(this, aVar, i10, j10);
    }

    public /* synthetic */ void l0(c.a aVar, String str) {
        b.e(this, aVar, str);
    }

    public /* synthetic */ void m(c.a aVar, e eVar) {
        b.a(this, aVar, eVar);
    }

    public /* synthetic */ void m0(c.a aVar, k0 k0Var) {
        b.J(this, aVar, k0Var);
    }

    public /* synthetic */ void n(c.a aVar, e0 e0Var, int i10) {
        b.I(this, aVar, e0Var, i10);
    }

    public /* synthetic */ void n0(c.a aVar, boolean z10, int i10) {
        b.R(this, aVar, z10, i10);
    }

    public /* synthetic */ void o(c.a aVar, androidx.media3.exoplayer.n nVar) {
        b.f(this, aVar, nVar);
    }

    public /* synthetic */ void o0(c.a aVar, String str, long j10, long j11) {
        b.i0(this, aVar, str, j10, j11);
    }

    public /* synthetic */ void p(c.a aVar, float f10) {
        b.o0(this, aVar, f10);
    }

    public /* synthetic */ void p0(c.a aVar, String str, long j10) {
        b.c(this, aVar, str, j10);
    }

    public void q(c.a aVar, String str, boolean z10) {
        f0.b bVar = aVar.f13177d;
        if ((bVar == null || !bVar.b()) && str.equals(this.f13147i)) {
            C0();
        }
        this.f13145g.remove(str);
        this.f13146h.remove(str);
    }

    public void q0(c.a aVar, androidx.media3.exoplayer.n nVar) {
        this.f13162x += nVar.f4546g;
        this.f13163y += nVar.f4544e;
    }

    public /* synthetic */ void r(c.a aVar, Exception exc) {
        b.x(this, aVar, exc);
    }

    public void r0(c.a aVar, s1.y yVar, s1.b0 b0Var, IOException iOException, boolean z10) {
        this.f13160v = b0Var.f17381a;
    }

    public /* synthetic */ void s(c.a aVar, int i10, long j10, long j11) {
        b.m(this, aVar, i10, j10, j11);
    }

    public /* synthetic */ void s0(c.a aVar, s1.y yVar, s1.b0 b0Var) {
        b.E(this, aVar, yVar, b0Var);
    }

    public /* synthetic */ void t(c.a aVar, long j10) {
        b.H(this, aVar, j10);
    }

    public /* synthetic */ void t0(c.a aVar, boolean z10) {
        b.G(this, aVar, z10);
    }

    public void u(c.a aVar, String str, String str2) {
    }

    public /* synthetic */ void u0(c.a aVar, boolean z10) {
        b.a0(this, aVar, z10);
    }

    public /* synthetic */ void v(c.a aVar, r0 r0Var) {
        b.M(this, aVar, r0Var);
    }

    public /* synthetic */ void v0(c.a aVar) {
        b.Q(this, aVar);
    }

    public /* synthetic */ void w(c.a aVar, int i10) {
        b.O(this, aVar, i10);
    }

    public /* synthetic */ void w0(c.a aVar, String str, long j10) {
        b.h0(this, aVar, str, j10);
    }

    public /* synthetic */ void x(c.a aVar, q qVar) {
        b.q(this, aVar, qVar);
    }

    public /* synthetic */ void x0(c.a aVar, boolean z10) {
        b.B(this, aVar, z10);
    }

    public /* synthetic */ void y(c.a aVar, String str) {
        b.j0(this, aVar, str);
    }

    public /* synthetic */ void y0(c.a aVar, s1.y yVar, s1.b0 b0Var) {
        b.F(this, aVar, yVar, b0Var);
    }

    public /* synthetic */ void z(c.a aVar, l0 l0Var) {
        b.K(this, aVar, l0Var);
    }

    public /* synthetic */ void z0(c.a aVar, int i10) {
        b.T(this, aVar, i10);
    }
}
