package x6;

import android.content.ContentResolver;
import android.content.res.AssetFileDescriptor;
import android.net.Uri;
import android.provider.ContactsContract;
import android.provider.MediaStore;
import c9.a;
import java.io.FileNotFoundException;
import java.net.MalformedURLException;
import java.net.URL;

public abstract class f {

    /* renamed from: a  reason: collision with root package name */
    private static final Uri f19401a = Uri.withAppendedPath((Uri) a.e(ContactsContract.AUTHORITY_URI), "display_photo");

    public static AssetFileDescriptor a(ContentResolver contentResolver, Uri uri) {
        if (i(uri)) {
            try {
                return contentResolver.openAssetFileDescriptor(uri, "r");
            } catch (FileNotFoundException unused) {
            }
        }
        return null;
    }

    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r1v3, resolved type: java.lang.String} */
    /* JADX WARNING: type inference failed for: r1v0 */
    /* JADX WARNING: type inference failed for: r1v2, types: [android.database.Cursor] */
    /* JADX WARNING: type inference failed for: r1v4 */
    /* JADX WARNING: type inference failed for: r1v5 */
    /* JADX WARNING: Multi-variable type inference failed */
    /* JADX WARNING: Removed duplicated region for block: B:19:0x0034  */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public static java.lang.String b(android.content.ContentResolver r8, android.net.Uri r9) {
        /*
            boolean r0 = i(r9)
            r1 = 0
            if (r0 == 0) goto L_0x0038
            r4 = 0
            r5 = 0
            r6 = 0
            r7 = 0
            r2 = r8
            r3 = r9
            android.database.Cursor r8 = r2.query(r3, r4, r5, r6, r7)     // Catch:{ all -> 0x0031 }
            if (r8 == 0) goto L_0x002b
            boolean r9 = r8.moveToFirst()     // Catch:{ all -> 0x0028 }
            if (r9 == 0) goto L_0x002b
            java.lang.String r9 = "_data"
            int r9 = r8.getColumnIndex(r9)     // Catch:{ all -> 0x0028 }
            r0 = -1
            if (r9 == r0) goto L_0x002b
            java.lang.String r9 = r8.getString(r9)     // Catch:{ all -> 0x0028 }
            r1 = r9
            goto L_0x002b
        L_0x0028:
            r9 = move-exception
            r1 = r8
            goto L_0x0032
        L_0x002b:
            if (r8 == 0) goto L_0x0042
            r8.close()
            goto L_0x0042
        L_0x0031:
            r9 = move-exception
        L_0x0032:
            if (r1 == 0) goto L_0x0037
            r1.close()
        L_0x0037:
            throw r9
        L_0x0038:
            boolean r8 = j(r9)
            if (r8 == 0) goto L_0x0042
            java.lang.String r1 = r9.getPath()
        L_0x0042:
            return r1
        */
        throw new UnsupportedOperationException("Method not decompiled: x6.f.b(android.content.ContentResolver, android.net.Uri):java.lang.String");
    }

    public static String c(Uri uri) {
        if (uri == null) {
            return null;
        }
        return uri.getScheme();
    }

    public static Uri d(int i10) {
        return new Uri.Builder().scheme("res").path(String.valueOf(i10)).build();
    }

    public static boolean e(Uri uri) {
        return "data".equals(c(uri));
    }

    public static boolean f(Uri uri) {
        return "asset".equals(c(uri));
    }

    public static boolean g(Uri uri) {
        String uri2 = uri.toString();
        if (uri2.startsWith(MediaStore.Images.Media.EXTERNAL_CONTENT_URI.toString()) || uri2.startsWith(MediaStore.Images.Media.INTERNAL_CONTENT_URI.toString())) {
            return true;
        }
        return false;
    }

    public static boolean h(Uri uri) {
        if (uri.getPath() != null && i(uri) && "com.android.contacts".equals(uri.getAuthority()) && !uri.getPath().startsWith((String) a.e(f19401a.getPath()))) {
            return true;
        }
        return false;
    }

    public static boolean i(Uri uri) {
        return "content".equals(c(uri));
    }

    public static boolean j(Uri uri) {
        return "file".equals(c(uri));
    }

    public static boolean k(Uri uri) {
        return "res".equals(c(uri));
    }

    public static boolean l(Uri uri) {
        String c10 = c(uri);
        if ("https".equals(c10) || "http".equals(c10)) {
            return true;
        }
        return false;
    }

    public static boolean m(Uri uri) {
        return "android.resource".equals(c(uri));
    }

    public static URL n(Uri uri) {
        if (uri == null) {
            return null;
        }
        try {
            return new URL(uri.toString());
        } catch (MalformedURLException e10) {
            throw new RuntimeException(e10);
        }
    }
}
