package ck;

abstract class b {
}
