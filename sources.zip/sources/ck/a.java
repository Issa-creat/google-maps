package ck;

public abstract class a extends c {
}
