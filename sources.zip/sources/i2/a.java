package i2;

import androidx.media3.common.util.f0;
import b2.l0;
import b2.o0;
import b2.q;
import b2.r;
import b2.s;
import b2.t;
import java.util.List;

public final class a implements r {

    /* renamed from: a  reason: collision with root package name */
    private final f0 f13970a = new f0(4);

    /* renamed from: b  reason: collision with root package name */
    private final o0 f13971b = new o0(-1, -1, "image/heif");

    private boolean a(s sVar, int i10) {
        this.f13970a.Q(4);
        sVar.o(this.f13970a.e(), 0, 4);
        if (this.f13970a.J() == ((long) i10)) {
            return true;
        }
        return false;
    }

    public void b(t tVar) {
        this.f13971b.b(tVar);
    }

    public void c(long j10, long j11) {
        this.f13971b.c(j10, j11);
    }

    public /* synthetic */ r d() {
        return q.b(this);
    }

    public int g(s sVar, l0 l0Var) {
        return this.f13971b.g(sVar, l0Var);
    }

    public boolean h(s sVar) {
        sVar.g(4);
        if (!a(sVar, 1718909296) || !a(sVar, 1751476579)) {
            return false;
        }
        return true;
    }

    public /* synthetic */ List i() {
        return q.a(this);
    }

    public void release() {
    }
}
