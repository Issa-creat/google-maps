package g8;

import android.net.Uri;
import j6.d;
import java.util.Iterator;
import java.util.LinkedHashSet;
import k8.s;
import p6.j;
import t6.CloseableReference;

public class c {

    /* renamed from: a  reason: collision with root package name */
    private final d f13102a;

    /* renamed from: b  reason: collision with root package name */
    private final s f13103b;

    /* renamed from: c  reason: collision with root package name */
    private final s.b f13104c = new a();

    /* renamed from: d  reason: collision with root package name */
    private final LinkedHashSet f13105d = new LinkedHashSet();

    class a implements s.b {
        a() {
        }

        /* renamed from: b */
        public void a(d dVar, boolean z10) {
            c.this.f(dVar, z10);
        }
    }

    static class b implements d {

        /* renamed from: a  reason: collision with root package name */
        private final d f13107a;

        /* renamed from: b  reason: collision with root package name */
        private final int f13108b;

        public b(d dVar, int i10) {
            this.f13107a = dVar;
            this.f13108b = i10;
        }

        public boolean a(Uri uri) {
            return this.f13107a.a(uri);
        }

        public boolean b() {
            return false;
        }

        public String c() {
            return null;
        }

        public boolean equals(Object obj) {
            if (obj == this) {
                return true;
            }
            if (!(obj instanceof b)) {
                return false;
            }
            b bVar = (b) obj;
            if (this.f13108b != bVar.f13108b || !this.f13107a.equals(bVar.f13107a)) {
                return false;
            }
            return true;
        }

        public int hashCode() {
            return (this.f13107a.hashCode() * 1013) + this.f13108b;
        }

        public String toString() {
            return j.c(this).b("imageCacheKey", this.f13107a).a("frameIndex", this.f13108b).toString();
        }
    }

    public c(d dVar, s sVar) {
        this.f13102a = dVar;
        this.f13103b = sVar;
    }

    private b e(int i10) {
        return new b(this.f13102a, i10);
    }

    private synchronized d g() {
        d dVar;
        Iterator it = this.f13105d.iterator();
        if (it.hasNext()) {
            dVar = (d) it.next();
            it.remove();
        } else {
            dVar = null;
        }
        return dVar;
    }

    public CloseableReference a(int i10, CloseableReference closeableReference) {
        return this.f13103b.f(e(i10), closeableReference, this.f13104c);
    }

    public boolean b(int i10) {
        return this.f13103b.contains(e(i10));
    }

    public CloseableReference c(int i10) {
        return this.f13103b.get(e(i10));
    }

    public CloseableReference d() {
        CloseableReference c10;
        do {
            d g10 = g();
            if (g10 == null) {
                return null;
            }
            c10 = this.f13103b.c(g10);
        } while (c10 == null);
        return c10;
    }

    public synchronized void f(d dVar, boolean z10) {
        if (z10) {
            this.f13105d.add(dVar);
        } else {
            this.f13105d.remove(dVar);
        }
    }
}
