package g8;

import android.graphics.Rect;
import e8.a;
import e8.e;

public interface b {
    a a(e eVar, Rect rect);
}
