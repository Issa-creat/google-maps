package g8;

import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Rect;
import e8.b;
import e8.c;
import e8.d;
import e8.e;

public class a implements e8.a {

    /* renamed from: a  reason: collision with root package name */
    private final h8.a f13090a;

    /* renamed from: b  reason: collision with root package name */
    private final e f13091b;

    /* renamed from: c  reason: collision with root package name */
    private final c f13092c;

    /* renamed from: d  reason: collision with root package name */
    private final Rect f13093d;

    /* renamed from: e  reason: collision with root package name */
    private final int[] f13094e;

    /* renamed from: f  reason: collision with root package name */
    private final int[] f13095f;

    /* renamed from: g  reason: collision with root package name */
    private final int f13096g;

    /* renamed from: h  reason: collision with root package name */
    private final b[] f13097h;

    /* renamed from: i  reason: collision with root package name */
    private final Rect f13098i = new Rect();

    /* renamed from: j  reason: collision with root package name */
    private final Rect f13099j = new Rect();

    /* renamed from: k  reason: collision with root package name */
    private final boolean f13100k;

    /* renamed from: l  reason: collision with root package name */
    private Bitmap f13101l;

    public a(h8.a aVar, e eVar, Rect rect, boolean z10) {
        this.f13090a = aVar;
        this.f13091b = eVar;
        c d10 = eVar.d();
        this.f13092c = d10;
        int[] C = d10.C();
        this.f13094e = C;
        aVar.a(C);
        this.f13096g = aVar.c(C);
        this.f13095f = aVar.b(C);
        this.f13093d = k(d10, rect);
        this.f13100k = z10;
        this.f13097h = new b[d10.a()];
        for (int i10 = 0; i10 < this.f13092c.a(); i10++) {
            this.f13097h[i10] = this.f13092c.c(i10);
        }
    }

    private synchronized void j() {
        Bitmap bitmap = this.f13101l;
        if (bitmap != null) {
            bitmap.recycle();
            this.f13101l = null;
        }
    }

    private static Rect k(c cVar, Rect rect) {
        if (rect == null) {
            return new Rect(0, 0, cVar.getWidth(), cVar.getHeight());
        }
        return new Rect(0, 0, Math.min(rect.width(), cVar.getWidth()), Math.min(rect.height(), cVar.getHeight()));
    }

    private synchronized Bitmap l(int i10, int i11) {
        Bitmap bitmap = this.f13101l;
        if (bitmap != null && (bitmap.getWidth() < i10 || this.f13101l.getHeight() < i11)) {
            j();
        }
        if (this.f13101l == null) {
            this.f13101l = Bitmap.createBitmap(i10, i11, Bitmap.Config.ARGB_8888);
        }
        this.f13101l.eraseColor(0);
        return this.f13101l;
    }

    private void m(Canvas canvas, d dVar) {
        int i10;
        int i11;
        int i12;
        int i13;
        if (this.f13100k) {
            float max = Math.max(((float) dVar.getWidth()) / ((float) Math.min(dVar.getWidth(), canvas.getWidth())), ((float) dVar.getHeight()) / ((float) Math.min(dVar.getHeight(), canvas.getHeight())));
            i12 = (int) (((float) dVar.getWidth()) / max);
            i11 = (int) (((float) dVar.getHeight()) / max);
            i10 = (int) (((float) dVar.c()) / max);
            i13 = (int) (((float) dVar.d()) / max);
        } else {
            i12 = dVar.getWidth();
            i11 = dVar.getHeight();
            i10 = dVar.c();
            i13 = dVar.d();
        }
        synchronized (this) {
            Bitmap l10 = l(i12, i11);
            this.f13101l = l10;
            dVar.a(i12, i11, l10);
            canvas.save();
            canvas.translate((float) i10, (float) i13);
            canvas.drawBitmap(this.f13101l, 0.0f, 0.0f, (Paint) null);
            canvas.restore();
        }
    }

    private void n(Canvas canvas, d dVar) {
        double width = ((double) this.f13093d.width()) / ((double) this.f13092c.getWidth());
        double height = ((double) this.f13093d.height()) / ((double) this.f13092c.getHeight());
        int round = (int) Math.round(((double) dVar.getWidth()) * width);
        int round2 = (int) Math.round(((double) dVar.getHeight()) * height);
        int c10 = (int) (((double) dVar.c()) * width);
        int d10 = (int) (((double) dVar.d()) * height);
        synchronized (this) {
            int width2 = this.f13093d.width();
            int height2 = this.f13093d.height();
            l(width2, height2);
            Bitmap bitmap = this.f13101l;
            if (bitmap != null) {
                dVar.a(round, round2, bitmap);
            }
            this.f13098i.set(0, 0, width2, height2);
            this.f13099j.set(c10, d10, width2 + c10, height2 + d10);
            Bitmap bitmap2 = this.f13101l;
            if (bitmap2 != null) {
                canvas.drawBitmap(bitmap2, this.f13098i, this.f13099j, (Paint) null);
            }
        }
    }

    public int a() {
        return this.f13092c.a();
    }

    public int b() {
        return this.f13092c.b();
    }

    public b c(int i10) {
        return this.f13097h[i10];
    }

    public void d(int i10, Canvas canvas) {
        d A = this.f13092c.A(i10);
        try {
            if (A.getWidth() > 0) {
                if (A.getHeight() > 0) {
                    if (this.f13092c.B()) {
                        n(canvas, A);
                    } else {
                        m(canvas, A);
                    }
                    A.b();
                }
            }
        } finally {
            A.b();
        }
    }

    public int e(int i10) {
        return this.f13094e[i10];
    }

    public e8.a f(Rect rect) {
        if (k(this.f13092c, rect).equals(this.f13093d)) {
            return this;
        }
        return new a(this.f13090a, this.f13091b, rect, this.f13100k);
    }

    public int g() {
        return this.f13093d.height();
    }

    public int getHeight() {
        return this.f13092c.getHeight();
    }

    public int getWidth() {
        return this.f13092c.getWidth();
    }

    public int h() {
        return this.f13093d.width();
    }

    public e i() {
        return this.f13091b;
    }
}
