package h7;

import a8.b;
import a8.e;
import a8.h;
import a8.i;
import a8.l;
import android.os.Handler;
import android.os.HandlerThread;
import android.os.Looper;
import android.os.Message;
import java.io.Closeable;
import p6.k;
import p6.n;
import w6.b;

public class a extends a8.a implements Closeable {
    private static C0183a B;
    private h A = null;

    /* renamed from: w  reason: collision with root package name */
    private final b f13826w;

    /* renamed from: x  reason: collision with root package name */
    private final i f13827x;

    /* renamed from: y  reason: collision with root package name */
    private final h f13828y;

    /* renamed from: z  reason: collision with root package name */
    private final n f13829z;

    /* renamed from: h7.a$a  reason: collision with other inner class name */
    static class C0183a extends Handler {

        /* renamed from: a  reason: collision with root package name */
        private final h f13830a;

        /* renamed from: b  reason: collision with root package name */
        private h f13831b;

        public C0183a(Looper looper, h hVar, h hVar2) {
            super(looper);
            this.f13830a = hVar;
            this.f13831b = hVar2;
        }

        public void handleMessage(Message message) {
            i iVar = (i) k.g(message.obj);
            h hVar = this.f13831b;
            int i10 = message.what;
            if (i10 == 1) {
                e a10 = e.f265w.a(message.arg1);
                if (a10 != null) {
                    this.f13830a.b(iVar, a10);
                    if (hVar != null) {
                        hVar.b(iVar, a10);
                        return;
                    }
                    return;
                }
                throw new IllegalArgumentException("Invalid ImageLoadStatus value: " + message.arg1);
            } else if (i10 == 2) {
                l a11 = l.f314w.a(message.arg1);
                if (a11 != null) {
                    this.f13830a.a(iVar, a11);
                    if (hVar != null) {
                        hVar.a(iVar, a11);
                        return;
                    }
                    return;
                }
                throw new IllegalArgumentException("Invalid VisibilityState value: " + message.arg1);
            }
        }
    }

    public a(b bVar, i iVar, h hVar, n nVar) {
        this.f13826w = bVar;
        this.f13827x = iVar;
        this.f13828y = hVar;
        this.f13829z = nVar;
    }

    private boolean A() {
        boolean booleanValue = ((Boolean) this.f13829z.get()).booleanValue();
        if (booleanValue && B == null) {
            i();
        }
        return booleanValue;
    }

    private void B(i iVar, e eVar) {
        iVar.n(eVar);
        if (A()) {
            Message obtainMessage = ((C0183a) k.g(B)).obtainMessage();
            obtainMessage.what = 1;
            obtainMessage.arg1 = eVar.c();
            obtainMessage.obj = iVar;
            B.sendMessage(obtainMessage);
            return;
        }
        this.f13828y.b(iVar, eVar);
        h hVar = this.A;
        if (hVar != null) {
            hVar.b(iVar, eVar);
        }
    }

    private void G(i iVar, l lVar) {
        if (A()) {
            Message obtainMessage = ((C0183a) k.g(B)).obtainMessage();
            obtainMessage.what = 2;
            obtainMessage.arg1 = lVar.c();
            obtainMessage.obj = iVar;
            B.sendMessage(obtainMessage);
            return;
        }
        this.f13828y.a(iVar, lVar);
        h hVar = this.A;
        if (hVar != null) {
            hVar.a(iVar, lVar);
        }
    }

    private synchronized void i() {
        if (B == null) {
            HandlerThread handlerThread = new HandlerThread("ImagePerfControllerListener2Thread");
            handlerThread.start();
            B = new C0183a((Looper) k.g(handlerThread.getLooper()), this.f13828y, this.A);
        }
    }

    private void o(i iVar, long j10) {
        iVar.x(false);
        iVar.r(j10);
        G(iVar, l.INVISIBLE);
    }

    public void b(String str, b.a aVar) {
        long now = this.f13826w.now();
        i iVar = this.f13827x;
        iVar.l(aVar);
        iVar.h(str);
        e a10 = iVar.a();
        if (!(a10 == e.SUCCESS || a10 == e.ERROR || a10 == e.DRAW)) {
            iVar.e(now);
            B(iVar, e.CANCELED);
        }
        o(iVar, now);
    }

    public void c(String str, Throwable th2, b.a aVar) {
        long now = this.f13826w.now();
        i iVar = this.f13827x;
        iVar.l(aVar);
        iVar.f(now);
        iVar.h(str);
        iVar.k(th2);
        B(iVar, e.ERROR);
        o(iVar, now);
    }

    public void close() {
        x();
    }

    public void e(String str, Object obj, b.a aVar) {
        long now = this.f13826w.now();
        i iVar = this.f13827x;
        iVar.c();
        iVar.j(now);
        iVar.h(str);
        iVar.d(obj);
        iVar.l(aVar);
        B(iVar, e.REQUESTED);
        u(iVar, now);
    }

    /* renamed from: k */
    public void d(String str, r8.k kVar, b.a aVar) {
        long now = this.f13826w.now();
        i iVar = this.f13827x;
        iVar.l(aVar);
        iVar.g(now);
        iVar.p(now);
        iVar.h(str);
        iVar.m(kVar);
        B(iVar, e.SUCCESS);
    }

    /* renamed from: n */
    public void a(String str, r8.k kVar) {
        long now = this.f13826w.now();
        i iVar = this.f13827x;
        iVar.i(now);
        iVar.h(str);
        iVar.m(kVar);
        B(iVar, e.INTERMEDIATE_AVAILABLE);
    }

    public void u(i iVar, long j10) {
        iVar.x(true);
        iVar.w(j10);
        G(iVar, l.VISIBLE);
    }

    public void x() {
        this.f13827x.b();
    }
}
