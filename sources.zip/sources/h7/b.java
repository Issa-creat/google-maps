package h7;

import a8.i;
import t8.a;

public class b extends a {

    /* renamed from: a  reason: collision with root package name */
    private final w6.b f13832a;

    /* renamed from: b  reason: collision with root package name */
    private final i f13833b;

    public b(w6.b bVar, i iVar) {
        this.f13832a = bVar;
        this.f13833b = iVar;
    }

    public void a(x8.b bVar, String str, Throwable th2, boolean z10) {
        this.f13833b.p(this.f13832a.now());
        this.f13833b.o(bVar);
        this.f13833b.v(str);
        this.f13833b.u(z10);
    }

    public void b(x8.b bVar, Object obj, String str, boolean z10) {
        this.f13833b.q(this.f13832a.now());
        this.f13833b.o(bVar);
        this.f13833b.d(obj);
        this.f13833b.v(str);
        this.f13833b.u(z10);
    }

    public void g(x8.b bVar, String str, boolean z10) {
        this.f13833b.p(this.f13832a.now());
        this.f13833b.o(bVar);
        this.f13833b.v(str);
        this.f13833b.u(z10);
    }

    public void k(String str) {
        this.f13833b.p(this.f13832a.now());
        this.f13833b.v(str);
    }
}
