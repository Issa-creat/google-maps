package g;

public interface b {
    void a(Object obj);
}
