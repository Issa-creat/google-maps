package g;

public interface f {
    e getActivityResultRegistry();
}
