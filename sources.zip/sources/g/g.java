package g;

import ak.k;
import android.content.Intent;
import android.content.IntentSender;
import android.os.Parcel;
import android.os.Parcelable;
import kotlin.jvm.internal.DefaultConstructorMarker;

public final class g implements Parcelable {
    public static final Parcelable.Creator<g> CREATOR = new b();

    /* renamed from: z  reason: collision with root package name */
    public static final c f12886z = new c((DefaultConstructorMarker) null);

    /* renamed from: a  reason: collision with root package name */
    private final IntentSender f12887a;

    /* renamed from: w  reason: collision with root package name */
    private final Intent f12888w;

    /* renamed from: x  reason: collision with root package name */
    private final int f12889x;

    /* renamed from: y  reason: collision with root package name */
    private final int f12890y;

    public static final class a {

        /* renamed from: a  reason: collision with root package name */
        private final IntentSender f12891a;

        /* renamed from: b  reason: collision with root package name */
        private Intent f12892b;

        /* renamed from: c  reason: collision with root package name */
        private int f12893c;

        /* renamed from: d  reason: collision with root package name */
        private int f12894d;

        public a(IntentSender intentSender) {
            k.f(intentSender, "intentSender");
            this.f12891a = intentSender;
        }

        public final g a() {
            return new g(this.f12891a, this.f12892b, this.f12893c, this.f12894d);
        }

        public final a b(Intent intent) {
            this.f12892b = intent;
            return this;
        }

        public final a c(int i10, int i11) {
            this.f12894d = i10;
            this.f12893c = i11;
            return this;
        }
    }

    public static final class b implements Parcelable.Creator {
        b() {
        }

        /* renamed from: a */
        public g createFromParcel(Parcel parcel) {
            k.f(parcel, "inParcel");
            return new g(parcel);
        }

        /* renamed from: b */
        public g[] newArray(int i10) {
            return new g[i10];
        }
    }

    public static final class c {
        private c() {
        }

        public /* synthetic */ c(DefaultConstructorMarker defaultConstructorMarker) {
            this();
        }
    }

    public g(IntentSender intentSender, Intent intent, int i10, int i11) {
        k.f(intentSender, "intentSender");
        this.f12887a = intentSender;
        this.f12888w = intent;
        this.f12889x = i10;
        this.f12890y = i11;
    }

    public final Intent a() {
        return this.f12888w;
    }

    public final int b() {
        return this.f12889x;
    }

    public final int c() {
        return this.f12890y;
    }

    public final IntentSender d() {
        return this.f12887a;
    }

    public int describeContents() {
        return 0;
    }

    public void writeToParcel(Parcel parcel, int i10) {
        k.f(parcel, "dest");
        parcel.writeParcelable(this.f12887a, i10);
        parcel.writeParcelable(this.f12888w, i10);
        parcel.writeInt(this.f12889x);
        parcel.writeInt(this.f12890y);
    }

    /* JADX WARNING: Illegal instructions before constructor call */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public g(android.os.Parcel r4) {
        /*
            r3 = this;
            java.lang.String r0 = "parcel"
            ak.k.f(r4, r0)
            java.lang.Class<android.content.IntentSender> r0 = android.content.IntentSender.class
            java.lang.ClassLoader r0 = r0.getClassLoader()
            android.os.Parcelable r0 = r4.readParcelable(r0)
            ak.k.c(r0)
            android.content.IntentSender r0 = (android.content.IntentSender) r0
            java.lang.Class<android.content.Intent> r1 = android.content.Intent.class
            java.lang.ClassLoader r1 = r1.getClassLoader()
            android.os.Parcelable r1 = r4.readParcelable(r1)
            android.content.Intent r1 = (android.content.Intent) r1
            int r2 = r4.readInt()
            int r4 = r4.readInt()
            r3.<init>(r0, r1, r2, r4)
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: g.g.<init>(android.os.Parcel):void");
    }
}
