package g;

public abstract class c {
    public void a(Object obj) {
        b(obj, (androidx.core.app.c) null);
    }

    public abstract void b(Object obj, androidx.core.app.c cVar);

    public abstract void c();
}
