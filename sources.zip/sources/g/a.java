package g;

import ak.k;
import android.content.Intent;
import android.os.Parcel;
import android.os.Parcelable;
import kotlin.jvm.internal.DefaultConstructorMarker;

public final class a implements Parcelable {
    public static final Parcelable.Creator<a> CREATOR = new C0178a();

    /* renamed from: x  reason: collision with root package name */
    public static final b f12860x = new b((DefaultConstructorMarker) null);

    /* renamed from: a  reason: collision with root package name */
    private final int f12861a;

    /* renamed from: w  reason: collision with root package name */
    private final Intent f12862w;

    /* renamed from: g.a$a  reason: collision with other inner class name */
    public static final class C0178a implements Parcelable.Creator {
        C0178a() {
        }

        /* renamed from: a */
        public a createFromParcel(Parcel parcel) {
            k.f(parcel, "parcel");
            return new a(parcel);
        }

        /* renamed from: b */
        public a[] newArray(int i10) {
            return new a[i10];
        }
    }

    public static final class b {
        private b() {
        }

        public /* synthetic */ b(DefaultConstructorMarker defaultConstructorMarker) {
            this();
        }

        public final String a(int i10) {
            if (i10 == -1) {
                return "RESULT_OK";
            }
            if (i10 != 0) {
                return String.valueOf(i10);
            }
            return "RESULT_CANCELED";
        }
    }

    public a(int i10, Intent intent) {
        this.f12861a = i10;
        this.f12862w = intent;
    }

    public final Intent a() {
        return this.f12862w;
    }

    public final int b() {
        return this.f12861a;
    }

    public int describeContents() {
        return 0;
    }

    public String toString() {
        return "ActivityResult{resultCode=" + f12860x.a(this.f12861a) + ", data=" + this.f12862w + '}';
    }

    public void writeToParcel(Parcel parcel, int i10) {
        int i11;
        k.f(parcel, "dest");
        parcel.writeInt(this.f12861a);
        if (this.f12862w == null) {
            i11 = 0;
        } else {
            i11 = 1;
        }
        parcel.writeInt(i11);
        Intent intent = this.f12862w;
        if (intent != null) {
            intent.writeToParcel(parcel, i10);
        }
    }

    /* JADX INFO: this call moved to the top of the method (can break code semantics) */
    public a(Parcel parcel) {
        this(parcel.readInt(), parcel.readInt() == 0 ? null : (Intent) Intent.CREATOR.createFromParcel(parcel));
        k.f(parcel, "parcel");
    }
}
