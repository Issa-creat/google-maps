package g;

import androidx.lifecycle.i;
import androidx.lifecycle.m;
import androidx.lifecycle.o;
import h.a;

public final /* synthetic */ class d implements m {

    /* renamed from: a  reason: collision with root package name */
    public final /* synthetic */ e f12863a;

    /* renamed from: w  reason: collision with root package name */
    public final /* synthetic */ String f12864w;

    /* renamed from: x  reason: collision with root package name */
    public final /* synthetic */ b f12865x;

    /* renamed from: y  reason: collision with root package name */
    public final /* synthetic */ a f12866y;

    public /* synthetic */ d(e eVar, String str, b bVar, a aVar) {
        this.f12863a = eVar;
        this.f12864w = str;
        this.f12865x = bVar;
        this.f12866y = aVar;
    }

    public final void c(o oVar, i.a aVar) {
        e.n(this.f12863a, this.f12864w, this.f12865x, this.f12866y, oVar, aVar);
    }
}
