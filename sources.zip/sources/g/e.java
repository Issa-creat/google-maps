package g;

import ak.k;
import ak.l;
import ak.w;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import androidx.lifecycle.i;
import androidx.lifecycle.m;
import androidx.lifecycle.o;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.NoSuchElementException;
import kotlin.jvm.internal.DefaultConstructorMarker;

public abstract class e {

    /* renamed from: h  reason: collision with root package name */
    private static final b f12867h = new b((DefaultConstructorMarker) null);

    /* renamed from: a  reason: collision with root package name */
    private final Map f12868a = new LinkedHashMap();
    /* access modifiers changed from: private */

    /* renamed from: b  reason: collision with root package name */
    public final Map f12869b = new LinkedHashMap();

    /* renamed from: c  reason: collision with root package name */
    private final Map f12870c = new LinkedHashMap();
    /* access modifiers changed from: private */

    /* renamed from: d  reason: collision with root package name */
    public final List f12871d = new ArrayList();

    /* renamed from: e  reason: collision with root package name */
    private final transient Map f12872e = new LinkedHashMap();

    /* renamed from: f  reason: collision with root package name */
    private final Map f12873f = new LinkedHashMap();

    /* renamed from: g  reason: collision with root package name */
    private final Bundle f12874g = new Bundle();

    private static final class a {

        /* renamed from: a  reason: collision with root package name */
        private final b f12875a;

        /* renamed from: b  reason: collision with root package name */
        private final h.a f12876b;

        public a(b bVar, h.a aVar) {
            k.f(bVar, "callback");
            k.f(aVar, "contract");
            this.f12875a = bVar;
            this.f12876b = aVar;
        }

        public final b a() {
            return this.f12875a;
        }

        public final h.a b() {
            return this.f12876b;
        }
    }

    private static final class b {
        private b() {
        }

        public /* synthetic */ b(DefaultConstructorMarker defaultConstructorMarker) {
            this();
        }
    }

    private static final class c {

        /* renamed from: a  reason: collision with root package name */
        private final i f12877a;

        /* renamed from: b  reason: collision with root package name */
        private final List f12878b = new ArrayList();

        public c(i iVar) {
            k.f(iVar, "lifecycle");
            this.f12877a = iVar;
        }

        public final void a(m mVar) {
            k.f(mVar, "observer");
            this.f12877a.a(mVar);
            this.f12878b.add(mVar);
        }

        public final void b() {
            for (m c10 : this.f12878b) {
                this.f12877a.c(c10);
            }
            this.f12878b.clear();
        }
    }

    static final class d extends l implements zj.a {

        /* renamed from: a  reason: collision with root package name */
        public static final d f12879a = new d();

        d() {
            super(0);
        }

        /* renamed from: a */
        public final Integer invoke() {
            return Integer.valueOf(dk.c.f45454a.c(2147418112) + 65536);
        }
    }

    /* renamed from: g.e$e  reason: collision with other inner class name */
    public static final class C0179e extends c {

        /* renamed from: a  reason: collision with root package name */
        final /* synthetic */ e f12880a;

        /* renamed from: b  reason: collision with root package name */
        final /* synthetic */ String f12881b;

        /* renamed from: c  reason: collision with root package name */
        final /* synthetic */ h.a f12882c;

        C0179e(e eVar, String str, h.a aVar) {
            this.f12880a = eVar;
            this.f12881b = str;
            this.f12882c = aVar;
        }

        public void b(Object obj, androidx.core.app.c cVar) {
            Object obj2 = this.f12880a.f12869b.get(this.f12881b);
            h.a aVar = this.f12882c;
            if (obj2 != null) {
                int intValue = ((Number) obj2).intValue();
                this.f12880a.f12871d.add(this.f12881b);
                try {
                    this.f12880a.i(intValue, this.f12882c, obj, cVar);
                } catch (Exception e10) {
                    this.f12880a.f12871d.remove(this.f12881b);
                    throw e10;
                }
            } else {
                throw new IllegalStateException(("Attempting to launch an unregistered ActivityResultLauncher with contract " + aVar + " and input " + obj + ". You must ensure the ActivityResultLauncher is registered before calling launch().").toString());
            }
        }

        public void c() {
            this.f12880a.p(this.f12881b);
        }
    }

    public static final class f extends c {

        /* renamed from: a  reason: collision with root package name */
        final /* synthetic */ e f12883a;

        /* renamed from: b  reason: collision with root package name */
        final /* synthetic */ String f12884b;

        /* renamed from: c  reason: collision with root package name */
        final /* synthetic */ h.a f12885c;

        f(e eVar, String str, h.a aVar) {
            this.f12883a = eVar;
            this.f12884b = str;
            this.f12885c = aVar;
        }

        public void b(Object obj, androidx.core.app.c cVar) {
            Object obj2 = this.f12883a.f12869b.get(this.f12884b);
            h.a aVar = this.f12885c;
            if (obj2 != null) {
                int intValue = ((Number) obj2).intValue();
                this.f12883a.f12871d.add(this.f12884b);
                try {
                    this.f12883a.i(intValue, this.f12885c, obj, cVar);
                } catch (Exception e10) {
                    this.f12883a.f12871d.remove(this.f12884b);
                    throw e10;
                }
            } else {
                throw new IllegalStateException(("Attempting to launch an unregistered ActivityResultLauncher with contract " + aVar + " and input " + obj + ". You must ensure the ActivityResultLauncher is registered before calling launch().").toString());
            }
        }

        public void c() {
            this.f12883a.p(this.f12884b);
        }
    }

    private final void d(int i10, String str) {
        this.f12868a.put(Integer.valueOf(i10), str);
        this.f12869b.put(str, Integer.valueOf(i10));
    }

    private final void g(String str, int i10, Intent intent, a aVar) {
        b bVar;
        if (aVar != null) {
            bVar = aVar.a();
        } else {
            bVar = null;
        }
        if (bVar == null || !this.f12871d.contains(str)) {
            this.f12873f.remove(str);
            this.f12874g.putParcelable(str, new a(i10, intent));
            return;
        }
        aVar.a().a(aVar.b().c(i10, intent));
        this.f12871d.remove(str);
    }

    private final int h() {
        for (Number number : k.e(d.f12879a)) {
            if (!this.f12868a.containsKey(Integer.valueOf(number.intValue()))) {
                return number.intValue();
            }
        }
        throw new NoSuchElementException("Sequence contains no element matching the predicate.");
    }

    /* access modifiers changed from: private */
    public static final void n(e eVar, String str, b bVar, h.a aVar, o oVar, i.a aVar2) {
        k.f(eVar, "this$0");
        k.f(str, "$key");
        k.f(bVar, "$callback");
        k.f(aVar, "$contract");
        k.f(oVar, "<anonymous parameter 0>");
        k.f(aVar2, "event");
        if (i.a.ON_START == aVar2) {
            eVar.f12872e.put(str, new a(bVar, aVar));
            if (eVar.f12873f.containsKey(str)) {
                Object obj = eVar.f12873f.get(str);
                eVar.f12873f.remove(str);
                bVar.a(obj);
            }
            a aVar3 = (a) androidx.core.os.c.a(eVar.f12874g, str, a.class);
            if (aVar3 != null) {
                eVar.f12874g.remove(str);
                bVar.a(aVar.c(aVar3.b(), aVar3.a()));
            }
        } else if (i.a.ON_STOP == aVar2) {
            eVar.f12872e.remove(str);
        } else if (i.a.ON_DESTROY == aVar2) {
            eVar.p(str);
        }
    }

    private final void o(String str) {
        if (((Integer) this.f12869b.get(str)) == null) {
            d(h(), str);
        }
    }

    public final boolean e(int i10, int i11, Intent intent) {
        String str = (String) this.f12868a.get(Integer.valueOf(i10));
        if (str == null) {
            return false;
        }
        g(str, i11, intent, (a) this.f12872e.get(str));
        return true;
    }

    public final boolean f(int i10, Object obj) {
        b bVar;
        String str = (String) this.f12868a.get(Integer.valueOf(i10));
        if (str == null) {
            return false;
        }
        a aVar = (a) this.f12872e.get(str);
        if (aVar != null) {
            bVar = aVar.a();
        } else {
            bVar = null;
        }
        if (bVar == null) {
            this.f12874g.remove(str);
            this.f12873f.put(str, obj);
            return true;
        }
        b a10 = aVar.a();
        k.d(a10, "null cannot be cast to non-null type androidx.activity.result.ActivityResultCallback<O of androidx.activity.result.ActivityResultRegistry.dispatchResult>");
        if (!this.f12871d.remove(str)) {
            return true;
        }
        a10.a(obj);
        return true;
    }

    public abstract void i(int i10, h.a aVar, Object obj, androidx.core.app.c cVar);

    public final void j(Bundle bundle) {
        if (bundle != null) {
            ArrayList<Integer> integerArrayList = bundle.getIntegerArrayList("KEY_COMPONENT_ACTIVITY_REGISTERED_RCS");
            ArrayList<String> stringArrayList = bundle.getStringArrayList("KEY_COMPONENT_ACTIVITY_REGISTERED_KEYS");
            if (stringArrayList != null && integerArrayList != null) {
                ArrayList<String> stringArrayList2 = bundle.getStringArrayList("KEY_COMPONENT_ACTIVITY_LAUNCHED_KEYS");
                if (stringArrayList2 != null) {
                    this.f12871d.addAll(stringArrayList2);
                }
                Bundle bundle2 = bundle.getBundle("KEY_COMPONENT_ACTIVITY_PENDING_RESULT");
                if (bundle2 != null) {
                    this.f12874g.putAll(bundle2);
                }
                int size = stringArrayList.size();
                for (int i10 = 0; i10 < size; i10++) {
                    String str = stringArrayList.get(i10);
                    if (this.f12869b.containsKey(str)) {
                        Integer num = (Integer) this.f12869b.remove(str);
                        if (!this.f12874g.containsKey(str)) {
                            w.d(this.f12868a).remove(num);
                        }
                    }
                    Integer num2 = integerArrayList.get(i10);
                    k.e(num2, "rcs[i]");
                    int intValue = num2.intValue();
                    String str2 = stringArrayList.get(i10);
                    k.e(str2, "keys[i]");
                    d(intValue, str2);
                }
            }
        }
    }

    public final void k(Bundle bundle) {
        k.f(bundle, "outState");
        bundle.putIntegerArrayList("KEY_COMPONENT_ACTIVITY_REGISTERED_RCS", new ArrayList(this.f12869b.values()));
        bundle.putStringArrayList("KEY_COMPONENT_ACTIVITY_REGISTERED_KEYS", new ArrayList(this.f12869b.keySet()));
        bundle.putStringArrayList("KEY_COMPONENT_ACTIVITY_LAUNCHED_KEYS", new ArrayList(this.f12871d));
        bundle.putBundle("KEY_COMPONENT_ACTIVITY_PENDING_RESULT", new Bundle(this.f12874g));
    }

    public final c l(String str, o oVar, h.a aVar, b bVar) {
        k.f(str, "key");
        k.f(oVar, "lifecycleOwner");
        k.f(aVar, "contract");
        k.f(bVar, "callback");
        i lifecycle = oVar.getLifecycle();
        if (!lifecycle.b().b(i.b.STARTED)) {
            o(str);
            c cVar = (c) this.f12870c.get(str);
            if (cVar == null) {
                cVar = new c(lifecycle);
            }
            cVar.a(new d(this, str, bVar, aVar));
            this.f12870c.put(str, cVar);
            return new C0179e(this, str, aVar);
        }
        throw new IllegalStateException(("LifecycleOwner " + oVar + " is attempting to register while current state is " + lifecycle.b() + ". LifecycleOwners must call register before they are STARTED.").toString());
    }

    public final c m(String str, h.a aVar, b bVar) {
        k.f(str, "key");
        k.f(aVar, "contract");
        k.f(bVar, "callback");
        o(str);
        this.f12872e.put(str, new a(bVar, aVar));
        if (this.f12873f.containsKey(str)) {
            Object obj = this.f12873f.get(str);
            this.f12873f.remove(str);
            bVar.a(obj);
        }
        a aVar2 = (a) androidx.core.os.c.a(this.f12874g, str, a.class);
        if (aVar2 != null) {
            this.f12874g.remove(str);
            bVar.a(aVar.c(aVar2.b(), aVar2.a()));
        }
        return new f(this, str, aVar);
    }

    public final void p(String str) {
        Integer num;
        k.f(str, "key");
        if (!this.f12871d.contains(str) && (num = (Integer) this.f12869b.remove(str)) != null) {
            this.f12868a.remove(num);
        }
        this.f12872e.remove(str);
        if (this.f12873f.containsKey(str)) {
            Log.w("ActivityResultRegistry", "Dropping pending result for request " + str + ": " + this.f12873f.get(str));
            this.f12873f.remove(str);
        }
        if (this.f12874g.containsKey(str)) {
            Log.w("ActivityResultRegistry", "Dropping pending result for request " + str + ": " + ((a) androidx.core.os.c.a(this.f12874g, str, a.class)));
            this.f12874g.remove(str);
        }
        c cVar = (c) this.f12870c.get(str);
        if (cVar != null) {
            cVar.b();
            this.f12870c.remove(str);
        }
    }
}
