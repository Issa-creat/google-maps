package ld;

import android.view.View;
import com.google.android.material.bottomsheet.BottomSheetDragHandleView;
import g0.o0;

public final /* synthetic */ class a implements o0 {

    /* renamed from: a  reason: collision with root package name */
    public final /* synthetic */ BottomSheetDragHandleView f42714a;

    public /* synthetic */ a(BottomSheetDragHandleView bottomSheetDragHandleView) {
        this.f42714a = bottomSheetDragHandleView;
    }

    public final boolean a(View view, o0.a aVar) {
        return this.f42714a.j(view, aVar);
    }
}
