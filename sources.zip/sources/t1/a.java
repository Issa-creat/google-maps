package t1;

import y0.e0;

public interface a {

    /* renamed from: t1.a$a  reason: collision with other inner class name */
    public interface C0266a {
        a a(e0.b bVar);
    }
}
