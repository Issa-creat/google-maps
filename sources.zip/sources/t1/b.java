package t1;

import s1.h;

public abstract class b extends h {
}
