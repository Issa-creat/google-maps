package pa;

import java.util.ArrayList;
import java.util.List;

public abstract class b {

    /* renamed from: a  reason: collision with root package name */
    public static Boolean f16829a = Boolean.FALSE;

    public static abstract class a {
        public abstract a a(String str, int i10);

        public abstract a b(String str, Object obj);

        public abstract void c();
    }

    /* renamed from: pa.b$b  reason: collision with other inner class name */
    private static class C0243b extends a {

        /* renamed from: a  reason: collision with root package name */
        private long f16830a;

        public C0243b(long j10) {
            this.f16830a = j10;
        }

        public a a(String str, int i10) {
            return this;
        }

        public a b(String str, Object obj) {
            return this;
        }

        public void c() {
            a.g(this.f16830a);
        }
    }

    private static class c extends a {

        /* renamed from: a  reason: collision with root package name */
        private String f16831a;

        /* renamed from: b  reason: collision with root package name */
        private long f16832b;

        /* renamed from: c  reason: collision with root package name */
        private List f16833c = new ArrayList();

        public c(long j10, String str) {
            this.f16832b = j10;
            this.f16831a = str;
        }

        private void d(String str, String str2) {
            List list = this.f16833c;
            list.add(str + ": " + str2);
        }

        public a a(String str, int i10) {
            d(str, String.valueOf(i10));
            return this;
        }

        public a b(String str, Object obj) {
            d(str, String.valueOf(obj));
            return this;
        }

        public void c() {
            String str;
            long j10 = this.f16832b;
            StringBuilder sb2 = new StringBuilder();
            sb2.append(this.f16831a);
            if (!b.f16829a.booleanValue() || this.f16833c.size() <= 0) {
                str = "";
            } else {
                str = " (" + c.a(", ", this.f16833c) + ")";
            }
            sb2.append(str);
            a.c(j10, sb2.toString());
        }
    }

    public static a a(long j10, String str) {
        return new c(j10, str);
    }

    public static a b(long j10) {
        return new C0243b(j10);
    }
}
