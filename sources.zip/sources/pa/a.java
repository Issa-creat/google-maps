package pa;

import com.facebook.systrace.TraceListener;

public abstract class a {

    /* renamed from: pa.a$a  reason: collision with other inner class name */
    public enum C0242a {
        THREAD('t'),
        PROCESS('p'),
        GLOBAL('g');
        

        /* renamed from: a  reason: collision with root package name */
        private final char f16828a;

        private C0242a(char c10) {
            this.f16828a = c10;
        }
    }

    public static void a(long j10, String str, int i10) {
        a4.a.a(str, i10);
    }

    public static void b(long j10, String str, int i10, long j11) {
        a(j10, str, i10);
    }

    public static void c(long j10, String str) {
        a4.a.c(str);
    }

    public static void d(long j10, String str, int i10) {
        e(j10, str, i10);
    }

    public static void e(long j10, String str, int i10) {
        a4.a.d(str, i10);
    }

    public static void f(long j10, String str, int i10, long j11) {
        e(j10, str, i10);
    }

    public static void g(long j10) {
        a4.a.f();
    }

    public static boolean h(long j10) {
        return false;
    }

    public static void i(TraceListener traceListener) {
    }

    public static void j(long j10, String str, int i10) {
        a(j10, str, i10);
    }

    public static void k(long j10, String str, int i10) {
        a4.a.j(str, i10);
    }

    public static void l(long j10, String str, C0242a aVar) {
    }

    public static void m(TraceListener traceListener) {
    }
}
